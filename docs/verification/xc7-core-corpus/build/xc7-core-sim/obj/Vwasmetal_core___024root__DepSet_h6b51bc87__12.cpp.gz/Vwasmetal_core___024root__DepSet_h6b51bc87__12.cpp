#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

void Vwasmetal_core___024root___ico_sequent__TOP__0(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__1(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__2(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__3(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__4(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__5(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__6(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__7(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__8(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__9(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__10(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__11(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__12(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__13(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__14(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__15(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__16(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__17(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__18(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__19(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__20(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__21(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__22(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__23(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__24(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__25(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__26(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__27(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__28(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__29(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__30(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__31(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__32(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__33(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__34(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135426___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135071___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135070___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135069___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135075___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135074___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135073___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135072___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135068___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135064___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135067___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135066___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135065___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__35(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__36(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__37(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__38(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135070___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135074___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135066___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134221___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134229___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134226___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134223___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134220___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134228___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134225___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134222___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134227___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134224___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__39(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135071___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135075___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135067___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134229___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134226___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134223___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__40(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135068___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135072___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135064___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134227___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134224___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__41(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__42(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__43(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__44(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134221___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__45(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__46(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135196___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134230___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134231___0(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134232___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135195___0(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__47(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134231___1(Vwasmetal_core_DSP48E1__pi2* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134230___1(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__48(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135195___1(Vwasmetal_core_DSP48E1__pi1* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__49(Vwasmetal_core___024root* vlSelf);
void Vwasmetal_core___024root___ico_sequent__TOP__50(Vwasmetal_core___024root* vlSelf);

void Vwasmetal_core___024root___eval_ico(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___eval_ico\n"); );
    // Body
    if ((1ULL & vlSelf->__VicoTriggered.word(0U))) {
        Vwasmetal_core___024root___ico_sequent__TOP__0(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__1(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__2(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__3(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__4(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__5(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__6(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__7(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__8(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__9(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__10(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__11(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__12(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__13(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__14(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__15(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__16(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__17(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__18(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__19(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__20(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__21(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__22(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__23(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__24(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__25(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__26(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__27(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__28(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__29(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__30(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__31(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__32(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__33(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__34(vlSelf);
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135426___0((&vlSymsp->TOP__wasmetal_core__DOT___135426_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135071___0((&vlSymsp->TOP__wasmetal_core__DOT___135071_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135070___0((&vlSymsp->TOP__wasmetal_core__DOT___135070_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135069___0((&vlSymsp->TOP__wasmetal_core__DOT___135069_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135075___0((&vlSymsp->TOP__wasmetal_core__DOT___135075_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135074___0((&vlSymsp->TOP__wasmetal_core__DOT___135074_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135073___0((&vlSymsp->TOP__wasmetal_core__DOT___135073_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135072___0((&vlSymsp->TOP__wasmetal_core__DOT___135072_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135068___0((&vlSymsp->TOP__wasmetal_core__DOT___135068_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135064___0((&vlSymsp->TOP__wasmetal_core__DOT___135064_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135067___0((&vlSymsp->TOP__wasmetal_core__DOT___135067_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135066___0((&vlSymsp->TOP__wasmetal_core__DOT___135066_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135065___0((&vlSymsp->TOP__wasmetal_core__DOT___135065_));
        Vwasmetal_core___024root___ico_sequent__TOP__35(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__36(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__37(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__38(vlSelf);
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135070___1((&vlSymsp->TOP__wasmetal_core__DOT___135070_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135074___1((&vlSymsp->TOP__wasmetal_core__DOT___135074_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135066___1((&vlSymsp->TOP__wasmetal_core__DOT___135066_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134221___0((&vlSymsp->TOP__wasmetal_core__DOT___134221_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134229___0((&vlSymsp->TOP__wasmetal_core__DOT___134229_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134226___0((&vlSymsp->TOP__wasmetal_core__DOT___134226_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134223___0((&vlSymsp->TOP__wasmetal_core__DOT___134223_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134220___0((&vlSymsp->TOP__wasmetal_core__DOT___134220_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134228___0((&vlSymsp->TOP__wasmetal_core__DOT___134228_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134225___0((&vlSymsp->TOP__wasmetal_core__DOT___134225_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134222___0((&vlSymsp->TOP__wasmetal_core__DOT___134222_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134227___0((&vlSymsp->TOP__wasmetal_core__DOT___134227_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134224___0((&vlSymsp->TOP__wasmetal_core__DOT___134224_));
        Vwasmetal_core___024root___ico_sequent__TOP__39(vlSelf);
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135071___1((&vlSymsp->TOP__wasmetal_core__DOT___135071_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135075___1((&vlSymsp->TOP__wasmetal_core__DOT___135075_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135067___1((&vlSymsp->TOP__wasmetal_core__DOT___135067_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134229___1((&vlSymsp->TOP__wasmetal_core__DOT___134229_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134226___1((&vlSymsp->TOP__wasmetal_core__DOT___134226_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134223___1((&vlSymsp->TOP__wasmetal_core__DOT___134223_));
        Vwasmetal_core___024root___ico_sequent__TOP__40(vlSelf);
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135068___1((&vlSymsp->TOP__wasmetal_core__DOT___135068_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135072___1((&vlSymsp->TOP__wasmetal_core__DOT___135072_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___135064___1((&vlSymsp->TOP__wasmetal_core__DOT___135064_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134227___1((&vlSymsp->TOP__wasmetal_core__DOT___134227_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134224___1((&vlSymsp->TOP__wasmetal_core__DOT___134224_));
        Vwasmetal_core___024root___ico_sequent__TOP__41(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__42(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__43(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__44(vlSelf);
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134221___1((&vlSymsp->TOP__wasmetal_core__DOT___134221_));
        Vwasmetal_core___024root___ico_sequent__TOP__45(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__46(vlSelf);
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135196___0((&vlSymsp->TOP__wasmetal_core__DOT___135196_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134230___0((&vlSymsp->TOP__wasmetal_core__DOT___134230_));
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134231___0((&vlSymsp->TOP__wasmetal_core__DOT___134231_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134232___0((&vlSymsp->TOP__wasmetal_core__DOT___134232_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135195___0((&vlSymsp->TOP__wasmetal_core__DOT___135195_));
        Vwasmetal_core___024root___ico_sequent__TOP__47(vlSelf);
        Vwasmetal_core_DSP48E1__pi2___ico_sequent__TOP__wasmetal_core__DOT___134231___1((&vlSymsp->TOP__wasmetal_core__DOT___134231_));
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___134230___1((&vlSymsp->TOP__wasmetal_core__DOT___134230_));
        Vwasmetal_core___024root___ico_sequent__TOP__48(vlSelf);
        Vwasmetal_core_DSP48E1__pi1___ico_sequent__TOP__wasmetal_core__DOT___135195___1((&vlSymsp->TOP__wasmetal_core__DOT___135195_));
        Vwasmetal_core___024root___ico_sequent__TOP__49(vlSelf);
        Vwasmetal_core___024root___ico_sequent__TOP__50(vlSelf);
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vwasmetal_core___024root___dump_triggers__act(Vwasmetal_core___024root* vlSelf);
#endif  // VL_DEBUG

void Vwasmetal_core___024root___eval_triggers__act(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___eval_triggers__act\n"); );
    // Body
    vlSelf->__VactTriggered.set(0U, ((IData)(vlSelf->clk) 
                                     & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__clk__0))));
    vlSelf->__VactTriggered.set(1U, ((~ (IData)(vlSelf->clk)) 
                                     & (IData)(vlSelf->__Vtrigprevexpr___TOP__clk__0)));
    vlSelf->__VactTriggered.set(2U, (((IData)(vlSelf->clk) 
                                      & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__clk__0))) 
                                     | ((IData)(vlSelf->reset) 
                                        & (~ (IData)(vlSelf->__Vtrigprevexpr___TOP__reset__0)))));
    vlSelf->__Vtrigprevexpr___TOP__clk__0 = vlSelf->clk;
    vlSelf->__Vtrigprevexpr___TOP__reset__0 = vlSelf->reset;
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vwasmetal_core___024root___dump_triggers__act(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__1(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__1\n"); );
    // Body
    if (vlSelf->reset) {
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b31__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b30__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b29__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b28__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b27__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b26__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b25__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b24__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b23__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b22__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b21__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b20__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b19__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b18__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b17__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b16__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b15__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b14__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b13__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b12__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b11__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b10__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b9__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b8__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b7__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b6__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b5__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b4__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b3__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b2__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b1__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__fp__05b0__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b31__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b30__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b29__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b28__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b27__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b26__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b25__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b24__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b23__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b22__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b21__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b20__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b19__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b18__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b17__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b16__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b15__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b14__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b13__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b12__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b11__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b10__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b9__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b8__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b7__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b6__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b5__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b4__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b3__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b2__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b1__05d = 0U;
        vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128935___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128934___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128933___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128932___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128931___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128930___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128929___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128928___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128927___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128926___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128925___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128924___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128923___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128922___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128921___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128920___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128919___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128918___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128917___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128916___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128915___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128914___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128913___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128912___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128911___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128910___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128909___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128908___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128907___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128906___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128905___Q = 0U;
        vlSelf->wasmetal_core__DOT____Vcellout___128904___Q = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_next__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_next__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__expected_type__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_next__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b125__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b123__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b127__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b122__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b124__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b120__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_reference = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__load_width__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b12__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019782_) {
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b31__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x38U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b31__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b30__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                            >> 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b29__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x37U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b28__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x36U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b27__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x35U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b26__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x34U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b25__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x33U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b24__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x32U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b23__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x31U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b22__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x30U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b21__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                            >> 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b20__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2fU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b19__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2eU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b18__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2dU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b17__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2cU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b16__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2bU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b15__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x2aU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b14__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x29U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b13__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x28U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b12__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity) 
                                            >> 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b11__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x27U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b10__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x26U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b9__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x25U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b8__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x24U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b7__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x23U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b6__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x22U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b5__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x21U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b4__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x20U)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b3__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__parity)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b2__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x1fU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b1__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x1eU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d))))));
            vlSelf->__Vdly__wasmetal_core__DOT__fp__05b0__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(
                                                    (vlSymsp->TOP__wasmetal_core__DOT__frames_memory__02e0__02e0.__PVT__data 
                                                     >> 0x1dU)) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d))))));
        }
        if (vlSelf->wasmetal_core__DOT___019783_) {
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b31__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b31__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128146___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128041___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b30__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b30__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128146___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128041___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b29__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b29__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128146___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128041___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b28__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b28__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128146___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128505___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128041___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b27__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b27__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128145___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128040___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b26__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b26__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128145___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128040___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b25__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b25__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128145___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128040___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b24__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b24__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128145___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128504___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128040___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b23__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b23__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128144___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128039___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b22__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b22__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128144___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128039___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b21__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b21__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128144___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128039___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b20__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b20__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128144___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128503___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128039___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b19__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b19__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128143___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128038___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b18__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b18__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128143___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128038___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b17__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b17__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128143___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128038___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b16__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b16__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128143___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128502___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128038___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b15__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b15__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128142___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128037___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b14__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b14__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128142___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128037___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b13__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b13__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128142___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128037___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b12__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b12__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128142___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128501___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128037___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b11__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b11__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128141___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128036___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b10__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b10__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128141___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128036___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b9__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b9__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128141___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128036___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b8__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b8__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128141___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128500___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128036___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b7__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b7__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128140___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128035___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b6__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b6__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128140___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128035___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b5__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b5__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128140___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128035___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b4__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b4__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128140___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128499___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128035___O))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b3__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b3__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                         >> 1U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128139___O) 
                                                                            >> 2U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128034___O) 
                                                    >> 3U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b2__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b2__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128139___O) 
                                                                            >> 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128034___O) 
                                                    >> 2U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b1__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b1__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                         << 1U)) 
                                                                     | ((2U 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128139___O)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128034___O) 
                                                    >> 1U))))))));
            vlSelf->__Vdly__wasmetal_core__DOT__control_sp__05b0__05d 
                = (1U & (0xcfaf0f0fU >> (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (0x777000007770777ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___053539_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128139___O) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___046420_)))))))) 
                                                  << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128034___O))))))));
        }
        if (vlSelf->wasmetal_core__DOT___019790_) {
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b31__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b30__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b29__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b28__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128353___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b27__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b26__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b25__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b24__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128352___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128351___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128350___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b15__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b14__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b13__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b12__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128349___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b11__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b10__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b9__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b8__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128348___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b7__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b6__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b5__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128347___O));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b3__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                         >> 3U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b2__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                         >> 2U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d 
                = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O) 
                         >> 1U));
            vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d 
                = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128346___O));
        }
        if (vlSelf->wasmetal_core__DOT___019805_) {
            vlSelf->wasmetal_core__DOT____Vcellout___128935___Q 
                = vlSelf->wasmetal_core__DOT___022463_;
            vlSelf->wasmetal_core__DOT____Vcellout___128934___Q 
                = vlSelf->wasmetal_core__DOT___022462_;
            vlSelf->wasmetal_core__DOT____Vcellout___128933___Q 
                = vlSelf->wasmetal_core__DOT___022460_;
            vlSelf->wasmetal_core__DOT____Vcellout___128932___Q 
                = vlSelf->wasmetal_core__DOT___022459_;
            vlSelf->wasmetal_core__DOT____Vcellout___128931___Q 
                = vlSelf->wasmetal_core__DOT___022458_;
            vlSelf->wasmetal_core__DOT____Vcellout___128930___Q 
                = vlSelf->wasmetal_core__DOT___022457_;
            vlSelf->wasmetal_core__DOT____Vcellout___128929___Q 
                = vlSelf->wasmetal_core__DOT___022456_;
            vlSelf->wasmetal_core__DOT____Vcellout___128928___Q 
                = vlSelf->wasmetal_core__DOT___022455_;
            vlSelf->wasmetal_core__DOT____Vcellout___128927___Q 
                = vlSelf->wasmetal_core__DOT___022454_;
            vlSelf->wasmetal_core__DOT____Vcellout___128926___Q 
                = vlSelf->wasmetal_core__DOT___022453_;
            vlSelf->wasmetal_core__DOT____Vcellout___128925___Q 
                = vlSelf->wasmetal_core__DOT___022452_;
            vlSelf->wasmetal_core__DOT____Vcellout___128924___Q 
                = vlSelf->wasmetal_core__DOT___022451_;
            vlSelf->wasmetal_core__DOT____Vcellout___128923___Q 
                = vlSelf->wasmetal_core__DOT___022449_;
            vlSelf->wasmetal_core__DOT____Vcellout___128922___Q 
                = vlSelf->wasmetal_core__DOT___022448_;
            vlSelf->wasmetal_core__DOT____Vcellout___128921___Q 
                = vlSelf->wasmetal_core__DOT___022447_;
            vlSelf->wasmetal_core__DOT____Vcellout___128920___Q 
                = vlSelf->wasmetal_core__DOT___022446_;
            vlSelf->wasmetal_core__DOT____Vcellout___128919___Q 
                = vlSelf->wasmetal_core__DOT___022445_;
            vlSelf->wasmetal_core__DOT____Vcellout___128918___Q 
                = vlSelf->wasmetal_core__DOT___022444_;
            vlSelf->wasmetal_core__DOT____Vcellout___128917___Q 
                = vlSelf->wasmetal_core__DOT___022443_;
            vlSelf->wasmetal_core__DOT____Vcellout___128916___Q 
                = vlSelf->wasmetal_core__DOT___022442_;
            vlSelf->wasmetal_core__DOT____Vcellout___128915___Q 
                = vlSelf->wasmetal_core__DOT___022441_;
            vlSelf->wasmetal_core__DOT____Vcellout___128914___Q 
                = vlSelf->wasmetal_core__DOT___022440_;
            vlSelf->wasmetal_core__DOT____Vcellout___128913___Q 
                = vlSelf->wasmetal_core__DOT___022470_;
            vlSelf->wasmetal_core__DOT____Vcellout___128912___Q 
                = vlSelf->wasmetal_core__DOT___022469_;
            vlSelf->wasmetal_core__DOT____Vcellout___128911___Q 
                = vlSelf->wasmetal_core__DOT___022468_;
            vlSelf->wasmetal_core__DOT____Vcellout___128910___Q 
                = vlSelf->wasmetal_core__DOT___022467_;
            vlSelf->wasmetal_core__DOT____Vcellout___128909___Q 
                = vlSelf->wasmetal_core__DOT___022466_;
            vlSelf->wasmetal_core__DOT____Vcellout___128908___Q 
                = vlSelf->wasmetal_core__DOT___022465_;
            vlSelf->wasmetal_core__DOT____Vcellout___128907___Q 
                = vlSelf->wasmetal_core__DOT___022464_;
            vlSelf->wasmetal_core__DOT____Vcellout___128906___Q 
                = vlSelf->wasmetal_core__DOT___022461_;
            vlSelf->wasmetal_core__DOT____Vcellout___128905___Q 
                = vlSelf->wasmetal_core__DOT___022450_;
            vlSelf->wasmetal_core__DOT____Vcellout___128904___Q 
                = vlSelf->wasmetal_core__DOT___022439_;
        }
        if (vlSelf->wasmetal_core__DOT___019778_) {
            vlSelf->wasmetal_core__DOT__copy_next__05b0__05d = 1U;
            vlSelf->wasmetal_core__DOT__copy_next__05b3__05d 
                = vlSelf->wasmetal_core__DOT___046419_;
            vlSelf->wasmetal_core__DOT__copy_next__05b4__05d 
                = vlSelf->wasmetal_core__DOT___046420_;
            vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h218c78da__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h3feec5ff__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_hf708f436__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h5602457e__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128329___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128329___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_ha8d532c2__0))));
        }
        if (vlSelf->wasmetal_core__DOT___019775_) {
            vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d 
                = vlSelf->wasmetal_core__DOT___069605_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d 
                = vlSelf->wasmetal_core__DOT___069536_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d 
                = vlSelf->wasmetal_core__DOT___069413_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d 
                = vlSelf->wasmetal_core__DOT___070183_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d 
                = vlSelf->wasmetal_core__DOT___070169_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d 
                = vlSelf->wasmetal_core__DOT___069908_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b6__05d 
                = vlSelf->wasmetal_core__DOT___065400_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d 
                = vlSelf->wasmetal_core__DOT___069971_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d 
                = vlSelf->wasmetal_core__DOT___069362_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d 
                = vlSelf->wasmetal_core__DOT___068146_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d 
                = vlSelf->wasmetal_core__DOT___068469_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d 
                = vlSelf->wasmetal_core__DOT___068361_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d 
                = vlSelf->wasmetal_core__DOT___069489_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d 
                = vlSelf->wasmetal_core__DOT___069279_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d 
                = vlSelf->wasmetal_core__DOT___066637_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d 
                = vlSelf->wasmetal_core__DOT___069387_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d 
                = vlSelf->wasmetal_core__DOT___070412_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d 
                = vlSelf->wasmetal_core__DOT___070363_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d 
                = vlSelf->wasmetal_core__DOT___070310_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d 
                = vlSelf->wasmetal_core__DOT___070200_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d 
                = vlSelf->wasmetal_core__DOT___070142_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d 
                = vlSelf->wasmetal_core__DOT___070082_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d 
                = vlSelf->wasmetal_core__DOT___070009_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d 
                = vlSelf->wasmetal_core__DOT___069582_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b7__05d 
                = vlSelf->wasmetal_core__DOT___065506_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d 
                = vlSelf->wasmetal_core__DOT___070437_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d 
                = vlSelf->wasmetal_core__DOT___070424_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d 
                = vlSelf->wasmetal_core__DOT___070387_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d 
                = vlSelf->wasmetal_core__DOT___070230_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d 
                = vlSelf->wasmetal_core__DOT___069336_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d 
                = vlSelf->wasmetal_core__DOT___068714_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d 
                = vlSelf->wasmetal_core__DOT___067680_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d 
                = vlSelf->wasmetal_core__DOT___065049_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d 
                = vlSelf->wasmetal_core__DOT___064888_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d 
                = vlSelf->wasmetal_core__DOT___069627_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d 
                = vlSelf->wasmetal_core__DOT___069558_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d 
                = vlSelf->wasmetal_core__DOT___069512_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d 
                = vlSelf->wasmetal_core__DOT___069437_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d 
                = vlSelf->wasmetal_core__DOT___069311_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d 
                = vlSelf->wasmetal_core__DOT___070347_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d 
                = vlSelf->wasmetal_core__DOT___070323_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d 
                = vlSelf->wasmetal_core__DOT___070261_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d 
                = vlSelf->wasmetal_core__DOT___070156_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d 
                = vlSelf->wasmetal_core__DOT___070110_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d 
                = vlSelf->wasmetal_core__DOT___067915_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d 
                = vlSelf->wasmetal_core__DOT___067617_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d 
                = vlSelf->wasmetal_core__DOT___064460_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d 
                = vlSelf->wasmetal_core__DOT___070125_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d 
                = vlSelf->wasmetal_core__DOT___069846_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d 
                = vlSelf->wasmetal_core__DOT___069761_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d 
                = vlSelf->wasmetal_core__DOT___069671_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d 
                = vlSelf->wasmetal_core__DOT___069650_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d 
                = vlSelf->wasmetal_core__DOT___069466_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d 
                = vlSelf->wasmetal_core__DOT___068910_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d 
                = vlSelf->wasmetal_core__DOT___070449_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d 
                = vlSelf->wasmetal_core__DOT___070399_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d 
                = vlSelf->wasmetal_core__DOT___070375_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d 
                = vlSelf->wasmetal_core__DOT___070335_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d 
                = vlSelf->wasmetal_core__DOT___070297_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d 
                = vlSelf->wasmetal_core__DOT___070285_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d 
                = vlSelf->wasmetal_core__DOT___070273_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d 
                = vlSelf->wasmetal_core__DOT___070244_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d 
                = vlSelf->wasmetal_core__DOT___070215_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d 
                = vlSelf->wasmetal_core__DOT___070096_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d 
                = vlSelf->wasmetal_core__DOT___070066_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d 
                = vlSelf->wasmetal_core__DOT___070051_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d 
                = vlSelf->wasmetal_core__DOT___070032_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d 
                = vlSelf->wasmetal_core__DOT___069888_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d 
                = vlSelf->wasmetal_core__DOT___069867_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d 
                = vlSelf->wasmetal_core__DOT___069782_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d 
                = vlSelf->wasmetal_core__DOT___069739_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d 
                = vlSelf->wasmetal_core__DOT___069695_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d 
                = vlSelf->wasmetal_core__DOT___069252_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d 
                = vlSelf->wasmetal_core__DOT___069102_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d 
                = vlSelf->wasmetal_core__DOT___069058_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d 
                = vlSelf->wasmetal_core__DOT___068960_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d 
                = vlSelf->wasmetal_core__DOT___068814_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d 
                = vlSelf->wasmetal_core__DOT___068666_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d 
                = vlSelf->wasmetal_core__DOT___068566_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d 
                = vlSelf->wasmetal_core__DOT___068199_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d 
                = vlSelf->wasmetal_core__DOT___067807_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d 
                = vlSelf->wasmetal_core__DOT___067744_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d 
                = vlSelf->wasmetal_core__DOT___069929_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d 
                = vlSelf->wasmetal_core__DOT___068863_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d 
                = vlSelf->wasmetal_core__DOT___068763_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d 
                = vlSelf->wasmetal_core__DOT___069991_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d 
                = vlSelf->wasmetal_core__DOT___069826_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d 
                = vlSelf->wasmetal_core__DOT___069804_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d 
                = vlSelf->wasmetal_core__DOT___069717_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d 
                = vlSelf->wasmetal_core__DOT___068416_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d 
                = vlSelf->wasmetal_core__DOT___069202_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d 
                = vlSelf->wasmetal_core__DOT___069152_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d 
                = vlSelf->wasmetal_core__DOT___069009_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d 
                = vlSelf->wasmetal_core__DOT___068617_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d 
                = vlSelf->wasmetal_core__DOT___068307_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d 
                = vlSelf->wasmetal_core__DOT___067958_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d 
                = vlSelf->wasmetal_core__DOT___067859_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d 
                = vlSelf->wasmetal_core__DOT___067103_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d 
                = vlSelf->wasmetal_core__DOT___067029_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d 
                = vlSelf->wasmetal_core__DOT___068094_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d 
                = vlSelf->wasmetal_core__DOT___068515_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d 
                = vlSelf->wasmetal_core__DOT___068254_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d 
                = vlSelf->wasmetal_core__DOT___066474_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d 
                = vlSelf->wasmetal_core__DOT___066114_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b12__05d 
                = vlSelf->wasmetal_core__DOT___066011_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d 
                = vlSelf->wasmetal_core__DOT___068038_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d 
                = vlSelf->wasmetal_core__DOT___066389_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d 
                = vlSelf->wasmetal_core__DOT___066552_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d 
                = vlSelf->wasmetal_core__DOT___066803_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d 
                = vlSelf->wasmetal_core__DOT___066721_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d 
                = vlSelf->wasmetal_core__DOT___067404_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d 
                = vlSelf->wasmetal_core__DOT___067298_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d 
                = vlSelf->wasmetal_core__DOT___067542_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b11__05d 
                = vlSelf->wasmetal_core__DOT___065922_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d 
                = vlSelf->wasmetal_core__DOT___064721_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b22__05d 
                = vlSelf->wasmetal_core__DOT___066881_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d 
                = vlSelf->wasmetal_core__DOT___067473_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b8__05d 
                = vlSelf->wasmetal_core__DOT___065636_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d 
                = vlSelf->wasmetal_core__DOT___066961_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b4__05d 
                = vlSelf->wasmetal_core__DOT___065172_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b10__05d 
                = vlSelf->wasmetal_core__DOT___065832_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b9__05d 
                = vlSelf->wasmetal_core__DOT___065733_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d 
                = vlSelf->wasmetal_core__DOT___067261_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b5__05d 
                = vlSelf->wasmetal_core__DOT___065288_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d 
                = vlSelf->wasmetal_core__DOT___066303_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d 
                = vlSelf->wasmetal_core__DOT___067183_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b14__05d 
                = vlSelf->wasmetal_core__DOT___066210_;
            vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d 
                = vlSelf->wasmetal_core__DOT___069950_;
        }
        if (vlSelf->wasmetal_core__DOT___019798_) {
            vlSelf->wasmetal_core__DOT__query_index__05b7__05d 
                = (1U & (vlSelf->cmd_index >> 7U));
            vlSelf->wasmetal_core__DOT__query_index__05b6__05d 
                = (1U & (vlSelf->cmd_index >> 6U));
            vlSelf->wasmetal_core__DOT__query_index__05b29__05d 
                = (1U & (vlSelf->cmd_index >> 0x1dU));
            vlSelf->wasmetal_core__DOT__query_index__05b28__05d 
                = (1U & (vlSelf->cmd_index >> 0x1cU));
            vlSelf->wasmetal_core__DOT__query_index__05b25__05d 
                = (1U & (vlSelf->cmd_index >> 0x19U));
            vlSelf->wasmetal_core__DOT__query_index__05b22__05d 
                = (1U & (vlSelf->cmd_index >> 0x16U));
            vlSelf->wasmetal_core__DOT__query_index__05b11__05d 
                = (1U & (vlSelf->cmd_index >> 0xbU));
            vlSelf->wasmetal_core__DOT__query_index__05b9__05d 
                = (1U & (vlSelf->cmd_index >> 9U));
            vlSelf->wasmetal_core__DOT__query_index__05b8__05d 
                = (1U & (vlSelf->cmd_index >> 8U));
            vlSelf->wasmetal_core__DOT__query_index__05b24__05d 
                = (1U & (vlSelf->cmd_index >> 0x18U));
            vlSelf->wasmetal_core__DOT__query_index__05b10__05d 
                = (1U & (vlSelf->cmd_index >> 0xaU));
            vlSelf->wasmetal_core__DOT__query_index__05b31__05d 
                = (vlSelf->cmd_index >> 0x1fU);
            vlSelf->wasmetal_core__DOT__query_index__05b30__05d 
                = (1U & (vlSelf->cmd_index >> 0x1eU));
            vlSelf->wasmetal_core__DOT__query_index__05b21__05d 
                = (1U & (vlSelf->cmd_index >> 0x15U));
            vlSelf->wasmetal_core__DOT__query_index__05b20__05d 
                = (1U & (vlSelf->cmd_index >> 0x14U));
            vlSelf->wasmetal_core__DOT__query_index__05b23__05d 
                = (1U & (vlSelf->cmd_index >> 0x17U));
            vlSelf->wasmetal_core__DOT__query_index__05b19__05d 
                = (1U & (vlSelf->cmd_index >> 0x13U));
            vlSelf->wasmetal_core__DOT__query_index__05b17__05d 
                = (1U & (vlSelf->cmd_index >> 0x11U));
            vlSelf->wasmetal_core__DOT__query_index__05b16__05d 
                = (1U & (vlSelf->cmd_index >> 0x10U));
            vlSelf->wasmetal_core__DOT__query_index__05b18__05d 
                = (1U & (vlSelf->cmd_index >> 0x12U));
            vlSelf->wasmetal_core__DOT__query_index__05b13__05d 
                = (1U & (vlSelf->cmd_index >> 0xdU));
            vlSelf->wasmetal_core__DOT__query_index__05b12__05d 
                = (1U & (vlSelf->cmd_index >> 0xcU));
            vlSelf->wasmetal_core__DOT__query_index__05b27__05d 
                = (1U & (vlSelf->cmd_index >> 0x1bU));
            vlSelf->wasmetal_core__DOT__query_index__05b26__05d 
                = (1U & (vlSelf->cmd_index >> 0x1aU));
            vlSelf->wasmetal_core__DOT__query_index__05b15__05d 
                = (1U & (vlSelf->cmd_index >> 0xfU));
            vlSelf->wasmetal_core__DOT__query_index__05b14__05d 
                = (1U & (vlSelf->cmd_index >> 0xeU));
            vlSelf->wasmetal_core__DOT__query_index__05b5__05d 
                = (1U & (vlSelf->cmd_index >> 5U));
            vlSelf->wasmetal_core__DOT__query_index__05b4__05d 
                = (1U & (vlSelf->cmd_index >> 4U));
            vlSelf->wasmetal_core__DOT__query_index__05b3__05d 
                = (1U & (vlSelf->cmd_index >> 3U));
            vlSelf->wasmetal_core__DOT__query_index__05b2__05d 
                = (1U & (vlSelf->cmd_index >> 2U));
        }
        if (vlSelf->wasmetal_core__DOT___019785_) {
            vlSelf->wasmetal_core__DOT__expected_type__05b31__05d 
                = (vlSelf->insn_x >> 0x1fU);
            vlSelf->wasmetal_core__DOT__expected_type__05b30__05d 
                = (1U & (vlSelf->insn_x >> 0x1eU));
            vlSelf->wasmetal_core__DOT__expected_type__05b29__05d 
                = (1U & (vlSelf->insn_x >> 0x1dU));
            vlSelf->wasmetal_core__DOT__expected_type__05b28__05d 
                = (1U & (vlSelf->insn_x >> 0x1cU));
            vlSelf->wasmetal_core__DOT__expected_type__05b27__05d 
                = (1U & (vlSelf->insn_x >> 0x1bU));
            vlSelf->wasmetal_core__DOT__expected_type__05b26__05d 
                = (1U & (vlSelf->insn_x >> 0x1aU));
            vlSelf->wasmetal_core__DOT__expected_type__05b25__05d 
                = (1U & (vlSelf->insn_x >> 0x19U));
            vlSelf->wasmetal_core__DOT__expected_type__05b24__05d 
                = (1U & (vlSelf->insn_x >> 0x18U));
            vlSelf->wasmetal_core__DOT__expected_type__05b23__05d 
                = (1U & (vlSelf->insn_x >> 0x17U));
            vlSelf->wasmetal_core__DOT__expected_type__05b22__05d 
                = (1U & (vlSelf->insn_x >> 0x16U));
            vlSelf->wasmetal_core__DOT__expected_type__05b21__05d 
                = (1U & (vlSelf->insn_x >> 0x15U));
            vlSelf->wasmetal_core__DOT__expected_type__05b20__05d 
                = (1U & (vlSelf->insn_x >> 0x14U));
            vlSelf->wasmetal_core__DOT__expected_type__05b19__05d 
                = (1U & (vlSelf->insn_x >> 0x13U));
            vlSelf->wasmetal_core__DOT__expected_type__05b18__05d 
                = (1U & (vlSelf->insn_x >> 0x12U));
            vlSelf->wasmetal_core__DOT__expected_type__05b17__05d 
                = (1U & (vlSelf->insn_x >> 0x11U));
            vlSelf->wasmetal_core__DOT__expected_type__05b16__05d 
                = (1U & (vlSelf->insn_x >> 0x10U));
            vlSelf->wasmetal_core__DOT__expected_type__05b15__05d 
                = (1U & (vlSelf->insn_x >> 0xfU));
            vlSelf->wasmetal_core__DOT__expected_type__05b14__05d 
                = (1U & (vlSelf->insn_x >> 0xeU));
            vlSelf->wasmetal_core__DOT__expected_type__05b13__05d 
                = (1U & (vlSelf->insn_x >> 0xdU));
            vlSelf->wasmetal_core__DOT__expected_type__05b12__05d 
                = (1U & (vlSelf->insn_x >> 0xcU));
            vlSelf->wasmetal_core__DOT__expected_type__05b11__05d 
                = (1U & (vlSelf->insn_x >> 0xbU));
            vlSelf->wasmetal_core__DOT__expected_type__05b10__05d 
                = (1U & (vlSelf->insn_x >> 0xaU));
            vlSelf->wasmetal_core__DOT__expected_type__05b9__05d 
                = (1U & (vlSelf->insn_x >> 9U));
            vlSelf->wasmetal_core__DOT__expected_type__05b8__05d 
                = (1U & (vlSelf->insn_x >> 8U));
            vlSelf->wasmetal_core__DOT__expected_type__05b7__05d 
                = (1U & (vlSelf->insn_x >> 7U));
            vlSelf->wasmetal_core__DOT__expected_type__05b6__05d 
                = (1U & (vlSelf->insn_x >> 6U));
            vlSelf->wasmetal_core__DOT__expected_type__05b5__05d 
                = (1U & (vlSelf->insn_x >> 5U));
            vlSelf->wasmetal_core__DOT__expected_type__05b4__05d 
                = (1U & (vlSelf->insn_x >> 4U));
            vlSelf->wasmetal_core__DOT__expected_type__05b3__05d 
                = (1U & (vlSelf->insn_x >> 3U));
            vlSelf->wasmetal_core__DOT__expected_type__05b2__05d 
                = (1U & (vlSelf->insn_x >> 2U));
            vlSelf->wasmetal_core__DOT__expected_type__05b1__05d 
                = (1U & (vlSelf->insn_x >> 1U));
            vlSelf->wasmetal_core__DOT__expected_type__05b0__05d 
                = (1U & vlSelf->insn_x);
        }
        if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)))) {
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b125__05d 
                = vlSelf->wasmetal_core__DOT___019427_;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b123__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b3__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b127__05d 
                = vlSelf->wasmetal_core__DOT___019420_;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b122__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b2__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b124__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b4__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b120__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_value__05b0__05d;
        }
        if (vlSelf->wasmetal_core__DOT___053334_) {
            vlSelf->wasmetal_core__DOT__catch_reference 
                = (1U & vlSelf->insn_x);
        }
        if (vlSelf->wasmetal_core__DOT___019791_) {
            vlSelf->wasmetal_core__DOT__gc_position__05b31__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128212___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b30__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128212___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b29__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128212___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b28__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128212___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b27__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128211___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
        }
        if (vlSelf->wasmetal_core__DOT___019781_) {
            vlSelf->wasmetal_core__DOT__call_depth__05b31__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128425___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128009___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b30__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128425___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128009___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b29__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128425___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128009___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b28__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128425___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128009___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b27__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128424___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128008___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b26__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128424___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128008___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b25__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128424___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128008___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b24__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128424___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128008___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b23__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128423___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128007___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b22__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128423___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128007___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b21__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128423___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128007___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b20__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128423___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128007___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b19__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128422___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128006___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b18__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128422___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128006___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b17__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128422___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128006___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b16__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128422___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128006___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b15__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128421___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128005___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b14__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128421___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128005___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b7__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128003___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b6__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128003___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b5__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128003___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b4__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128419___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128003___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b13__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128421___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128005___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b3__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128002___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b12__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128421___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128005___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
        }
        if (vlSelf->wasmetal_core__DOT___019786_) {
            vlSelf->wasmetal_core__DOT__catch_left__05b31__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128377___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                            >> 2U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b30__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128377___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data 
                                                            >> 1U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128377___O)) 
                                              | (1U 
                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e7.__PVT__data))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128377___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__parity) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128374___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__parity))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128372___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__parity) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128376___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xfU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128376___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xeU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128376___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xdU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128376___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xcU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128375___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xbU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128375___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 0xaU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128375___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 9U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128375___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 8U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128374___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 7U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128374___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 6U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128374___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 5U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128373___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 4U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128373___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 3U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b1__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128370___O)) 
                                              | (1U 
                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__parity))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128373___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 2U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128373___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data 
                                                            >> 1U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128372___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e6.__PVT__data))))));
        }
        if (vlSelf->wasmetal_core__DOT___019777_) {
            vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128162___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
        }
        if (vlSelf->wasmetal_core__DOT___019789_) {
            vlSelf->wasmetal_core__DOT__load_width__05b4__05d 
                = (1U & (vlSelf->insn_z >> 4U));
            vlSelf->wasmetal_core__DOT__load_width__05b3__05d 
                = (1U & (vlSelf->insn_z >> 3U));
            vlSelf->wasmetal_core__DOT__load_width__05b7__05d 
                = (1U & (vlSelf->insn_z >> 7U));
            vlSelf->wasmetal_core__DOT__load_width__05b6__05d 
                = (1U & (vlSelf->insn_z >> 6U));
            vlSelf->wasmetal_core__DOT__load_width__05b5__05d 
                = (1U & (vlSelf->insn_z >> 5U));
            vlSelf->wasmetal_core__DOT__load_width__05b2__05d 
                = (1U & (vlSelf->insn_z >> 2U));
            vlSelf->wasmetal_core__DOT__load_width__05b1__05d 
                = (1U & (vlSelf->insn_z >> 1U));
            vlSelf->wasmetal_core__DOT__load_width__05b0__05d 
                = (1U & vlSelf->insn_z);
        }
    }
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d 
        = vlSelf->wasmetal_core__DOT___040077_;
    vlSelf->wasmetal_core__DOT__call_kind__05b0__05d 
        = vlSelf->wasmetal_core__DOT___019770_;
    if (vlSelf->wasmetal_core__DOT___072257_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b54__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128799___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b53__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b53__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128799___O) 
                                                 >> 1U))))));
    }
    vlSelf->wasmetal_core__DOT__bulk_source_index__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039548_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b127__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039751_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b126__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039736_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b125__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039750_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b124__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040047_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b123__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039753_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b122__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039754_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b121__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039756_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b120__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039757_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039759_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b118__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039749_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b117__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039748_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b116__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039747_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b115__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039737_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b114__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039738_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b113__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039739_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b112__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039740_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039722_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b110__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039735_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b109__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039726_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b108__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039743_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b107__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039744_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b106__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039745_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b105__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039746_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b104__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039752_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b103__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039734_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b102__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039733_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b101__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039732_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b100__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039723_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b99__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039724_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b98__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039729_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b97__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039725_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b96__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039709_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b95__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039721_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b94__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040050_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b93__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039728_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b92__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039730_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b91__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039731_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b90__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039742_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b89__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039720_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b88__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039710_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039711_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b85__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039713_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b81__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039716_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b80__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039717_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b78__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039719_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b76__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039707_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b75__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039706_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b74__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039705_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b73__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039704_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b72__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039703_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b71__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039702_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b70__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039701_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b69__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039700_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b68__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039680_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b67__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039678_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b66__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039697_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b65__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039696_));
    vlSelf->wasmetal_core__DOT__gc_fill_value__05b64__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039695_));
    vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b126__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040097_));
    vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b121__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040096_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040033_));
    vlSelf->wasmetal_core__DOT__init_left__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039843_));
    vlSelf->wasmetal_core__DOT__init_left__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039852_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040034_));
    vlSelf->wasmetal_core__DOT__init_left__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039853_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040036_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039524_));
    vlSelf->wasmetal_core__DOT__init_left__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039849_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040031_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039525_));
    vlSelf->wasmetal_core__DOT__init_left__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039848_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040032_));
    vlSelf->wasmetal_core__DOT__check_type = ((1U & 
                                               (~ (IData)(vlSelf->reset))) 
                                              && (IData)(vlSelf->wasmetal_core__DOT___039820_));
    vlSelf->wasmetal_core__DOT__init_left__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039839_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040037_));
    vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040038_));
    vlSelf->wasmetal_core__DOT__init_left__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039840_));
    vlSelf->wasmetal_core__DOT__init_left__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039841_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039526_));
    vlSelf->wasmetal_core__DOT__init_left__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039842_));
    vlSelf->wasmetal_core__DOT__init_left__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039824_));
    vlSelf->wasmetal_core__DOT__init_left__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039838_));
    vlSelf->wasmetal_core__DOT__divider__02edone = 
        ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___019809_));
    vlSelf->wasmetal_core__DOT__init_left__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039829_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039527_));
    vlSelf->wasmetal_core__DOT__init_left__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039844_));
    vlSelf->wasmetal_core__DOT__init_left__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039845_));
    vlSelf->wasmetal_core__DOT__catch_values__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039781_));
    vlSelf->wasmetal_core__DOT__catch_values__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039783_));
    vlSelf->wasmetal_core__DOT__catch_values__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039410_));
    vlSelf->wasmetal_core__DOT__catch_values__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039763_));
    vlSelf->wasmetal_core__DOT__catch_values__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039774_));
    vlSelf->wasmetal_core__DOT__catch_values__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039770_));
    vlSelf->wasmetal_core__DOT__catch_values__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039768_));
    vlSelf->wasmetal_core__DOT__catch_values__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039767_));
    vlSelf->wasmetal_core__DOT__catch_values__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039799_));
    vlSelf->wasmetal_core__DOT__catch_values__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039800_));
    vlSelf->wasmetal_core__DOT__catch_values__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039787_));
    vlSelf->wasmetal_core__DOT__catch_values__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039765_));
    vlSelf->wasmetal_core__DOT__catch_values__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039764_));
    vlSelf->wasmetal_core__DOT__catch_values__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039762_));
    vlSelf->wasmetal_core__DOT__catch_values__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039792_));
    vlSelf->wasmetal_core__DOT__catch_values__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039788_));
    vlSelf->wasmetal_core__DOT__catch_values__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039773_));
    vlSelf->wasmetal_core__DOT__catch_values__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039771_));
    vlSelf->wasmetal_core__DOT__catch_values__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039769_));
    vlSelf->wasmetal_core__DOT__catch_values__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039805_));
    vlSelf->wasmetal_core__DOT__catch_values__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039786_));
    vlSelf->wasmetal_core__DOT__catch_values__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039776_));
    vlSelf->wasmetal_core__DOT__catch_values__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039777_));
    vlSelf->wasmetal_core__DOT__catch_values__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039778_));
    vlSelf->wasmetal_core__DOT__catch_values__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039779_));
    vlSelf->wasmetal_core__DOT__catch_values__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039412_));
    vlSelf->wasmetal_core__DOT__catch_values__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039766_));
    vlSelf->wasmetal_core__DOT__catch_values__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039782_));
    vlSelf->wasmetal_core__DOT__catch_values__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039784_));
    vlSelf->wasmetal_core__DOT__init_left__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039846_));
    vlSelf->wasmetal_core__DOT__catch_values__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039785_));
    vlSelf->wasmetal_core__DOT__catch_values__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039796_));
    vlSelf->wasmetal_core__DOT__catch_values__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039772_));
    vlSelf->wasmetal_core__DOT__init_left__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039847_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039509_));
    vlSelf->wasmetal_core__DOT__init_left__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039851_));
    vlSelf->wasmetal_core__DOT__catch_position__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039816_));
    vlSelf->wasmetal_core__DOT__init_left__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039837_));
    vlSelf->wasmetal_core__DOT__init_left__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039836_));
    vlSelf->wasmetal_core__DOT__catch_position__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039807_));
    vlSelf->wasmetal_core__DOT__init_left__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039835_));
    vlSelf->wasmetal_core__DOT__fpu__02edone = ((1U 
                                                 & (~ (IData)(vlSelf->reset))) 
                                                && (IData)(vlSelf->wasmetal_core__DOT___019773_));
    vlSelf->wasmetal_core__DOT__init_left__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039825_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039522_));
    vlSelf->wasmetal_core__DOT__init_left__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039826_));
    vlSelf->wasmetal_core__DOT__init_left__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039827_));
    vlSelf->wasmetal_core__DOT__init_left__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039828_));
    vlSelf->wasmetal_core__DOT__catch_position__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039414_));
    vlSelf->wasmetal_core__DOT__init_left__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039830_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039868_));
    vlSelf->wasmetal_core__DOT__init_left__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039823_));
    vlSelf->wasmetal_core__DOT__init_left__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039822_));
    vlSelf->wasmetal_core__DOT__catch_position__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039802_));
    vlSelf->wasmetal_core__DOT__init_left__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039831_));
    vlSelf->wasmetal_core__DOT__init_left__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039832_));
    vlSelf->wasmetal_core__DOT__init_left__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039833_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039529_));
    vlSelf->wasmetal_core__DOT__init_left__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039834_));
    vlSelf->wasmetal_core__DOT__init_left__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039850_));
    vlSelf->wasmetal_core__DOT__catch_position__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039818_));
    vlSelf->wasmetal_core__DOT__catch_position__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039821_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039530_));
    vlSelf->wasmetal_core__DOT__catch_position__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039815_));
}

VL_INLINE_OPT void Vwasmetal_core___024root___nba_sequent__TOP__2(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_sequent__TOP__2\n"); );
    // Body
    if (vlSelf->reset) {
        vlSelf->wasmetal_core__DOT__call_depth__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__call_depth__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__query_index__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__catch_left__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b96__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b93__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b92__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b91__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b90__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b88__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b80__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b78__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b75__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b72__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b110__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b109__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b108__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b104__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b77__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b76__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b74__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b64__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b102__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b67__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b66__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b103__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b95__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b87__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b85__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b83__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b79__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b119__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b117__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b115__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b111__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b107__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b106__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b101__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b94__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b86__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b82__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b118__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b114__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b98__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b112__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b116__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b100__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b84__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b71__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b69__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b68__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b70__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__gc_position__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_src__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_len__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b63__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b62__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b61__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b59__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b58__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b56__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b55__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b53__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b52__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b50__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b49__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b47__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b46__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b44__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b43__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b41__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b40__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b38__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b37__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b35__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b34__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b32__05d = 0U;
        vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b31__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b29__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b28__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b26__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b25__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b23__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b22__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b20__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b19__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d = 0U;
        vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b17__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b16__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b15__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b14__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b13__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b12__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b11__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b7__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b6__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b5__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b4__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b3__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b2__05d = 0U;
        vlSelf->wasmetal_core__DOT__divider__02eresult__05b1__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d = 0U;
        vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d = 0U;
    } else {
        if (vlSelf->wasmetal_core__DOT___019781_) {
            vlSelf->wasmetal_core__DOT__call_depth__05b2__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128002___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b11__05d 
                = (1U & (0x8f88U >> ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128004___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b1__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128002___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b0__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128418___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128002___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b10__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O) 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128004___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b9__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O) 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128004___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
            vlSelf->wasmetal_core__DOT__call_depth__05b8__05d 
                = (1U & (0x8f88U >> ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128420___O) 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___053564_) 
                                         << 2U) | (
                                                   (2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128004___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))))));
        }
        if (vlSelf->wasmetal_core__DOT___019778_) {
            vlSelf->wasmetal_core__DOT__copy_src__05b29__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128329___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b28__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128329___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h80bb2749__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b27__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128328___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h933139ae__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b26__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128328___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h42d23a7e__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b25__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128328___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_hb7f09636__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b23__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128327___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b24__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128328___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h7a3b8afa__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b22__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128327___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h5ea42220__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b21__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128327___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128327___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_haa9dc77d__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h91e2b446__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b19__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128326___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128326___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h8a5293d1__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128326___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h610947b6__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128326___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128470___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h903bd06c__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128325___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h5400cd37__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128325___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h3430b2d3__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128325___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h46529cf5__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128325___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_ha8665b39__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128324___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h670296ed__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_hc76756a0__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b10__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128324___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h39758c7a__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128324___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h059f97dd__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h17ac0e74__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h91ec2f34__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_hc8853298__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128324___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128468___O))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h34bdd8b8__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h38aeb521__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_hfc8fcd60__0))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h0173ca0c__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b7__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128323___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    >> 3U))))));
            vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                    << 2U) | (IData)(vlSelf->__VdfgTmp_h16ea9dbb__0))));
            vlSelf->wasmetal_core__DOT__copy_src__05b6__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128323___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    >> 2U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b5__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128323___O)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O) 
                                                    >> 1U))))));
            vlSelf->wasmetal_core__DOT__copy_src__05b4__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___046419_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128323___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128467___O))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b31__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                           >> 5U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b31__05d) 
                                               << 1U) 
                                              | (vlSelf->function_params 
                                                 >> 0x1fU)))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b29__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                           >> 3U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b29__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x1dU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b30__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                           >> 4U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b30__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x1eU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b25__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__parity) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b25__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x19U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b28__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                           >> 2U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b28__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x1cU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b27__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                           >> 1U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b27__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x1bU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b26__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b26__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x1aU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b16__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__parity) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b16__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x10U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b24__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xfU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b24__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x18U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b23__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xeU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b23__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x17U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b22__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xdU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b22__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x16U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b21__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xcU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b21__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x15U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b20__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xbU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b20__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x14U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b19__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 0xaU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b19__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x13U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b18__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 9U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b18__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x12U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b17__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 8U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b17__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0x11U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b7__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__parity) 
                                                  << 1U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b7__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 7U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b15__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 7U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b15__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xfU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b14__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 6U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b14__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xeU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b13__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 5U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b13__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xdU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b12__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 4U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b12__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xcU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b11__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 3U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b11__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xbU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b10__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 2U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b10__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 0xaU))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b9__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data 
                                                           >> 1U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b9__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 9U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b8__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e4.__PVT__data) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b8__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 8U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b6__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xfU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b6__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 6U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b5__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xeU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b5__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 5U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b4__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xdU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b4__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 4U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b3__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xcU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b3__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 3U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b2__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xbU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b2__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 2U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b1__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 0xaU)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b1__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (vlSelf->function_params 
                                                    >> 1U))))))));
            vlSelf->wasmetal_core__DOT__copy_len__05b0__05d 
                = (1U & (0xf0aafcccU >> (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___046420_) 
                                           << 3U) | 
                                          ((4U & ((IData)(
                                                          (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e3.__PVT__data 
                                                           >> 9U)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__result_arity__05b0__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & vlSelf->function_params)))))));
        }
        if (vlSelf->wasmetal_core__DOT___019791_) {
            vlSelf->wasmetal_core__DOT__gc_position__05b26__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128211___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b25__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128211___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b24__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128211___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b23__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128210___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b22__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128210___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b21__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128210___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b20__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128210___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b19__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128209___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b18__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128209___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b17__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128209___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b16__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128209___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b15__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128208___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b14__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128208___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b13__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128208___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b12__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128208___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b11__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128207___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b10__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128207___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b9__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128207___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b8__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128207___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b7__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128206___O) 
                                       >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b6__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128206___O) 
                                       >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b5__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128206___O)) 
                                | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
            vlSelf->wasmetal_core__DOT__gc_position__05b4__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128206___O) 
                                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___052999_))));
        }
        if (vlSelf->wasmetal_core__DOT___019777_) {
            vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128162___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128162___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128162___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128161___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128161___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128161___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128161___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128160___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128160___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128160___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128160___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128159___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128159___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128159___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128159___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128158___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128158___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128158___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128158___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128157___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128157___O) 
                                       >> 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d 
                = (1U & (8U >> ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128157___O)) 
                                | (1U & (4U >> (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128157___O) 
                                       << 1U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
            vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d 
                = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128156___O) 
                                       >> 2U)) | (1U 
                                                  & (4U 
                                                     >> 
                                                     (3U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128230___O)))))));
        }
        if (vlSelf->wasmetal_core__DOT___019779_) {
            vlSelf->wasmetal_core__DOT__pending_branch__05b31__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x1cU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b30__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x1bU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b29__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x1aU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b28__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x19U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b27__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x18U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b26__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x17U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b25__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x16U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b24__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x15U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b23__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x14U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b22__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x13U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b21__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x12U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b20__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x11U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b19__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0x10U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b18__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xfU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b17__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xeU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b16__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xdU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b15__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xcU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b14__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xbU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b13__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 0xaU)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b12__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 9U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b11__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 8U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b10__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 7U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b9__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 6U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b8__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 5U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   (2U 
                                                    & (vlSelf->insn_z 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b7__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 4U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 7U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b6__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 6U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b5__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 5U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b4__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            >> 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 4U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d 
                = (1U & (0x8f88U >> ((8U & vlSelf->insn_x) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 3U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            << 1U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 2U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            << 2U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_z 
                                                         >> 1U)))))));
            vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d 
                = (1U & (0x8f88U >> ((8U & (vlSelf->insn_x 
                                            << 3U)) 
                                     | (((IData)(vlSelf->wasmetal_core__DOT___070485_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->insn_z))))));
        }
        if (vlSelf->wasmetal_core__DOT___019798_) {
            vlSelf->wasmetal_core__DOT__query_index__05b0__05d 
                = (1U & vlSelf->cmd_index);
            vlSelf->wasmetal_core__DOT__query_index__05b1__05d 
                = (1U & (vlSelf->cmd_index >> 1U));
        }
        if (vlSelf->wasmetal_core__DOT___019786_) {
            vlSelf->wasmetal_core__DOT__catch_left__05b9__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128372___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xfU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b8__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128372___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xeU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b7__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128371___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xdU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b6__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128371___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xcU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b5__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128371___O)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xbU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b4__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128371___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 0xaU)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b3__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128370___O) 
                                                >> 2U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 9U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b2__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128370___O) 
                                                >> 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 8U)))))));
            vlSelf->wasmetal_core__DOT__catch_left__05b0__05d 
                = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                    << 2U) | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128370___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & (IData)(
                                                           (vlSymsp->TOP__wasmetal_core__DOT__labels_memory__02e0__02e5.__PVT__data 
                                                            >> 7U)))))));
        }
        if (vlSelf->wasmetal_core__DOT___052805_) {
            vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d 
                = vlSelf->wasmetal_core__DOT___052804_;
            vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d 
                = vlSelf->wasmetal_core__DOT___052802_;
        }
        if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_hd461afd0__0)))) {
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b96__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b96__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b93__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b93__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b92__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b92__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b91__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b91__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b90__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b90__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b88__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b88__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b80__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b80__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b78__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b78__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b75__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b75__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b72__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b72__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b110__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b110__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b109__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b109__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b108__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b108__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b104__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b104__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b77__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b77__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b76__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b76__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b74__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b74__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b64__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b64__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b102__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b102__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b67__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b67__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b66__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b66__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b103__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b103__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b95__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b95__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b87__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b87__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b85__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b85__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b83__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b83__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b79__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b79__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b44__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b44__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b30__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b30__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b26__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b26__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b119__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b119__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b117__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b117__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b115__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b115__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b111__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b111__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b107__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b107__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b106__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b106__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b101__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b101__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b94__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b94__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b86__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b86__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b82__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b82__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b118__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b118__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b114__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b114__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b59__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b59__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b14__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b14__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b11__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b11__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b98__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b98__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b62__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b62__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b58__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b58__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b54__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b54__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b112__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b112__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b45__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b45__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b31__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b31__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b29__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b29__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b28__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b28__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b27__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b27__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b24__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b24__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b23__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b23__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b21__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b21__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b19__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b19__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b16__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b16__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b60__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b60__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b47__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b47__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b43__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b43__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b40__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b40__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b37__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b37__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b15__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b15__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b8__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b8__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b22__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b22__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b18__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b18__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b63__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b63__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b34__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b34__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b13__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b13__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b10__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b10__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b46__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b46__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b42__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b42__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b38__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b38__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b61__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b61__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b50__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b50__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b39__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b39__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b12__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b12__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b48__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b48__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b32__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b32__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b55__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b55__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b53__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b53__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b51__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b51__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b56__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b56__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b0__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b0__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b4__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b4__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b1__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b1__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b116__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b116__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b100__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b100__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b84__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b84__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b20__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b20__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b36__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b36__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b7__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b7__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b6__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b6__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b52__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b52__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b71__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b71__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b69__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b69__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b5__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b5__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b68__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b68__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b70__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b70__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b2__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b2__05d;
            vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b3__05d 
                = vlSelf->wasmetal_core__DOT__simd_integer__02eaccumulated__05b3__05d;
        }
        if (vlSelf->wasmetal_core__DOT___019795_) {
            vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d 
                = (1U & (0xf0f088ffU >> (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___054188_) 
                                           << 3U) | 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128392___O) 
                                                  << 1U)) 
                                           | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128138___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___054187_)))))));
        }
        if (vlSelf->wasmetal_core__DOT___019797_) {
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x1cU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x13U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0xaU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 1U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x18U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0xfU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 6U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x19U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x16U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x10U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0xdU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 7U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 4U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x1dU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b1__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          << 1U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          << 2U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x1bU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x15U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x12U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0xcU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 9U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 3U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d 
                = (1U & (0x10U >> ((4U & vlSelf->cmd_data[2U]) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          << 2U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x1aU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x17U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x11U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0xeU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 8U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 5U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0x14U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 0xbU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          >> 2U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[3U] 
                                          << 1U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x1cU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x16U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x13U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0xdU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0xaU)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 4U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 1U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x19U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 0x10U)) 
                                   | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
            vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d 
                = (1U & (0x10U >> ((4U & (vlSelf->cmd_data[2U] 
                                          >> 7U)) | (IData)(vlSelf->__VdfgTmp_h2df5fb6a__0))));
        }
        if (vlSelf->wasmetal_core__DOT___019809_) {
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b63__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x35U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128694___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b63__05d)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034695_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128678___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b62__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b62__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128694___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034694_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128678___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b61__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b61__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128694___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034693_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128678___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b60__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b60__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128694___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034692_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128678___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b59__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b59__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128693___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034690_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128677___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b58__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b58__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128693___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034689_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128677___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b57__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b57__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128693___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034688_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128677___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b56__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b56__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128693___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034687_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128677___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b55__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b55__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128692___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034686_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128676___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b54__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b54__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128692___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034685_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128676___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b53__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b53__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128692___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034684_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128676___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b52__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b52__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128692___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034683_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128676___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b51__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b51__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128691___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034682_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128675___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b50__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b50__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128691___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034681_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128675___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b49__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b49__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128691___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034679_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128675___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b48__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b48__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128691___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034678_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128675___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b47__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b47__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128690___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034677_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128674___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b46__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b46__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128690___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034676_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128674___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b45__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b45__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128690___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034675_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128674___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b44__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b44__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128690___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034674_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128674___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b43__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b43__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128689___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034673_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128673___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b42__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b42__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128689___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034672_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128673___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b41__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b41__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128689___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034671_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128673___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b40__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b40__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128689___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034670_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128673___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b39__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b39__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128703___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034668_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128687___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b38__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b38__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128703___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034667_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128687___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b37__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b37__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128703___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034666_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128687___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b36__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b36__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128703___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034665_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128687___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b35__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b35__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128702___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034664_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128686___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b34__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b34__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128702___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034663_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128686___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b33__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b33__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128702___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034662_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128686___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b32__05d 
                = (1U & (IData)((0xaa330f0f00000000ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054639_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b32__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128702___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034661_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128686___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b31__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b31__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128701___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034660_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128685___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b30__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b30__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128701___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034659_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128685___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b29__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b29__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128701___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034657_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128685___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b28__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b28__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128701___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034656_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128685___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b27__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b27__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128700___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034655_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128684___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b26__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b26__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128700___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034654_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128684___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b25__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b25__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128700___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034653_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128684___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b24__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b24__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128700___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034652_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128684___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b23__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b23__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128699___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034651_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128683___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b22__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b22__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128699___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034650_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128683___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b21__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b21__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128699___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034649_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128683___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b20__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b20__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128699___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034648_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128683___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b19__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b19__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128698___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034646_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128682___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b18__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b18__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128698___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034645_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128682___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b17__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b17__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128698___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034644_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128682___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b16__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b16__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128698___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034643_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128682___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b15__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b15__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128697___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034642_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128681___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b14__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b14__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128697___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034641_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128681___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b13__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b13__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128697___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034640_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128681___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b12__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b12__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128697___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034639_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128681___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b11__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b11__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128696___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034638_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128680___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b10__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b10__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128696___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034637_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128680___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b9__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b9__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128696___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034699_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128680___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b8__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b8__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128696___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034698_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128680___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b7__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b7__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128695___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034697_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128679___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b6__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b6__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128695___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034696_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128679___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b5__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b5__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128695___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034691_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128679___O) 
                                                               >> 1U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b4__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b4__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128695___O))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034680_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128679___O))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b3__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b3__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128688___O) 
                                                                     >> 3U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034669_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128672___O) 
                                                               >> 3U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b2__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b2__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128688___O) 
                                                                     >> 2U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034658_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128672___O) 
                                                               >> 2U))))))))));
            vlSelf->wasmetal_core__DOT__divider__02eresult__05b1__05d 
                = (1U & (IData)((0xaa3300000f0fULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT__divider__02eis_rem) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_r) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x53U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__divider__02eneg_q) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128688___O) 
                                                                     >> 1U))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___034647_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128672___O) 
                                                               >> 1U))))))))));
        }
    }
    vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039531_));
    vlSelf->wasmetal_core__DOT__catch_position__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039814_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039532_));
    vlSelf->wasmetal_core__DOT__catch_position__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039808_));
    vlSelf->wasmetal_core__DOT__catch_position__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039812_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039541_));
    vlSelf->wasmetal_core__DOT__catch_position__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039809_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039521_));
    vlSelf->wasmetal_core__DOT__catch_position__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039810_));
    vlSelf->wasmetal_core__DOT__catch_position__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039803_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039465_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039520_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039466_));
    vlSelf->wasmetal_core__DOT__catch_position__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039811_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039519_));
    vlSelf->wasmetal_core__DOT__catch_position__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039813_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039470_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039510_));
    vlSelf->wasmetal_core__DOT__catch_position__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039817_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039472_));
    vlSelf->wasmetal_core__DOT__catch_position__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039789_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039474_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039511_));
    vlSelf->wasmetal_core__DOT__catch_position__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039413_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039452_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039512_));
    vlSelf->wasmetal_core__DOT__catch_position__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039795_));
    if (vlSelf->wasmetal_core__DOT___072257_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b52__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128799___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b51__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b50__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b49__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b48__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128798___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b47__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b46__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b45__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b44__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128797___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b43__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b42__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b41__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b40__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128796___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b39__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b38__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b37__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b36__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128809___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b35__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b34__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b33__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b32__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128808___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b31__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128807___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b30__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128807___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b29__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128807___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b28__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128807___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b27__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b26__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b25__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b24__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128806___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b23__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b22__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b21__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b20__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128805___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b19__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128804___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b18__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128804___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b17__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128804___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b16__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128804___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b15__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b14__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b13__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b12__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128803___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b11__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b10__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b9__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b8__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128802___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b7__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128801___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b6__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128801___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b5__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128801___O) 
                                                 >> 1U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b4__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d) 
                                           << 1U) | 
                                          (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128801___O))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b3__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                 >> 3U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b2__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                 >> 2U))))));
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b1__05d 
            = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O) 
                                                 >> 1U))))));
    }
    vlSelf->wasmetal_core__DOT__divider__02ebusy = 
        ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___040040_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039464_));
    vlSelf->wasmetal_core__DOT__catch_position__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039806_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039513_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039862_));
    vlSelf->wasmetal_core__DOT__catch_position__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039804_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039496_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039468_));
    vlSelf->wasmetal_core__DOT__catch_position__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039801_));
    vlSelf->wasmetal_core__DOT__catch_position__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039790_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039473_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039508_));
    vlSelf->wasmetal_core__DOT__catch_position__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039791_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039471_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039867_));
    vlSelf->wasmetal_core__DOT__catch_position__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039793_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039863_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039515_));
    vlSelf->wasmetal_core__DOT__catch_position__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039794_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039469_));
    vlSelf->wasmetal_core__DOT__catch_position__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039775_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039516_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039463_));
    vlSelf->wasmetal_core__DOT__catch_position__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039411_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039517_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039462_));
    vlSelf->wasmetal_core__DOT__catch_position__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039780_));
    vlSelf->wasmetal_core__DOT__catch_position__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039797_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039461_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039518_));
    vlSelf->wasmetal_core__DOT__catch_position__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039798_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039453_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039528_));
    vlSelf->wasmetal_core__DOT__catch_position__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039819_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039454_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039507_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039455_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039506_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039456_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039505_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039444_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039451_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039861_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039497_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039457_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039498_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039458_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039499_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039459_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039484_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039460_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039467_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039495_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039450_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039866_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039501_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039502_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039503_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039504_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039514_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039494_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039493_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039492_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039481_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039485_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039480_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039486_));
    if ((1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___072257_) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02enewBit))))) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b0__05d = 0U;
    } else if (vlSelf->wasmetal_core__DOT___072257_) {
        vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b0__05d 
            = (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128795___O));
    }
    vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039479_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039482_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039488_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b2__05d 
        = vlSelf->wasmetal_core__DOT___040073_;
    vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039449_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039490_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039500_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039448_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039475_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039445_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039478_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039446_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039864_));
    vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039477_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039483_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039491_));
    vlSelf->wasmetal_core__DOT__simd_integer__02edone 
        = ((1U & (~ (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02erunning) 
                               << 1U) | (IData)(vlSelf->reset))))) 
           && (1U & (0x8000U >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI))));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039489_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039865_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039487_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039476_));
    vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d 
        = ((1U & (~ (IData)(vlSelf->reset))) && (IData)(vlSelf->wasmetal_core__DOT___039534_));
}
