#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__5(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__5\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_6;
    VlWide<3>/*95:0*/ __Vtemp_12;
    VlWide<3>/*95:0*/ __Vtemp_18;
    VlWide<3>/*95:0*/ __Vtemp_24;
    VlWide<3>/*95:0*/ __Vtemp_30;
    VlWide<4>/*127:0*/ __Vtemp_38;
    VlWide<4>/*127:0*/ __Vtemp_44;
    VlWide<4>/*127:0*/ __Vtemp_50;
    VlWide<4>/*127:0*/ __Vtemp_56;
    VlWide<4>/*127:0*/ __Vtemp_62;
    // Body
    vlSelf->wasmetal_core__DOT___069988_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069984_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069983_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b95__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x1dU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___048695_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_he8484823__0))))));
    vlSelf->wasmetal_core__DOT__top__05b79__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he8484823__0))))));
    vlSelf->wasmetal_core__DOT___069647_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069643_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069642_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b79__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0xdU)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___062451_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b111__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0xeU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b111__05d)))))));
    vlSelf->wasmetal_core__DOT__top__05b111__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_he18e3e19__0))))));
    vlSelf->__VdfgTmp_ha13bce2f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003690_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___003689_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he18e3e19__0)))))));
    vlSelf->wasmetal_core__DOT___062470_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b119__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[3U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b119__05d)))))));
    vlSelf->wasmetal_core__DOT___005496_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h3fce9550__0))))));
    vlSelf->wasmetal_core__DOT__top__05b119__05d = 
        (1U & (IData)((0xff110f0f00000000ULL >> (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                  << 5U) 
                                                 | ((0x10U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                        << 3U)) 
                                                    | (IData)(vlSelf->__VdfgTmp_h3fce9550__0))))));
    vlSelf->wasmetal_core__DOT___062390_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x53U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__gc_fill) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__gc_fill_value__05b87__05d)))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[2U] 
                                                                >> 0x16U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill_value__05b87__05d)))))));
    vlSelf->wasmetal_core__DOT___069822_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7077000070777077ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & (vlSelf->insn_imm[2U] 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_x 
                                                                           >> 0x14U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x17U))))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___069819_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b87__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[2U] 
                                                                             >> 0x17U))))))))));
    vlSelf->wasmetal_core__DOT___048070_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h29fb25ab__0))))));
    vlSelf->wasmetal_core__DOT__top__05b87__05d = (1U 
                                                   & (IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                      << 3U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h29fb25ab__0))))));
    vlSelf->wasmetal_core__DOT___052193_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052178_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052177_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052176_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052175_))))));
    vlSelf->wasmetal_core__DOT___069231_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069229_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069228_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___069235_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hee23ef9b__0))))));
    vlSelf->__VdfgTmp_hb85239a7__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005636_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001330_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hee23ef9b__0)))))));
    vlSelf->wasmetal_core__DOT___068642_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x11U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f9a0992__0))))));
    vlSelf->__VdfgTmp_h64e10f56__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003876_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000927_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5f9a0992__0)))))));
    vlSelf->wasmetal_core__DOT___068596_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068593_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0x10U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5172aa32__0))))));
    vlSelf->__VdfgTmp_hf93df92c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004092_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000897_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h5172aa32__0)))))));
    vlSelf->wasmetal_core__DOT___052452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052447_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052446_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052445_)))));
    vlSelf->wasmetal_core__DOT___068556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d))));
    vlSelf->wasmetal_core__DOT___068545_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068543_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068542_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xfU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56fd8038__0))))));
    vlSelf->__VdfgTmp_h4a9c07e1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004314_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000896_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h56fd8038__0)))))));
    vlSelf->wasmetal_core__DOT___068510_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068509_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068508_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xeU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___068479_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde7deab4__0))))));
    vlSelf->__VdfgTmp_hb9ea03dd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004018_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000873_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hde7deab4__0)))))));
    vlSelf->wasmetal_core__DOT___068466_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xeU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hca53b37a__0))))));
    vlSelf->__VdfgTmp_h33498483__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003720_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000872_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hca53b37a__0)))))));
    vlSelf->wasmetal_core__DOT___068391_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068390_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068389_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 0xcU)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___068403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfa0f79c8__0))))));
    vlSelf->__VdfgTmp_hbd8e6335__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004684_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000849_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hfa0f79c8__0)))))));
    vlSelf->wasmetal_core__DOT___068334_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b13__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (vlSelf->cmd_data[1U] 
                                                            >> 0xdU))))));
    vlSelf->wasmetal_core__DOT___068348_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3fc388f6__0))))));
    vlSelf->__VdfgTmp_hf0dacca2__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004240_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000848_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3fc388f6__0)))))));
    vlSelf->wasmetal_core__DOT___068281_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xbU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068294_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha15d8995__0))))));
    vlSelf->__VdfgTmp_h2566b586__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004166_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000824_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha15d8995__0)))))));
    vlSelf->wasmetal_core__DOT___068227_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 0xaU)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068241_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_he2dbc386__0))))));
    vlSelf->__VdfgTmp_hd5a2b04d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003572_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000825_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_he2dbc386__0)))))));
    vlSelf->wasmetal_core__DOT___068195_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___068156_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaa3ad0b__0))))));
    vlSelf->__VdfgTmp_h7f6ab5bd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003498_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000796_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_haaa3ad0b__0)))))));
    vlSelf->wasmetal_core__DOT___068141_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 8U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___068105_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ec183f3__0))))));
    vlSelf->__VdfgTmp_h2712d491__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003646_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000795_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h3ec183f3__0)))))));
    vlSelf->wasmetal_core__DOT___068070_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068068_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068067_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___068080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7c76017__0))))));
    vlSelf->__VdfgTmp_h2f983ac6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003794_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000772_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_ha7c76017__0)))))));
    vlSelf->wasmetal_core__DOT___068021_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d))));
    vlSelf->wasmetal_core__DOT___068012_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 6U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h97352ffe__0))))));
    vlSelf->__VdfgTmp_h158a449d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004610_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000771_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h97352ffe__0)))))));
    vlSelf->wasmetal_core__DOT___067952_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067951_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067950_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        >> 4U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___067964_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h01ca3900__0))))));
    vlSelf->__VdfgTmp_h2937d10d__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004462_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000747_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h01ca3900__0)))))));
    vlSelf->wasmetal_core__DOT___067889_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 4U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067898_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2bc911a1__0))))));
    vlSelf->__VdfgTmp_ha7dc0a46__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004388_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000748_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2bc911a1__0)))))));
    vlSelf->wasmetal_core__DOT___052571_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052508_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052507_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052505_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052504_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052503_)))))))));
    vlSelf->wasmetal_core__DOT___067855_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 3U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067811_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc61dfdcc__0))))));
    vlSelf->__VdfgTmp_h6e7f092f__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004536_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000723_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hc61dfdcc__0)))))));
    vlSelf->wasmetal_core__DOT___067802_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[1U] 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067750_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h33ea4c85__0))))));
    vlSelf->__VdfgTmp_hd1b03413__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004758_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000724_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h33ea4c85__0)))))));
    vlSelf->wasmetal_core__DOT___067723_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067720_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & vlSelf->cmd_data[1U]) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___067725_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_heeded769__0))))));
    vlSelf->__VdfgTmp_h59e987ab__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___004832_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000694_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_heeded769__0)))))));
    vlSelf->wasmetal_core__DOT___067652_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->cmd_data[1U]) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___067660_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2f17a8a4__0))))));
    vlSelf->__VdfgTmp_hf92587e4__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003288_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000693_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h2f17a8a4__0)))))));
    vlSelf->wasmetal_core__DOT___052453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052418_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052417_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052416_)))));
    vlSelf->wasmetal_core__DOT___067586_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067585_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[1U] 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf38f2779U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h51a3fd4e__0))))));
    vlSelf->__VdfgTmp_ha8427a44__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___003208_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___000665_))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                 & (IData)(
                                                           (0xff1100000f0fULL 
                                                            >> 
                                                            ((0x20U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                                 << 4U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h51a3fd4e__0)))))));
    vlSelf->wasmetal_core__DOT___028661_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052235_))));
    vlSelf->wasmetal_core__DOT___028973_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052235_))));
    vlSelf->wasmetal_core__DOT___045434_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052233_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052234_)))))))));
    vlSelf->wasmetal_core__DOT___045446_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052233_)))))))));
    vlSelf->wasmetal_core__DOT___067537_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x777U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___048484_))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xf38f2779U 
                                                           >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                                          << 1U)) 
                                                      | (vlSelf->cmd_data[0U] 
                                                         >> 0x1fU)))));
    vlSelf->wasmetal_core__DOT___048007_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hbfbeb842__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbfbeb842__0))))));
    vlSelf->wasmetal_core__DOT___028648_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003270_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052256_))));
    vlSelf->wasmetal_core__DOT___028960_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052256_))));
    vlSelf->wasmetal_core__DOT___064716_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & vlSelf->cmd_data[0U]) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    vlSelf->wasmetal_core__DOT___064463_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))));
    vlSelf->wasmetal_core__DOT___048138_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h37d1cc77__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h37d1cc77__0))))));
    vlSelf->wasmetal_core__DOT___045433_ = (1U & (0x2b22U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052256_))))));
    vlSelf->wasmetal_core__DOT___045445_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052256_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052558_))))));
    vlSelf->wasmetal_core__DOT___028637_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052558_))));
    vlSelf->wasmetal_core__DOT___052569_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052560_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052559_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052558_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052557_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052556_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052555_)))))))));
    vlSelf->wasmetal_core__DOT___028949_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052558_))));
    vlSelf->wasmetal_core__DOT___064450_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (vlSelf->cmd_data[0U] 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf38f2779U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)))))))))));
    __Vtemp_1[0U] = (IData)((((QData)((IData)((1U & 
                                               (8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                              << 0x3fU) | (((QData)((IData)(
                                                            (1U 
                                                             & (8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(
                                                               (1U 
                                                                & (8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                               << 0x3dU) 
                                              | (((QData)((IData)(
                                                                  (1U 
                                                                   & (8U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                  << 0x3cU) 
                                                 | (((QData)((IData)(
                                                                     (1U 
                                                                      & (8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                     << 0x3bU) 
                                                    | (((QData)((IData)(
                                                                        (1U 
                                                                         & (8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                        << 0x3aU) 
                                                       | (((QData)((IData)(
                                                                           (1U 
                                                                            & (8U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                           << 0x39U) 
                                                          | (((QData)((IData)(
                                                                              (1U 
                                                                               & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                              << 0x38U) 
                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                 << 0x37U) 
                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                    << 0x36U) 
                                                                   | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                       << 0x35U) 
                                                                      | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                          << 0x34U) 
                                                                         | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                             << 0x33U) 
                                                                            | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                               | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)((1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b63__05d)))))) 
                               << 0x3fU) | (((QData)((IData)(
                                                             (1U 
                                                              & (8U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(
                                                                (1U 
                                                                 & (8U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))) 
                                                << 0x3dU) 
                                               | (((QData)((IData)(
                                                                   (1U 
                                                                    & (8U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))) 
                                                   << 0x3cU) 
                                                  | (((QData)((IData)(
                                                                      (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b59__05d)))))) 
                                                      << 0x3bU) 
                                                     | (((QData)((IData)(
                                                                         (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))) 
                                                         << 0x3aU) 
                                                        | (((QData)((IData)(
                                                                            (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b57__05d)))))) 
                                                            << 0x39U) 
                                                           | (((QData)((IData)(
                                                                               (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b56__05d)))))) 
                                                               << 0x38U) 
                                                              | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b55__05d)))))) 
                                                                  << 0x37U) 
                                                                 | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b54__05d)))))) 
                                                                     << 0x36U) 
                                                                    | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b53__05d)))))) 
                                                                        << 0x35U) 
                                                                       | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b52__05d)))))) 
                                                                           << 0x34U) 
                                                                          | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b51__05d)))))) 
                                                                              << 0x33U) 
                                                                             | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b50__05d)))))) 
                                                                                << 0x32U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b49__05d)))))) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b48__05d)))))) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b47__05d)))))) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b46__05d)))))) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b45__05d)))))) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b44__05d)))))) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b43__05d)))))) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b42__05d)))))) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b41__05d)))))) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b40__05d)))))) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b39__05d)))))) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b38__05d)))))) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b37__05d)))))) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b36__05d)))))) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b35__05d)))))) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b34__05d)))))) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b33__05d)))))) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b32__05d)))))) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d))) 
                                                                                << 0x1fU) 
                                                                                | ((0x40000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d))) 
                                                                                << 0x1eU)) 
                                                                                | ((0x20000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b29__05d))) 
                                                                                << 0x1dU)) 
                                                                                | ((0x10000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b28__05d))) 
                                                                                << 0x1cU)) 
                                                                                | ((0x8000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b27__05d))) 
                                                                                << 0x1bU)) 
                                                                                | ((0x4000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b26__05d))) 
                                                                                << 0x1aU)) 
                                                                                | ((0x2000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b25__05d))) 
                                                                                << 0x19U)) 
                                                                                | ((0x1000000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d))) 
                                                                                << 0x18U)) 
                                                                                | ((0x800000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b23__05d))) 
                                                                                << 0x17U)) 
                                                                                | ((0x400000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b22__05d))) 
                                                                                << 0x16U)) 
                                                                                | ((0x200000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b21__05d))) 
                                                                                << 0x15U)) 
                                                                                | ((0x100000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b20__05d))) 
                                                                                << 0x14U)) 
                                                                                | ((0x80000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b19__05d))) 
                                                                                << 0x13U)) 
                                                                                | ((0x40000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b18__05d))) 
                                                                                << 0x12U)) 
                                                                                | ((0x20000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b17__05d))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b16__05d))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b15__05d))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b7__05d))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b6__05d))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b4__05d))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b3__05d))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b1__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b0__05d))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
                             >> 0x20U));
    __Vtemp_6[2U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b69__05d))) 
                               << 5U)) | ((0x10U & 
                                           ((8U >> 
                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b68__05d))) 
                                            << 4U)) 
                                          | ((8U & 
                                              ((8U 
                                                >> 
                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b67__05d))) 
                                               << 3U)) 
                                             | ((4U 
                                                 & ((8U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b66__05d))) 
                                                    << 2U)) 
                                                | ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b65__05d))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b64__05d)))))))));
    __Vtemp_12[2U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b75__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b74__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b73__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b72__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b71__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b70__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_6[2U]))))));
    __Vtemp_18[2U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b81__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b80__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b79__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b78__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b77__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b76__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_12[2U]))))));
    __Vtemp_24[2U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b87__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b86__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b85__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b84__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b83__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b82__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_18[2U]))))));
    __Vtemp_30[2U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b93__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b92__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b91__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b90__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b89__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b88__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_24[2U]))))));
    __Vtemp_38[3U] = ((0x20U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b101__05d))) 
                                << 5U)) | ((0x10U & 
                                            ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b100__05d))) 
                                             << 4U)) 
                                           | ((8U & 
                                               ((8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b99__05d))) 
                                                << 3U)) 
                                              | ((4U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b98__05d))) 
                                                     << 2U)) 
                                                 | ((2U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b97__05d))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b96__05d)))))))));
    __Vtemp_44[3U] = ((0x800U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b107__05d))) 
                                 << 0xbU)) | ((0x400U 
                                               & ((8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b106__05d))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b105__05d))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b104__05d))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b103__05d))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b102__05d))) 
                                                              << 6U)) 
                                                          | __Vtemp_38[3U]))))));
    __Vtemp_50[3U] = ((0x20000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b113__05d))) 
                                   << 0x11U)) | ((0x10000U 
                                                  & ((8U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b112__05d))) 
                                                     << 0x10U)) 
                                                 | ((0x8000U 
                                                     & ((8U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b111__05d))) 
                                                        << 0xfU)) 
                                                    | ((0x4000U 
                                                        & ((8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b110__05d))) 
                                                           << 0xeU)) 
                                                       | ((0x2000U 
                                                           & ((8U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b109__05d))) 
                                                              << 0xdU)) 
                                                          | ((0x1000U 
                                                              & ((8U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b108__05d))) 
                                                                 << 0xcU)) 
                                                             | __Vtemp_44[3U]))))));
    __Vtemp_56[3U] = ((0x800000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b119__05d))) 
                                    << 0x17U)) | ((0x400000U 
                                                   & ((8U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b118__05d))) 
                                                      << 0x16U)) 
                                                  | ((0x200000U 
                                                      & ((8U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b117__05d))) 
                                                         << 0x15U)) 
                                                     | ((0x100000U 
                                                         & ((8U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b116__05d))) 
                                                            << 0x14U)) 
                                                        | ((0x80000U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b115__05d))) 
                                                               << 0x13U)) 
                                                           | ((0x40000U 
                                                               & ((8U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b114__05d))) 
                                                                  << 0x12U)) 
                                                              | __Vtemp_50[3U]))))));
    __Vtemp_62[3U] = ((0x20000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b125__05d))) 
                                      << 0x1dU)) | 
                      ((0x10000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b124__05d))) 
                                       << 0x1cU)) | 
                       ((0x8000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b123__05d))) 
                                       << 0x1bU)) | 
                        ((0x4000000U & ((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b122__05d))) 
                                        << 0x1aU)) 
                         | ((0x2000000U & ((8U >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b121__05d))) 
                                           << 0x19U)) 
                            | ((0x1000000U & ((8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b120__05d))) 
                                              << 0x18U)) 
                               | __Vtemp_56[3U]))))));
    vlSelf->result_data[0U] = __Vtemp_1[0U];
    vlSelf->result_data[1U] = __Vtemp_1[1U];
    vlSelf->result_data[2U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b95__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b94__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_30[2U]));
    vlSelf->result_data[3U] = (((8U >> (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b127__05d))) 
                                << 0x1fU) | ((0x40000000U 
                                              & ((8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b126__05d))) 
                                                 << 0x1eU)) 
                                             | __Vtemp_62[3U]));
    vlSelf->wasmetal_core__DOT___048021_ = ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                            & (IData)(
                                                      (0xff1100000f0fULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                            << 4U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hc5249891__0))))));
    vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d 
        = (1U & (IData)((0xff110f0f00000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                          << 3U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc5249891__0))))));
    vlSelf->wasmetal_core__DOT___067099_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067098_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067097_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x16U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___067025_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067024_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067023_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066793_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066791_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x12U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066710_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066709_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066708_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x11U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066548_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066547_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066546_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066467_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066466_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066465_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xeU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___066385_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066384_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066383_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b16__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___052370_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052295_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052294_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052293_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbeaa94ef__0)))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h22773bc1__0)))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h95c9c2c5__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff555503f303f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h00d09e7a__0))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xac00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052282_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052281_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052280_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052279_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0589a813__0)))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___052817_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052813_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003827_)))))))));
    vlSelf->wasmetal_core__DOT___052830_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004635_)))))))));
    vlSelf->wasmetal_core__DOT___052810_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003901_)))))))));
    vlSelf->wasmetal_core__DOT___005454_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39540d35__0)))));
    vlSelf->wasmetal_core__DOT___001168_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h39540d35__0))));
    vlSelf->wasmetal_core__DOT___052826_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052822_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052821_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004875_)))))))));
    vlSelf->wasmetal_core__DOT___069201_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069198_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069197_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054245_)))))))));
    vlSelf->wasmetal_core__DOT___005417_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hffec0e42__0)))));
    vlSelf->wasmetal_core__DOT___001146_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hffec0e42__0))));
    vlSelf->wasmetal_core__DOT___069151_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069132_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069131_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054243_)))))))));
    vlSelf->wasmetal_core__DOT___005407_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h15e8b450__0)))));
    vlSelf->wasmetal_core__DOT___001124_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h15e8b450__0))));
    vlSelf->wasmetal_core__DOT___001102_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h638471cc__0))));
    vlSelf->__VdfgTmp_h9462500e__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005040_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001103_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h638471cc__0))))));
    vlSelf->wasmetal_core__DOT___069057_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069054_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069053_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054239_)))))))));
    vlSelf->wasmetal_core__DOT___005387_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h82a219c8__0)))));
    vlSelf->wasmetal_core__DOT___001080_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82a219c8__0))));
    vlSelf->wasmetal_core__DOT___069008_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069005_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069004_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))))));
    vlSelf->wasmetal_core__DOT___001058_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60872440__0))));
    vlSelf->__VdfgTmp_hcea60642__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005380_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001059_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h60872440__0))))));
    vlSelf->wasmetal_core__DOT___068959_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068956_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068955_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054235_)))))))));
    vlSelf->wasmetal_core__DOT___001036_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h881dfff7__0))));
    vlSelf->__VdfgTmp_hc3acb233__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005108_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001037_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h881dfff7__0))))));
    vlSelf->wasmetal_core__DOT___052768_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb3e18d1b__0)))));
    vlSelf->wasmetal_core__DOT___045148_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3e18d1b__0))))))));
    vlSelf->wasmetal_core__DOT___068890_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068887_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054233_)))))));
    vlSelf->wasmetal_core__DOT___001014_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h69848182__0))));
    vlSelf->__VdfgTmp_he5858a3c__0 = ((((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                        & ((IData)(vlSelf->wasmetal_core__DOT___003146_)
                                            ? (IData)(vlSelf->wasmetal_core__DOT___005176_)
                                            : (IData)(vlSelf->wasmetal_core__DOT___001015_))) 
                                       << 1U) | (1U 
                                                 & (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h69848182__0))))));
    vlSelf->wasmetal_core__DOT___068843_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068839_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))));
    vlSelf->wasmetal_core__DOT___005484_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h426f01c6__0)))));
    vlSelf->wasmetal_core__DOT___000992_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h426f01c6__0))));
    vlSelf->wasmetal_core__DOT___068815_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068810_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054229_)))))))));
    vlSelf->wasmetal_core__DOT___005474_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7c65fb3__0)))));
    vlSelf->wasmetal_core__DOT___000980_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7c65fb3__0))));
    vlSelf->wasmetal_core__DOT___068743_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068739_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054227_)))))));
    vlSelf->wasmetal_core__DOT___005464_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ff94b24__0)))));
    vlSelf->wasmetal_core__DOT___001327_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3ff94b24__0))));
    vlSelf->wasmetal_core__DOT___052776_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052767_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052766_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000873_)))))))));
    vlSelf->wasmetal_core__DOT___068713_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068695_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068694_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054225_)))))))));
    vlSelf->wasmetal_core__DOT___052779_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052765_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052764_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000796_)))))))));
    vlSelf->wasmetal_core__DOT___045140_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha7f22436__0))))))));
    vlSelf->wasmetal_core__DOT___045164_ = (1U & (0x41000041U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003288_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___028485_)))))));
    vlSelf->wasmetal_core__DOT__divider__02esign_a 
        = (1U & (0xd0U >> (((IData)(vlSelf->wasmetal_core__DOT___052584_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___052583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034342_)))));
    vlSelf->wasmetal_core__DOT___048170_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb653ab3a__0)))));
    vlSelf->wasmetal_core__DOT___000657_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb653ab3a__0))));
    vlSelf->wasmetal_core__DOT___067446_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067444_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067443_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1bU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048241_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3063303a__0)))));
    vlSelf->wasmetal_core__DOT___000635_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3063303a__0))));
    vlSelf->wasmetal_core__DOT___067397_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067395_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048182_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h69cbf44b__0)))));
    vlSelf->wasmetal_core__DOT___000613_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h69cbf44b__0))));
    vlSelf->wasmetal_core__DOT___052258_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052234_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7bad9dec__0))))))));
    vlSelf->wasmetal_core__DOT___045163_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028481_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028482_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028484_)))));
    vlSelf->wasmetal_core__DOT___067296_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067295_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067294_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048257_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h81d9a883__0)))));
    vlSelf->wasmetal_core__DOT___000591_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h81d9a883__0))));
    vlSelf->wasmetal_core__DOT___067253_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067251_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b27__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048180_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d8dd092__0)))));
    vlSelf->wasmetal_core__DOT___000564_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1d8dd092__0))));
    vlSelf->wasmetal_core__DOT___051954_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051953_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051951_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (1ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003332_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003314_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004314_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004300_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004062_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004044_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005040_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005028_))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005380_)))))))));
    vlSelf->wasmetal_core__DOT___067144_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067141_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x17U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048243_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0989e186__0)))));
    vlSelf->wasmetal_core__DOT___000542_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0989e186__0))));
    vlSelf->wasmetal_core__DOT___054005_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___003416_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9b6103f__0))));
    vlSelf->wasmetal_core__DOT___054018_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005096_))) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9b6103f__0))));
    vlSelf->wasmetal_core__DOT___045183_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028478_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028479_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028480_)))));
    vlSelf->wasmetal_core__DOT___048174_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93789414__0)))));
    vlSelf->wasmetal_core__DOT___000520_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h93789414__0))));
    vlSelf->wasmetal_core__DOT___044545_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005176_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf95886a6__0))))))));
    vlSelf->wasmetal_core__DOT___045442_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052527_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052237_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052236_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf95886a6__0))))))));
    vlSelf->wasmetal_core__DOT___048069_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h62980089__0)))));
    vlSelf->wasmetal_core__DOT___000498_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h62980089__0))));
    vlSelf->wasmetal_core__DOT___045158_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003348_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005164_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005096_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbaa2fe71__0))))))));
    vlSelf->wasmetal_core__DOT___066954_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066953_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066952_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x14U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b23__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048045_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2af30db__0)))));
    vlSelf->wasmetal_core__DOT___000476_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2af30db__0))));
    vlSelf->wasmetal_core__DOT___045182_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028475_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028476_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028477_)))));
    vlSelf->wasmetal_core__DOT___066875_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066873_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048058_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hba3bfb32__0)))));
    vlSelf->wasmetal_core__DOT___000464_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hba3bfb32__0))));
    vlSelf->wasmetal_core__DOT___048041_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5a48cd94__0)))));
    vlSelf->wasmetal_core__DOT___000432_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5a48cd94__0))));
    vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001875_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128640___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__0__KET__ 
        = ((9U >> (IData)(vlSelf->__VdfgTmp_h4ae0787e__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___003190_));
    vlSelf->wasmetal_core__DOT___048142_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h76eadb80__0)))));
    vlSelf->wasmetal_core__DOT___000419_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h76eadb80__0))));
    vlSelf->wasmetal_core__DOT___045181_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028471_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028473_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028474_)))));
    vlSelf->wasmetal_core__DOT___066624_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066623_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066622_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x10U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b19__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048019_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h58ec7cd3__0)))));
    vlSelf->wasmetal_core__DOT___001646_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h58ec7cd3__0))));
    vlSelf->wasmetal_core__DOT___052670_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052666_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052665_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052664_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005284_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005266_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___004892_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003428_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003416_)))))))));
    vlSelf->wasmetal_core__DOT___048073_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf275be9a__0)))));
    vlSelf->wasmetal_core__DOT___001624_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf275be9a__0))));
    vlSelf->wasmetal_core__DOT___052751_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052750_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001613_)))))));
    vlSelf->wasmetal_core__DOT___048009_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4781af3e__0)))));
    vlSelf->wasmetal_core__DOT___001612_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4781af3e__0))));
    vlSelf->wasmetal_core__DOT___054034_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054029_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054028_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005300_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005028_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___004960_))))))))))));
    vlSelf->wasmetal_core__DOT___045180_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028468_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028469_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028470_)))));
    vlSelf->wasmetal_core__DOT___048694_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h808c51bd__0)))));
    vlSelf->wasmetal_core__DOT___001580_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h808c51bd__0))));
    vlSelf->wasmetal_core__DOT___066302_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066298_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054095_)))))))));
    vlSelf->wasmetal_core__DOT___048192_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haaaaa9f9__0)))));
    vlSelf->wasmetal_core__DOT___001568_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haaaaa9f9__0))));
    vlSelf->wasmetal_core__DOT___066209_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066203_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054091_)))))))));
    vlSelf->wasmetal_core__DOT___048237_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h60633cb7__0)))));
    vlSelf->wasmetal_core__DOT___001536_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h60633cb7__0))));
    vlSelf->wasmetal_core__DOT___045179_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028465_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028466_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028467_)))));
    vlSelf->wasmetal_core__DOT___066069_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066066_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066065_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054087_)))))))));
    vlSelf->wasmetal_core__DOT___048188_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc1bc9aa3__0)))));
    vlSelf->wasmetal_core__DOT___001524_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1bc9aa3__0))));
    vlSelf->wasmetal_core__DOT___066007_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066004_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b12__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054083_)))))));
    vlSelf->wasmetal_core__DOT___048261_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h38c61391__0)))));
    vlSelf->wasmetal_core__DOT___001425_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38c61391__0))));
    vlSelf->wasmetal_core__DOT___054000_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053997_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053996_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___004892_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___004448_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d))))))))))));
    vlSelf->wasmetal_core__DOT___065888_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065885_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065884_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054079_)))))))));
    vlSelf->wasmetal_core__DOT___048200_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7b1a2166__0)))));
    vlSelf->wasmetal_core__DOT___001413_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7b1a2166__0))));
    vlSelf->wasmetal_core__DOT___050341_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050339_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050338_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003558_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003542_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003524_)))))))));
    vlSelf->wasmetal_core__DOT___045178_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028462_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028463_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028464_)))));
    vlSelf->wasmetal_core__DOT___065792_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065789_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065788_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___048233_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h35d7421d__0)))));
    vlSelf->wasmetal_core__DOT___001381_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h35d7421d__0))));
    vlSelf->wasmetal_core__DOT___050354_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050349_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050348_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___004522_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___004358_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004340_)))))));
    vlSelf->wasmetal_core__DOT___065732_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065724_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065723_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054071_)))))))));
    vlSelf->wasmetal_core__DOT___048194_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd822ef23__0)))));
    vlSelf->wasmetal_core__DOT___001369_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd822ef23__0))));
    vlSelf->wasmetal_core__DOT___065594_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065592_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065591_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 5U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___048065_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hae88697a__0)))));
    vlSelf->wasmetal_core__DOT___001487_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae88697a__0))));
    vlSelf->wasmetal_core__DOT___045177_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028490_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028491_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028492_)))));
    vlSelf->wasmetal_core__DOT___065505_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065502_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054063_)))))));
    vlSelf->wasmetal_core__DOT___048015_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2996e40e__0)))));
    vlSelf->wasmetal_core__DOT___001475_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2996e40e__0))));
    vlSelf->wasmetal_core__DOT___052671_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051986_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003208_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003151_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004758_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))))));
    vlSelf->wasmetal_core__DOT___065399_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054059_)))))));
    vlSelf->wasmetal_core__DOT___048155_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcab9d929__0)))));
    vlSelf->wasmetal_core__DOT___001443_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcab9d929__0))));
    vlSelf->wasmetal_core__DOT___065287_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065284_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065283_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054055_)))))))));
    vlSelf->wasmetal_core__DOT___048029_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a4b1d7e__0)))));
    vlSelf->wasmetal_core__DOT___001437_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a4b1d7e__0))));
    vlSelf->wasmetal_core__DOT___052570_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052477_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052476_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h91f69850__0)))));
    vlSelf->wasmetal_core__DOT___045176_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028487_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028488_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028489_)))));
    vlSelf->wasmetal_core__DOT___065160_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065157_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054051_)))))));
    vlSelf->wasmetal_core__DOT___048151_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h99694808__0)))));
    vlSelf->wasmetal_core__DOT___001886_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h99694808__0))));
    vlSelf->wasmetal_core__DOT___065047_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065044_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054047_)))))));
    vlSelf->wasmetal_core__DOT___048035_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003147_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb773d3a6__0)))));
    vlSelf->wasmetal_core__DOT___001874_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000417_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb773d3a6__0))));
    vlSelf->wasmetal_core__DOT___054033_ = (1U & (IData)(
                                                         (0x1001000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054025_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054024_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003632_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003270_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___003780_))))))))))));
    vlSelf->wasmetal_core__DOT___052758_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052753_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052752_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001414_)))))))));
    vlSelf->wasmetal_core__DOT___045173_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___028472_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___028483_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028486_)))));
    vlSelf->wasmetal_core__DOT___064887_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064883_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054043_)))))));
    vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128475___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128140___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031070_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128323___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___056746_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d))));
    vlSelf->__VdfgTmp_h51befd44__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004783_));
    vlSelf->__VdfgTmp_h8916279c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5877aba2__0)));
    vlSelf->wasmetal_core__DOT___056777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d))));
    vlSelf->__VdfgTmp_h4403b5cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d));
    vlSelf->__VdfgTmp_ha84b0b95__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004925_));
    vlSelf->__VdfgTmp_hd9f044bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9c9d0618__0)));
    vlSelf->wasmetal_core__DOT___048859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___070044_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063450_))));
    vlSelf->wasmetal_core__DOT___056745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d))));
    vlSelf->__VdfgTmp_h6d3f2850__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004801_));
    vlSelf->__VdfgTmp_hf2656e40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h79a44c81__0)));
    vlSelf->wasmetal_core__DOT___005659_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8dbe6334__0))));
    vlSelf->wasmetal_core__DOT___056778_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d))));
    vlSelf->__VdfgTmp_h4f39dfcd__0 = (((IData)(vlSelf->wasmetal_core__DOT___004943_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d));
    vlSelf->__VdfgTmp_h3b966d55__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004943_));
    vlSelf->__VdfgTmp_hff1fe4fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h79b790c2__0)));
    vlSelf->wasmetal_core__DOT___048860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___056731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d))));
    vlSelf->wasmetal_core__DOT___048780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))));
    vlSelf->wasmetal_core__DOT___054808_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003449_))))));
    vlSelf->__VdfgTmp_hbb98e230__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfd746550__0)));
    vlSelf->wasmetal_core__DOT___056730_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d))));
    vlSelf->__VdfgTmp_h585a3ceb__0 = (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d));
    vlSelf->__VdfgTmp_h633a8051__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003105_));
    vlSelf->__VdfgTmp_h4f29d017__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h45475158__0)));
    vlSelf->wasmetal_core__DOT___005504_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h52266111__0))));
    vlSelf->wasmetal_core__DOT___056968_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d))));
    vlSelf->wasmetal_core__DOT___051493_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004709_))))));
    vlSelf->__VdfgTmp_hce0059e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hdb8b9d9d__0)));
    vlSelf->wasmetal_core__DOT___057128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d))));
    vlSelf->__VdfgTmp_had719570__0 = (((IData)(vlSelf->wasmetal_core__DOT___004487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d));
    vlSelf->__VdfgTmp_heb8a147e__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004487_));
    vlSelf->__VdfgTmp_h3d3eaa9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9699bb18__0)));
    vlSelf->__VdfgTmp_h2d637bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004993_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d));
    vlSelf->__VdfgTmp_h136edfac__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004993_));
    vlSelf->__VdfgTmp_hc530df9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h928bb96c__0)));
    vlSelf->wasmetal_core__DOT___048684_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057286_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d))));
    vlSelf->__VdfgTmp_h3ce0f075__0 = (((IData)(vlSelf->wasmetal_core__DOT___004339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d));
    vlSelf->wasmetal_core__DOT___054948_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004339_))))));
    vlSelf->__VdfgTmp_h5f14afc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1d34c5b9__0)));
    vlSelf->wasmetal_core__DOT___057095_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d))));
    vlSelf->__VdfgTmp_h1bd58642__0 = (((IData)(vlSelf->wasmetal_core__DOT___004857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d));
    vlSelf->wasmetal_core__DOT___054909_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004857_))))));
    vlSelf->__VdfgTmp_h0e7ef094__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf0d36e17__0)));
    vlSelf->wasmetal_core__DOT___048851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->__VdfgTmp_hb73e868c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d));
    vlSelf->__VdfgTmp_h5f6c8a95__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005265_));
    vlSelf->__VdfgTmp_h1ad74d3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h778ea1a1__0)));
    vlSelf->wasmetal_core__DOT___048849_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057443_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d))));
    vlSelf->__VdfgTmp_hb1867682__0 = (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d));
    vlSelf->__VdfgTmp_hf9b00456__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005197_));
    vlSelf->__VdfgTmp_h83a675b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha95ffc90__0)));
    vlSelf->wasmetal_core__DOT___048869_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d))));
    vlSelf->wasmetal_core__DOT___048890_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))));
    vlSelf->wasmetal_core__DOT___054987_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004413_))))));
    vlSelf->__VdfgTmp_h9ebbc558__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h92dd6962__0)));
    vlSelf->wasmetal_core__DOT___056967_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d))));
    vlSelf->__VdfgTmp_h18ff28cf__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004727_));
    vlSelf->__VdfgTmp_hbf3b567a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h103d8e23__0)));
    vlSelf->wasmetal_core__DOT___005647_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7d4fca25__0))));
    vlSelf->wasmetal_core__DOT___057127_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d))));
    vlSelf->__VdfgTmp_h7cf17ecc__0 = (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d));
    vlSelf->__VdfgTmp_h51fc7bb2__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003097_));
    vlSelf->__VdfgTmp_h68d11ed0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbbacc71f__0)));
    vlSelf->wasmetal_core__DOT___005557_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d77f97__0))));
    vlSelf->wasmetal_core__DOT___057288_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))));
    vlSelf->wasmetal_core__DOT___054956_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003099_))))));
    vlSelf->__VdfgTmp_hb18976f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6b621180__0)));
    vlSelf->wasmetal_core__DOT___005541_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0176237__0))));
    vlSelf->wasmetal_core__DOT___057390_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d))));
    vlSelf->wasmetal_core__DOT___054995_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003101_))))));
    vlSelf->__VdfgTmp_hab3c597f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h880089dc__0)));
    vlSelf->wasmetal_core__DOT___005549_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbacded4f__0))));
    vlSelf->wasmetal_core__DOT___057077_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d))));
    vlSelf->__VdfgTmp_h957273a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005011_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d));
    vlSelf->__VdfgTmp_h8541949a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005011_));
    vlSelf->__VdfgTmp_h815644ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5f30aa50__0)));
    vlSelf->wasmetal_core__DOT___048685_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d))));
    vlSelf->wasmetal_core__DOT___054901_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004875_))))));
    vlSelf->__VdfgTmp_hbaaa25aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc83e3035__0));
    vlSelf->wasmetal_core__DOT___048852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d))));
    vlSelf->wasmetal_core__DOT___054951_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005283_))))));
    vlSelf->__VdfgTmp_hde99fb2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4e776e09__0)));
    vlSelf->wasmetal_core__DOT___048850_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___056984_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d))));
    vlSelf->wasmetal_core__DOT___048773_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))));
    vlSelf->wasmetal_core__DOT___051491_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003523_))))));
    vlSelf->__VdfgTmp_h86c1a93d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1b5c1c30__0)));
    vlSelf->wasmetal_core__DOT___057442_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d))));
    vlSelf->__VdfgTmp_h39dd035b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d));
    vlSelf->__VdfgTmp_h46681fd6__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005215_));
    vlSelf->__VdfgTmp_hc08ecb6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h77d6a635__0)));
    vlSelf->wasmetal_core__DOT___048870_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d))));
    vlSelf->__VdfgTmp_hb14b0648__0 = (((IData)(vlSelf->wasmetal_core__DOT___004117_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d));
    vlSelf->__VdfgTmp_ha853ba7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004117_));
    vlSelf->__VdfgTmp_h5d9bd5b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc2378e95__0)));
    vlSelf->wasmetal_core__DOT___057290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d))));
    vlSelf->__VdfgTmp_h491e13b5__0 = (((IData)(vlSelf->wasmetal_core__DOT___004191_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d));
    vlSelf->wasmetal_core__DOT___054949_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004191_))))));
    vlSelf->__VdfgTmp_hdc49a285__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3e014765__0)));
    vlSelf->wasmetal_core__DOT___056983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d))));
    vlSelf->wasmetal_core__DOT___054861_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003107_))))));
    vlSelf->__VdfgTmp_h79bfec12__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h1dfe6e3d__0)));
    vlSelf->wasmetal_core__DOT___005508_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcde84ebb__0))));
    vlSelf->wasmetal_core__DOT___057385_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d))));
    vlSelf->wasmetal_core__DOT___048823_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))));
    vlSelf->__VdfgTmp_hf41e7ecd__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004635_));
    vlSelf->__VdfgTmp_h84d68e3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb797ade1__0)));
    vlSelf->wasmetal_core__DOT___057129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d))));
    vlSelf->wasmetal_core__DOT___054907_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003117_))))));
    vlSelf->__VdfgTmp_h692f01d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc85d0f69__0)));
    vlSelf->wasmetal_core__DOT___005517_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0adea875__0))));
    vlSelf->wasmetal_core__DOT___057289_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d))));
    vlSelf->__VdfgTmp_h98d262dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d));
    vlSelf->wasmetal_core__DOT___054957_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003119_))))));
    vlSelf->__VdfgTmp_hc03ee7e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9d0797f2__0)));
    vlSelf->wasmetal_core__DOT___005561_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79860539__0))));
    vlSelf->wasmetal_core__DOT___057384_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))));
    vlSelf->wasmetal_core__DOT___054996_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003121_))))));
    vlSelf->__VdfgTmp_h437f0271__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he9b54a3e__0)));
    vlSelf->wasmetal_core__DOT___005521_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5978f26f__0))));
    vlSelf->wasmetal_core__DOT___056769_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d))));
    vlSelf->__VdfgTmp_ha2b26e01__0 = (((IData)(vlSelf->wasmetal_core__DOT___004043_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d));
    vlSelf->wasmetal_core__DOT___054809_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004043_))))));
    vlSelf->__VdfgTmp_hbb6385ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h2e498b5e__0)));
    vlSelf->wasmetal_core__DOT___056768_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d))));
    vlSelf->__VdfgTmp_h22b2afd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d));
    vlSelf->__VdfgTmp_h1eef7f72__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004061_));
    vlSelf->__VdfgTmp_h13d4f79e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0fc0fcd7__0)));
    vlSelf->wasmetal_core__DOT___005545_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31225405__0))));
    vlSelf->wasmetal_core__DOT___011459_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d))));
    vlSelf->wasmetal_core__DOT___048805_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))));
    vlSelf->wasmetal_core__DOT___054767_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003233_))))));
    vlSelf->__VdfgTmp_h890db370__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5b4e7e80__0)));
    vlSelf->wasmetal_core__DOT___056599_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d))));
    vlSelf->__VdfgTmp_h339d407e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d));
    vlSelf->__VdfgTmp_h10697dc9__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005333_));
    vlSelf->__VdfgTmp_h782800f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb476a254__0)));
    vlSelf->wasmetal_core__DOT___048841_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___070033_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070029_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070028_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b97__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[3U] 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___011458_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))));
    vlSelf->wasmetal_core__DOT___054775_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003095_))))));
    vlSelf->__VdfgTmp_h898c2bb0__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h5702c3be__0));
    vlSelf->wasmetal_core__DOT___005651_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h09328eec__0))));
    vlSelf->wasmetal_core__DOT___056622_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d))));
    vlSelf->wasmetal_core__DOT___048765_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))));
    vlSelf->wasmetal_core__DOT___054768_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003597_))))));
    vlSelf->__VdfgTmp_h7751d301__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc0be46f7__0)));
    vlSelf->wasmetal_core__DOT___056600_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d))));
    vlSelf->__VdfgTmp_hb12ee9bf__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005351_));
    vlSelf->__VdfgTmp_heeb73844__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8511382f__0));
    vlSelf->wasmetal_core__DOT___048842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___056623_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))));
    vlSelf->wasmetal_core__DOT___054777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003111_))))));
    vlSelf->wasmetal_core__DOT___054778_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d))))));
    vlSelf->__VdfgTmp_h5c5b87f4__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hacafc5c0__0));
    vlSelf->wasmetal_core__DOT___005529_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hff8a2099__0))));
    vlSelf->wasmetal_core__DOT___057205_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d))));
    vlSelf->wasmetal_core__DOT___054908_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003901_))))));
    vlSelf->__VdfgTmp_h2e164c3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h063ae0f2__0)));
    vlSelf->__VdfgTmp_hfd72e8ff__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003381_));
    vlSelf->__VdfgTmp_h707c99af__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha36008d9__0)));
    vlSelf->wasmetal_core__DOT___063766_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d)))))))));
    vlSelf->wasmetal_core__DOT___057449_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d))));
    vlSelf->wasmetal_core__DOT___054998_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003313_))))));
    vlSelf->__VdfgTmp_hef8f7e11__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hab2bfea3__0)));
    vlSelf->wasmetal_core__DOT___069736_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069732_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069731_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b83__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x11U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___057044_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d))));
    vlSelf->wasmetal_core__DOT___051498_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003827_))))));
    vlSelf->__VdfgTmp_h4f418a9b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc135e20a__0)));
    vlSelf->__VdfgTmp_ha720ddd6__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d));
    vlSelf->__VdfgTmp_hdb184deb__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003845_));
    vlSelf->__VdfgTmp_hb918ea35__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbe45befc__0)));
    vlSelf->wasmetal_core__DOT___057092_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d))));
    vlSelf->__VdfgTmp_h63a6348e__0 = (((IData)(vlSelf->wasmetal_core__DOT___003919_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d));
    vlSelf->wasmetal_core__DOT___054900_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003919_))))));
    vlSelf->__VdfgTmp_h6277318a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h74dbdf51__0));
    vlSelf->wasmetal_core__DOT___057247_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d))));
    vlSelf->__VdfgTmp_h8ae31ec8__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d));
    vlSelf->__VdfgTmp_h9eae91ba__0 = (((IData)(vlSelf->wasmetal_core__DOT___003399_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d));
    vlSelf->__VdfgTmp_h52bd55da__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003399_));
    vlSelf->__VdfgTmp_ha4d9f57f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_ha6dc66a3__0)));
    vlSelf->wasmetal_core__DOT___057450_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d))));
    vlSelf->__VdfgTmp_h76527ded__0 = (((IData)(vlSelf->wasmetal_core__DOT___003331_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d));
    vlSelf->__VdfgTmp_h979ce723__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003331_));
    vlSelf->__VdfgTmp_haf65e04e__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0f5e432a__0)));
    vlSelf->wasmetal_core__DOT___056598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d))));
    vlSelf->wasmetal_core__DOT___048757_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))));
    vlSelf->wasmetal_core__DOT___054769_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___004265_))))));
    vlSelf->__VdfgTmp_h9fcdfa16__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he315da1d__0)));
    vlSelf->wasmetal_core__DOT___056597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d))));
    vlSelf->wasmetal_core__DOT___054779_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003115_))))));
    vlSelf->__VdfgTmp_hd5b1a253__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbd0c1b7__0));
    vlSelf->wasmetal_core__DOT___005537_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h177129ae__0))));
    vlSelf->wasmetal_core__DOT___050409_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))));
    vlSelf->wasmetal_core__DOT___056382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))));
    vlSelf->__VdfgTmp_h2a4ee2b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___003150_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d));
    vlSelf->wasmetal_core__DOT___054708_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003150_))))));
    vlSelf->wasmetal_core__DOT___054709_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hd0bdda62__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d))))));
    vlSelf->__VdfgTmp_h1ccba379__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd0bdda62__0));
    vlSelf->wasmetal_core__DOT___056336_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d))));
    vlSelf->__VdfgTmp_h8aa65d09__0 = (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d));
    vlSelf->wasmetal_core__DOT___054674_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005061_))))));
    vlSelf->wasmetal_core__DOT___054675_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h24206284__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d))))));
    vlSelf->__VdfgTmp_hf6ccaf8c__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h24206284__0));
    vlSelf->wasmetal_core__DOT___048861_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___044039_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d))));
    vlSelf->__VdfgTmp_h3a53928b__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d));
    vlSelf->__VdfgTmp_h33bf650d__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d));
    vlSelf->wasmetal_core__DOT___054691_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003091_))))));
    vlSelf->wasmetal_core__DOT___054692_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d))))));
    vlSelf->__VdfgTmp_hc1ba948d__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hffad8cfa__0));
    vlSelf->wasmetal_core__DOT___003134_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048022_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048023_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))))))));
    vlSelf->wasmetal_core__DOT___005553_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha59547bb__0))));
    vlSelf->wasmetal_core__DOT___056371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))));
    vlSelf->__VdfgTmp_h2112a96a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d));
    vlSelf->__VdfgTmp_hf440d852__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003745_));
    vlSelf->wasmetal_core__DOT___054706_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h477043a8__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d))))));
    vlSelf->__VdfgTmp_h7c46a142__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h477043a8__0));
    vlSelf->wasmetal_core__DOT___056335_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))));
    vlSelf->wasmetal_core__DOT___054698_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005079_))))));
    vlSelf->wasmetal_core__DOT___054699_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h3ac48b87__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d))))));
    vlSelf->__VdfgTmp_hd68176c7__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3ac48b87__0));
    vlSelf->wasmetal_core__DOT___048862_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___070137_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052847_))));
    vlSelf->wasmetal_core__DOT___044033_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))))))));
    vlSelf->__VdfgTmp_he0c10a9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d));
    vlSelf->__VdfgTmp_h3fcac4a1__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d));
    vlSelf->__VdfgTmp_h23f02d0a__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003109_));
    vlSelf->wasmetal_core__DOT___054689_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h350dca3c__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d))))));
    vlSelf->__VdfgTmp_he6e69fea__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h350dca3c__0));
    vlSelf->wasmetal_core__DOT___005533_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h601dd350__0))));
    vlSelf->wasmetal_core__DOT___056331_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))));
    vlSelf->wasmetal_core__DOT___048818_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))));
    vlSelf->__VdfgTmp_h691e257b__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003969_));
    vlSelf->wasmetal_core__DOT___054702_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_hf3cb0d91__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d))))));
    vlSelf->__VdfgTmp_h88a0444f__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf3cb0d91__0));
    vlSelf->wasmetal_core__DOT___050416_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d))))));
    vlSelf->wasmetal_core__DOT___056501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))));
    vlSelf->__VdfgTmp_h73150903__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003113_));
    vlSelf->wasmetal_core__DOT___054683_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x35U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h154ca593__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d))))));
    vlSelf->__VdfgTmp_h63aeb1f3__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h154ca593__0));
    vlSelf->wasmetal_core__DOT___005655_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h71a6f88b__0))));
    vlSelf->wasmetal_core__DOT___044036_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))))))));
    vlSelf->wasmetal_core__DOT___055046_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005581_))))));
    vlSelf->__VdfgTmp_h0919a607__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hbd4ae96e__0)));
    vlSelf->wasmetal_core__DOT___048922_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057572_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d))));
    vlSelf->wasmetal_core__DOT___048750_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))));
    vlSelf->__VdfgTmp_hc9d89c9c__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___004561_));
    vlSelf->__VdfgTmp_h7a210d44__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hce00e764__0)));
    vlSelf->wasmetal_core__DOT___050407_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d))))));
    vlSelf->wasmetal_core__DOT___057571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d))));
    vlSelf->wasmetal_core__DOT___055041_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003103_))))));
    vlSelf->__VdfgTmp_hde24342a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h903282ee__0)));
    vlSelf->wasmetal_core__DOT___005565_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a72eea__0))));
    vlSelf->wasmetal_core__DOT___057539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d))));
    vlSelf->__VdfgTmp_h67e9fb36__0 = (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d));
    vlSelf->wasmetal_core__DOT___055036_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005599_))))));
    vlSelf->__VdfgTmp_hd79df6c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h66a2df13__0)));
    vlSelf->wasmetal_core__DOT___048923_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___057573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d))));
    vlSelf->wasmetal_core__DOT___048731_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))));
    vlSelf->wasmetal_core__DOT___055034_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003671_))))));
    vlSelf->__VdfgTmp_hb4659c85__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h5f949c7c__0)));
    vlSelf->wasmetal_core__DOT___048730_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___050408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d))));
    vlSelf->wasmetal_core__DOT___057574_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))));
    vlSelf->wasmetal_core__DOT___047862_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))))));
    vlSelf->wasmetal_core__DOT___055042_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003689_))))));
    vlSelf->__VdfgTmp_hb69256f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h4b62075b__0)));
    vlSelf->wasmetal_core__DOT___048729_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000666_))));
    vlSelf->wasmetal_core__DOT___005525_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha13bce2f__0))));
    vlSelf->wasmetal_core__DOT___044035_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))))))));
    vlSelf->__VdfgTmp_hc2efa860__0 = (((IData)(vlSelf->wasmetal_core__DOT___005129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d));
    vlSelf->__VdfgTmp_h5c8699d0__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005129_));
    vlSelf->__VdfgTmp_hdfae4d94__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb797e152__0)));
    vlSelf->wasmetal_core__DOT___069823_ = (1U & (IData)(
                                                         (0x153f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069819_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b87__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->cmd_data[2U] 
                                                                        >> 0x15U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2ee8e39__0))))))));
    vlSelf->wasmetal_core__DOT___057536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d))));
    vlSelf->__VdfgTmp_h5fb0de62__0 = (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d));
    vlSelf->wasmetal_core__DOT___055035_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005147_))))));
    vlSelf->__VdfgTmp_h6ce01618__0 = (((IData)(vlSelf->wasmetal_core__DOT___007203_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h26cb2e9d__0)));
    vlSelf->type_actual = (((0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d) 
                                                   << 1U) 
                                                  | (vlSelf->function_type 
                                                     >> 0x1fU)))) 
                            << 0x1fU) | ((0x40000000U 
                                          & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1eU))))) 
                                             << 0x1eU)) 
                                         | ((0x20000000U 
                                             & ((0xacU 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (vlSelf->function_type 
                                                           >> 0x1dU))))) 
                                                << 0x1dU)) 
                                            | ((0x10000000U 
                                                & ((0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (vlSelf->function_type 
                                                              >> 0x1cU))))) 
                                                   << 0x1cU)) 
                                               | ((0x8000000U 
                                                   & ((0xacU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (vlSelf->function_type 
                                                                 >> 0x1bU))))) 
                                                      << 0x1bU)) 
                                                  | ((0x4000000U 
                                                      & ((0xacU 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d) 
                                                               << 1U) 
                                                              | (1U 
                                                                 & (vlSelf->function_type 
                                                                    >> 0x1aU))))) 
                                                         << 0x1aU)) 
                                                     | ((0x2000000U 
                                                         & ((0xacU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                  << 1U) 
                                                                 | (1U 
                                                                    & (vlSelf->function_type 
                                                                       >> 0x19U))))) 
                                                            << 0x19U)) 
                                                        | ((0x1000000U 
                                                            & ((0xacU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (vlSelf->function_type 
                                                                          >> 0x18U))))) 
                                                               << 0x18U)) 
                                                           | ((0x800000U 
                                                               & ((0xacU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->function_type 
                                                                             >> 0x17U))))) 
                                                                  << 0x17U)) 
                                                              | ((0x400000U 
                                                                  & ((0xacU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (vlSelf->function_type 
                                                                                >> 0x16U))))) 
                                                                     << 0x16U)) 
                                                                 | ((0x200000U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x15U))))) 
                                                                        << 0x15U)) 
                                                                    | ((0x100000U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x14U))))) 
                                                                           << 0x14U)) 
                                                                       | ((0x80000U 
                                                                           & ((0xacU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x13U))))) 
                                                                              << 0x13U)) 
                                                                          | ((0x40000U 
                                                                              & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x12U))))) 
                                                                                << 0x12U)) 
                                                                             | ((0x20000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x11U))))) 
                                                                                << 0x11U)) 
                                                                                | ((0x10000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0x10U))))) 
                                                                                << 0x10U)) 
                                                                                | ((0x8000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xfU))))) 
                                                                                << 0xfU)) 
                                                                                | ((0x4000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xeU))))) 
                                                                                << 0xeU)) 
                                                                                | ((0x2000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xdU))))) 
                                                                                << 0xdU)) 
                                                                                | ((0x1000U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xcU))))) 
                                                                                << 0xcU)) 
                                                                                | ((0x800U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xbU))))) 
                                                                                << 0xbU)) 
                                                                                | ((0x400U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 0xaU))))) 
                                                                                << 0xaU)) 
                                                                                | ((0x200U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 9U))))) 
                                                                                << 9U)) 
                                                                                | ((0x100U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 8U))))) 
                                                                                << 8U)) 
                                                                                | ((0x80U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 7U))))) 
                                                                                << 7U)) 
                                                                                | ((0x40U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 6U))))) 
                                                                                << 6U)) 
                                                                                | ((0x20U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 5U))))) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 4U))))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 3U))))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 2U))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->function_type 
                                                                                >> 1U))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052876_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & vlSelf->function_type))))))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052266_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052193_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052192_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052191_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052190_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h14b4bf2b__0))))))));
    vlSelf->wasmetal_core__DOT___026722_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005636_))));
    vlSelf->wasmetal_core__DOT___027192_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026992_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054247_))));
    vlSelf->wasmetal_core__DOT___010568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->__VdfgTmp_hdb4c449f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001330_));
    vlSelf->__VdfgTmp_h8696f73b__0 = (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d));
    vlSelf->wasmetal_core__DOT___007419_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h965c3061__0))))))));
    vlSelf->wasmetal_core__DOT___034507_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->__VdfgTmp_he9d835d5__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047989_)))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb85239a7__0)))));
    vlSelf->wasmetal_core__DOT___068646_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068642_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054223_)))))));
    vlSelf->wasmetal_core__DOT___026709_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003876_))));
    vlSelf->wasmetal_core__DOT___027179_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026979_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054223_))));
    vlSelf->wasmetal_core__DOT___010538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->wasmetal_core__DOT___048902_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))))));
    vlSelf->__VdfgTmp_hbf523586__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000927_));
    vlSelf->__VdfgTmp_hf33edb7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d));
    vlSelf->wasmetal_core__DOT___007308_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf825dcba__0))))))));
    vlSelf->wasmetal_core__DOT___048903_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___034495_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->__VdfgTmp_hde5a6edf__0 = ((2U & ((0xe0U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70d2167a__0))) 
                                             << 1U)) 
                                      | (1U & (0xeU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h64e10f56__0)))));
    vlSelf->wasmetal_core__DOT___068616_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068595_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054221_)))))))));
    vlSelf->wasmetal_core__DOT___026708_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004092_))));
    vlSelf->wasmetal_core__DOT___027178_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026978_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054221_))));
    vlSelf->wasmetal_core__DOT___010537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___048919_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))))));
    vlSelf->__VdfgTmp_h379ad787__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000897_));
    vlSelf->__VdfgTmp_hb40a316f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d));
    vlSelf->wasmetal_core__DOT___007281_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7f74d59__0))))))));
    vlSelf->wasmetal_core__DOT___048920_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___034494_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___005546_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf93df92c__0))));
    vlSelf->wasmetal_core__DOT___068567_ = (1U & (IData)(
                                                         (0xaf3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068545_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054219_)))))))));
    vlSelf->wasmetal_core__DOT___044325_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed1a6099__0))))))));
    vlSelf->wasmetal_core__DOT___026706_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004314_))));
    vlSelf->wasmetal_core__DOT___027176_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026976_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054219_))));
    vlSelf->wasmetal_core__DOT___010540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___048921_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))))));
    vlSelf->__VdfgTmp_h375e931a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000896_));
    vlSelf->__VdfgTmp_h461c5ceb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d));
    vlSelf->wasmetal_core__DOT___007254_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hef5b3f20__0))))))));
    vlSelf->wasmetal_core__DOT___034493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___005538_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a9c07e1__0))));
    vlSelf->wasmetal_core__DOT___068513_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054217_)))))));
    vlSelf->wasmetal_core__DOT___026705_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004018_))));
    vlSelf->wasmetal_core__DOT___027175_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026975_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054217_))));
    vlSelf->wasmetal_core__DOT___056325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___048918_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))))));
    vlSelf->__VdfgTmp_hd06fbc0c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000873_));
    vlSelf->__VdfgTmp_h38e0bed2__0 = (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d));
    vlSelf->__VdfgTmp_h38ad22b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hfec86816__0)));
    vlSelf->wasmetal_core__DOT___034492_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___005656_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb9ea03dd__0))));
    vlSelf->wasmetal_core__DOT___068471_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068467_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068466_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054215_)))))))));
    vlSelf->wasmetal_core__DOT___050412_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))))))));
    vlSelf->wasmetal_core__DOT___026704_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003720_))));
    vlSelf->wasmetal_core__DOT___027174_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026974_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054215_))));
    vlSelf->wasmetal_core__DOT___010749_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___048898_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))))));
    vlSelf->__VdfgTmp_h2b7d2fec__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000872_));
    vlSelf->__VdfgTmp_hac359f24__0 = (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d));
    vlSelf->wasmetal_core__DOT___007417_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h97b1be8c__0))))))));
    vlSelf->wasmetal_core__DOT___034491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___005526_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33498483__0))));
    vlSelf->wasmetal_core__DOT___068394_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068391_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054213_)))))));
    vlSelf->wasmetal_core__DOT___044324_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h79eb8028__0))))))));
    vlSelf->wasmetal_core__DOT___026703_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004684_))));
    vlSelf->wasmetal_core__DOT___027173_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b46__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026973_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054213_))));
    vlSelf->wasmetal_core__DOT___010755_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___048901_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))));
    vlSelf->__VdfgTmp_hb948b455__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000849_));
    vlSelf->__VdfgTmp_h132c3402__0 = (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d));
    vlSelf->wasmetal_core__DOT___007390_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2cbbdbef__0))))))));
    vlSelf->wasmetal_core__DOT___034490_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___005522_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbd8e6335__0))));
    vlSelf->wasmetal_core__DOT___068335_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068334_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068333_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xaU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___026702_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004240_))));
    vlSelf->wasmetal_core__DOT___027172_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026972_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054211_))));
    vlSelf->wasmetal_core__DOT___010741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___048904_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))))));
    vlSelf->__VdfgTmp_h5dede88d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000848_));
    vlSelf->__VdfgTmp_h82148a8f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d));
    vlSelf->wasmetal_core__DOT___007364_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1fd76cb3__0))))))));
    vlSelf->wasmetal_core__DOT___034489_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___005562_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf0dacca2__0))));
    vlSelf->wasmetal_core__DOT___068283_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068281_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068280_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b44__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___026701_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004166_))));
    vlSelf->wasmetal_core__DOT___027171_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b44__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026971_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054209_))));
    vlSelf->wasmetal_core__DOT___010735_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___048899_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))))));
    vlSelf->__VdfgTmp_h8c7509c5__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000824_));
    vlSelf->__VdfgTmp_h33528dbb__0 = (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d));
    vlSelf->__VdfgTmp_h7678d7b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h598b279f__0)));
    vlSelf->wasmetal_core__DOT___048900_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___034488_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___005518_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2566b586__0))));
    vlSelf->wasmetal_core__DOT___068232_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068228_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068227_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054207_)))))))));
    vlSelf->wasmetal_core__DOT___044323_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h179c0c32__0))))))));
    vlSelf->wasmetal_core__DOT___026700_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003572_))));
    vlSelf->wasmetal_core__DOT___027170_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b43__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026970_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054207_))));
    vlSelf->wasmetal_core__DOT___010767_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___048894_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))))));
    vlSelf->__VdfgTmp_hc65b9dd7__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000825_));
    vlSelf->__VdfgTmp_h9319fdaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d));
    vlSelf->wasmetal_core__DOT___007305_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d1b60d2__0))))))));
    vlSelf->wasmetal_core__DOT___034487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___005509_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a2b04d__0))));
    vlSelf->wasmetal_core__DOT___068198_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068195_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054205_)))))));
    vlSelf->wasmetal_core__DOT___026699_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003498_))));
    vlSelf->wasmetal_core__DOT___027169_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026969_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054205_))));
    vlSelf->wasmetal_core__DOT___010761_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___048897_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))));
    vlSelf->__VdfgTmp_h483290db__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000796_));
    vlSelf->__VdfgTmp_h17bd1a59__0 = (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d));
    vlSelf->wasmetal_core__DOT___007278_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h38fb75d8__0))))))));
    vlSelf->wasmetal_core__DOT___034486_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___005505_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7f6ab5bd__0))));
    vlSelf->wasmetal_core__DOT___068147_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068142_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068141_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054203_)))))))));
    vlSelf->wasmetal_core__DOT___026698_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003646_))));
    vlSelf->wasmetal_core__DOT___027168_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026968_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054203_))));
    vlSelf->wasmetal_core__DOT___010773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___048895_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))))));
    vlSelf->__VdfgTmp_h268e4ef9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000795_));
    vlSelf->__VdfgTmp_h9963adf9__0 = (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d));
    vlSelf->wasmetal_core__DOT___007251_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe166c9c__0))))))));
    vlSelf->wasmetal_core__DOT___034485_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___005530_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2712d491__0))));
    vlSelf->wasmetal_core__DOT___044322_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df568d0__0))))))));
    vlSelf->wasmetal_core__DOT___026697_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003794_))));
    vlSelf->wasmetal_core__DOT___027167_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026967_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054201_))));
    vlSelf->wasmetal_core__DOT___056367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___048896_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))))));
    vlSelf->__VdfgTmp_he040c9e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000772_));
    vlSelf->__VdfgTmp_hc231438f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d));
    vlSelf->__VdfgTmp_h81bae7c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0)));
    vlSelf->wasmetal_core__DOT___034484_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___005534_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2f983ac6__0))));
    vlSelf->wasmetal_core__DOT___068017_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068013_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068012_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054199_)))))))));
    vlSelf->wasmetal_core__DOT___050414_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___026695_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004610_))));
    vlSelf->wasmetal_core__DOT___027165_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026965_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054199_))));
    vlSelf->wasmetal_core__DOT___010874_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___048905_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))))));
    vlSelf->__VdfgTmp_h877e6c65__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000771_));
    vlSelf->__VdfgTmp_h0e28c49d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d));
    vlSelf->wasmetal_core__DOT___007418_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94bf9d34__0))))))));
    vlSelf->wasmetal_core__DOT___034483_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___005566_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h158a449d__0))));
    vlSelf->wasmetal_core__DOT___067959_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067952_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054197_)))))));
    vlSelf->wasmetal_core__DOT___050428_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))))))));
    vlSelf->wasmetal_core__DOT___026694_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004462_))));
    vlSelf->wasmetal_core__DOT___027164_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026964_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054197_))));
    vlSelf->wasmetal_core__DOT___010868_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___048912_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))))));
    vlSelf->__VdfgTmp_h218f194f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000747_));
    vlSelf->__VdfgTmp_hde05f3fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d));
    vlSelf->wasmetal_core__DOT___007391_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h58f52bdc__0))))))));
    vlSelf->wasmetal_core__DOT___034482_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___005550_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2937d10d__0))));
    vlSelf->wasmetal_core__DOT___067894_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067890_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067889_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054195_)))))))));
    vlSelf->wasmetal_core__DOT___044321_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8e211f59__0))))))));
    vlSelf->wasmetal_core__DOT___050420_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___026693_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004388_))));
    vlSelf->wasmetal_core__DOT___027163_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026963_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054195_))));
    vlSelf->wasmetal_core__DOT___010860_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___048907_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))))));
    vlSelf->__VdfgTmp_hd87e5f33__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000748_));
    vlSelf->__VdfgTmp_h866cdbfa__0 = (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d));
    vlSelf->wasmetal_core__DOT___007365_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcf95a844__0))))))));
    vlSelf->wasmetal_core__DOT___034481_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___005542_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7dc0a46__0))));
    vlSelf->wasmetal_core__DOT___067860_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054193_)))))))));
    vlSelf->wasmetal_core__DOT___026692_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004536_))));
    vlSelf->wasmetal_core__DOT___027162_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026962_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054193_))));
    vlSelf->wasmetal_core__DOT___010854_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___048906_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))))));
    vlSelf->__VdfgTmp_h45ac64ad__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000723_));
    vlSelf->__VdfgTmp_hcfe971ad__0 = (((IData)(vlSelf->wasmetal_core__DOT___000723_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d));
    vlSelf->wasmetal_core__DOT___007339_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a4ea67__0))))))));
    vlSelf->wasmetal_core__DOT___034480_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___005558_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e7f092f__0))));
    vlSelf->wasmetal_core__DOT___067806_ = (1U & (IData)(
                                                         (0xaf3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067803_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054191_)))))))));
    vlSelf->wasmetal_core__DOT___026691_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004758_))));
    vlSelf->wasmetal_core__DOT___027161_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026961_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054191_))));
    vlSelf->wasmetal_core__DOT___010886_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___048913_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)))))));
    vlSelf->__VdfgTmp_hb0eafd09__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000724_));
    vlSelf->__VdfgTmp_hf8cdee79__0 = (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d));
    vlSelf->wasmetal_core__DOT___007306_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf98ad324__0))))))));
    vlSelf->wasmetal_core__DOT___048914_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___034479_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___005648_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd1b03413__0))));
    vlSelf->wasmetal_core__DOT___044320_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1c632a11__0))))))));
    vlSelf->wasmetal_core__DOT___026690_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___004832_))));
    vlSelf->wasmetal_core__DOT___027160_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026960_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054189_))));
    vlSelf->wasmetal_core__DOT___010880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___048916_ = (1U & (0xca000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))))));
    vlSelf->__VdfgTmp_h9dd568d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000694_));
    vlSelf->__VdfgTmp_he7d3ff65__0 = (((IData)(vlSelf->wasmetal_core__DOT___000694_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d));
    vlSelf->wasmetal_core__DOT___007279_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84433958__0))))))));
    vlSelf->wasmetal_core__DOT___048917_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047996_))));
    vlSelf->wasmetal_core__DOT___034478_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___005660_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h59e987ab__0))));
    vlSelf->wasmetal_core__DOT___067656_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067652_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067651_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___026689_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003288_))));
    vlSelf->wasmetal_core__DOT___027159_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026959_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054186_))));
    vlSelf->wasmetal_core__DOT___010892_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->__VdfgTmp_h4bc445dd__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000693_));
    vlSelf->__VdfgTmp_hd40e4c18__0 = (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d));
    vlSelf->wasmetal_core__DOT___007252_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2ae5a25__0))))))));
    vlSelf->wasmetal_core__DOT___034477_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->wasmetal_core__DOT___005652_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf92587e4__0))));
    vlSelf->wasmetal_core__DOT___052574_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052453_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052452_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052451_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052450_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h23d702b8__0))))))));
    vlSelf->wasmetal_core__DOT___067590_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067586_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054182_)))))));
    vlSelf->wasmetal_core__DOT___063789_ = (1U & (IData)(
                                                         (0x7077000070777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053990_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[0U] 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063786_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___026688_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003208_))));
    vlSelf->wasmetal_core__DOT___027158_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___054478_)))));
    vlSelf->wasmetal_core__DOT___026958_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054182_))));
    vlSelf->wasmetal_core__DOT___056381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->__VdfgTmp_h80fb591c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000665_));
    vlSelf->__VdfgTmp_h9a79492f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d));
    vlSelf->wasmetal_core__DOT___007432_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4bbfe337__0))))))));
    vlSelf->wasmetal_core__DOT___034476_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->wasmetal_core__DOT___005554_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8427a44__0))));
    vlSelf->wasmetal_core__DOT___067538_ = (1U & (IData)(
                                                         (0x153f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067537_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->mem_rdata[0U] 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb457b6b4__0))))))));
    vlSelf->wasmetal_core__DOT___005572_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048003_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048006_)))))))));
    vlSelf->__VdfgTmp_h92d236ac__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___047989_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047990_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048004_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048003_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048007_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048006_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb85239a7__0))))))))));
    vlSelf->wasmetal_core__DOT___044319_ = (1U & (IData)(
                                                         (0xfce8e8c0e8c0e8c0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h561bfeb8__0))))))));
}
