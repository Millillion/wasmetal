#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__2(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__2\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___044119_;
    wasmetal_core__DOT___044119_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044717_;
    wasmetal_core__DOT___044717_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044724_;
    wasmetal_core__DOT___044724_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044725_;
    wasmetal_core__DOT___044725_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048337_;
    wasmetal_core__DOT___048337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048436_;
    wasmetal_core__DOT___048436_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053415_;
    wasmetal_core__DOT___053415_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070572_;
    wasmetal_core__DOT___070572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070579_;
    wasmetal_core__DOT___070579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070939_;
    wasmetal_core__DOT___070939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071474_;
    wasmetal_core__DOT___071474_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071479_;
    wasmetal_core__DOT___071479_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071483_;
    wasmetal_core__DOT___071483_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071487_;
    wasmetal_core__DOT___071487_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071494_;
    wasmetal_core__DOT___071494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071496_;
    wasmetal_core__DOT___071496_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071500_;
    wasmetal_core__DOT___071500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071502_;
    wasmetal_core__DOT___071502_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071505_;
    wasmetal_core__DOT___071505_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071508_;
    wasmetal_core__DOT___071508_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071511_;
    wasmetal_core__DOT___071511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071517_;
    wasmetal_core__DOT___071517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071522_;
    wasmetal_core__DOT___071522_ = 0;
    CData/*2:0*/ __VdfgTmp_he741bbfe__0;
    __VdfgTmp_he741bbfe__0 = 0;
    CData/*3:0*/ __VdfgTmp_hdba9480e__0;
    __VdfgTmp_hdba9480e__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___051214_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051212_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051208_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051209_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___049395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___048512_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051198_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051197_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___048547_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___048544_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___048538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___048543_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___048568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051195_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___051196_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051140_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051139_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051138_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051137_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049941_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051136_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051135_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050562_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___051134_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___051132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049946_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049948_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050368_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050555_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051131_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051130_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049943_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050469_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050468_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050466_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050465_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050088_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050089_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050440_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050436_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___049582_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050396_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050391_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___050390_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050374_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050375_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050370_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050372_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049426_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049424_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___050355_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___050356_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050279_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___050330_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050329_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___049583_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050326_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___050324_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050323_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049594_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___051379_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___049935_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___049922_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___049919_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049421_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___049951_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___049950_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___049949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___051378_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___049916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___049915_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___050471_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051246_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___051245_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___051244_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___050085_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050086_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___051233_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___051232_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049914_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___051234_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051213_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051211_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050734_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050376_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051206_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051192_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___050910_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___051190_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___050437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___051133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___050373_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050345_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050083_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050082_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT___050084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048541_))));
    vlSelf->wasmetal_core__DOT___051489_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048567_))));
    vlSelf->wasmetal_core__DOT___051490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049347_))));
    vlSelf->wasmetal_core__DOT___050331_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049345_))));
    vlSelf->wasmetal_core__DOT___050325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049550_))));
    vlSelf->wasmetal_core__DOT___051377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049543_))));
    vlSelf->wasmetal_core__DOT___051488_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048575_))));
    vlSelf->wasmetal_core__DOT___051487_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048571_))));
    vlSelf->wasmetal_core__DOT___049612_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048510_))));
    vlSelf->wasmetal_core__DOT___049939_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049390_))));
    vlSelf->wasmetal_core__DOT___049952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049392_))));
    vlSelf->wasmetal_core__DOT___049937_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049003_))));
    vlSelf->wasmetal_core__DOT___049940_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048962_))));
    vlSelf->wasmetal_core__DOT___050327_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048546_))));
    vlSelf->wasmetal_core__DOT___050470_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048298_))));
    vlSelf->wasmetal_core__DOT___050478_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048536_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128274___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030584_ = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___065587_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->mem_rdata[0U] 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065585_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128222___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___030010_ = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029925_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032877_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___044260_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044274_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044273_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044272_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044271_) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___044263_))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044272_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044273_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044274_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127994___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027664_ = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070256_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->cmd_data[3U] 
                                                       >> 0xfU)) 
                                                   | (1U 
                                                      & (0xf38f2779U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he557a56d__0))))));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029756_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029393_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027812_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128255___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___030370_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___052676_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052024_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052023_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052022_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128050___O 
        = (((0xeU & vlSelf->insn_x) | (1U & (~ vlSelf->insn_x))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & (vlSelf->insn_x 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___028180_ = ((vlSelf->insn_x 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029232_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128018___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027890_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___067581_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                         >> 3U)))));
    wasmetal_core__DOT___044725_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052867_))));
    wasmetal_core__DOT___044724_ = (1U & (0x80U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___032689_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_h42a8fe82__0))));
    vlSelf->__VdfgTmp_hb829d41d__0 = (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)));
    vlSelf->wasmetal_core__DOT____Vcellout___128314___O 
        = (((8U & ((~ (vlSelf->function_params >> 3U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 2U)) << 2U)) 
                              | ((2U & ((~ (vlSelf->function_params 
                                            >> 1U)) 
                                        << 1U)) | (1U 
                                                   & (~ vlSelf->function_params))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ vlSelf->function_params) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___030971_ = ((~ (vlSelf->function_params 
                                                >> 3U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___034222_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___053263_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045590_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045586_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045585_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045583_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h58222fb0__0)) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___045587_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045582_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he13e3256__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045589_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___045581_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___038870_ = ((IData)(vlSelf->wasmetal_core__DOT___045581_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___045590_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___045589_)
                                                  ? 
                                                 ((1U 
                                                   & (0x80U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcd6b7a1f__0)))
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___045587_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___045586_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___045585_)
                                                      ? 
                                                     ((1U 
                                                       & (0x80U 
                                                          >> (IData)(vlSelf->__VdfgTmp_he13e3256__0)))
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___045583_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___045582_)
                                                         ? 
                                                        ((~ 
                                                          (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h58222fb0__0))) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___045568_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045570_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___045571_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045572_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___045573_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___045574_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___045575_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___045576_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___045577_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___045578_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___045569_));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hbf5bedf6__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___044720_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___032676_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf0d31b4__0))));
    vlSelf->wasmetal_core__DOT___065554_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065553_))));
    wasmetal_core__DOT___044717_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052868_))));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032685_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___065579_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___065562_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065561_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___064087_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064086_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___065557_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064091_))));
    vlSelf->wasmetal_core__DOT___066366_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b2__05d)))));
    vlSelf->__VdfgTmp_h92a0f8b0__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064091_));
    wasmetal_core__DOT___071505_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071478_))));
    wasmetal_core__DOT___071479_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071478_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___037195_)) 
                 & (9U >> (IData)(vlSelf->__VdfgTmp_h2cd56cce__0))));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__ 
        = ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_hff2c11ba__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b0__05d));
    vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d 
        = ((IData)(vlSelf->wasmetal_core__DOT___042520_)
            ? ((IData)(vlSelf->wasmetal_core__DOT___042519_)
                ? ((IData)(vlSelf->wasmetal_core__DOT___042517_)
                    ? ((IData)(vlSelf->wasmetal_core__DOT___042516_)
                        ? ((IData)(vlSelf->wasmetal_core__DOT___042515_)
                            ? ((IData)(vlSelf->wasmetal_core__DOT___042514_)
                                ? ((IData)(vlSelf->wasmetal_core__DOT___042513_)
                                    ? ((IData)(vlSelf->wasmetal_core__DOT___042512_)
                                        ? ((IData)(vlSelf->wasmetal_core__DOT___042511_)
                                            ? ((IData)(vlSelf->wasmetal_core__DOT___042510_)
                                                ? ((IData)(vlSelf->wasmetal_core__DOT___042509_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___042508_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___042528_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___042527_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___042526_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___042525_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___042524_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___042523_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___042522_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___042521_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___042518_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___042507_) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___042483_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___042494_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___042497_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___042498_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___042499_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___042500_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___042501_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___042502_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___042503_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___042504_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___042484_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___042485_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___042486_))
                                            : (IData)(vlSelf->wasmetal_core__DOT___042487_))
                                        : (IData)(vlSelf->wasmetal_core__DOT___042488_))
                                    : (IData)(vlSelf->wasmetal_core__DOT___042489_))
                                : (IData)(vlSelf->wasmetal_core__DOT___042490_))
                            : (IData)(vlSelf->wasmetal_core__DOT___042491_))
                        : (IData)(vlSelf->wasmetal_core__DOT___042492_))
                    : (IData)(vlSelf->wasmetal_core__DOT___042493_))
                : (IData)(vlSelf->wasmetal_core__DOT___042495_))
            : (IData)(vlSelf->wasmetal_core__DOT___042496_));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026272_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b1__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026176_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026368_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b1__05d));
    wasmetal_core__DOT___071511_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071486_))));
    wasmetal_core__DOT___071487_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071486_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071508_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071482_))));
    wasmetal_core__DOT___071483_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071482_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071502_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071473_))));
    wasmetal_core__DOT___071474_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071473_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    wasmetal_core__DOT___071496_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070571_))));
    wasmetal_core__DOT___070572_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___070571_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b3__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128498___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032988_ = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128498___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___044119_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044142_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044151_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044150_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044149_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044148_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044147_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044146_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044145_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044144_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044143_) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___044131_))
                                                         : 
                                                        (~ (IData)(vlSelf->wasmetal_core__DOT___044144_)))
                                                        : 
                                                       (~ (IData)(vlSelf->wasmetal_core__DOT___044145_)))
                                                       : 
                                                      (~ (IData)(vlSelf->wasmetal_core__DOT___044146_)))
                                                      : 
                                                     (~ (IData)(vlSelf->wasmetal_core__DOT___044147_)))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044148_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044149_)))
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044150_)))
                                               : (~ (IData)(vlSelf->wasmetal_core__DOT___044151_)))
                                           : (~ (IData)(vlSelf->wasmetal_core__DOT___044142_))));
    wasmetal_core__DOT___070939_ = (1U & (8U >> ((2U 
                                                  & ((IData)(
                                                             (0x9000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___070936_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___070935_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070934_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((9U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b5__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b1__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x1000U 
                                                       >> 
                                                       ((8U 
                                                         & ((0x90090000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___070921_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d)))))) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((0x90090000U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070924_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b6__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b7__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d)))))) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b21__05d) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02eindex_a__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___049006_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___009506_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         >> 3U)))));
    __VdfgTmp_he741bbfe__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_)))));
    __VdfgTmp_hdba9480e__0 = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                     << 3U)) | ((4U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                    << 2U)) 
                                                | ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))));
    vlSelf->__VdfgTmp_hab049741__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 1U)) 
                                      | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))));
    vlSelf->__VdfgTmp_h4e415d3f__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 1U)) 
                                      | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))));
    vlSelf->__VdfgTmp_ha1c1569b__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 1U)) 
                                      | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128509___O 
        = ((0xeU | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b2__05d)))) 
           ^ ((0xeU & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___033042_))) 
                       << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___128509___DOT____VdfgTmp_h9d2c3928__0)));
    vlSelf->__VdfgTmp_h078a1663__0 = ((2U & ((8U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                >> 2U))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_haf6246da__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___066351_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O)))));
    vlSelf->wasmetal_core__DOT___064200_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128576___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071545_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071521_))));
    wasmetal_core__DOT___071522_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071521_))));
    vlSelf->wasmetal_core__DOT___071543_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071516_))));
    wasmetal_core__DOT___071517_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___071516_))));
    vlSelf->wasmetal_core__DOT___071542_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc1ba27eb__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071514_))));
    vlSelf->wasmetal_core__DOT___071515_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071514_))));
    vlSelf->wasmetal_core__DOT___071536_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071499_))));
    wasmetal_core__DOT___071500_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071499_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071534_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071493_))));
    wasmetal_core__DOT___071494_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___071493_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071533_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071491_))));
    vlSelf->wasmetal_core__DOT___071492_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071491_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___058083_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha330fec4__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048947_))));
    vlSelf->wasmetal_core__DOT___048948_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048947_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d))));
    vlSelf->wasmetal_core__DOT___048503_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (1ULL 
                                                                >> 
                                                                (0x3fU 
                                                                 & (vlSelf->insn_x 
                                                                    >> 0xcU)))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048500_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044248_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b3__05d) {
        vlSelf->wasmetal_core__DOT___031898_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___033933_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
        vlSelf->wasmetal_core__DOT___032955_ = vlSelf->wasmetal_core__DOT__sp__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___031898_ = vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___033933_ = vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___032955_ = vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128394___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_hc50f84f8__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128394___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___062986_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062983_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___062982_))));
    vlSelf->wasmetal_core__DOT___052999_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052992_))));
    vlSelf->wasmetal_core__DOT___052996_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052992_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052952_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052864_))));
    vlSelf->wasmetal_core__DOT___052987_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051013_))));
    vlSelf->wasmetal_core__DOT___051016_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051013_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___043139_ = (1U & (0x8fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 4U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070577_)))));
    vlSelf->wasmetal_core__DOT___043583_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070577_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 8U))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3ca161df__0)))));
    vlSelf->wasmetal_core__DOT___043141_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070577_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 5U))))));
    vlSelf->wasmetal_core__DOT___043131_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070577_))));
    vlSelf->wasmetal_core__DOT___043286_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070578_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 5U))))));
    wasmetal_core__DOT___070579_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 4U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070578_))));
    vlSelf->wasmetal_core__DOT___046420_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052857_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052856_))));
    vlSelf->wasmetal_core__DOT___063465_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063473_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063481_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063489_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063497_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063521_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063545_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063561_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063569_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063577_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063585_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063601_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063609_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063617_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063625_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063633_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063641_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063649_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063657_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063665_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063673_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063681_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063689_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___063705_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019394_))));
    vlSelf->wasmetal_core__DOT___053285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___052876_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052654_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052652_))));
    vlSelf->wasmetal_core__DOT___053005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___053281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053004_))));
    vlSelf->wasmetal_core__DOT___052986_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048520_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048517_))));
    vlSelf->wasmetal_core__DOT___052998_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052993_))));
    vlSelf->wasmetal_core__DOT___046418_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052859_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051015_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___046571_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051015_))));
    vlSelf->wasmetal_core__DOT___052990_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->wasmetal_core__DOT___009510_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->wasmetal_core__DOT___048116_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048109_))));
    vlSelf->busy = (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___048480_) 
                                    << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048480_))));
    vlSelf->wasmetal_core__DOT___053558_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048478_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048484_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048478_))));
    vlSelf->wasmetal_core__DOT___054471_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c590b04__0))));
    vlSelf->wasmetal_core__DOT___048483_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048481_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0))))));
    vlSelf->wasmetal_core__DOT___048114_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6c590b04__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a7964bb__0))));
    vlSelf->wasmetal_core__DOT___045646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070626_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___044096_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070626_))));
    vlSelf->wasmetal_core__DOT___044076_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070624_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___044104_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070624_))));
    vlSelf->wasmetal_core__DOT___045643_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070626_))));
    vlSelf->__VdfgTmp_h6ef8db86__0 = ((8U & (vlSelf->insn_op 
                                             << 3U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h71254871__0));
    vlSelf->wasmetal_core__DOT___045979_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_x 
                                                      >> 0x1aU))) 
                                            & ((IData)(
                                                       (1ULL 
                                                        >> 
                                                        (0x3fU 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U)))) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044249_) 
                                                  & ((1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___044248_) 
                                                        & ((~ 
                                                            (4U 
                                                             >> 
                                                             (3U 
                                                              & vlSelf->insn_x))) 
                                                           & (~ 
                                                              (vlSelf->insn_x 
                                                               >> 1U))))))));
    if ((1U & (IData)((1ULL >> (vlSelf->insn_x >> 0x1aU))))) {
        if ((1U & (IData)((1ULL >> (0x3fU & (vlSelf->insn_x 
                                             >> 0x14U)))))) {
            if (vlSelf->wasmetal_core__DOT___044249_) {
                vlSelf->wasmetal_core__DOT___044604_ 
                    = (1U & ((1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)))
                              ? ((IData)(vlSelf->wasmetal_core__DOT___044248_)
                                  ? ((4U >> (3U & vlSelf->insn_x)) 
                                     | (8U >> (3U & vlSelf->insn_x)))
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___044248_)))
                              : (~ (1U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)))));
                vlSelf->wasmetal_core__DOT___044240_ 
                    = (1U & ((4U >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0)) 
                             | (IData)(vlSelf->wasmetal_core__DOT___044243_)));
            } else {
                vlSelf->wasmetal_core__DOT___044604_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044249_)));
                vlSelf->wasmetal_core__DOT___044240_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044249_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___044604_ = 
                (1U & (~ (IData)((1ULL >> (0x3fU & 
                                           (vlSelf->insn_x 
                                            >> 0x14U))))));
            vlSelf->wasmetal_core__DOT___044240_ = 
                (1U & (~ (IData)((1ULL >> (0x3fU & 
                                           (vlSelf->insn_x 
                                            >> 0x14U))))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___044604_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_x 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044240_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_x 
                                                               >> 0x1aU)))));
    }
    vlSelf->wasmetal_core__DOT___045777_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_x 
                                                      >> 0x1aU))) 
                                            & ((IData)(
                                                       (1ULL 
                                                        >> 
                                                        (0x3fU 
                                                         & (vlSelf->insn_x 
                                                            >> 0x14U)))) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044249_) 
                                                  & ((~ 
                                                      (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0))) 
                                                     & (1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2d79cdd9__0))))));
    vlSelf->wasmetal_core__DOT___048537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049928_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___048573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__element_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049422_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___049938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    vlSelf->wasmetal_core__DOT___048300_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02epending_write) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048293_))));
    wasmetal_core__DOT___053415_ = (1U & (8U >> ((2U 
                                                  & ((IData)(
                                                             (0x9000000000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___053406_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___053405_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053404_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((9U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b5__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b1__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x1000U 
                                                       >> 
                                                       ((8U 
                                                         & ((0x90090000U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___053407_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b13__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b13__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b9__05d)))))) 
                                                            << 3U)) 
                                                        | ((4U 
                                                            & ((0x90090000U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053410_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b6__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b7__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d)))))) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b21__05d) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02eindex_a__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___048513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048303_))));
    vlSelf->wasmetal_core__DOT___050392_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048447_))));
    vlSelf->wasmetal_core__DOT___053775_ = (1U & (0x111fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f7c118b__0))))));
    vlSelf->wasmetal_core__DOT___053781_ = (1U & (0x111fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x1000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x4000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5f7c118b__0))))));
    vlSelf->wasmetal_core__DOT___048469_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((8U 
                                                      & vlSelf->insn_op)
                                                      ? (IData)(
                                                                (0x5555ffff303f00ffULL 
                                                                 >> 
                                                                 ((0x30U 
                                                                   & (vlSelf->insn_op 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & (vlSelf->insn_op 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___002988_)))))))
                                                      : 
                                                     (0xd0f1555U 
                                                      >> 
                                                      ((0x18U 
                                                        & (vlSelf->insn_op 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (vlSelf->insn_op 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___002994_))))))));
    wasmetal_core__DOT___048436_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___000358_ = ((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                            & ((1U 
                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                               & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (1ULL 
                                                                        >> 
                                                                        (vlSelf->insn_op 
                                                                         >> 0x1aU))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & (vlSelf->insn_op 
                                                                                >> 6U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U)))))))))))));
    vlSelf->wasmetal_core__DOT___000359_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0x1000U 
                                                                >> 
                                                                (0xfU 
                                                                 & (vlSelf->insn_op 
                                                                    >> 0x10U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (1ULL 
                                                                              >> 
                                                                              (vlSelf->insn_op 
                                                                               >> 0x1aU))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (3U 
                                                                              & (vlSelf->insn_op 
                                                                                >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048277_ = ((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048278_ = ((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048279_ = ((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                            & (IData)(
                                                      (0x4000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000371_) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf3a49853__0)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (1ULL 
                                                                           >> 
                                                                           (vlSelf->insn_op 
                                                                            >> 0x1aU))) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xeU 
                                                                          >> 
                                                                          (3U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 0x18U))))))))))));
    vlSelf->wasmetal_core__DOT___048398_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048468_ = (1U & (0xe7ffffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h71254871__0)))));
    wasmetal_core__DOT___048337_ = (1U & (8U >> ((2U 
                                                  & ((8U 
                                                      >> 
                                                      (3U 
                                                       & (vlSelf->insn_op 
                                                          >> 2U))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___047969_ = (1U & (IData)(
                                                         (0x2ffeffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x4000U 
                                                                   >> 
                                                                   (0xfU 
                                                                    & (vlSelf->insn_op 
                                                                       >> 4U))) 
                                                                  << 4U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))));
    vlSelf->wasmetal_core__DOT___048365_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___002981_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___048326_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048320_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___047781_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048343_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048327_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___010006_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_hc416787b__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___000353_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_)))));
    vlSelf->wasmetal_core__DOT___010007_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___070595_ = (1U & (0xc4ffffffU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x4000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->insn_op 
                                                             >> 1U)) 
                                                         | (3U 
                                                            & vlSelf->insn_op))))));
    vlSelf->wasmetal_core__DOT___003010_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x100U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047955_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0xfff533ff3f3f3f3fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & vlSelf->insn_op) 
                                                                       | ((2U 
                                                                           & ((0x4000U 
                                                                               >> 
                                                                               (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___002988_))))))))));
    vlSelf->__VdfgTmp_h4e9e0a77__0 = ((2U & ((0x100U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___002966_ = (1U & (IData)(
                                                         (0x5dffffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & vlSelf->insn_op) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & vlSelf->insn_op) 
                                                                       | (1U 
                                                                          & (0x4000U 
                                                                             >> 
                                                                             (0xfU 
                                                                              & (vlSelf->insn_op 
                                                                                >> 4U))))))))))));
    vlSelf->wasmetal_core__DOT___002965_ = (1U & (IData)(
                                                         (0xff0fff11ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))))));
    vlSelf->wasmetal_core__DOT___048283_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_h28012a28__0 = ((2U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___048328_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___048284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    if (vlSelf->wasmetal_core__DOT__sp__05b4__05d) {
        vlSelf->wasmetal_core__DOT___032633_ = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___032633_ = vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___128395___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031898_;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128458___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128458___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___007059_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha8374813__0))))));
    vlSelf->__VdfgTmp_h84a34a18__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_ha8374813__0));
    vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001230_) 
           | (IData)(vlSelf->wasmetal_core__DOT___043130_));
    vlSelf->wasmetal_core__DOT___047968_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x4000U 
                                                           >> 
                                                           (0xfU 
                                                            & (vlSelf->insn_op 
                                                               >> 4U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001230_))))));
    vlSelf->wasmetal_core__DOT___048314_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->__VdfgTmp_hbcc95063__0 = (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___047983_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x4000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x100U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___002985_))))));
    vlSelf->__VdfgTmp_hec761a3f__0 = (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002984_));
    vlSelf->wasmetal_core__DOT___070629_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___048467_ = (1U & (IData)(
                                                         (0x87fcffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | (0xfU 
                                                                 & vlSelf->insn_op))))));
    vlSelf->wasmetal_core__DOT___044083_ = (1U & (0xfff8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & (vlSelf->insn_op 
                                                               >> 6U))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 3U)))))));
    vlSelf->__VdfgTmp_h7dabefa3__0 = ((4U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048336_)));
    vlSelf->wasmetal_core__DOT___045687_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 2U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___048474_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x53f0ff305fffffffULL 
                                                             >> 
                                                             ((0x20U 
                                                               & ((0x1000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                  << 5U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 3U)) 
                                                                 | ((0xcU 
                                                                     & vlSelf->insn_op) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007028_)))))))));
    vlSelf->wasmetal_core__DOT___048476_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x3fffffffdfffdULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & (vlSelf->insn_op 
                                                                           << 1U)) 
                                                                       | ((2U 
                                                                           & (vlSelf->insn_op 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))))));
    vlSelf->__VdfgTmp_h755be032__0 = (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000368_));
    vlSelf->wasmetal_core__DOT___047964_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> 
                                                                  (0xfU 
                                                                   & (vlSelf->insn_op 
                                                                      >> 4U))))))))));
    vlSelf->wasmetal_core__DOT___002978_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047783_)))))));
    vlSelf->wasmetal_core__DOT___002979_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((8U 
                                                      & vlSelf->insn_op)
                                                      ? 
                                                     (0xffffcf55U 
                                                      >> 
                                                      ((0x10U 
                                                        & (vlSelf->insn_op 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & (vlSelf->insn_op 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_op 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002988_))))))
                                                      : 
                                                     (0xffff153fU 
                                                      >> 
                                                      ((0x10U 
                                                        & (vlSelf->insn_op 
                                                           << 3U)) 
                                                       | ((8U 
                                                           & (vlSelf->insn_op 
                                                              << 1U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & (vlSelf->insn_op 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (0x4000U 
                                                                      >> 
                                                                      (0xfU 
                                                                       & (vlSelf->insn_op 
                                                                          >> 4U))))))))))));
    vlSelf->__VdfgTmp_h94b1bf18__0 = (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                       << 1U) | (1U 
                                                 & (vlSelf->insn_op 
                                                    >> 3U)));
    vlSelf->wasmetal_core__DOT___003012_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0xffff3ff5ff335f5fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x18U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))))));
    vlSelf->wasmetal_core__DOT___047966_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x4000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047954_ = (1U & (0x1ffffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h87f36829__0))))));
    vlSelf->wasmetal_core__DOT___047976_ = (1U & (IData)(
                                                         (0xfa3fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & vlSelf->insn_op) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_op 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_op)))))))));
    vlSelf->wasmetal_core__DOT___047794_ = (1U & (IData)(
                                                         (0xfff777777777777fULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->insn_op 
                                                               << 2U)) 
                                                           | ((8U 
                                                               & (vlSelf->insn_op 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001234_))))))));
    vlSelf->wasmetal_core__DOT___003009_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x55f5f3ffffffff3fULL 
                                                             >> 
                                                             ((0x20U 
                                                               & (vlSelf->insn_op 
                                                                  << 4U)) 
                                                              | ((0x10U 
                                                                  & (vlSelf->insn_op 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & (vlSelf->insn_op 
                                                                        << 3U)) 
                                                                    | ((4U 
                                                                        & vlSelf->insn_op) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0x4000U 
                                                                                >> 
                                                                                (0xfU 
                                                                                & (vlSelf->insn_op 
                                                                                >> 4U)))))))))))));
    vlSelf->wasmetal_core__DOT___053009_ = (1U & (0xff01ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001240_)))))));
    vlSelf->wasmetal_core__DOT___048005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xfffeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))));
    vlSelf->wasmetal_core__DOT___043674_ = (1U & (0x1ff0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 8U))) 
                                                       << 4U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___047795_ = (1U & (0xff15ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & ((0x4000U 
                                                              >> 
                                                              (0xfU 
                                                               & (vlSelf->insn_op 
                                                                  >> 4U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))))));
    vlSelf->wasmetal_core__DOT___047791_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | (IData)(
                                                            (0x30fff5f5ffff30ffULL 
                                                             >> 
                                                             ((0x30U 
                                                               & (vlSelf->insn_op 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((0x4000U 
                                                                      >> 
                                                                      (0xfU 
                                                                       & (vlSelf->insn_op 
                                                                          >> 4U))) 
                                                                     << 3U)) 
                                                                 | ((6U 
                                                                     & (vlSelf->insn_op 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))))))));
    vlSelf->wasmetal_core__DOT___048275_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x100U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xfffeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))));
    vlSelf->wasmetal_core__DOT___002980_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((IData)(vlSelf->wasmetal_core__DOT___001240_)
                                                      ? (IData)(
                                                                (0x700070007ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((0x1000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h6253e4f3__0)))))))
                                                      : 
                                                     (0x777U 
                                                      >> 
                                                      ((8U 
                                                        & ((0x1000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6253e4f3__0)))))));
    vlSelf->wasmetal_core__DOT___047985_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))));
    vlSelf->wasmetal_core__DOT___070596_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x100U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))));
    vlSelf->wasmetal_core__DOT___047977_ = (1U & (0xf5bbffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((0xcU 
                                                       & vlSelf->insn_op) 
                                                      | ((2U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001234_))))));
    vlSelf->wasmetal_core__DOT___001246_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001241_))))));
    vlSelf->wasmetal_core__DOT___047793_ = (1U & (IData)(
                                                         (0xf53fffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & vlSelf->insn_op) 
                                                                 | ((2U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x4000U 
                                                                          >> 
                                                                          (0xfU 
                                                                           & (vlSelf->insn_op 
                                                                              >> 4U)))))))))));
    vlSelf->wasmetal_core__DOT___002968_ = (1U & (0xbfU 
                                                  >> 
                                                  ((4U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___001232_ = (IData)(
                                                   ((3U 
                                                     == 
                                                     (3U 
                                                      & vlSelf->insn_op)) 
                                                    & (0x1000000000000ULL 
                                                       >> 
                                                       ((0x30U 
                                                         & (vlSelf->insn_op 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h695ce273__0)))));
    vlSelf->wasmetal_core__DOT___048424_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xfffeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))))));
    vlSelf->wasmetal_core__DOT___051563_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xfffeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))));
    vlSelf->__VdfgTmp_hdd61004f__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 1U) | (1U 
                                                 & (0xfffeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->__VdfgTmp_h323e8784__0 = ((2U & (vlSelf->insn_op 
                                             >> 2U)) 
                                      | (1U & (0xfffeU 
                                               >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___044158_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (vlSelf->insn_op 
                                                            >> 6U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070615_))));
    vlSelf->wasmetal_core__DOT___045697_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070615_))));
    vlSelf->wasmetal_core__DOT___045694_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070615_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (vlSelf->insn_op 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (vlSelf->insn_op 
                                                                >> 6U))))))));
    vlSelf->wasmetal_core__DOT___044630_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->__VdfgTmp_h73c641ae__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048272_));
    vlSelf->wasmetal_core__DOT____Vcellout___128593___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                               << 2U) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128593___DOT__CO__BRA__2__KET__) 
                     << 3U) | ((IData)(vlSelf->__VdfgTmp_h58bd40ba__0) 
                               << 1U))));
    vlSelf->wasmetal_core__DOT____Vcellout___128490___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)) 
                                     << 2U)) | (IData)(vlSelf->wasmetal_core__DOT____VdfgTmp_h1702059a__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128490___DOT__CO__BRA__2__KET__) 
                     << 3U) | ((IData)(vlSelf->__VdfgTmp_h58bd40ba__0) 
                               << 1U))));
    vlSelf->wasmetal_core__DOT___052014_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write))));
    vlSelf->wasmetal_core__DOT___000209_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h17767d6e__0)))));
    vlSelf->wasmetal_core__DOT___000262_ = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b27__05d)
                                              ? ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000306_))
                                              : ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000306_))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b23__05d)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000302_))
                                                 : 
                                                ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d)) 
                                                 & (IData)(vlSelf->wasmetal_core__DOT___000302_))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000271_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000270_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000269_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write) 
                                                                         & (IData)(
                                                                                (0x1001000000001001ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b8__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b2__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h17767d6e__0))))))))) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b29__05d)
                                                                          ? 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000283_))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___000283_))) 
                                                                        << 1U) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b0__05d__02eread_row__05b24__05d)
                                                                           ? 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000279_))
                                                                           : 
                                                                          ((~ (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d)) 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT___000279_))))))))))));
    vlSelf->wasmetal_core__DOT___000313_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                               & (IData)(
                                                         (0x4100004100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b1__05d__02eread_row__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d))))))))));
    vlSelf->wasmetal_core__DOT___000222_ = ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b1__05d) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___000248_) 
                                               & (IData)(
                                                         (0x9009000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__value_file__02epending_write) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ebanks__05b3__05d__02eread_row__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d))))))))));
    vlSelf->wasmetal_core__DOT___048001_ = (1U & (IData)(
                                                         (0xdfff7555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfffeU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))))));
    vlSelf->wasmetal_core__DOT___047787_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))));
    vlSelf->wasmetal_core__DOT___048448_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048447_))));
    vlSelf->wasmetal_core__DOT___048307_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048303_))));
    vlSelf->wasmetal_core__DOT___047792_ = (1U & ((~ 
                                                   (vlSelf->insn_op 
                                                    >> 3U)) 
                                                  | ((4U 
                                                      & vlSelf->insn_op)
                                                      ? 
                                                     (0xefbfU 
                                                      >> 
                                                      ((8U 
                                                        & (vlSelf->insn_op 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (vlSelf->insn_op 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xfffeU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))))
                                                      : 
                                                     (0xf7U 
                                                      >> 
                                                      ((4U 
                                                        & (vlSelf->insn_op 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((0x4000U 
                                                               >> 
                                                               (0xfU 
                                                                & (vlSelf->insn_op 
                                                                   >> 4U))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000368_)))))));
    vlSelf->wasmetal_core__DOT___003040_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h87f36829__0)))));
    vlSelf->__VdfgTmp_ha37d1f60__0 = (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                       << 1U) | (1U 
                                                 & (0xfffeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0))));
    vlSelf->wasmetal_core__DOT___043133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054454_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054455_))));
    vlSelf->wasmetal_core__DOT___044061_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 8U)))))));
    vlSelf->wasmetal_core__DOT___053367_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       >> 0x10U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048515_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 0x10U))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (vlSelf->insn_op 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___048516_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> 
                                                        (0xfU 
                                                         & (vlSelf->insn_op 
                                                            >> 0x10U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048515_))));
    vlSelf->wasmetal_core__DOT___052953_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->insn_valid) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & (vlSelf->insn_op 
                                                                        >> 8U)) 
                                                                    | ((8U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 0xaU)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8e88a732__0))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___045735_ = (1U & (0xd00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> 
                                                              (3U 
                                                               & (vlSelf->insn_op 
                                                                  >> 2U))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001234_))))));
    vlSelf->wasmetal_core__DOT___047962_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x4000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x8000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->__VdfgTmp_h11a2e1d4__0 = ((2U & ((0x8000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___047780_));
    vlSelf->wasmetal_core__DOT___047789_ = (1U & (IData)(
                                                         (0x7ffffffffffffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_op 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->insn_op 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_op 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047780_)))))))));
    vlSelf->__VdfgTmp_haec53eda__0 = ((2U & ((0x4000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___047780_));
    vlSelf->wasmetal_core__DOT___048315_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___044184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7a4c1007__0))))));
    vlSelf->wasmetal_core__DOT___070609_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047780_))));
    vlSelf->wasmetal_core__DOT___044111_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045705_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he33f1ed5__0))));
    vlSelf->wasmetal_core__DOT___044168_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))
                                                   ? 
                                                  ((1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044174_) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___044170_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (3U 
                                                     & (vlSelf->insn_op 
                                                        >> 0x18U))))
                                                   : 
                                                  (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU))))));
    vlSelf->wasmetal_core__DOT___070487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051227_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->cmd_kind)))));
    vlSelf->wasmetal_core__DOT___070489_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->cmd_kind) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051227_))));
    vlSelf->wasmetal_core__DOT___128794___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___035884_));
    vlSelf->wasmetal_core__DOT___063417_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063392_))));
    vlSelf->wasmetal_core__DOT___128721___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___035215_));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 4U) & (IData)(vlSelf->wasmetal_core__DOT___027954_));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 4U) : (IData)(vlSelf->wasmetal_core__DOT___030489_)));
    vlSelf->wasmetal_core__DOT___128003___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027729_));
    vlSelf->wasmetal_core__DOT___128035___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___028019_));
    vlSelf->wasmetal_core__DOT___128156___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029310_));
    vlSelf->wasmetal_core__DOT___128189___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029672_));
    vlSelf->wasmetal_core__DOT___128206___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___029841_));
    vlSelf->wasmetal_core__DOT___128371___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031611_));
    vlSelf->wasmetal_core__DOT___063408_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d))));
    vlSelf->wasmetal_core__DOT___063377_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045941_))));
    vlSelf->wasmetal_core__DOT___128419___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032092_));
    vlSelf->wasmetal_core__DOT___054476_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9a5fea4e__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___052940_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052939_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_reference))));
    vlSelf->wasmetal_core__DOT___063382_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063379_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h17c4848e__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)))));
    vlSelf->wasmetal_core__DOT___128275___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030584_));
    vlSelf->wasmetal_core__DOT___128223___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___030010_));
    vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029936_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128213___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d));
    vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032888_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___127995___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT___027664_));
    vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029767_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128196___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d));
    vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029404_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128163___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d));
    vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027823_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d));
    vlSelf->wasmetal_core__DOT___128256___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030370_));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 4U) & (IData)(vlSelf->wasmetal_core__DOT___028180_));
    vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029243_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128147___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d));
    vlSelf->wasmetal_core__DOT___128019___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___027890_));
    vlSelf->wasmetal_core__DOT___052870_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___032681_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052868_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052867_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032679_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___032680_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044723_) 
                                                                                << 2U) 
                                                                                | (((IData)(wasmetal_core__DOT___044724_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___044722_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___044757_ = (1U & (0x2b22U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_locals 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O)) 
                                                         | (1U 
                                                            & (vlSelf->function_locals 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___044769_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->function_locals 
                                                       << 2U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128314___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & vlSelf->function_locals)))));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 4U)) & (IData)(vlSelf->wasmetal_core__DOT___030971_));
    vlSelf->wasmetal_core__DOT____Vcellout___128632___O 
        = ((8U | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)) 
                         << 2U)) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d)) 
                                           << 1U)) 
                                    | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___034222_) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (1U & 
                                               (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d)))))));
    vlSelf->__VdfgTmp_h6f508139__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                             << 1U)) 
                                      | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_))));
    vlSelf->__VdfgTmp_hf123769f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                             << 2U)) 
                                      | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___034222_)) 
                                                << 1U)) 
                                         | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___034222_)))));
    vlSelf->__VdfgTmp_h0ff1168c__0 = (((IData)(vlSelf->wasmetal_core__DOT___038870_) 
                                       << 1U) | (IData)(vlSelf->mem_fault));
    vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032216_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128426___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___044693_ = ((IData)(vlSelf->wasmetal_core__DOT___044716_)
                                             ? ((IData)(wasmetal_core__DOT___044725_)
                                                 ? 
                                                ((IData)(wasmetal_core__DOT___044724_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044723_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044722_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044721_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044720_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044719_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044718_)
                                                        ? 
                                                       ((IData)(wasmetal_core__DOT___044717_)
                                                         ? 
                                                        ((~ 
                                                          (8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___044703_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044705_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044706_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044707_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044708_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044709_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044710_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044711_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044712_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___044713_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___044704_));
    vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032696_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___065582_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065579_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xeff7ffffffffffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h49b76e08__0)))))))))));
    vlSelf->wasmetal_core__DOT___065565_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065563_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065562_)))));
    vlSelf->wasmetal_core__DOT___064978_ = (1U & (0x80000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 4U)) 
                                                   | ((8U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h49b76e08__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064088_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064091_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064087_)))))));
    vlSelf->wasmetal_core__DOT___065556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065554_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___065558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___064093_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064088_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___066365_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065557_)))));
    vlSelf->wasmetal_core__DOT___067556_ = (1U & (0xbfffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064087_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065553_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___066367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066366_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064087_))));
    vlSelf->wasmetal_core__DOT___064452_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___064992_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064095_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___064973_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h835050f4__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h92a0f8b0__0))));
    vlSelf->wasmetal_core__DOT___071538_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071505_))));
    vlSelf->wasmetal_core__DOT___071506_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071526_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071479_))));
    vlSelf->wasmetal_core__DOT___071480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071479_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037206_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h61cb7e30__0))));
    vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035106_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128704___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d));
    vlSelf->wasmetal_core__DOT___128688___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__divider__02enext_q__05b0__05d))));
    vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026283_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127834___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b2__05d));
    vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026187_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127826___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d));
    vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026379_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b2__05d));
    vlSelf->wasmetal_core__DOT___071540_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071511_))));
    vlSelf->wasmetal_core__DOT___071512_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071530_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071487_))));
    vlSelf->wasmetal_core__DOT___071488_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071508_))));
    vlSelf->wasmetal_core__DOT___071509_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071508_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->__VdfgTmp_he775e720__0 = ((2U & ((8U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                << 1U) 
                                               | (IData)(wasmetal_core__DOT___071483_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d));
    vlSelf->wasmetal_core__DOT___071484_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071537_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071502_))));
    vlSelf->wasmetal_core__DOT___071503_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071524_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071474_))));
    vlSelf->wasmetal_core__DOT___071475_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071474_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071535_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071532_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071496_))));
    vlSelf->wasmetal_core__DOT___071497_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___071519_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070572_))));
    vlSelf->wasmetal_core__DOT___070573_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070572_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032827_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032824_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032813_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032802_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__pending_branch__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128498___O)))));
    vlSelf->wasmetal_core__DOT___128499___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032988_));
    vlSelf->wasmetal_core__DOT___046933_ = (1U & (0xf1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___044119_)))));
    vlSelf->__VdfgTmp_hf5e419f7__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                       << 1U) | (IData)(wasmetal_core__DOT___044119_));
    vlSelf->wasmetal_core__DOT___049048_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->__VdfgTmp_h10b5292d__0 = (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                    >> 1U)));
    vlSelf->__VdfgTmp_hdc489de0__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009506_));
    vlSelf->wasmetal_core__DOT___048561_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x5ffffffffffffff3ULL 
                                                                >> 
                                                                ((0x20U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                     << 5U)) 
                                                                 | ((0x10U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                        << 4U)) 
                                                                    | ((8U 
                                                                        & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(__VdfgTmp_hdba9480e__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x8000U 
                                                                                >> (IData)(__VdfgTmp_hdba9480e__0)))))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x5ffffffffffffff3ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                        << 5U)) 
                                                                    | ((0x18U 
                                                                        & ((~ 
                                                                            (3U 
                                                                             & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___033042_))) 
                                                                                >> 2U))) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> (IData)(__VdfgTmp_he741bbfe__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x80U 
                                                                                >> (IData)(__VdfgTmp_he741bbfe__0))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5ffffffffffffff3ULL 
                                                                    >> 
                                                                    ((0x20U 
                                                                      & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                         << 5U)) 
                                                                     | ((0x10U 
                                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                            << 4U)) 
                                                                        | ((8U 
                                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                               << 3U)) 
                                                                           | ((4U 
                                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab049741__0)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))))) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 3U)) 
                                                                                | (7U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab049741__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___033042_))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h4c404d9f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h4e415d3f__0));
    vlSelf->wasmetal_core__DOT___047767_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha1c1569b__0))))))));
    vlSelf->__VdfgTmp_hc04260ca__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h28672704__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___033042_)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___066352_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066351_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                         >> 3U)))));
    vlSelf->__VdfgTmp_hb5acd9d8__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                   >> 2U)))));
    vlSelf->wasmetal_core__DOT___065544_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> 
                                                             (7U 
                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___064079_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (7U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128585___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b3__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b2__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128568___DOT____VdfgTmp_h9d2c3928__0) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128534___DOT____VdfgTmp_h9d2c3928__0) 
                                     << 1U) | (1U & 
                                               (~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___128586___DOT____VdfgTmp_h9d2c3928__0 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b4__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128577___DOT____VdfgTmp_h9d2c3928__0));
    vlSelf->wasmetal_core__DOT___071558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071522_))));
    vlSelf->wasmetal_core__DOT___071523_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071556_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071517_))));
    vlSelf->wasmetal_core__DOT___071518_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071517_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071551_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071500_))));
    vlSelf->wasmetal_core__DOT___071501_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071500_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->wasmetal_core__DOT___071549_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___071494_))));
    vlSelf->wasmetal_core__DOT___071495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d))));
    vlSelf->__VdfgTmp_h2c6daa45__0 = (((IData)(vlSelf->wasmetal_core__DOT___071492_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b5__05d));
    vlSelf->wasmetal_core__DOT___058084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058083_))));
    vlSelf->wasmetal_core__DOT___052586_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d))));
    vlSelf->__VdfgTmp_hb0c92cfa__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048948_));
    vlSelf->wasmetal_core__DOT___048949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048948_))));
    vlSelf->wasmetal_core__DOT___052947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045941_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051016_))));
    vlSelf->wasmetal_core__DOT___043578_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070579_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043131_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 4U))))));
    vlSelf->wasmetal_core__DOT___043284_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___043131_))));
    vlSelf->wasmetal_core__DOT___043135_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 3U)) 
                                                   | (IData)(wasmetal_core__DOT___070579_))));
    vlSelf->wasmetal_core__DOT___052858_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___038870_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052857_))));
    vlSelf->wasmetal_core__DOT___052948_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052857_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___038870_))));
    vlSelf->wasmetal_core__DOT___053564_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052857_))));
    vlSelf->wasmetal_core__DOT___053284_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052949_))));
    vlSelf->wasmetal_core__DOT___065281_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065721_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065882_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___066200_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___068807_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___068953_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069002_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069051_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___069195_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___070255_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b112__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___065786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->wasmetal_core__DOT___066063_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053281_))));
    vlSelf->__VdfgTmp_ha2ee8e39__0 = ((2U & ((0xf38f2779U 
                                              >> (IData)(vlSelf->__VdfgTmp_he557a56d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___053281_));
    vlSelf->wasmetal_core__DOT___052988_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052985_)))));
    vlSelf->wasmetal_core__DOT___070064_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b99__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b99__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070108_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b102__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 4U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b102__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070140_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b104__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 6U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b104__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070198_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b108__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xaU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b108__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070213_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b109__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xbU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b109__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070228_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b110__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xcU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b110__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070309_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b116__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x12U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b116__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070361_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b120__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x16U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b120__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___069277_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[2U]))))));
    vlSelf->wasmetal_core__DOT___069307_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___069334_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___069358_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___069383_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 4U)))))));
    vlSelf->wasmetal_core__DOT___069409_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 5U)))))));
    vlSelf->wasmetal_core__DOT___069433_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 6U)))))));
    vlSelf->wasmetal_core__DOT___069459_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 7U)))))));
    vlSelf->wasmetal_core__DOT___069487_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 8U)))))));
    vlSelf->wasmetal_core__DOT___069554_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xbU)))))));
    vlSelf->wasmetal_core__DOT___069623_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b78__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xeU)))))));
    vlSelf->wasmetal_core__DOT___069669_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x10U)))))));
    vlSelf->wasmetal_core__DOT___069843_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x18U)))))));
    vlSelf->wasmetal_core__DOT___069864_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b89__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x19U)))))));
    vlSelf->wasmetal_core__DOT___069884_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1aU)))))));
    vlSelf->wasmetal_core__DOT___069905_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1bU)))))));
    vlSelf->wasmetal_core__DOT___069925_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1cU)))))));
    vlSelf->wasmetal_core__DOT___069946_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1dU)))))));
    vlSelf->wasmetal_core__DOT___070007_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b96__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->mem_rdata[3U]))))));
    vlSelf->wasmetal_core__DOT___069506_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 9U)))))));
    vlSelf->wasmetal_core__DOT___069530_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xaU)))))));
    vlSelf->wasmetal_core__DOT___069578_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xcU)))))));
    vlSelf->wasmetal_core__DOT___069599_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___069691_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x11U)))))));
    vlSelf->wasmetal_core__DOT___070077_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b100__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b100__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070122_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b103__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b103__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070093_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b101__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070153_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b105__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b105__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070166_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b106__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 8U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b106__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070180_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b107__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b107__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070241_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b111__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xdU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b111__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070270_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b113__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0xfU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b113__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070282_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b114__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x10U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b114__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b115__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x11U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b115__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070320_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b117__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x13U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b117__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070332_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b118__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x14U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b118__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070344_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b119__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x15U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b119__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070372_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b121__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x17U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b121__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070384_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b122__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x18U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b122__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070396_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b123__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x19U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b123__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070409_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b124__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1aU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b124__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070421_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b125__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1bU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b125__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070434_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b126__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1cU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b126__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___070446_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b127__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[3U] 
                                                                        >> 0x1dU)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053281_)))))))));
    vlSelf->wasmetal_core__DOT___069964_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1eU)))))));
    vlSelf->wasmetal_core__DOT___070046_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b98__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 2U)))))));
    vlSelf->__VdfgTmp_h26689d2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052987_));
    vlSelf->wasmetal_core__DOT___053422_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0))))));
    vlSelf->wasmetal_core__DOT___053000_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052999_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052998_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052654_))))));
    vlSelf->wasmetal_core__DOT___046419_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___046420_))));
    vlSelf->wasmetal_core__DOT___053539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___046418_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052876_))));
    vlSelf->wasmetal_core__DOT___067141_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___067443_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b30__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___067651_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b33__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b33__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b33__05d)))))))));
    vlSelf->wasmetal_core__DOT___068280_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b44__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___065282_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b5__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___065722_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b9__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d))))));
    vlSelf->wasmetal_core__DOT___065883_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b11__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d))))));
    vlSelf->wasmetal_core__DOT___066201_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b14__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d))))));
    vlSelf->wasmetal_core__DOT___068808_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b54__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b54__05d))))));
    vlSelf->wasmetal_core__DOT___068954_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b57__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b57__05d))))));
    vlSelf->wasmetal_core__DOT___069003_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b58__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b58__05d))))));
    vlSelf->wasmetal_core__DOT___069052_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b59__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b59__05d))))));
    vlSelf->wasmetal_core__DOT___069196_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b62__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b62__05d))))));
    vlSelf->wasmetal_core__DOT___066383_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___066465_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___066546_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___066622_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___066708_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___066791_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___066873_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___066952_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b23__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___067023_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___067097_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___067251_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___067294_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___067395_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___067536_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___068333_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b45__05d)))))))));
    vlSelf->wasmetal_core__DOT___064715_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b1__05d)))))))));
    vlSelf->wasmetal_core__DOT___065591_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___066297_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___067719_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b34__05d)))))))));
    vlSelf->wasmetal_core__DOT___067801_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b35__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b35__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___067854_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b36__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___067888_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b37__05d)))))))));
    vlSelf->wasmetal_core__DOT___068066_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___068140_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___068226_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___068465_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b47__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b47__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___069079_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b60__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b60__05d)))))))));
    vlSelf->wasmetal_core__DOT___069227_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b63__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b63__05d)))))))));
    vlSelf->wasmetal_core__DOT___064880_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___065393_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b6__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___065499_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___067949_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b38__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b38__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___068192_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b42__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___068388_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___065787_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b10__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___066064_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d))))));
    vlSelf->wasmetal_core__DOT___068541_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___068592_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b50__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___068691_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b52__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b52__05d)))))))));
    vlSelf->wasmetal_core__DOT___069128_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b61__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b61__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b61__05d)))))))));
    vlSelf->wasmetal_core__DOT___068011_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___064449_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___066001_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___067583_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b32__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b32__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___068507_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b48__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b48__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b48__05d)))))))));
    vlSelf->wasmetal_core__DOT___068884_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b56__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b56__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___068639_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b51__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b51__05d)))))))));
    vlSelf->wasmetal_core__DOT___068736_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b53__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___068836_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b55__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b55__05d)))))))));
    vlSelf->wasmetal_core__DOT___065154_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___065041_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02eresult__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052987_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02eresult__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___053283_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edone) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052954_)))));
    vlSelf->wasmetal_core__DOT___052860_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02edone))));
    vlSelf->__VdfgTmp_h803b5189__0 = (((IData)(vlSelf->wasmetal_core__DOT___053281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052859_));
    vlSelf->__VdfgTmp_hb457b6b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052998_));
    vlSelf->wasmetal_core__DOT___052995_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___009510_))));
    vlSelf->wasmetal_core__DOT___053421_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edone))));
    vlSelf->wasmetal_core__DOT___053273_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009510_)))));
    vlSelf->wasmetal_core__DOT___052587_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045744_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->busy))));
    vlSelf->__VdfgTmp_hc49c7557__0 = (((IData)(vlSelf->cmd_valid) 
                                       << 1U) | (IData)(vlSelf->busy));
    vlSelf->wasmetal_core__DOT___063356_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b0__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___063355_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b2__05d))))));
    vlSelf->wasmetal_core__DOT___053613_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053343_))));
    vlSelf->wasmetal_core__DOT___039850_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___039834_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)))))));
    vlSelf->wasmetal_core__DOT___039833_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O) 
                                                          << 1U)) 
                                                      | ((4U 
                                                          & vlSelf->function_locals) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT___039832_ = (1U & (0xff00e2e2U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052996_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128274___O)) 
                                                      | ((4U 
                                                          & (vlSelf->function_locals 
                                                             >> 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053558_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___053562_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053558_))));
    vlSelf->wasmetal_core__DOT___069276_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b64__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069306_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b65__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b66__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069357_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b67__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b68__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069408_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b69__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069432_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b70__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069458_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b71__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069486_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b72__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069553_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b75__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069622_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b78__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069668_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b80__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069842_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b88__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069863_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b89__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b90__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069904_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b91__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b92__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069945_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b93__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___070006_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b96__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___070028_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b97__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067720_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068067_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069228_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069505_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b73__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069529_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b74__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069577_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b76__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069598_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b77__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069690_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b81__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___064881_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065394_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065500_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067950_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068193_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068389_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069642_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b79__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069709_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b82__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b83__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b84__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b85__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b86__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069818_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b87__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069983_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b95__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068542_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068593_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068692_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069129_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___069963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b94__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___066002_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___067584_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068508_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068885_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068640_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068737_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___068837_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065155_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___065042_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___053615_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053308_))));
    vlSelf->wasmetal_core__DOT___053348_ = (1U & (0xbfbf00bfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052990_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052991_)))))));
    vlSelf->wasmetal_core__DOT___053335_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b98__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048484_))));
    vlSelf->wasmetal_core__DOT___053614_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052987_))));
    vlSelf->wasmetal_core__DOT___063021_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052986_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))));
    vlSelf->__VdfgTmp_h2df5fb6a__0 = ((2U & ((4U >> 
                                              ((2U 
                                                & ((4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h73f978ac__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & ((IData)(vlSelf->cmd_kind) 
                                                     >> 1U)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___048483_));
    vlSelf->wasmetal_core__DOT___050388_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->busy) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048483_))));
    vlSelf->wasmetal_core__DOT___052696_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052654_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h14e88ecb__0)))))));
    vlSelf->__VdfgTmp_h4b91004e__0 = (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                       << 1U) | (IData)(vlSelf->insn_valid));
    vlSelf->wasmetal_core__DOT___051017_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___046571_))))));
    vlSelf->wasmetal_core__DOT___062987_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052654_))));
    vlSelf->wasmetal_core__DOT___063079_ = (1U & (0xf153f3fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination_index__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__bulk_source_index__05b17__05d)))))));
    vlSelf->__VdfgTmp_h3e4445d3__0 = (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052987_));
    vlSelf->wasmetal_core__DOT___048485_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048482_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048481_))));
    vlSelf->wasmetal_core__DOT___044073_ = (1U & (0xeU 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044104_))));
    vlSelf->wasmetal_core__DOT___007061_ = (1U & (IData)(
                                                         (0xbf1ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))));
    vlSelf->wasmetal_core__DOT___048306_ = (1U & (0xfe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x1000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x4000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)))))))));
    vlSelf->wasmetal_core__DOT___047961_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x1000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)))))))));
    vlSelf->wasmetal_core__DOT___047967_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))))));
    vlSelf->wasmetal_core__DOT___003041_ = (1U & (0x1fffU 
                                                  >> 
                                                  ((8U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x1000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0))))))));
    vlSelf->wasmetal_core__DOT___048321_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    vlSelf->wasmetal_core__DOT___053331_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044604_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053330_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x9009000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053314_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053313_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b85__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x13U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b81__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x11U))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x9009000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053326_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053325_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b95__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1dU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b94__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1eU))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___053324_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053323_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053322_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x9009U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b77__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b73__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 9U)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053318_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053317_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b92__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x1aU)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b75__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xbU))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1001000000001001ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b84__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0x10U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b80__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 0xeU)) 
                                                                                | ((2U 
                                                                                & ((6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b67__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 3U)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (6U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b66__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (vlSelf->insn_y 
                                                                                >> 2U)))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___021222_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___019818_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___070940_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049928_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070939_))));
    vlSelf->wasmetal_core__DOT___020203_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___070943_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048573_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070939_))));
    vlSelf->wasmetal_core__DOT___021480_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049422_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___070941_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049422_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070939_))));
    vlSelf->wasmetal_core__DOT___020842_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049938_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___071004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049938_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___070939_))));
    vlSelf->wasmetal_core__DOT___020584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___067603_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048537_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___053415_))));
    vlSelf->wasmetal_core__DOT___053988_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049422_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___053415_))));
    vlSelf->wasmetal_core__DOT___053419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049938_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___053415_))));
    vlSelf->wasmetal_core__DOT___054477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048300_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___053415_))));
    vlSelf->wasmetal_core__DOT___050403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048513_))));
    vlSelf->wasmetal_core__DOT___050404_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052578_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048513_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050392_)))));
    vlSelf->wasmetal_core__DOT___062976_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052741_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___052891_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___025060_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048436_))));
    vlSelf->wasmetal_core__DOT___053091_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000359_))));
    vlSelf->wasmetal_core__DOT___054481_ = (1U & (IData)(
                                                         (0xfcf3ff3ffffffff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___062493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048278_))));
    vlSelf->wasmetal_core__DOT___050397_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048398_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050392_)))));
    vlSelf->wasmetal_core__DOT___052693_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048398_))));
    vlSelf->wasmetal_core__DOT___048339_ = (1U & (0x8000U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_op 
                                                       << 3U)) 
                                                   | (((IData)(wasmetal_core__DOT___048337_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000354_))))));
    vlSelf->wasmetal_core__DOT___048434_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT___048337_))));
    vlSelf->wasmetal_core__DOT___048432_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___048337_))));
    vlSelf->wasmetal_core__DOT___052850_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048365_))));
    vlSelf->wasmetal_core__DOT___010005_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007028_)))));
    vlSelf->wasmetal_core__DOT___048367_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048365_))));
    vlSelf->wasmetal_core__DOT___071778_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->wasmetal_core__DOT___056252_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___053753_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048326_))));
    vlSelf->wasmetal_core__DOT___062175_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048320_))));
    vlSelf->wasmetal_core__DOT___053495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048320_))));
    vlSelf->wasmetal_core__DOT___048322_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048320_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007028_))));
    vlSelf->wasmetal_core__DOT___053770_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___048351_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048439_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047781_))));
    vlSelf->wasmetal_core__DOT___048383_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->wasmetal_core__DOT___048404_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x8000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->wasmetal_core__DOT___019280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048343_))));
    vlSelf->__VdfgTmp_h82d8a9a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048343_));
    vlSelf->wasmetal_core__DOT___052900_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048327_)))));
    vlSelf->wasmetal_core__DOT___048384_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048366_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
    vlSelf->wasmetal_core__DOT___048458_ = (1U & (0xf8f7ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h682c3842__0))));
    vlSelf->wasmetal_core__DOT___048414_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048327_))));
}
