#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__32(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__32\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006190_;
    wasmetal_core__DOT___006190_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006195_;
    wasmetal_core__DOT___006195_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006251_;
    wasmetal_core__DOT___006251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006252_;
    wasmetal_core__DOT___006252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006260_;
    wasmetal_core__DOT___006260_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006261_;
    wasmetal_core__DOT___006261_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006269_;
    wasmetal_core__DOT___006269_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006270_;
    wasmetal_core__DOT___006270_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006286_;
    wasmetal_core__DOT___006286_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006287_;
    wasmetal_core__DOT___006287_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006293_;
    wasmetal_core__DOT___006293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006294_;
    wasmetal_core__DOT___006294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006302_;
    wasmetal_core__DOT___006302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006303_;
    wasmetal_core__DOT___006303_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006312_;
    wasmetal_core__DOT___006312_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006313_;
    wasmetal_core__DOT___006313_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006327_;
    wasmetal_core__DOT___006327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006328_;
    wasmetal_core__DOT___006328_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006336_;
    wasmetal_core__DOT___006336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006337_;
    wasmetal_core__DOT___006337_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006346_;
    wasmetal_core__DOT___006346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006347_;
    wasmetal_core__DOT___006347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006355_;
    wasmetal_core__DOT___006355_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006356_;
    wasmetal_core__DOT___006356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006365_;
    wasmetal_core__DOT___006365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006366_;
    wasmetal_core__DOT___006366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006367_;
    wasmetal_core__DOT___006367_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006368_;
    wasmetal_core__DOT___006368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006371_;
    wasmetal_core__DOT___006371_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006379_;
    wasmetal_core__DOT___006379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006442_;
    wasmetal_core__DOT___006442_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006443_;
    wasmetal_core__DOT___006443_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006489_;
    wasmetal_core__DOT___006489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006531_;
    wasmetal_core__DOT___006531_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006532_;
    wasmetal_core__DOT___006532_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006572_;
    wasmetal_core__DOT___006572_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006608_;
    wasmetal_core__DOT___006608_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006611_;
    wasmetal_core__DOT___006611_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006612_;
    wasmetal_core__DOT___006612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___006618_;
    wasmetal_core__DOT___006618_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007069_;
    wasmetal_core__DOT___007069_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007072_;
    wasmetal_core__DOT___007072_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007075_;
    wasmetal_core__DOT___007075_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007087_;
    wasmetal_core__DOT___007087_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007091_;
    wasmetal_core__DOT___007091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007100_;
    wasmetal_core__DOT___007100_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007109_;
    wasmetal_core__DOT___007109_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007113_;
    wasmetal_core__DOT___007113_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007117_;
    wasmetal_core__DOT___007117_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007123_;
    wasmetal_core__DOT___007123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007135_;
    wasmetal_core__DOT___007135_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007145_;
    wasmetal_core__DOT___007145_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___007155_;
    wasmetal_core__DOT___007155_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009495_;
    wasmetal_core__DOT___009495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012317_;
    wasmetal_core__DOT___012317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012357_;
    wasmetal_core__DOT___012357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012358_;
    wasmetal_core__DOT___012358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012359_;
    wasmetal_core__DOT___012359_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___012971_;
    wasmetal_core__DOT___012971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013023_;
    wasmetal_core__DOT___013023_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014473_;
    wasmetal_core__DOT___014473_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014483_;
    wasmetal_core__DOT___014483_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014497_;
    wasmetal_core__DOT___014497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014500_;
    wasmetal_core__DOT___014500_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014501_;
    wasmetal_core__DOT___014501_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014511_;
    wasmetal_core__DOT___014511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014525_;
    wasmetal_core__DOT___014525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014553_;
    wasmetal_core__DOT___014553_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015115_;
    wasmetal_core__DOT___015115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024185_;
    wasmetal_core__DOT___024185_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024194_;
    wasmetal_core__DOT___024194_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024316_;
    wasmetal_core__DOT___024316_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024325_;
    wasmetal_core__DOT___024325_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024451_;
    wasmetal_core__DOT___024451_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024617_;
    wasmetal_core__DOT___024617_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024868_;
    wasmetal_core__DOT___024868_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024876_;
    wasmetal_core__DOT___024876_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___024881_;
    wasmetal_core__DOT___024881_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035332_;
    wasmetal_core__DOT___035332_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035704_;
    wasmetal_core__DOT___035704_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035705_;
    wasmetal_core__DOT___035705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035706_;
    wasmetal_core__DOT___035706_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035792_;
    wasmetal_core__DOT___035792_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035801_;
    wasmetal_core__DOT___035801_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035805_;
    wasmetal_core__DOT___035805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035809_;
    wasmetal_core__DOT___035809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035814_;
    wasmetal_core__DOT___035814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___035825_;
    wasmetal_core__DOT___035825_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043364_;
    wasmetal_core__DOT___043364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043365_;
    wasmetal_core__DOT___043365_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043366_;
    wasmetal_core__DOT___043366_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043387_;
    wasmetal_core__DOT___043387_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043388_;
    wasmetal_core__DOT___043388_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043389_;
    wasmetal_core__DOT___043389_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043428_;
    wasmetal_core__DOT___043428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043429_;
    wasmetal_core__DOT___043429_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043430_;
    wasmetal_core__DOT___043430_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043452_;
    wasmetal_core__DOT___043452_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043453_;
    wasmetal_core__DOT___043453_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043454_;
    wasmetal_core__DOT___043454_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043494_;
    wasmetal_core__DOT___043494_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043495_;
    wasmetal_core__DOT___043495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043516_;
    wasmetal_core__DOT___043516_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043517_;
    wasmetal_core__DOT___043517_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043518_;
    wasmetal_core__DOT___043518_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043753_;
    wasmetal_core__DOT___043753_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043754_;
    wasmetal_core__DOT___043754_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043755_;
    wasmetal_core__DOT___043755_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043777_;
    wasmetal_core__DOT___043777_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043778_;
    wasmetal_core__DOT___043778_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043779_;
    wasmetal_core__DOT___043779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043820_;
    wasmetal_core__DOT___043820_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043821_;
    wasmetal_core__DOT___043821_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043844_;
    wasmetal_core__DOT___043844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043845_;
    wasmetal_core__DOT___043845_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048080_;
    wasmetal_core__DOT___048080_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048081_;
    wasmetal_core__DOT___048081_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048092_;
    wasmetal_core__DOT___048092_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048093_;
    wasmetal_core__DOT___048093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048094_;
    wasmetal_core__DOT___048094_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048095_;
    wasmetal_core__DOT___048095_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048096_;
    wasmetal_core__DOT___048096_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048101_;
    wasmetal_core__DOT___048101_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048102_;
    wasmetal_core__DOT___048102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048103_;
    wasmetal_core__DOT___048103_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048105_;
    wasmetal_core__DOT___048105_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048106_;
    wasmetal_core__DOT___048106_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048107_;
    wasmetal_core__DOT___048107_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048162_;
    wasmetal_core__DOT___048162_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048217_;
    wasmetal_core__DOT___048217_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048218_;
    wasmetal_core__DOT___048218_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048219_;
    wasmetal_core__DOT___048219_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048224_;
    wasmetal_core__DOT___048224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048225_;
    wasmetal_core__DOT___048225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048227_;
    wasmetal_core__DOT___048227_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048228_;
    wasmetal_core__DOT___048228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048229_;
    wasmetal_core__DOT___048229_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048251_;
    wasmetal_core__DOT___048251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048252_;
    wasmetal_core__DOT___048252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048253_;
    wasmetal_core__DOT___048253_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048254_;
    wasmetal_core__DOT___048254_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048255_;
    wasmetal_core__DOT___048255_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048268_;
    wasmetal_core__DOT___048268_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048936_;
    wasmetal_core__DOT___048936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048938_;
    wasmetal_core__DOT___048938_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048939_;
    wasmetal_core__DOT___048939_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048940_;
    wasmetal_core__DOT___048940_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___050077_;
    wasmetal_core__DOT___050077_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056300_;
    wasmetal_core__DOT___056300_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056707_;
    wasmetal_core__DOT___056707_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056934_;
    wasmetal_core__DOT___056934_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056935_;
    wasmetal_core__DOT___056935_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056936_;
    wasmetal_core__DOT___056936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056949_;
    wasmetal_core__DOT___056949_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056971_;
    wasmetal_core__DOT___056971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057033_;
    wasmetal_core__DOT___057033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057064_;
    wasmetal_core__DOT___057064_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057206_;
    wasmetal_core__DOT___057206_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057214_;
    wasmetal_core__DOT___057214_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057296_;
    wasmetal_core__DOT___057296_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057421_;
    wasmetal_core__DOT___057421_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057427_;
    wasmetal_core__DOT___057427_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057612_;
    wasmetal_core__DOT___057612_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058379_;
    wasmetal_core__DOT___058379_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058393_;
    wasmetal_core__DOT___058393_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071843_;
    wasmetal_core__DOT___071843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071866_;
    wasmetal_core__DOT___071866_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___071885_;
    wasmetal_core__DOT___071885_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d;
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127643___O;
    wasmetal_core__DOT____Vcellout___127643___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127660___O;
    wasmetal_core__DOT____Vcellout___127660___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127692___CO;
    wasmetal_core__DOT____Vcellout___127692___CO = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128732___O;
    wasmetal_core__DOT____Vcellout___128732___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128782___O;
    wasmetal_core__DOT____Vcellout___128782___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128783___O;
    wasmetal_core__DOT____Vcellout___128783___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128784___O;
    wasmetal_core__DOT____Vcellout___128784___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128785___O;
    wasmetal_core__DOT____Vcellout___128785___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128786___O;
    wasmetal_core__DOT____Vcellout___128786___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___O;
    wasmetal_core__DOT____Vcellout___128787___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128787___CO;
    wasmetal_core__DOT____Vcellout___128787___CO = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*4:0*/ __VdfgTmp_h00a84c57__0;
    __VdfgTmp_h00a84c57__0 = 0;
    CData/*2:0*/ __VdfgTmp_h32160e17__0;
    __VdfgTmp_h32160e17__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc24ed5a6__0;
    __VdfgTmp_hc24ed5a6__0 = 0;
    CData/*2:0*/ __VdfgTmp_h267c01fb__0;
    __VdfgTmp_h267c01fb__0 = 0;
    CData/*1:0*/ __VdfgTmp_hb49f8759__0;
    __VdfgTmp_hb49f8759__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2242a82b__0;
    __VdfgTmp_h2242a82b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1785588f__0;
    __VdfgTmp_h1785588f__0 = 0;
    // Body
    wasmetal_core__DOT___006379_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048078_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h454147c9__0))))));
    vlSelf->wasmetal_core__DOT___035776_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048079_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048078_))));
    wasmetal_core__DOT___006368_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h2914f84f__0))))));
    wasmetal_core__DOT___006371_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023209_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048097_)))));
    vlSelf->wasmetal_core__DOT___035775_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048098_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048097_))));
    wasmetal_core__DOT___006356_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023206_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048087_)))));
    wasmetal_core__DOT___006367_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048086_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd5e33f95__0))))));
    vlSelf->wasmetal_core__DOT___035774_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048087_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048086_))));
    wasmetal_core__DOT___006355_ = (1U & (0x33aaf0f0U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048168_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5b56c921__0))))));
    vlSelf->wasmetal_core__DOT___035773_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006352_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048168_))));
    wasmetal_core__DOT___006346_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023203_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048201_)))));
    vlSelf->wasmetal_core__DOT___035772_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006343_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048201_))));
    vlSelf->wasmetal_core__DOT___035798_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006333_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006340_))));
    wasmetal_core__DOT___006327_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023198_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048202_)))));
    vlSelf->wasmetal_core__DOT___035797_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048202_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006319_))));
    vlSelf->wasmetal_core__DOT___035796_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006316_))));
    vlSelf->wasmetal_core__DOT___035795_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006306_))));
    wasmetal_core__DOT___006293_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023192_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048077_)))));
    vlSelf->wasmetal_core__DOT___035794_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006290_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048077_))));
    wasmetal_core__DOT___006286_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023189_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048076_)))));
    vlSelf->wasmetal_core__DOT___035793_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048076_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006277_))));
    wasmetal_core__DOT___006261_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023186_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048214_)))));
    wasmetal_core__DOT___006269_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023187_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048213_)))));
    wasmetal_core__DOT___035792_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___048214_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048213_))));
    wasmetal_core__DOT___006252_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023184_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048246_)))));
    vlSelf->wasmetal_core__DOT___035791_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006264_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048246_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127674___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)) 
                   << 3U)) | ((4U & ((9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0)) 
                                     << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___024504_) 
                                                 << 1U) 
                                                | (1U 
                                                   & (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024447_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0)))) {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT___127674___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
    } else {
        wasmetal_core__DOT___024451_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d;
        wasmetal_core__DOT___024617_ = vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127640___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024247_) 
                               << 2U) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024181_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0)))) {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT___127640___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
    } else {
        wasmetal_core__DOT___024185_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d;
        wasmetal_core__DOT___024316_ = vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127657___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h8bc92329__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024247_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_heca6da7c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfd423f40__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127657___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024312_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127722___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024863_)))));
    wasmetal_core__DOT___024868_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127722___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127690___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h284e2fd7__0))) 
                   << 3U)) | ((4U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h6abc2452__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___024504_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7f725de9__0))))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127707___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024613_)))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035384_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_h04659776__0))));
    wasmetal_core__DOT___006489_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048943_)))));
    wasmetal_core__DOT___006190_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___048683_)))));
    if (vlSelf->wasmetal_core__DOT___006127_) {
        wasmetal_core__DOT___006347_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc6c88546__0))))));
        wasmetal_core__DOT___006337_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h13911493__0))))));
        wasmetal_core__DOT___006328_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h89d79bf3__0))))));
        wasmetal_core__DOT___006336_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127441___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf7ef4e0e__0))))));
        wasmetal_core__DOT___006313_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hfa88dfaf__0))))));
        wasmetal_core__DOT___006303_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9fed8b62__0))))));
        wasmetal_core__DOT___006312_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127442___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h3cb929d5__0))))));
        wasmetal_core__DOT___006294_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0283b263__0))))));
        wasmetal_core__DOT___006302_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127428___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hd64632c9__0))))));
        wasmetal_core__DOT___006287_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbacebd3b__0))))));
        wasmetal_core__DOT___006270_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127429___O)) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha45fb011__0))))));
        wasmetal_core__DOT___006260_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            << 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_hab846b7c__0))))));
        wasmetal_core__DOT___006251_ = (1U & (0xf0f0077U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127430___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_he55adf41__0))))));
        wasmetal_core__DOT___006195_ = (1U & (0xf0f00ddU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                      << 3U) 
                                                     | ((4U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127431___O) 
                                                            << 2U)) 
                                                        | (IData)(vlSelf->__VdfgTmp_h21922827__0))))));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006479_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006478_)))))))));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006478_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006475_)))))))));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006475_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006474_)))))))));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006474_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006469_)))))))));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006469_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006468_)))))))));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006468_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006463_)))))))));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006463_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006462_)))))))));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006462_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006457_)))))))));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006457_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006456_)))))))));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006456_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006451_)))))))));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006451_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006450_)))))))));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006450_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006445_)))))))));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006445_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006444_)))))))));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006444_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006435_)))))))));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006435_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006434_)))))))));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006434_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006429_)))))))));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006429_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006428_)))))))));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006428_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006423_)))))))));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006423_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006422_)))))))));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006422_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006419_)))))))));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006419_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006418_)))))))));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006418_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006384_)))))))));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006384_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006383_)))))))));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006383_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006380_)))))))));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006380_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006379_)))))))));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006379_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___006372_)))))))));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___006372_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006371_)))))))));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006371_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006368_)))))))));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006368_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006367_)))))))));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006367_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006356_)))))))));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006356_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006355_)))))))));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006355_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006347_)))))))));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006347_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006346_)))))))));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006346_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006337_)))))))));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006337_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006336_)))))))));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006336_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006328_)))))))));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006328_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006327_)))))))));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006327_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006313_)))))))));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006313_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006312_)))))))));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006312_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006303_)))))))));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006303_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006302_)))))))));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006302_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006294_)))))))));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006294_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006293_)))))))));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006293_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006287_)))))))));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006287_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006286_)))))))));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006286_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006270_)))))))));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006270_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006269_)))))))));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006269_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006261_)))))))));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006261_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006260_)))))))));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006260_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006252_)))))))));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006252_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006251_)))))))));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006190_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006489_)))))))));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006195_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006190_)))))))));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (IData)(
                                                          (0xbfffffff80000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___006251_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006194_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006192_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                         << 1U) 
                                                                        | (IData)(wasmetal_core__DOT___006195_)))))))));
    } else {
        wasmetal_core__DOT___006347_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006352_)));
        wasmetal_core__DOT___006337_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006343_)));
        wasmetal_core__DOT___006328_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006333_)));
        wasmetal_core__DOT___006336_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006340_)));
        wasmetal_core__DOT___006313_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006319_)));
        wasmetal_core__DOT___006303_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006309_)));
        wasmetal_core__DOT___006312_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006316_)));
        wasmetal_core__DOT___006294_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006299_)));
        wasmetal_core__DOT___006302_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006306_)));
        wasmetal_core__DOT___006287_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006290_)));
        wasmetal_core__DOT___006270_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006277_)));
        wasmetal_core__DOT___006260_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006264_)));
        wasmetal_core__DOT___006251_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006255_)));
        wasmetal_core__DOT___006195_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___006246_)));
        vlSelf->wasmetal_core__DOT___006614_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006478_)));
        vlSelf->wasmetal_core__DOT___006569_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006475_)));
        vlSelf->wasmetal_core__DOT___006615_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006474_)));
        vlSelf->wasmetal_core__DOT___006570_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006469_)));
        vlSelf->wasmetal_core__DOT___006616_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006468_)));
        vlSelf->wasmetal_core__DOT___006571_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006463_)));
        vlSelf->wasmetal_core__DOT___006438_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006462_)));
        vlSelf->wasmetal_core__DOT___006554_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006457_)));
        vlSelf->wasmetal_core__DOT___006439_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006456_)));
        vlSelf->wasmetal_core__DOT___006555_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006451_)));
        vlSelf->wasmetal_core__DOT___006440_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006450_)));
        vlSelf->wasmetal_core__DOT___006556_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006445_)));
        vlSelf->wasmetal_core__DOT___006441_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006444_)));
        vlSelf->wasmetal_core__DOT___006557_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006435_)));
        vlSelf->wasmetal_core__DOT___006413_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006434_)));
        vlSelf->wasmetal_core__DOT___006541_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006429_)));
        vlSelf->wasmetal_core__DOT___006414_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006428_)));
        vlSelf->wasmetal_core__DOT___006542_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006423_)));
        vlSelf->wasmetal_core__DOT___006415_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006422_)));
        vlSelf->wasmetal_core__DOT___006543_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006419_)));
        vlSelf->wasmetal_core__DOT___006416_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006418_)));
        vlSelf->wasmetal_core__DOT___006544_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006384_)));
        vlSelf->wasmetal_core__DOT___006361_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006383_)));
        vlSelf->wasmetal_core__DOT___006527_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006380_)));
        vlSelf->wasmetal_core__DOT___006362_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006379_)));
        vlSelf->wasmetal_core__DOT___006528_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006372_)));
        vlSelf->wasmetal_core__DOT___006363_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006371_)));
        vlSelf->wasmetal_core__DOT___006529_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006368_)));
        vlSelf->wasmetal_core__DOT___006364_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006367_)));
        vlSelf->wasmetal_core__DOT___006530_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006356_)));
        vlSelf->wasmetal_core__DOT___006322_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006355_)));
        vlSelf->wasmetal_core__DOT___006514_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006347_)));
        vlSelf->wasmetal_core__DOT___006323_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006346_)));
        vlSelf->wasmetal_core__DOT___006515_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006337_)));
        vlSelf->wasmetal_core__DOT___006324_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006336_)));
        vlSelf->wasmetal_core__DOT___006516_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006328_)));
        vlSelf->wasmetal_core__DOT___006325_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006327_)));
        vlSelf->wasmetal_core__DOT___006517_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006313_)));
        vlSelf->wasmetal_core__DOT___006280_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006312_)));
        vlSelf->wasmetal_core__DOT___006500_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006303_)));
        vlSelf->wasmetal_core__DOT___006281_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006302_)));
        vlSelf->wasmetal_core__DOT___006501_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006294_)));
        vlSelf->wasmetal_core__DOT___006282_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006293_)));
        vlSelf->wasmetal_core__DOT___006502_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006287_)));
        vlSelf->wasmetal_core__DOT___006283_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006286_)));
        vlSelf->wasmetal_core__DOT___006503_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006270_)));
        vlSelf->wasmetal_core__DOT___005691_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006269_)));
        vlSelf->wasmetal_core__DOT___006484_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006261_)));
        vlSelf->wasmetal_core__DOT___005692_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006260_)));
        vlSelf->wasmetal_core__DOT___006485_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006252_)));
        vlSelf->wasmetal_core__DOT___005693_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006251_)));
        vlSelf->wasmetal_core__DOT___006487_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006489_)));
        vlSelf->wasmetal_core__DOT___005694_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006190_)));
        vlSelf->wasmetal_core__DOT___006486_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___006195_)));
    }
    wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d 
        = (1U & (7U >> (((IData)(vlSelf->wasmetal_core__DOT___048943_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048683_))));
    vlSelf->wasmetal_core__DOT___035782_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006246_))));
    vlSelf->wasmetal_core__DOT___057260_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127674___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057257_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057256_)))))))));
    if (vlSelf->wasmetal_core__DOT___024507_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024451_;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024617_;
    }
    vlSelf->wasmetal_core__DOT___043818_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043817_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043842_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043492_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)))));
    wasmetal_core__DOT___071866_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024185_;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__ 
            = wasmetal_core__DOT___024316_;
    }
    vlSelf->wasmetal_core__DOT___043363_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)))));
    vlSelf->wasmetal_core__DOT___043752_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043751_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043776_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___071885_ = (1U & (6U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           & (IData)(wasmetal_core__DOT___024868_));
    vlSelf->wasmetal_core__DOT___043427_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___043426_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                          << 2U)) 
                                                      | (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___043451_ = (1U & (0x4002U 
                                                  >> 
                                                  ((0xeU 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043450_ = (1U & (0x4002U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                       << 3U)) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035385_)
                  ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__)
                  : (0xcaU >> (IData)(vlSelf->__VdfgTmp_hc17e62e9__0))));
    vlSelf->__VdfgTmp_hf3b81358__0 = (((IData)(wasmetal_core__DOT___006489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050073_));
    wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035782_));
    vlSelf->__VdfgTmp_hb69d909d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006569_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006568_));
    vlSelf->__VdfgTmp_h46e4da0c__0 = (((IData)(vlSelf->wasmetal_core__DOT___006615_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006614_));
    vlSelf->__VdfgTmp_hc1f8ef63__0 = (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_));
    vlSelf->__VdfgTmp_he99783ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_));
    vlSelf->__VdfgTmp_h8be5cf2e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006554_));
    vlSelf->__VdfgTmp_ha20d2c5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006440_));
    vlSelf->__VdfgTmp_h45e8af23__0 = (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006281_));
    vlSelf->__VdfgTmp_h19cea986__0 = (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006501_));
    vlSelf->__VdfgTmp_hc8c3f180__0 = (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006282_));
    vlSelf->__VdfgTmp_h8170b1e8__0 = (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006502_));
    vlSelf->__VdfgTmp_h980f95b2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006283_));
    vlSelf->__VdfgTmp_h088d475b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006503_));
    vlSelf->__VdfgTmp_ha3862ccc__0 = (((IData)(vlSelf->wasmetal_core__DOT___005692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005691_));
    vlSelf->__VdfgTmp_hfc403f7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006485_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006484_));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)))) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043841_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071861_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071862_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071866_)))));
    vlSelf->wasmetal_core__DOT___043515_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071866_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___043386_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___071885_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((9U 
                                                           >> 
                                                           ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (9U 
                                                            >> 
                                                            ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                 >> 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))));
    vlSelf->wasmetal_core__DOT___043775_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071880_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071881_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___071885_)))));
    wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___035332_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035386_)
                                           ? (IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__)
                                           : (0xcaU 
                                              >> (IData)(vlSelf->__VdfgTmp_heb875033__0))));
    wasmetal_core__DOT____Vcellout___128732___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035386_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035385_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035384_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035383_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128732___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128732___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035328_)))));
    wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035791_) 
           & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_ha576ac17__0 = (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    vlSelf->__VdfgTmp_h455b45b4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    if (vlSelf->wasmetal_core__DOT___024509_) {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
    } else {
        wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d;
        wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__;
    }
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)))) {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
    } else {
        wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d;
        wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hd481047b__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 2U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_h1c3d35c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              >> 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf5c220e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___128732___O)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_hf7faa60c__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128731___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->__VdfgTmp_ha523ac5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___014611_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___128732___O) 
                                                           >> 1U)) 
                                                       | ((2U 
                                                           & (((0xdf2f20dU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1b3b7d3d__0)) 
                                                               ^ (IData)(wasmetal_core__DOT___035332_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___014610_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128781___O 
        = ((((IData)(wasmetal_core__DOT___035792_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                   << 1U) | (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_reduced2SigSum__05b27__05d)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035821_ = ((IData)(wasmetal_core__DOT___035792_) 
                                            & (IData)(wasmetal_core__DOT___128781___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127675___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___010032_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___024509_) 
                        << 2U) | ((2U & ((9U >> (IData)(vlSelf->__VdfgTmp_h862c0500__0)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___024507_)))) 
           ^ (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127675___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024451_)))));
    if (vlSelf->wasmetal_core__DOT___010032_) {
        vlSelf->wasmetal_core__DOT___024455_ = wasmetal_core__DOT___127675___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024621_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024455_ = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d;
        vlSelf->wasmetal_core__DOT___024621_ = wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127641___O 
        = (((8U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)) 
                   << 3U)) | ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0)) 
                                     << 2U)) | ((2U 
                                                 & ((6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hde45e173__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127641___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024185_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0)))) {
        vlSelf->wasmetal_core__DOT___024189_ = wasmetal_core__DOT___127641___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___024320_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024189_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d;
        vlSelf->wasmetal_core__DOT___024320_ = wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127658___O 
        = (((8U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5f27695b__0))) 
                   << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h546dd473__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h742ef24c__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hde45e173__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127658___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024316_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127723___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
           ^ (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024868_)))));
    vlSelf->wasmetal_core__DOT___024872_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127723___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127691___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010032_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024509_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h862c0500__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___024507_)))))) 
           ^ (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127708___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024617_)))));
    vlSelf->wasmetal_core__DOT___048226_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                       >> 2U)) 
                                                   | (IData)(wasmetal_core__DOT___035792_))));
    vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035793_) 
           & (IData)(vlSelf->wasmetal_core__DOT___035821_));
    vlSelf->wasmetal_core__DOT___012024_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    vlSelf->wasmetal_core__DOT___010380_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127675___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))) {
        vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024455_;
        wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d;
        wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024621_;
    }
    vlSelf->wasmetal_core__DOT___043819_ = (1U & (0x7f00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | (7U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O)))));
    vlSelf->wasmetal_core__DOT___043843_ = (1U & (0x8001U 
                                                  >> 
                                                  ((0xeU 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    vlSelf->wasmetal_core__DOT___043493_ = (1U & (0xfe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 3U) 
                                                   | ((6U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___043516_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024189_;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024320_;
    }
    wasmetal_core__DOT___043364_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043753_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O)))));
    wasmetal_core__DOT___043387_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043777_ = (1U & (0x8001U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___057064_ = (1U & (IData)((0xf00bb00ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___056872_ = (1U & (0xfdd0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___024872_));
    wasmetal_core__DOT___043428_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | (7U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)))));
    wasmetal_core__DOT___043452_ = (1U & (0x4002U >> 
                                          ((0xeU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                             << 1U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))));
    wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035794_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)))) {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
    } else {
        wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d;
        wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__;
    }
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035795_) 
           & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127676___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___024511_) 
                               << 2U) | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0)) 
                                                << 1U)) 
                                         | (1U & (9U 
                                                  >> (IData)(vlSelf->__VdfgTmp_ha0636656__0)))))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___024511_)
                 ? (IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127676___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127676___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024455_)))));
    if ((1U & (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)))) {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
    } else {
        wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d;
        wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__;
    }
    wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___024511_)
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128782___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035794_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035793_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128782___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035821_)))));
    wasmetal_core__DOT___035825_ = ((IData)(vlSelf->wasmetal_core__DOT___035796_) 
                                    & (IData)(wasmetal_core__DOT___128782___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___057276_ = (1U & (IData)(
                                                         (0xf0f3f0f5ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hde86d559__0))))))));
    wasmetal_core__DOT___012358_ = (1U & (0x40U >> 
                                          ((4U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))));
    if (vlSelf->wasmetal_core__DOT___024256_) {
        wasmetal_core__DOT___024194_ = wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___024325_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
    } else {
        wasmetal_core__DOT___024194_ = vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d;
        wasmetal_core__DOT___024325_ = wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127642___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___024256_) 
             << 3U) | ((4U & ((0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0)) 
                              << 2U)) | ((2U & ((0x4fb0U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5b180012__0)) 
                                                << 1U)) 
                                         | (1U & (6U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7b799034__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127642___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024189_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127659___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024256_)) 
                   << 3U)) | ((4U & ((~ (0x4fb0U >> (IData)(vlSelf->__VdfgTmp_h36d9d765__0))) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (0x4fb0U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5b180012__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (6U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7b799034__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127659___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024320_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127724___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
           ^ (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024872_)))));
    wasmetal_core__DOT___024876_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127724___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___048081_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128782___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035794_))));
    wasmetal_core__DOT___048096_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035796_))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035797_) 
           & (IData)(wasmetal_core__DOT___035825_));
    wasmetal_core__DOT____Vcellout___127643___O = ((IData)(vlSelf->wasmetal_core__DOT___024256_) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(wasmetal_core__DOT___024194_)
                                                       : (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024194_)));
    wasmetal_core__DOT___043820_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043844_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043494_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043517_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT____Vcellout___127660___O = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->wasmetal_core__DOT___024256_))) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT___024256_)
                                                       ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d)
                                                       : (IData)(wasmetal_core__DOT___024325_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___024325_)));
    wasmetal_core__DOT___043365_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 2U)) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043754_ = (1U & (0x7f00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043388_ = (1U & (0x4002U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043778_ = (1U & (0x8001U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    vlSelf->__VdfgTmp_hc4dae929__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                    >> 2U)));
    wasmetal_core__DOT____Vcellout___127692___CO = 
        ((((1U & (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)
            : (IData)(wasmetal_core__DOT___127709___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127692___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_haa7da8bd__0))) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___024511_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (9U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h78ee927d__0))) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (9U 
                                                       >> (IData)(vlSelf->__VdfgTmp_ha0636656__0))))))) 
           ^ (((IData)(wasmetal_core__DOT___127709___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024621_)));
    wasmetal_core__DOT___048107_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035795_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128782___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035798_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___043821_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                       >> 2U)))))));
    wasmetal_core__DOT___043845_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043495_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043518_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127643___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043366_ = (1U & (0xfef0U >> 
                                          ((0x10U & 
                                            ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                             << 4U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     >> 1U)) 
                                                 | ((2U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                          >> 2U))))))));
    wasmetal_core__DOT___043389_ = (1U & (0x1000010U 
                                          >> ((0x10U 
                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                  << 3U)) 
                                              | ((8U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                     << 1U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                             >> 3U))))))));
    wasmetal_core__DOT___043779_ = (1U & (0x9000U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___043755_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(wasmetal_core__DOT____Vcellout___127660___O) 
                                                  << 3U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->__VdfgTmp_hc4dae929__0)))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           & (IData)(wasmetal_core__DOT___024876_));
    wasmetal_core__DOT___043430_ = (1U & (0xffe0U >> 
                                          ((8U & (IData)(wasmetal_core__DOT____Vcellout___127692___CO)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                               << 2U) 
                                              | (3U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                    >> 2U))))));
    wasmetal_core__DOT___043429_ = (1U & (0xfe00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 3U) 
                                           | ((6U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                << 1U)) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                    >> 3U))))));
    wasmetal_core__DOT___043454_ = (1U & (0x1004U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                  << 1U)) 
                                           | ((4U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                >> 1U)) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___043453_ = (1U & (0x4002U >> 
                                          ((0xcU & 
                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                             << 2U)) 
                                           | ((2U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))));
    wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035772_) 
           & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___043801_ = (1U & ((IData)(wasmetal_core__DOT___043845_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043844_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043843_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043842_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043841_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043840_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043839_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043838_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043837_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043836_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043835_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043834_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043853_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043852_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043851_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043850_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043849_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043848_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043847_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043846_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043823_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043824_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043825_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043826_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043827_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043828_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043829_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043810_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043811_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043812_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043813_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043814_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043815_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043816_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043817_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043818_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043819_))
                                                    : (IData)(wasmetal_core__DOT___043820_))
                                                   : (IData)(wasmetal_core__DOT___043821_)));
    vlSelf->wasmetal_core__DOT___043475_ = (1U & ((IData)(wasmetal_core__DOT___043518_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043517_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043516_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043515_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043514_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043513_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043512_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043511_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043510_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043509_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043508_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043507_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043525_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043524_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043523_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043522_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043521_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043520_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043519_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043497_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043498_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043499_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043500_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043501_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043502_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043484_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043485_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043486_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043487_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043488_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043489_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043490_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043491_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043492_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043493_))
                                                    : (IData)(wasmetal_core__DOT___043494_))
                                                   : (IData)(wasmetal_core__DOT___043495_)));
    vlSelf->wasmetal_core__DOT___043346_ = (1U & ((IData)(wasmetal_core__DOT___043389_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043388_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043387_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043386_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043385_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043384_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043383_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043382_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043381_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043380_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043379_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043378_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043396_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043395_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043394_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043393_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043392_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043391_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043390_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | ((6U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                                >> 3U))))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043368_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043369_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043370_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043371_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043372_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043373_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043355_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043356_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043357_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043358_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043359_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043360_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043361_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043362_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043363_))
                                                     : (IData)(wasmetal_core__DOT___043364_))
                                                    : (IData)(wasmetal_core__DOT___043365_))
                                                   : (IData)(wasmetal_core__DOT___043366_)));
    vlSelf->wasmetal_core__DOT___043735_ = (1U & ((IData)(wasmetal_core__DOT___043779_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043778_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043777_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043776_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043775_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043774_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043773_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043772_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043771_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043770_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043769_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043768_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043787_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043786_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043785_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043784_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043783_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043782_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___043781_)
                                                                     ? 
                                                                    ((~ (IData)(vlSelf->wasmetal_core__DOT___043780_)) 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hb920cb05__0)))
                                                                     : (IData)(vlSelf->wasmetal_core__DOT___043757_))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043758_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043759_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043760_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043761_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043762_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043763_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043744_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043745_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043746_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043747_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043748_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043749_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043750_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043751_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043752_))
                                                     : (IData)(wasmetal_core__DOT___043753_))
                                                    : (IData)(wasmetal_core__DOT___043754_))
                                                   : (IData)(wasmetal_core__DOT___043755_)));
    wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___043410_ = (1U & ((IData)(wasmetal_core__DOT___043454_)
                                                   ? 
                                                  ((IData)(wasmetal_core__DOT___043453_)
                                                    ? 
                                                   ((IData)(wasmetal_core__DOT___043452_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___043451_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043450_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043449_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043448_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043447_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___043446_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___043445_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___043444_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___043443_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___043461_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___043460_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___043459_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___043458_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___043457_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___043456_)
                                                                    ? 
                                                                   ((~ (IData)(vlSelf->wasmetal_core__DOT___043455_)) 
                                                                    & (0xfe00U 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 3U) 
                                                                        | (7U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))
                                                                    : (IData)(vlSelf->wasmetal_core__DOT___043432_))
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___043433_))
                                                                  : (IData)(vlSelf->wasmetal_core__DOT___043434_))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___043435_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___043436_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___043437_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043419_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043420_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043421_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043422_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043423_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043424_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043425_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043426_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043427_))
                                                     : (IData)(wasmetal_core__DOT___043428_))
                                                    : (IData)(wasmetal_core__DOT___043429_))
                                                   : (IData)(wasmetal_core__DOT___043430_)));
    wasmetal_core__DOT____Vcellout___128783___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035798_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035797_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035825_)))));
    wasmetal_core__DOT___035801_ = ((IData)(vlSelf->wasmetal_core__DOT___035773_) 
                                    & (IData)(wasmetal_core__DOT___128783___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___056936_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___056949_ = (1U & (0xc0aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                       >> 3U)))))));
    wasmetal_core__DOT___057206_ = (1U & (0xcc0035U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O))))))));
    wasmetal_core__DOT___056935_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043475_)))));
    vlSelf->wasmetal_core__DOT___057477_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012944_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057489_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((~ (IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127735___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127669___O) 
                                                                                >> 2U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012954_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128556___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057339_ = (1U & (IData)(
                                                         (0xff00fff0f0eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057332_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___043735_))))))))))));
    vlSelf->wasmetal_core__DOT___057348_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127729___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012594_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1d1d0f55U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056062_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127721___O) 
                                                                                >> 1U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127655___O) 
                                                                                >> 1U)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128543___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057282_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___057125_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127723___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127657___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056997_ = (1U & (IData)(
                                                         (0xcfcffcee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056993_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056941_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055964_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O))))))))));
    vlSelf->wasmetal_core__DOT___056954_ = (1U & (IData)(
                                                         (0xf0f055cc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010053_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127664___O) 
                                                                                >> 3U)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O))))))))));
    vlSelf->wasmetal_core__DOT___056841_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 2U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056881_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((0xf3faU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127722___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127656___O) 
                                                                                >> 2U)))))))))))) 
                                                                         & (IData)(
                                                                                (0x57f757f755ff7777ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010647_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056684_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___056696_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127668___O) 
                                                                                >> 1U))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)))))))));
    vlSelf->wasmetal_core__DOT___011275_ = (1U & (0xf5fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127662___O) 
                                                                              >> 1U)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127728___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___010379_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf3fa00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056318_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127724___O)) 
                                                                              | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056411_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f033aaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0x774477775f505f5fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056038_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127720___O)) 
                                                                                | (1U 
                                                                                & (0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127654___O)))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010376_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O))))))))));
    vlSelf->wasmetal_core__DOT___056512_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127732___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((0x35U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127666___O))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    wasmetal_core__DOT___057427_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                >> 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                              >> 2U))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___012513_ = (1U & (0xf110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xf044U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128552___O) 
                                                                      << 2U)) 
                                                                  | ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010376_))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xee22fa0a00000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012502_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000005533ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127731___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127665___O))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))))))))));
    wasmetal_core__DOT___057214_ = (1U & (IData)((0xf0f000005533ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127733___O) 
                                                                << 1U)) 
                                                            | ((2U 
                                                                & ((0x35U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O))))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))));
    vlSelf->wasmetal_core__DOT___013161_ = (1U & ((0xf3fa0000U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127734___O) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xcc35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127667___O) 
                                                                                >> 3U)))))))))))) 
                                                  & (IData)(
                                                            (0x57f757f755ff7777ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                  << 4U) 
                                                                 | ((8U 
                                                                     & ((0xfef0U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009711_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010378_))))))))));
    wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057400_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057413_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057435_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___057333_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___057197_ = (1U & (IData)(
                                                         (0xfff0fff0ffff2222ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127644___O))))))))));
    vlSelf->wasmetal_core__DOT___057190_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O))))))))));
    wasmetal_core__DOT___056971_ = (1U & (IData)((0xf000f0000ddddULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                >> 1U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                     >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___056791_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___056808_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127649___O) 
                                                                                >> 2U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                             >> 2U))))))))));
    wasmetal_core__DOT___056707_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aa0f0f00000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xcc35U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 2U)))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 2U)))))))))))));
    vlSelf->wasmetal_core__DOT___056754_ = (1U & (IData)(
                                                         (0xf000f0000ddddULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___011255_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O) 
                                                                                >> 1U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___056574_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O) 
                                                                                >> 1U)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O) 
                                                                                >> 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___056581_ = (1U & (IData)(
                                                         (0xf0f000000bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056578_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0fff0ffff2222ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056576_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___056471_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xf000f0000bbbbULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                          << 3U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___043801_))))))))))
                                                   : 
                                                  (0xbbbb0fffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010904_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011068_))))))));
    vlSelf->wasmetal_core__DOT___056493_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x33aa0f0f00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xcc35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127645___O)))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127695___O)))))))))))));
    vlSelf->wasmetal_core__DOT___056518_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127647___O)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O))))))))));
    vlSelf->wasmetal_core__DOT___057618_ = (1U & (IData)(
                                                         (0x11fff0ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha95c81f0__0)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127661___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___057612_ = (1U & (IData)((0x33aa0f0f00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xcc35U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127646___O) 
                                                                              >> 3U)))))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127696___O) 
                                                                     >> 3U))))))))));
    wasmetal_core__DOT___013023_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0x33aaf0f000000000ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((0xeU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 3U))))) 
                                                                             << 2U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                                                >> 3U)))))))))))));
    vlSelf->wasmetal_core__DOT___013177_ = (1U & (IData)(
                                                         (0x33aa0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc35U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127648___O) 
                                                                                >> 3U)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127698___O) 
                                                                             >> 3U))))))))));
    wasmetal_core__DOT___056934_ = (1U & (0xd0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    vlSelf->wasmetal_core__DOT___056297_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___043410_)))));
    wasmetal_core__DOT___048219_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128783___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035798_))));
    wasmetal_core__DOT___048218_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035773_))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035774_) 
           & (IData)(wasmetal_core__DOT___035801_));
    vlSelf->wasmetal_core__DOT___012896_ = (1U & (IData)(
                                                         (0xf0f0f0fd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057427_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfdd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                             ? 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))
                                                                             : 
                                                                            (0x77747777U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009708_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009707_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010972_))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))));
    vlSelf->wasmetal_core__DOT___012512_ = (1U & (IData)(
                                                         (0x1111000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057214_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xee22fa0a00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009712_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128554___O) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___010378_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x10U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010378_)))))))))))));
    wasmetal_core__DOT___024881_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                     >> 3U) & (IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127725___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
           ^ (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127725___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___024876_)))));
    vlSelf->wasmetal_core__DOT___056981_ = (1U & (IData)(
                                                         (0xccaa00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00ffffff4040ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056972_) 
                                                                                << 4U) 
                                                                                | (((IData)(wasmetal_core__DOT___056971_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127636___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xdd11f505U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056213_)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf0f00ddU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127727___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127653___O) 
                                                                                >> 3U))))))))))))))));
    vlSelf->wasmetal_core__DOT___056712_ = (1U & (IData)(
                                                         (0xff00bb00ff000f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056707_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056706_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127678___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057626_ = (1U & (IData)(
                                                         (0x11110000000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffff1000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057606_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057559_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127730___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127663___O) 
                                                                                >> 3U))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___008974_)))))))) 
                                                                           << 1U)) 
                                                                       | ((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                              ? 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))
                                                                              : 
                                                                             (0x888b8888U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___013087_) 
                                                                                << 4U) 
                                                                               | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h69066ba7__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d))))))))))))))));
    wasmetal_core__DOT___057421_ = (1U & (0xd0U >> 
                                          (((IData)(wasmetal_core__DOT___056934_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                    >> 2U))))));
    __VdfgTmp_h267c01fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                               << 2U) | (((IData)(wasmetal_core__DOT___056935_) 
                                          << 1U) | (IData)(wasmetal_core__DOT___056934_)));
    vlSelf->wasmetal_core__DOT___012481_ = (1U & (IData)(
                                                         (0xff00b000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057206_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056934_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127700___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    vlSelf->wasmetal_core__DOT___057510_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___012971_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O) 
                                                                                >> 2U))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O) 
                                                          >> 2U))))))));
    vlSelf->wasmetal_core__DOT___012604_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___057296_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127638___O) 
                                                                              >> 1U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127688___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___057120_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127640___O))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127690___O) 
                                                                    << 1U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012359_ = (1U & (0xdf0fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 3U) 
                                              | ((4U 
                                                  & ((IData)(
                                                             (0xcfcffcee00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127642___O))))))))) 
                                                     << 2U)) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127692___O))))))));
    wasmetal_core__DOT___057033_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012283_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x4f00U 
                                                         >> 
                                                         ((8U 
                                                           & ((0xccfe0000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                          << 1U) 
                                                                         | (1U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                               >> 3U))))))) 
                                                              << 3U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                                    >> 2U)) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___043410_)))))))));
    wasmetal_core__DOT___012317_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O) 
                                                                              >> 3U))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___012331_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056836_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                                >> 2U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___011685_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056680_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O) 
                                                                                >> 1U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___056691_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xccfe0000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127637___O) 
                                                                              >> 1U))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127687___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___056403_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127651___O))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127701___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___010381_ = (1U & (0xdf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xcfcffcee00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127641___O))))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043410_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127691___O))))))));
    wasmetal_core__DOT___056300_ = (1U & (0x4f00U >> 
                                          ((8U & ((IData)(
                                                          (0xcfcffcee00000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127639___O))))))))) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127689___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    vlSelf->wasmetal_core__DOT___013083_ = (1U & (0x4f00U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xcfcffcee00000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127652___O) 
                                                                                >> 3U))))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056297_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127702___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___043410_))))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035775_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013010_ = (1U & ((~ 
                                                   (0x10U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(
                                                                    (0xf0f0000000eeULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                             << 3U) 
                                                                            | (((IData)(
                                                                                (((IData)(wasmetal_core__DOT____Vcellout___127692___CO) 
                                                                                >> 3U) 
                                                                                ^ (IData)(wasmetal_core__DOT___024881_))) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O) 
                                                                                >> 3U))))))))) 
                                                            << 1U)) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xee22fa0a00000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056134_))))))))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010378_)
                                                      ? 
                                                     (1U 
                                                      >> (IData)(wasmetal_core__DOT___013023_))
                                                      : (IData)(
                                                                (0xf0fff3fff0fff5ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                      << 4U) 
                                                                     | (((IData)(wasmetal_core__DOT___013023_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x40U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h786db0b3__0))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hcfb94f0b__0))))))))));
    wasmetal_core__DOT___012357_ = (1U & (IData)((0xf0f033aa00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x1d1d0f55U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___056207_)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)) 
                                                               | (1U 
                                                                  & (0xcc35U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127659___O)))))))))))))));
    vlSelf->wasmetal_core__DOT___057073_ = (1U & (IData)(
                                                         (0xff00f000ff00ee00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057064_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1d1d0f55U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011171_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011170_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hab523f16__0)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xcc0035U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___043346_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___043735_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127658___O) 
                                                                                >> 3U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127725___O)))))))))))));
    vlSelf->wasmetal_core__DOT___057423_ = (1U & (IData)(
                                                         (0xff00e000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009691_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___056935_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___043475_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x35U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___043801_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127650___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___056940_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127699___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056936_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    vlSelf->wasmetal_core__DOT___056953_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010077_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f13551100000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127697___O) 
                                                                         << 1U)) 
                                                                     | (((IData)(wasmetal_core__DOT___056949_) 
                                                                         << 3U) 
                                                                        | (IData)(__VdfgTmp_h267c01fb__0))))))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        if (vlSelf->wasmetal_core__DOT___010378_) {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (2U >> (IData)(wasmetal_core__DOT___012971_)));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (1U >> (IData)(wasmetal_core__DOT___012317_)));
        } else {
            vlSelf->wasmetal_core__DOT___057523_ = 
                (1U & (0xb0U >> (((IData)(wasmetal_core__DOT___012971_) 
                                  << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127676___O) 
                                                   >> 1U)) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
            vlSelf->wasmetal_core__DOT___057060_ = 
                (1U & (0xbU >> (((IData)(wasmetal_core__DOT___012317_) 
                                 << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                  >> 2U)) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___011068_)))));
        }
    } else if (vlSelf->wasmetal_core__DOT___010378_) {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (2U 
                                                   >> (IData)(wasmetal_core__DOT___012971_)));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (1U 
                                                   >> (IData)(wasmetal_core__DOT___012317_)));
    } else {
        vlSelf->wasmetal_core__DOT___057523_ = (1U 
                                                & (0xe00U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012971_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb6e1260e__0))));
        vlSelf->wasmetal_core__DOT___057060_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___012317_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012316_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012315_))))));
    }
    vlSelf->wasmetal_core__DOT___057299_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057295_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127672___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    vlSelf->wasmetal_core__DOT___057040_ = (1U & (IData)(
                                                         (0xff00fff1ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___057033_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057032_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057031_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057030_)))))))));
    vlSelf->wasmetal_core__DOT___010076_ = (1U & (IData)(
                                                         (0xff00bb00ff00f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056300_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056299_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127673___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011068_)))))))));
    wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035776_) 
           & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012354_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009691_)) 
                                                  & (IData)(
                                                            (0xfff0fffeff00ff00ULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___012359_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___012358_) 
                                                                  << 4U) 
                                                                 | (((IData)(wasmetal_core__DOT___012357_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012356_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010376_))))))))));
    wasmetal_core__DOT____Vcellout___128784___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035776_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035775_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035774_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035801_)))));
    wasmetal_core__DOT___035805_ = ((IData)(vlSelf->wasmetal_core__DOT___035777_) 
                                    & (IData)(wasmetal_core__DOT___128784___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048095_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035774_))));
    wasmetal_core__DOT___048080_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035776_))));
    wasmetal_core__DOT___048102_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128784___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035775_))));
    wasmetal_core__DOT___048101_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128784___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035777_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035778_) 
           & (IData)(wasmetal_core__DOT___035805_));
    wasmetal_core__DOT___048939_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048102_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048095_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048219_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035797_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(wasmetal_core__DOT____Vcellout___128783___O))))))));
    wasmetal_core__DOT___048253_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048218_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048080_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___048101_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___035772_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___128783___O) 
                                                                  >> 2U))))))));
    wasmetal_core__DOT___048106_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048102_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048101_))));
    wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035779_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035780_) 
           & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128785___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035779_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035778_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035805_)))));
    wasmetal_core__DOT___035809_ = ((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                    & (IData)(wasmetal_core__DOT___128785___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048217_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128785___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035779_))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035783_) 
           & (IData)(wasmetal_core__DOT___035809_));
    wasmetal_core__DOT___048228_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___048106_) 
                                               << 4U) 
                                              | (((IData)(wasmetal_core__DOT___048096_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048219_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048218_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048217_)))))));
    wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035784_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035785_) 
           & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128786___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035785_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035784_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035783_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___035809_)))));
    wasmetal_core__DOT___035814_ = ((IData)(vlSelf->wasmetal_core__DOT___035786_) 
                                    & (IData)(wasmetal_core__DOT___128786___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___048103_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035783_))));
    wasmetal_core__DOT___048094_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035785_))));
    wasmetal_core__DOT___048093_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128786___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035784_))));
    wasmetal_core__DOT___048092_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128786___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035786_))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035787_) 
           & (IData)(wasmetal_core__DOT___035814_));
    wasmetal_core__DOT___048105_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___048095_) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___048094_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___048093_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___048092_))))));
    wasmetal_core__DOT___048225_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035781_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035788_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___035789_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT____Vcellout___128787___CO = 
        ((((IData)(vlSelf->wasmetal_core__DOT___035790_) 
           & (IData)(wasmetal_core__DOT___128787___DOT__CO__BRA__2__KET__)) 
          << 3U) | (IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0));
    wasmetal_core__DOT____Vcellout___128787___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___035790_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___035789_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___035788_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___035787_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128787___DOT____VdfgTmp_h3cda4b7d__0) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___035814_)));
    wasmetal_core__DOT___048162_ = (1U & (IData)((0x1000000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048107_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048106_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048105_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0xdU 
                                                                 >> 
                                                                 (((IData)(wasmetal_core__DOT___048081_) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___048080_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___035793_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(wasmetal_core__DOT____Vcellout___128782___O)))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                                   >> 2U)) 
                                                               | (IData)(wasmetal_core__DOT___048103_)))))))));
    wasmetal_core__DOT___048936_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035787_))));
    wasmetal_core__DOT___048251_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035789_))));
    wasmetal_core__DOT___048224_ = (1U & (4U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128787___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035788_))));
    wasmetal_core__DOT___071843_ = (1U & (4U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___035790_))));
    vlSelf->wasmetal_core__DOT___005697_ = (1U & (IData)(
                                                         (0x80008000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___048162_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048161_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048160_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048159_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048158_)))))))));
    wasmetal_core__DOT___035706_ = (1U & (0x4bU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035681_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048162_)))));
    wasmetal_core__DOT___048252_ = (1U & (0xdU >> (
                                                   ((IData)(wasmetal_core__DOT___048251_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___048094_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___035780_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___128785___O) 
                                                               >> 2U)))))));
    wasmetal_core__DOT___048940_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048939_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048253_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128787___CO)) 
                                                         | (((IData)(wasmetal_core__DOT___048251_) 
                                                             << 2U) 
                                                            | (((IData)(wasmetal_core__DOT___048224_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___048936_)))))))));
    wasmetal_core__DOT___048227_ = (1U & (0x10U >> 
                                          (((IData)(wasmetal_core__DOT___048225_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___048093_) 
                                               << 1U) 
                                              | (IData)(wasmetal_core__DOT___048224_)))));
    wasmetal_core__DOT___048254_ = (1U & (8U >> (((IData)(wasmetal_core__DOT___048253_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___048252_))));
    vlSelf->wasmetal_core__DOT___007130_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048940_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006121_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006408_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006407_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006193_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hfdd5af20__0)))))))))))));
    vlSelf->wasmetal_core__DOT___035707_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035682_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048940_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048938_ = (1U & (0x80U >> 
                                          (((IData)(wasmetal_core__DOT___048252_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xdULL 
                                                         >> 
                                                         ((0x20U 
                                                           & ((IData)(wasmetal_core__DOT____Vcellout___128787___CO) 
                                                              << 2U)) 
                                                          | (((IData)(wasmetal_core__DOT___048936_) 
                                                              << 4U) 
                                                             | (((IData)(wasmetal_core__DOT___048103_) 
                                                                 << 3U) 
                                                                | (((IData)(wasmetal_core__DOT___048217_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___035778_) 
                                                                       << 1U) 
                                                                      | (1U 
                                                                         & (IData)(wasmetal_core__DOT____Vcellout___128785___O))))))))) 
                                                << 1U)) 
                                              | (IData)(wasmetal_core__DOT___048227_)))));
    wasmetal_core__DOT___048229_ = (1U & (IData)((0xd000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048228_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048227_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048081_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035782_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 1U))))))))));
    wasmetal_core__DOT___048255_ = (1U & (IData)((0xd00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048225_) 
                                                    << 5U) 
                                                   | (((IData)(wasmetal_core__DOT___048254_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___048107_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048226_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___035791_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128781___O) 
                                                                     >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___007129_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048938_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & (IData)(
                                                            (0x80000000ffffffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006191_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006392_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h35bc9263__0)) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006192_))))))))));
    vlSelf->wasmetal_core__DOT___035708_ = (1U & (0xb04fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___035683_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___048938_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___005696_ = (1U & ((~ (IData)(
                                                             (0xaf3f0f0fULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                                      << 1U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                      << 3U) 
                                                                     | (((IData)(wasmetal_core__DOT___048229_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h834dc827__0)))))))) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___006127_)) 
                                                     | (IData)(
                                                               (0x8000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___006126_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006125_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006124_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006123_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006122_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006121_)))))))))));
    wasmetal_core__DOT___035704_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035679_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048229_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    wasmetal_core__DOT___048268_ = (1U & (IData)((0xaf3f0f0fULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___128787___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___048255_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h834dc827__0))))))));
    wasmetal_core__DOT___035705_ = (1U & (0xb04fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___035680_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___048255_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___071843_))))));
    vlSelf->wasmetal_core__DOT___058404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058403_)))));
    vlSelf->wasmetal_core__DOT___058382_ = (1U & (0xf0f0cc55U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058380_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    vlSelf->wasmetal_core__DOT___058381_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005693_)))));
    wasmetal_core__DOT___058379_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_ha3862ccc__0))));
    vlSelf->wasmetal_core__DOT___058374_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h088d475b__0))));
    vlSelf->__VdfgTmp_h2d64090c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h980f95b2__0));
    vlSelf->wasmetal_core__DOT___058373_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006486_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006485_)))));
    vlSelf->wasmetal_core__DOT___058372_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hefac2d69__0))))));
    vlSelf->wasmetal_core__DOT___050074_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005692_)))));
    vlSelf->wasmetal_core__DOT___050075_ = (1U & (0xcc55f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x7fff0000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005694_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf3b81358__0))))));
    wasmetal_core__DOT___015115_ = (1U & (0xcaU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_he99783ec__0))));
    __VdfgTmp_hb49f8759__0 = ((2U & ((0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006615_)))) 
                                     << 1U)) | (1U 
                                                & (4U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
    __VdfgTmp_hc24ed5a6__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0));
    __VdfgTmp_h32160e17__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hb69d909d__0));
    wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___035704_) ? (IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035679_));
    vlSelf->wasmetal_core__DOT___005695_ = (1U & (IData)(
                                                         (0x8000ffffULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___048268_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048267_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048266_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048265_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048264_)))))))));
    wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___035705_) ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___035680_));
    vlSelf->wasmetal_core__DOT___058561_ = (1U & (IData)(
                                                         (0xf0f33aa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xccaaf0f0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                              << 3U) 
                                                                             | (((IData)(wasmetal_core__DOT___015115_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___058420_ = (1U & (IData)(
                                                         (0x7777f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058412_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058408_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058379_)))));
    wasmetal_core__DOT___058393_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h8170b1e8__0)))));
    vlSelf->wasmetal_core__DOT___058384_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058379_))));
    wasmetal_core__DOT___050077_ = ((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                    & (IData)((0xff00ccccf0f0aaaaULL 
                                               >> (
                                                   (0x20U 
                                                    & ((0x7fff0000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006598_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006597_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h180177b5__0))))))));
    vlSelf->wasmetal_core__DOT___058376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058373_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058372_)))));
    __VdfgTmp_h1785588f__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfc403f7f__0)))));
    __VdfgTmp_h2242a82b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                               << 1U) | (1U & (0xcaU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006487_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006486_))))));
    vlSelf->wasmetal_core__DOT___015107_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0xfaa330000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___015115_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_hb49f8759__0))))))));
    vlSelf->wasmetal_core__DOT___014966_ = ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                            & (IData)(
                                                      (0x3500000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | (IData)(__VdfgTmp_hc24ed5a6__0)))))));
    vlSelf->wasmetal_core__DOT___015076_ = ((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                            & (IData)(
                                                      (0x3355f0f000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0x3a00U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h32160e17__0))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xcaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))))))));
    vlSelf->wasmetal_core__DOT___058073_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006484_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h19cea986__0))))))));
    vlSelf->wasmetal_core__DOT___014540_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006500_)))))))));
    vlSelf->wasmetal_core__DOT___014526_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006280_)))))))));
    vlSelf->wasmetal_core__DOT___014498_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006325_)))))))));
    vlSelf->wasmetal_core__DOT___014484_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006516_)))))))));
    vlSelf->wasmetal_core__DOT___009486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006323_)))))))));
    vlSelf->wasmetal_core__DOT___014464_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006515_)))))))));
    vlSelf->wasmetal_core__DOT___007166_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006530_)))))))));
    vlSelf->wasmetal_core__DOT___007156_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006364_)))))))));
    vlSelf->wasmetal_core__DOT___007146_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006529_)))))))));
    vlSelf->wasmetal_core__DOT___007136_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006363_)))))))));
    vlSelf->wasmetal_core__DOT___014573_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))));
    vlSelf->wasmetal_core__DOT___006284_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006282_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006280_))))));
    vlSelf->wasmetal_core__DOT___014570_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006325_))))));
    vlSelf->wasmetal_core__DOT___014514_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006544_)))))))));
    vlSelf->wasmetal_core__DOT___014502_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006416_)))))))));
    vlSelf->wasmetal_core__DOT___014488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006543_)))))))));
    vlSelf->wasmetal_core__DOT___014476_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006415_)))))))));
    vlSelf->wasmetal_core__DOT___009488_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006414_)))))))));
    vlSelf->wasmetal_core__DOT___014466_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006542_)))))))));
    vlSelf->wasmetal_core__DOT___014487_ = (1U & (0x30a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb69d909d__0))))));
    vlSelf->wasmetal_core__DOT___014486_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc1f8ef63__0))))))));
    vlSelf->wasmetal_core__DOT___014528_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006361_)))))))));
    vlSelf->wasmetal_core__DOT___007124_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006528_)))))))));
    vlSelf->wasmetal_core__DOT___014567_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006516_))))));
    vlSelf->wasmetal_core__DOT___014542_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006527_)))))))));
    vlSelf->wasmetal_core__DOT___014558_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006362_)))))))));
    vlSelf->wasmetal_core__DOT___006609_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))));
    wasmetal_core__DOT___014553_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006515_))))));
    wasmetal_core__DOT___014525_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006514_))))));
    wasmetal_core__DOT___014511_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006322_))))));
    wasmetal_core__DOT___014497_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006530_))))));
    wasmetal_core__DOT___014483_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006364_))))));
    wasmetal_core__DOT___014473_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006514_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006529_))))));
    wasmetal_core__DOT___009495_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006322_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006363_))))));
    wasmetal_core__DOT___006608_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006323_))))));
    vlSelf->wasmetal_core__DOT___006504_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006500_))))));
    vlSelf->wasmetal_core__DOT___009490_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___007168_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006557_)))))))));
    vlSelf->wasmetal_core__DOT___007179_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006413_)))))))));
    vlSelf->wasmetal_core__DOT___007160_ = (1U & (0x35000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hc24ed5a6__0)))));
    vlSelf->wasmetal_core__DOT___007158_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006441_)))))))));
    vlSelf->wasmetal_core__DOT___007148_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006556_)))))))));
    vlSelf->wasmetal_core__DOT___007138_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha20d2c5b__0))))))));
    vlSelf->wasmetal_core__DOT___014517_ = (1U & (IData)(
                                                         (0xf00aa00330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    vlSelf->wasmetal_core__DOT___014516_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006571_)))))))));
    wasmetal_core__DOT___014501_ = (1U & (0x3050000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h46e4da0c__0))))));
    wasmetal_core__DOT___014500_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___006616_)))))))));
    vlSelf->wasmetal_core__DOT___014531_ = (1U & (IData)(
                                                         (0xf005500330000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)))))));
    vlSelf->wasmetal_core__DOT___014530_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he99783ec__0))))))));
    vlSelf->wasmetal_core__DOT___007126_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006555_)))))))));
    vlSelf->wasmetal_core__DOT___014544_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8be5cf2e__0))))))));
    vlSelf->wasmetal_core__DOT___014556_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006439_)))))))));
    wasmetal_core__DOT___006366_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006364_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006362_))))));
    vlSelf->wasmetal_core__DOT___007128_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006568_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005697_))))));
    vlSelf->wasmetal_core__DOT___007186_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___006541_)))))))));
    vlSelf->wasmetal_core__DOT___007170_ = (1U & (IData)(
                                                         (0xfaa330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    __VdfgTmp_h00a84c57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                          << 3U) | (IData)(vlSelf->__VdfgTmp_h455b45b4__0)));
    vlSelf->wasmetal_core__DOT___007150_ = (1U & (0x3a000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h32160e17__0)))));
    vlSelf->wasmetal_core__DOT___007140_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
    wasmetal_core__DOT___006532_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006528_))))));
    wasmetal_core__DOT___006365_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006363_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006361_))))));
    wasmetal_core__DOT___007155_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006528_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006544_))))));
    wasmetal_core__DOT___007145_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006362_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006416_))))));
    wasmetal_core__DOT___006572_ = (1U & (IData)((0xff33330f0faaaaULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha576ac17__0)))))));
    wasmetal_core__DOT___007109_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006542_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006557_))))));
    wasmetal_core__DOT___007100_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006414_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006441_))))));
    wasmetal_core__DOT___007091_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006541_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006556_))))));
    wasmetal_core__DOT___007087_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006413_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006440_))))));
    wasmetal_core__DOT___007135_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006527_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006543_))))));
    wasmetal_core__DOT___006612_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006361_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006415_))))));
    wasmetal_core__DOT___007113_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006415_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006413_))))));
    wasmetal_core__DOT___007117_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006543_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006541_))))));
    wasmetal_core__DOT___006611_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006416_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006414_))))));
    wasmetal_core__DOT___007123_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006544_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006542_))))));
    wasmetal_core__DOT___006531_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006529_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006527_))))));
    wasmetal_core__DOT___006443_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006441_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006439_))))));
    vlSelf->wasmetal_core__DOT___006559_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006557_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006555_))))));
    wasmetal_core__DOT___006442_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006440_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006438_))))));
    vlSelf->wasmetal_core__DOT___007078_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006555_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006571_))))));
    wasmetal_core__DOT___007075_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006616_))))));
    wasmetal_core__DOT___007072_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006570_))))));
    wasmetal_core__DOT___006618_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006438_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006615_))))));
    wasmetal_core__DOT___007069_ = (1U & (0x305U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006571_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___006569_))))));
    if (vlSelf->wasmetal_core__DOT___005696_) {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006439_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006614_)))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xc5U >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                  << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006554_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___006568_)))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006616_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006570_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006281_))))));
        vlSelf->wasmetal_core__DOT___058072_ = vlSelf->wasmetal_core__DOT___014567_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014497_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___006608_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006503_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006501_))))));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___009495_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___006365_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___006531_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___014467_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007149_ = vlSelf->wasmetal_core__DOT___007078_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (IData)(wasmetal_core__DOT___006618_));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (IData)(wasmetal_core__DOT___007069_));
    } else {
        if (vlSelf->wasmetal_core__DOT___005695_) {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006438_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006571_))));
        } else {
            vlSelf->wasmetal_core__DOT___014478_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006615_))));
            vlSelf->wasmetal_core__DOT___014468_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006569_))));
        }
        vlSelf->wasmetal_core__DOT___048942_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006284_));
        vlSelf->wasmetal_core__DOT___058072_ = wasmetal_core__DOT___014553_;
        vlSelf->wasmetal_core__DOT___014541_ = wasmetal_core__DOT___014525_;
        vlSelf->wasmetal_core__DOT___014499_ = wasmetal_core__DOT___014483_;
        vlSelf->wasmetal_core__DOT___014485_ = wasmetal_core__DOT___014473_;
        vlSelf->wasmetal_core__DOT___014527_ = wasmetal_core__DOT___014511_;
        vlSelf->wasmetal_core__DOT___048945_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___006504_));
        vlSelf->wasmetal_core__DOT___009487_ = wasmetal_core__DOT___006366_;
        vlSelf->wasmetal_core__DOT___014465_ = wasmetal_core__DOT___006532_;
        vlSelf->wasmetal_core__DOT___007157_ = wasmetal_core__DOT___007145_;
        vlSelf->wasmetal_core__DOT___014489_ = wasmetal_core__DOT___007091_;
        vlSelf->wasmetal_core__DOT___014477_ = wasmetal_core__DOT___007087_;
        vlSelf->wasmetal_core__DOT___007147_ = wasmetal_core__DOT___007135_;
        vlSelf->wasmetal_core__DOT___007137_ = wasmetal_core__DOT___006612_;
        vlSelf->wasmetal_core__DOT___014503_ = wasmetal_core__DOT___007100_;
        vlSelf->wasmetal_core__DOT___014515_ = wasmetal_core__DOT___007109_;
        vlSelf->wasmetal_core__DOT___014529_ = wasmetal_core__DOT___007113_;
        vlSelf->wasmetal_core__DOT___014559_ = wasmetal_core__DOT___006611_;
        vlSelf->wasmetal_core__DOT___007125_ = wasmetal_core__DOT___007123_;
        vlSelf->wasmetal_core__DOT___014543_ = wasmetal_core__DOT___007117_;
        vlSelf->wasmetal_core__DOT___007167_ = wasmetal_core__DOT___007155_;
        vlSelf->wasmetal_core__DOT___009489_ = wasmetal_core__DOT___006443_;
        vlSelf->wasmetal_core__DOT___014467_ = vlSelf->wasmetal_core__DOT___006559_;
        vlSelf->wasmetal_core__DOT___007178_ = wasmetal_core__DOT___006442_;
        vlSelf->wasmetal_core__DOT___007159_ = wasmetal_core__DOT___007075_;
        vlSelf->wasmetal_core__DOT___007149_ = wasmetal_core__DOT___007072_;
        vlSelf->wasmetal_core__DOT___007139_ = wasmetal_core__DOT___006618_;
        vlSelf->wasmetal_core__DOT___014557_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006616_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006614_))))));
        vlSelf->wasmetal_core__DOT___007127_ = wasmetal_core__DOT___007069_;
        vlSelf->wasmetal_core__DOT___014545_ = (1U 
                                                & (0x30aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___006568_))))));
    }
    vlSelf->wasmetal_core__DOT___006558_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006554_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128771___O 
        = ((((IData)(wasmetal_core__DOT___035706_) 
             << 3U) | (((IData)(wasmetal_core__DOT___035705_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___035704_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035701_)))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128771___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___035694_ = ((IData)(wasmetal_core__DOT___035706_)
                                             ? (IData)(wasmetal_core__DOT___128771___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___035681_));
    vlSelf->wasmetal_core__DOT___050081_ = (1U & (IData)(
                                                         (0xf000fccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___050077_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((1U 
                                                                          & (0x7fff0000U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1e09234e__0)))
                                                                          ? 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006604_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006602_)))))
                                                                          : 
                                                                         (0xc0aU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006603_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006601_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050075_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050074_)))))))));
    vlSelf->wasmetal_core__DOT___058417_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x5300U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058403_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058412_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0000ccaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->wasmetal_core__DOT___058394_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058393_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(__VdfgTmp_h1785588f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(__VdfgTmp_h2242a82b__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0fccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h08354128__0))))))))))))));
    vlSelf->__VdfgTmp_hf7593d1b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015107_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_hb335ec2f__0))))));
    vlSelf->__VdfgTmp_h1a5afed0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h532df62e__0))))));
    vlSelf->__VdfgTmp_h00939515__0 = (((IData)(vlSelf->wasmetal_core__DOT___014487_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014486_));
    vlSelf->__VdfgTmp_h9f75ffc3__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014525_)
                                         : (IData)(wasmetal_core__DOT___014497_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006502_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006501_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006500_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006517_))))))))));
    vlSelf->__VdfgTmp_ha7c43d57__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(wasmetal_core__DOT___014483_)
                                         : (IData)(wasmetal_core__DOT___009495_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006281_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006280_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___006324_))))))))));
    vlSelf->__VdfgTmp_he4917e71__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___006609_)
                                         : (IData)(wasmetal_core__DOT___006608_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                 & (IData)(
                                                           (0xff33330f0f5555ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005691_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006283_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h45e8af23__0)))))))));
    vlSelf->wasmetal_core__DOT___015194_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009490_)))));
    vlSelf->wasmetal_core__DOT___015030_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014468_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d 
        = (1U & (0xe000U >> (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___014516_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___014517_))))));
    vlSelf->__VdfgTmp_h2165c3f7__0 = (((IData)(wasmetal_core__DOT___014501_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014500_));
    vlSelf->__VdfgTmp_he4fae0fa__0 = (((IData)(wasmetal_core__DOT___014500_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___014501_));
    vlSelf->__VdfgTmp_h4a9651b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___014530_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014531_));
    vlSelf->wasmetal_core__DOT___014878_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007128_)))));
    vlSelf->wasmetal_core__DOT___015070_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0))))));
    vlSelf->wasmetal_core__DOT___007180_ = (1U & (IData)(
                                                         (0xf55330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                                            << 5U) 
                                                           | (IData)(__VdfgTmp_h00a84c57__0)))));
    vlSelf->wasmetal_core__DOT___014949_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007150_))));
    vlSelf->wasmetal_core__DOT___014979_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007140_)))));
    vlSelf->__VdfgTmp_h99d13f88__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006325_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006324_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006323_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006322_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006366_)
                                                  : (IData)(wasmetal_core__DOT___006365_)));
    vlSelf->wasmetal_core__DOT___058134_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007130_) 
                                               & (IData)(wasmetal_core__DOT___006572_)));
    vlSelf->wasmetal_core__DOT___007187_ = ((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                            & (IData)(wasmetal_core__DOT___006572_));
    vlSelf->__VdfgTmp_h3016d5c6__0 = ((((IData)(vlSelf->wasmetal_core__DOT___005697_) 
                                        & (IData)((0xff33330f0f5555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005696_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005695_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006517_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006516_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006515_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___006514_))))))))) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___005696_)
                                                  ? (IData)(wasmetal_core__DOT___006532_)
                                                  : (IData)(wasmetal_core__DOT___006531_)));
}
