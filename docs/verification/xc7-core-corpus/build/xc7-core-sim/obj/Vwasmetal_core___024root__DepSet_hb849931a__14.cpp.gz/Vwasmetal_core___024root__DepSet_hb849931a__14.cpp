#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__20(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__20\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___053908_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053906_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf32aU 
                                                                         >> 
                                                                         ((0xcU 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051584_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051587_)))))))));
    vlSelf->wasmetal_core__DOT___051862_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049211_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051857_)))))));
    vlSelf->wasmetal_core__DOT___049245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049212_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049211_)))));
    vlSelf->wasmetal_core__DOT___009523_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051062_)))));
    vlSelf->wasmetal_core__DOT___051761_ = (1U & (IData)(
                                                         (0x5533f00000000000ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051753_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051752_)))))));
    vlSelf->wasmetal_core__DOT___053528_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051422_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051753_)))));
    vlSelf->wasmetal_core__DOT___064460_ = (1U & (IData)(
                                                         (0xff00ff00ff007000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055082_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055081_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b0__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))));
    vlSelf->wasmetal_core__DOT___066011_ = (1U & (IData)(
                                                         (0xffff80ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053387_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053386_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053385_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050874_)))))))));
    vlSelf->wasmetal_core__DOT___064888_ = (1U & (IData)(
                                                         (0xff0f0000bbbb0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051012_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051008_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049464_))))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051006_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b2__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050978_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050977_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050904_))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xe0U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050896_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050733_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050625_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050729_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050731_))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___051928_ = (1U & (IData)(
                                                         (0x7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051901_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051696_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h10b5292d__0))))))));
    vlSelf->wasmetal_core__DOT___065288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff001f1f0000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051438_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051437_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x5300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051432_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051318_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051317_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051424_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___066803_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___066798_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___066797_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057736_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051048_))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->wasmetal_core__DOT___051656_ = (1U & (IData)(
                                                         (0x8000cfff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (3U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 1U))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051641_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048562_)))))))));
    vlSelf->wasmetal_core__DOT___053579_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051641_))));
    vlSelf->wasmetal_core__DOT___051802_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h36c85254__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf78fffffU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                         | (2U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                               << 1U)))))))))))));
    vlSelf->wasmetal_core__DOT___053823_ = (1U & (0x55cc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h36c85254__0))));
    vlSelf->wasmetal_core__DOT___051322_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049772_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051321_)))));
    vlSelf->wasmetal_core__DOT___050655_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049772_))));
    vlSelf->wasmetal_core__DOT___053533_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050719_))));
    vlSelf->wasmetal_core__DOT___050722_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050720_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050719_)))));
    vlSelf->wasmetal_core__DOT___051749_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07886821__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff7f80ffffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U))))))))))))))));
    vlSelf->wasmetal_core__DOT___053802_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h07886821__0))));
    vlSelf->wasmetal_core__DOT___051855_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd604be0c__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xffe01fffffffffffULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))))))))));
    vlSelf->wasmetal_core__DOT___050879_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd604be0c__0))));
    vlSelf->wasmetal_core__DOT___051546_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051544_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051543_)))));
    vlSelf->wasmetal_core__DOT___052610_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051544_))));
    vlSelf->wasmetal_core__DOT___051717_ = (1U & (IData)(
                                                         (0xbfff3f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xffaaffcc0fffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0)))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa3fU 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h6af6bfd0__0))))))))))));
    vlSelf->wasmetal_core__DOT___053716_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h32fdaf9b__0))));
    vlSelf->wasmetal_core__DOT___067183_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf3ffa200f3fff3ffULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b26__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___067176_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067175_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050600_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051359_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f000dd00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067179_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050047_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049528_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049526_)))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O))))))))))))))));
    vlSelf->__VdfgTmp_h56ff1f8b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051359_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049775_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051777_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((0xd0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xa300000U 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                             | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf722c8bb__0))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d)))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc485c507__0))))));
    vlSelf->wasmetal_core__DOT___053809_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc485c507__0))));
    vlSelf->wasmetal_core__DOT___051874_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfd7fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h808d3d88__0))))))))));
    vlSelf->wasmetal_core__DOT___049482_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8235f0ca__0))));
    vlSelf->wasmetal_core__DOT___053185_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051605_))));
    vlSelf->__VdfgTmp_h49696f4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___051605_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049447_)) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051704_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha2558491__0)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))))))));
    vlSelf->wasmetal_core__DOT___053708_ = (1U & (0xc5U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha03a7afa__0))));
    vlSelf->wasmetal_core__DOT___051815_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45934da4__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xfa3fU 
                                                                  >> 
                                                                  ((0xcU 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 1U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0))))))))));
    vlSelf->__VdfgTmp_hfed11520__0 = ((2U & ((0x55ccf0ffU 
                                              >> ((0x18U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 3U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h45934da4__0))) 
                                             << 1U)) 
                                      | (1U & (0xa3U 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he13a5cf9__0)))));
    vlSelf->__VdfgTmp_h19298f26__0 = (((IData)(vlSelf->wasmetal_core__DOT___051339_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049731_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___053527_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))));
    vlSelf->wasmetal_core__DOT___067404_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067403_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051576_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0f010f0f0f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b29__05d) 
                                                                                << 2U) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051574_))))))))))));
    vlSelf->__VdfgTmp_h0d8fe922__0 = (((IData)(vlSelf->wasmetal_core__DOT___051574_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((1U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___049252_)) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___051793_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xffaaffcc0fffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h937c72cf__0)))))))))));
    vlSelf->wasmetal_core__DOT___009513_ = (1U & (0xaacc0fffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ae5f1a__0))));
    vlSelf->__VdfgTmp_h70db4808__0 = (((IData)(vlSelf->wasmetal_core__DOT___051297_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                         << 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___051295_)))));
    vlSelf->wasmetal_core__DOT___051887_ = (1U & (0x70330000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff55ffccf0ffffffULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 3U)) 
                                                                       | ((0x10U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              << 4U)) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0f76403b__0)))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xf5cfU 
                                                                  >> 
                                                                  ((8U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                       << 2U)) 
                                                                   | ((4U 
                                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h073e4ce8__0)))))))))));
    vlSelf->wasmetal_core__DOT___049676_ = (1U & (0x55ccf0ffU 
                                                  >> 
                                                  ((0x18U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0f76403b__0))));
    vlSelf->__VdfgTmp_h4d7ec491__0 = (((IData)(vlSelf->wasmetal_core__DOT___051623_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((4U 
                                                          >> 
                                                          (2U 
                                                           & ((4U 
                                                               >> 
                                                               (2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (2U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                                          << 1U)) 
                                                                        << 1U))) 
                                                                   << 1U))) 
                                                              << 1U))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___055205_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053722_))))));
    vlSelf->wasmetal_core__DOT___067261_ = (1U & (0x33af0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xbfbb3f333f33ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 5U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053654_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbfbfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051985_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                              << 4U) 
                                                                             | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051513_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xf0f0aacc00000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052592_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050829_))))))))))))));
    vlSelf->__VdfgTmp_h28bc3512__0 = (((IData)(vlSelf->wasmetal_core__DOT___051513_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((1U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT___049869_)) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O))))));
    vlSelf->wasmetal_core__DOT___050819_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))));
    vlSelf->wasmetal_core__DOT___051840_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb744a8fa__0)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))))));
    vlSelf->wasmetal_core__DOT___050842_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))));
    vlSelf->wasmetal_core__DOT___066114_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x773f3f3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053731_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049212_))))))))))));
    vlSelf->wasmetal_core__DOT___049336_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))));
    vlSelf->wasmetal_core__DOT___066303_ = (1U & ((1U 
                                                   & (0xa300U 
                                                      >> 
                                                      ((8U 
                                                        & ((1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | ((2U 
                                                              & ((0xf0f5533U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 4U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xacU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___053212_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___053209_))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053210_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049649_))))))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009497_))
                                                   : (IData)(
                                                             (0xcccccccccc40c0c0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U))) 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009499_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0x773f3f3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009497_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___009496_))))))))));
    vlSelf->wasmetal_core__DOT___066389_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0x8f8f8f8fff00ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009509_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009508_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xffcf0080ffcfffcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049848_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049694_))))))))))));
    vlSelf->wasmetal_core__DOT___051894_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xa82aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))))));
    vlSelf->wasmetal_core__DOT___049696_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))));
    vlSelf->wasmetal_core__DOT___066470_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055415_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055414_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x45cfcf00ffffffULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                               << 4U)) 
                                                                           | ((0x10U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))))))))));
    vlSelf->wasmetal_core__DOT___052637_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h37fa163f__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))))));
    vlSelf->wasmetal_core__DOT___049745_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))));
    vlSelf->wasmetal_core__DOT___066552_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053729_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ffb000f0fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053726_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049784_))))))))))));
    vlSelf->wasmetal_core__DOT___052723_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h9b387498__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))))));
    vlSelf->wasmetal_core__DOT___049793_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))));
    vlSelf->wasmetal_core__DOT___066637_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066627_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f8808ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066629_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049879_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009506_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x40U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049877_)))))))))))));
    vlSelf->wasmetal_core__DOT___053523_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73a0c82f__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))))));
    vlSelf->wasmetal_core__DOT___049882_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))));
    vlSelf->wasmetal_core__DOT___066717_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066713_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xf0fccaaU 
                                                                  >> 
                                                                  ((0x18U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___051466_))))))))))));
    vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050457_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7fff00007fff7fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050450_))))))))))));
    vlSelf->wasmetal_core__DOT___050445_ = (1U & (IData)(
                                                         (0x2220fff00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050399_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___050406_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050400_))));
    vlSelf->wasmetal_core__DOT___051219_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051218_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051217_))));
    vlSelf->wasmetal_core__DOT___052655_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051217_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->__VdfgTmp_h0f244854__0 = (((IData)(vlSelf->wasmetal_core__DOT___052659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___050435_));
    vlSelf->wasmetal_core__DOT___052660_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052659_))));
    vlSelf->wasmetal_core__DOT___052844_ = (1U & (IData)(
                                                         (0xf888000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052836_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h56f16561__0))))))));
    vlSelf->wasmetal_core__DOT___051224_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050443_)))));
    vlSelf->wasmetal_core__DOT___051202_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050359_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___051204_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___050364_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050359_))));
    vlSelf->wasmetal_core__DOT___014611_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017194_))));
    vlSelf->wasmetal_core__DOT___005713_ = (1U & (IData)(
                                                         (0xff1fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048002_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048001_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he9d835d5__0))))))));
    vlSelf->wasmetal_core__DOT___060480_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048712_))));
    vlSelf->__VdfgTmp_h5e920d5f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048712_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019197_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___048711_)))));
    vlSelf->wasmetal_core__DOT___058690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048725_))));
    vlSelf->__VdfgTmp_h678017d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048717_));
    vlSelf->wasmetal_core__DOT___006238_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006155_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006159_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048166_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006112_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048167_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048206_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048205_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048166_)))))));
    vlSelf->wasmetal_core__DOT___005996_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006065_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048164_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006116_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048165_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048209_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048208_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048164_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005428_)))));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d 
        = (1U & (0xf1U >> (((IData)(vlSelf->wasmetal_core__DOT___005432_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005427_)))));
    vlSelf->wasmetal_core__DOT___006113_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005432_)) 
                                                  & (IData)(
                                                            (0xff80ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___005431_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005430_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005429_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005428_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005427_))))))))));
    vlSelf->wasmetal_core__DOT___005962_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__ 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                           << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048049_) 
                                      << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006115_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048050_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048149_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048148_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048049_)))))));
    vlSelf->wasmetal_core__DOT___005896_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___005830_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048051_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000158_)))));
    vlSelf->wasmetal_core__DOT___006114_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048052_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048063_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048062_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048051_)))))));
    vlSelf->wasmetal_core__DOT___013672_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001796_))));
    vlSelf->wasmetal_core__DOT___013670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001797_))));
    vlSelf->wasmetal_core__DOT___013668_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001802_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001798_))));
    vlSelf->wasmetal_core__DOT___000135_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001803_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___001802_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001800_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001799_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001798_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001797_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___001796_)))))))))));
    vlSelf->wasmetal_core__DOT___013694_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001799_))));
    vlSelf->wasmetal_core__DOT___017175_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005731_))));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005928_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->__VdfgTmp_h76ba8332__0 = (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT___013722_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000142_))));
    vlSelf->wasmetal_core__DOT___013701_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000143_))));
    vlSelf->__VdfgTmp_h68317e95__0 = (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___005716_)));
    vlSelf->wasmetal_core__DOT___013719_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000148_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000144_))));
    vlSelf->wasmetal_core__DOT___013658_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002187_))));
    vlSelf->wasmetal_core__DOT___013666_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002471_))));
    vlSelf->wasmetal_core__DOT___013648_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048788_))));
    vlSelf->__VdfgTmp_hd5565504__0 = (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002629_));
    vlSelf->wasmetal_core__DOT___013654_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048789_))));
    vlSelf->__VdfgTmp_h0ed8cd5e__0 = (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002634_));
    vlSelf->wasmetal_core__DOT___000138_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048792_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048789_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048788_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048787_)))))))));
    vlSelf->wasmetal_core__DOT___013690_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048787_))));
    vlSelf->__VdfgTmp_he7a338fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___005921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->__VdfgTmp_h0d220f7a__0 = (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013805_));
    vlSelf->wasmetal_core__DOT___013712_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002028_))));
    vlSelf->__VdfgTmp_hed5eddc9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013770_));
    vlSelf->wasmetal_core__DOT___013798_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048915_)))))))));
    vlSelf->wasmetal_core__DOT___013795_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048914_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048686_)))))))));
    vlSelf->wasmetal_core__DOT___013692_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002029_))));
    vlSelf->wasmetal_core__DOT___059542_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005745_))));
    vlSelf->__VdfgTmp_hbbe1bed2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005745_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->wasmetal_core__DOT___013705_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002030_))));
    vlSelf->__VdfgTmp_h7faa2984__0 = (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013785_));
    vlSelf->__VdfgTmp_h1e702231__0 = (((IData)(vlSelf->wasmetal_core__DOT___002469_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002468_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000158_)));
    vlSelf->wasmetal_core__DOT___000136_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___002034_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___002033_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___002032_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___002030_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002029_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002028_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___002027_)))))))))));
    vlSelf->wasmetal_core__DOT___013635_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002031_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002027_))));
    vlSelf->__VdfgTmp_h097d2f7b__0 = (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013737_));
    vlSelf->wasmetal_core__DOT___013652_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002188_))));
    vlSelf->wasmetal_core__DOT___013739_ = (1U & (0xf0fbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))));
    vlSelf->wasmetal_core__DOT___013656_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002189_))));
    vlSelf->__VdfgTmp_hc3924088__0 = (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014037_));
    vlSelf->wasmetal_core__DOT___000134_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000148_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___000147_)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000146_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000145_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000144_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000143_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000142_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___000141_)))))))))));
    vlSelf->wasmetal_core__DOT___013687_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000141_))));
    vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d 
        = (1U & (IData)((0xffff0000ffffff10ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048903_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048902_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___047924_)))))))));
    vlSelf->wasmetal_core__DOT___014245_ = (1U & (IData)(
                                                         (0xffff000000efULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048920_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048919_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047917_)))))))));
    vlSelf->wasmetal_core__DOT___000137_ = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                            & (IData)(
                                                      (1ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002192_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002190_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002189_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002188_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___002187_)))))))));
    vlSelf->wasmetal_core__DOT___060000_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005868_))));
    vlSelf->wasmetal_core__DOT___060032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___051505_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006106_))));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006106_) 
           | (IData)(vlSelf->wasmetal_core__DOT___005868_));
    vlSelf->__VdfgTmp_h80016717__0 = (((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002636_));
    vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002472_) 
           & (IData)(vlSelf->wasmetal_core__DOT___002473_));
    vlSelf->wasmetal_core__DOT___060056_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006022_))));
    vlSelf->wasmetal_core__DOT___059647_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006015_))));
    vlSelf->__VdfgTmp_hbc1c04e5__0 = (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006092_));
    vlSelf->wasmetal_core__DOT___060081_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->wasmetal_core__DOT___051507_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006099_))));
    vlSelf->wasmetal_core__DOT___060102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005989_))));
    vlSelf->wasmetal_core__DOT___060128_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006171_))));
    vlSelf->__VdfgTmp_h0c779906__0 = (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___060152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006144_))));
    vlSelf->__VdfgTmp_h419b9e2f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006171_));
    vlSelf->wasmetal_core__DOT___059198_ = (1U & (0x41U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___017815_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013805_))));
    vlSelf->wasmetal_core__DOT___006247_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005711_))));
    vlSelf->wasmetal_core__DOT___060188_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006215_))));
    vlSelf->wasmetal_core__DOT___059201_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xfef0000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006099_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006022_))))))))))));
    vlSelf->__VdfgTmp_h28ae1e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_hc6c88546__0 = (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___005889_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005653_)) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b33__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005652_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005651_))))))))));
    vlSelf->__VdfgTmp_h13911493__0 = (((IData)(vlSelf->wasmetal_core__DOT___005788_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hf7ef4e0e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005955_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hadeaba1a__0 = (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->__VdfgTmp_h89d79bf3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___059752_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006204_))));
    vlSelf->__VdfgTmp_hfa88dfaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h3cb929d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___003128_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006400_))));
    vlSelf->__VdfgTmp_h9fed8b62__0 = (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hd64632c9__0 = (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h0283b263__0 = (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_he473afc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003807_));
    vlSelf->__VdfgTmp_hbacebd3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048701_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006151_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005795_))))));
    vlSelf->wasmetal_core__DOT___059857_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003808_))));
    vlSelf->__VdfgTmp_ha45fb011__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_h8744bfbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006274_));
    vlSelf->__VdfgTmp_hab846b7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___005903_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                  ? (0xceU >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b51__05d))))
                  : (0xf0f0fef0U >> (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                      << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___005514_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde5a6edf__0)))))));
    vlSelf->wasmetal_core__DOT___059917_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003806_))));
    vlSelf->__VdfgTmp_h83434591__0 = (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___003806_));
    vlSelf->wasmetal_core__DOT___003129_ = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                            & (IData)(
                                                      (0x8000000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003806_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___003805_)))))))));
    vlSelf->wasmetal_core__DOT___059942_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005855_))));
    vlSelf->wasmetal_core__DOT___059973_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005770_))));
    vlSelf->wasmetal_core__DOT___127453___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005855_) 
           & (IData)(vlSelf->wasmetal_core__DOT___005770_));
    vlSelf->wasmetal_core__DOT___005669_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT___014613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048960_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___048134_ = (1U & (0x9fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048129_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017186_)))));
    vlSelf->wasmetal_core__DOT___060573_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060571_))));
    vlSelf->wasmetal_core__DOT___019194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017176_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017174_))));
    vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128410___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127851___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026480_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026447_)))));
    vlSelf->wasmetal_core__DOT___026451_ = ((IData)(vlSelf->wasmetal_core__DOT___026483_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d));
    vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036760_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134154___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbd028268__0))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028286_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028221_));
    vlSelf->wasmetal_core__DOT____Vcellout___127867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026591_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026590_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026589_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026588_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026529_)))));
    vlSelf->wasmetal_core__DOT___026559_ = ((IData)(vlSelf->wasmetal_core__DOT___026591_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001488_));
    vlSelf->wasmetal_core__DOT___053596_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053587_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052687_))));
    vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031331_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128348___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___128642___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034321_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034384_));
    vlSelf->wasmetal_core__DOT___128658___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034488_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034545_));
    vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027470_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027393_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b6__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128030___O 
        = (0xfU & ((vlSelf->insn_z >> 0x10U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027935_))))));
    vlSelf->wasmetal_core__DOT___027939_ = ((vlSelf->insn_z 
                                             >> 0x13U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128030___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128270___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x13U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x12U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x11U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x10U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030470_)))));
    vlSelf->wasmetal_core__DOT___030474_ = (1U & ((0x80000U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0x13U)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128270___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128486___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027809_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128014___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128054___O 
        = (0xfU & ((vlSelf->insn_x >> 0x10U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__) 
                                                 << 3U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028161_))))));
    vlSelf->wasmetal_core__DOT___028165_ = ((vlSelf->insn_x 
                                             >> 0x13U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128054___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028096_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128045___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xeU)));
    vlSelf->wasmetal_core__DOT____Vcellout___128318___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x13U)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x12U)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x11U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x10U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030952_)))));
    vlSelf->wasmetal_core__DOT___030956_ = ((~ (vlSelf->function_params 
                                                >> 0x13U)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128318___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___070645_ = (1U & (IData)(
                                                         (0x6060660006060066ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128469___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134211___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070643_)))))))));
    vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032682_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128470___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037192_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134212___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0dd4dc97__0))));
    vlSelf->wasmetal_core__DOT___054504_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054503_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xbU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054506_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054505_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xcU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054508_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054507_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xdU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063552_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063551_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063560_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063559_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063568_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063567_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063576_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063575_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128493___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___054502_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127829___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026365_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127846___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d));
    vlSelf->wasmetal_core__DOT___128404___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031964_));
    vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128291___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128172___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128292___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___056534_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___034151_)) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_h0812d53d__0)))));
    vlSelf->wasmetal_core__DOT___011154_ = (1U & (IData)(
                                                         (0xfcfaf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056535_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xca00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056541_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___054778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054782_))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h16ee9b67__0))))))));
    vlSelf->wasmetal_core__DOT___056499_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->wasmetal_core__DOT___056593_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->__VdfgTmp_h42ead4cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0));
    vlSelf->wasmetal_core__DOT___072006_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb25114eb__0)))));
    vlSelf->__VdfgTmp_h4cd16820__0 = (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb25114eb__0));
    vlSelf->__VdfgTmp_h2790f0bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011898_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010530_));
    vlSelf->wasmetal_core__DOT___056447_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010182_)))));
    vlSelf->wasmetal_core__DOT___056931_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011658_)))));
    vlSelf->wasmetal_core__DOT___011912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010302_))));
    vlSelf->wasmetal_core__DOT___011771_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010302_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))))));
    vlSelf->wasmetal_core__DOT___011206_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011666_)))));
    vlSelf->__VdfgTmp_hb44ad26b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h362b458b__0));
    vlSelf->__VdfgTmp_h450c5ec1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha569c0f1__0));
    vlSelf->wasmetal_core__DOT___055108_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0))))));
    vlSelf->wasmetal_core__DOT___013099_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbc86843d__0)))))));
    vlSelf->__VdfgTmp_h00eaf9c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010339_))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                   | (0xf010U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010302_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010342_)) 
                                                   & (0xf0feU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011658_))));
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010299_))));
    }
    vlSelf->wasmetal_core__DOT___011899_ = (1U & (0x50cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))));
    vlSelf->wasmetal_core__DOT___056826_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___010389_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d)))))))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010854_)));
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010860_)));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010969_))));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010925_)));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_))));
    } else {
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h658ce6a4__0))));
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb9280dfa__0))));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010972_)));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? 
                                                   (0xfeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))
                                                    : 
                                                   (0xf1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011020_)));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010770_)));
    }
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h658ce6a4__0)))));
    vlSelf->__VdfgTmp_h3fe4e0c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3820fb89__0)));
    vlSelf->wasmetal_core__DOT___012377_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010187_)
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010186_)) 
                                                    << 1U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      & (IData)(
                                                                (0xff00ffaaf0f0fcfcULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))))))))));
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
        vlSelf->wasmetal_core__DOT___011445_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (0xf4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha7112868__0)))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011388_))));
    } else {
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xceU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
        vlSelf->wasmetal_core__DOT___011445_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011389_))
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011390_))));
    }
    vlSelf->wasmetal_core__DOT___012422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010718_))));
    vlSelf->__VdfgTmp_hdeb472fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010717_));
    vlSelf->wasmetal_core__DOT___010392_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___056825_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___056641_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056286_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hb9280dfa__0)))));
    vlSelf->__VdfgTmp_haf508d85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010300_));
    vlSelf->__VdfgTmp_h6f308c91__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010340_))))));
    vlSelf->wasmetal_core__DOT___056961_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056552_)))))))));
    vlSelf->wasmetal_core__DOT___012632_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056553_)))));
    vlSelf->__VdfgTmp_ha429fd09__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011660_))))));
    vlSelf->__VdfgTmp_h98e4ab16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011659_));
    vlSelf->__VdfgTmp_h336e35bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012980_));
    vlSelf->__VdfgTmp_h23ac912c__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056433_));
    vlSelf->wasmetal_core__DOT___013142_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011379_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0))))))));
    vlSelf->__VdfgTmp_hf4d8b80a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___011973_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___011197_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                 & (IData)(
                                                           (0xff00ffaaf0f0fcfcULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))))));
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011197_));
        vlSelf->wasmetal_core__DOT___012983_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012028_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012027_))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011992_))))));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___011194_;
    } else {
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))));
        vlSelf->wasmetal_core__DOT___012983_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012029_))
                                                    : 
                                                   (0xbU 
                                                    >> (IData)(vlSelf->__VdfgTmp_hc9e45bda__0))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d))))));
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011194_));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___010187_;
    }
    vlSelf->wasmetal_core__DOT___010849_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8f305c7__0)))));
    vlSelf->__VdfgTmp_h14d4af94__0 = (((IData)(vlSelf->wasmetal_core__DOT___011380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011379_));
    vlSelf->__VdfgTmp_h4284cb76__0 = (((IData)(vlSelf->wasmetal_core__DOT___011920_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011919_));
    vlSelf->wasmetal_core__DOT___010390_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056284_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0931b472__0)))))))))));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011413_)));
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011538_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h479e0c47__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010575_)));
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011539_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011389_)));
        }
        vlSelf->wasmetal_core__DOT___010577_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010575_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012742_)));
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011540_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012729_)));
        } else {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (0xbU >> (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
            vlSelf->wasmetal_core__DOT___011632_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h06746976__0)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011390_)));
        }
        vlSelf->wasmetal_core__DOT___010577_ = (1U 
                                                & (0xf4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha620249b__0)));
    }
    vlSelf->wasmetal_core__DOT___056923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010221_)))));
    vlSelf->__VdfgTmp_he09ec1d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hee315f88__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___033390_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___033452_ = ((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hc33f85b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___033411_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x69U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6af19a3e__0)))));
    vlSelf->wasmetal_core__DOT___011998_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___012287_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___011602_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010972_)));
    vlSelf->wasmetal_core__DOT___056280_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___010220_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))))));
    vlSelf->wasmetal_core__DOT___057264_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012992_)))));
    vlSelf->__VdfgTmp_h1d16dec4__0 = (((IData)(vlSelf->wasmetal_core__DOT___011868_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcef50cee__0));
    vlSelf->__VdfgTmp_hcd2c6110__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011470_)));
    vlSelf->__VdfgTmp_h9484b551__0 = (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011390_));
    vlSelf->wasmetal_core__DOT___056725_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012125_)))))))));
    vlSelf->wasmetal_core__DOT___012179_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                   | (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012123_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011413_)))))));
    vlSelf->__VdfgTmp_h6bff4562__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))));
    vlSelf->__VdfgTmp_h58c9f225__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha4e3e772__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hda718c9e__0)))));
    vlSelf->wasmetal_core__DOT___010198_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___011697_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___056440_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011020_)));
    vlSelf->__VdfgTmp_h25f5437e__0 = (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)));
    vlSelf->wasmetal_core__DOT___056369_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010770_)));
    vlSelf->wasmetal_core__DOT___010125_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010123_))
                                                   : (IData)(
                                                             (0xff00ff00fffefff0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010123_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h39adae05__0))))))));
    vlSelf->wasmetal_core__DOT___011478_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39adae05__0)))));
    vlSelf->__VdfgTmp_h30784950__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011539_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011906_));
    vlSelf->wasmetal_core__DOT___012845_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011539_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011530_)))))))));
    vlSelf->wasmetal_core__DOT___010260_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010282_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c968075__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hffef1e62__0)))))));
    vlSelf->__VdfgTmp_hb211d2c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d));
    vlSelf->wasmetal_core__DOT___057067_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))))))));
    vlSelf->wasmetal_core__DOT___011923_ = (1U & (IData)(
                                                         (0x33330f0f00ff5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010574_)))))))));
    vlSelf->wasmetal_core__DOT___012175_ = (1U & (IData)(
                                                         (0xf0f000bb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->wasmetal_core__DOT___056899_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056897_)))))));
    vlSelf->wasmetal_core__DOT___013100_ = (1U & (IData)(
                                                         (0xccccf0f0ff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056375_)))))))));
    vlSelf->wasmetal_core__DOT___056643_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012293_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4a9b748c__0)))))));
    vlSelf->wasmetal_core__DOT___012176_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0))))));
    vlSelf->__VdfgTmp_h88f91f2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0));
    vlSelf->wasmetal_core__DOT___057549_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057065_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057066_)))))));
    vlSelf->__VdfgTmp_h3a025ab3__0 = (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0931b472__0)));
    vlSelf->__VdfgTmp_hf996b543__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h146131dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056381_));
    vlSelf->wasmetal_core__DOT___057102_ = (1U & (IData)(
                                                         (0xa0c000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->wasmetal_core__DOT___011205_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ff0faaaaccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->__VdfgTmp_h95d3d0ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h88263545__0));
    vlSelf->wasmetal_core__DOT___056340_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))))))));
    vlSelf->wasmetal_core__DOT___055277_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h8b4e795d__0 = ((2U & ((0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h08c644ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xfef0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___010413_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2133c371__0)))));
    vlSelf->wasmetal_core__DOT___071991_ = (1U & (IData)(
                                                         (0xff00ff00eeee0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xccccaaaaf0f0ff00ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)))))))))));
    vlSelf->wasmetal_core__DOT___056895_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h479e0c47__0)))))));
    vlSelf->wasmetal_core__DOT___012182_ = (1U & (IData)(
                                                         (0x55330000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056325_)))))))));
    vlSelf->__VdfgTmp_hede7bfa8__0 = (((IData)(vlSelf->wasmetal_core__DOT___012729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011389_));
    vlSelf->__VdfgTmp_h7bcb9cab__0 = (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011388_));
    vlSelf->wasmetal_core__DOT___056281_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))))));
    vlSelf->wasmetal_core__DOT___011722_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___057050_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___056206_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009842_)) 
                                                  & ((~ 
                                                      (0xfef0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009840_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)))))))))));
    vlSelf->__VdfgTmp_hb1f92188__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)));
    vlSelf->wasmetal_core__DOT___056341_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))));
    vlSelf->__VdfgTmp_hdcd859be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011527_)));
    vlSelf->wasmetal_core__DOT___056174_ = ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)) 
                                               & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))))))))));
    vlSelf->__VdfgTmp_he9d803b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010222_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___011032_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010222_)) 
                                                  & (IData)(
                                                            (0xff00ffddff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h362b458b__0)))))))));
    vlSelf->wasmetal_core__DOT___055199_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055122_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___055194_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___012804_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010721_))));
    vlSelf->wasmetal_core__DOT___010842_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)))))));
    vlSelf->__VdfgTmp_h8127a3d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)));
    vlSelf->wasmetal_core__DOT___057438_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056621_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012749_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h375c9c07__0))))))));
    vlSelf->wasmetal_core__DOT___011939_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h375c9c07__0))))))));
    vlSelf->wasmetal_core__DOT___056347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb18a766__0)))));
    vlSelf->__VdfgTmp_hc9438d71__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h51371d7f__0)))));
    vlSelf->__VdfgTmp_h6cc2c965__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51371d7f__0));
    vlSelf->wasmetal_core__DOT___065053_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128232___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048334_))));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030123_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030090_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030283_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030218_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___036894_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036900_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134172___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036900_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036899_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036898_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036897_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___065636_ = (1U & (IData)(
                                                         (0x4f4f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053129_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7000000077ffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053125_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___048562_))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049685_)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0faaccU 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                              | ((4U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049045_)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053126_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049846_))))))))))))));
    vlSelf->wasmetal_core__DOT___053912_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053910_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x6eU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051617_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___053904_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053902_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe0001ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___053549_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h4b125034__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))))));
    vlSelf->__VdfgTmp_h37b9b4c8__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4b125034__0)))));
    vlSelf->wasmetal_core__DOT___066881_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfffff44400000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066877_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___066876_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffffff40ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050069_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050068_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050067_)))))))))))));
    vlSelf->wasmetal_core__DOT___053556_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h72fb59a4__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))))));
    vlSelf->wasmetal_core__DOT___051110_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))));
    vlSelf->wasmetal_core__DOT___053850_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053848_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7dU 
                                                                         >> 
                                                                         ((4U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049525_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___069536_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfb07bbea__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050860_)))))))))))))));
    vlSelf->wasmetal_core__DOT___053897_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053895_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7cU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051371_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 2U)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051373_)))))))));
    vlSelf->wasmetal_core__DOT___053857_ = (1U & (IData)(
                                                         (0xbb00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051889_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___053825_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053822_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf807ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053820_)))))))));
    vlSelf->wasmetal_core__DOT___068093_ = (1U & (IData)(
                                                         (0x45000000cf00cfcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055140_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050798_))))))))))));
    vlSelf->wasmetal_core__DOT___053889_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053887_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe01ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___053842_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053840_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffe0001fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___053804_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053800_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff80007fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___053873_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053871_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff80007ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050710_)))))))));
    vlSelf->wasmetal_core__DOT___050724_ = (1U & (IData)(
                                                         (0x777000007770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050710_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf1ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___050707_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069362_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051739_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h53aec20d__0))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xffff7f7f00ffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051729_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049321_)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd698a5e2__0))))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051736_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070066_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053720_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051721_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053722_))))))))))));
    vlSelf->wasmetal_core__DOT___053819_ = (1U & (IData)(
                                                         (0xee00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053817_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051780_))))))));
    vlSelf->wasmetal_core__DOT___066961_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066957_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(
                                                                                (0xffff01ffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x3700U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051297_))))))))))));
    vlSelf->wasmetal_core__DOT___067542_ = (1U & (IData)(
                                                         (0xff8fff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053393_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051623_))))))))))));
    vlSelf->wasmetal_core__DOT___053916_ = (1U & (IData)(
                                                         (0xfff1ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053914_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053694_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___053797_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f773f333f33ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053703_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___067103_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf4ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051339_))))))))))));
    vlSelf->wasmetal_core__DOT___069605_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051862_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e945c96__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051859_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___069413_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051761_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ebff551__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051758_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))))))))));
    vlSelf->wasmetal_core__DOT___064721_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051928_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdf0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((0x7f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051700_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051460_))))))))))));
    vlSelf->wasmetal_core__DOT___069279_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051656_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051655_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051654_)))))))));
    vlSelf->wasmetal_core__DOT___070009_ = (1U & (IData)(
                                                         (0xf8f800ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053702_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053578_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053579_)))))))));
    vlSelf->wasmetal_core__DOT___067616_ = (1U & (0xb33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053579_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053578_))))));
    vlSelf->wasmetal_core__DOT___069489_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7f80000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0))))))))))));
    vlSelf->wasmetal_core__DOT___051334_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xa802aaaaaaaaaaaaULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 4U) 
                                                                    | ((0xcU 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051322_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009506_)))));
    vlSelf->wasmetal_core__DOT___067029_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050658_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050657_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050642_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050640_)))))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->wasmetal_core__DOT___053638_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe1fffffU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                           << 4U) 
                                                                          | (0xfU 
                                                                             & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O), 1U)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___053538_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053533_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff807ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053531_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069387_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051749_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                             << 1U) 
                                                            | (IData)(
                                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        >> 3U) 
                                                                       & (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))))))))));
    vlSelf->wasmetal_core__DOT___053921_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053802_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x807fffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___069582_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051854_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x1fffe00000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___050882_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050879_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xe01fffffU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)))))))));
    vlSelf->wasmetal_core__DOT___051556_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051546_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfe01ffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___067298_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfbbbf333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052608_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052610_)))))))));
    vlSelf->wasmetal_core__DOT___053668_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe01ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052610_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069336_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051717_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051716_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x3ab00000U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 1U)) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                         | ((2U 
                                                                             & ((0xa333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___050904_)))))))))))));
    vlSelf->wasmetal_core__DOT___070051_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053714_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051708_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___053715_)))))))))));
    vlSelf->wasmetal_core__DOT___054756_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053715_))))));
    vlSelf->wasmetal_core__DOT___053650_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h228e0a62__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))))));
    vlSelf->wasmetal_core__DOT___051363_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))));
    vlSelf->wasmetal_core__DOT___069437_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051774_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___067955_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___053814_ = (1U & (0x7033U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___069627_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (0x4aU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___049542_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049482_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049481_))))));
    vlSelf->wasmetal_core__DOT___067473_ = (1U & (0xf0fb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfffff88800000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053186_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053185_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049048_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x3f203f3fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053194_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___053192_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xaaccf000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h454dd727__0)))))))))))));
    vlSelf->wasmetal_core__DOT___069971_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41349efa__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaa33f0f000000000ULL 
                                                                         >> 
                                                                         ((0x38U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053689_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x9f00bf00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053192_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___051610_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))));
    vlSelf->wasmetal_core__DOT___069311_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051703_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051701_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051700_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053708_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053705_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051692_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053706_))))))))))));
    vlSelf->wasmetal_core__DOT___069512_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051814_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xfa33f333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070156_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053828_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051809_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050858_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))))));
    vlSelf->wasmetal_core__DOT___068146_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x7077000070777077ULL 
                                                                              >> 
                                                                              ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf011fcfdU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050847_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))));
    vlSelf->wasmetal_core__DOT___053644_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h2290cda0__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h19298f26__0))))));
    vlSelf->wasmetal_core__DOT___051343_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19298f26__0))));
    vlSelf->wasmetal_core__DOT___070096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053528_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051752_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053526_))))))))))));
    vlSelf->wasmetal_core__DOT___053530_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053526_))))));
    vlSelf->wasmetal_core__DOT___051578_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))));
    vlSelf->wasmetal_core__DOT___053687_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h03f43c88__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))))));
    vlSelf->wasmetal_core__DOT___069466_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051793_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051790_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___068038_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x45000000cf00cfcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___068034_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053815_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009513_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009512_)))))))));
    vlSelf->wasmetal_core__DOT___053585_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd52a210e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70db4808__0))))));
    vlSelf->__VdfgTmp_h47401135__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70db4808__0))) 
                                             << 1U)) 
                                      | (1U & (0x3aU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd52a210e__0)))));
    vlSelf->wasmetal_core__DOT___069650_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051887_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051884_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___070244_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053852_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051880_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049651_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___049674_)))))))))));
    vlSelf->wasmetal_core__DOT___068469_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049650_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049649_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049651_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049674_))))))))))));
    vlSelf->wasmetal_core__DOT___053699_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habfc584e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))))));
    vlSelf->wasmetal_core__DOT___051627_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))));
    vlSelf->wasmetal_core__DOT___067807_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055205_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050546_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049606_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053720_)))))))));
    vlSelf->wasmetal_core__DOT___069908_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27becb7d__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xaa0a3303ff0fff0fULL 
                                                                       >> 
                                                                       ((0x30U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053658_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0faaccU 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051517_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))));
    vlSelf->wasmetal_core__DOT___070169_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053832_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbcU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050818_))))))))))));
    vlSelf->wasmetal_core__DOT___051662_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050818_))))));
    vlSelf->wasmetal_core__DOT___069558_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051839_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051837_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___068254_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___050841_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050832_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050831_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___070183_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053836_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe1f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050825_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050831_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050841_))))))))))));
    vlSelf->wasmetal_core__DOT___070215_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049334_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053844_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051857_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049245_)))))))))))));
    vlSelf->wasmetal_core__DOT___068361_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049244_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049243_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049245_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049334_))))))))))));
    vlSelf->wasmetal_core__DOT___069671_ = (1U & (0xfe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051894_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xaa33f00000000000ULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049718_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051889_)))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x802aaaaaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___068515_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049696_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049695_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049724_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___066474_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066470_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x44ff0fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h558c6a5e__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049740_))))))))))));
    vlSelf->wasmetal_core__DOT___069695_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052637_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa33f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xab300000U 
                                                                             >> 
                                                                             ((0x1cU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052634_)))))))))))));
    vlSelf->wasmetal_core__DOT___070273_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049744_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053859_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))))))));
    vlSelf->wasmetal_core__DOT___049771_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049744_))))));
    vlSelf->wasmetal_core__DOT___069717_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052723_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052720_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070285_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049792_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053863_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))))))));
    vlSelf->wasmetal_core__DOT___049823_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049792_))))));
    vlSelf->wasmetal_core__DOT___069739_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053523_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xd1c40000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053519_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049895_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))))))))))))));
    vlSelf->wasmetal_core__DOT___070297_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049881_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053867_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))))))));
    vlSelf->wasmetal_core__DOT___049904_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049881_))))));
    vlSelf->wasmetal_core__DOT___066721_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066717_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf7770000f333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066715_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053531_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128181___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029608_)))));
    vlSelf->wasmetal_core__DOT___029612_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128283___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128181___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128284___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030683_)))));
    vlSelf->wasmetal_core__DOT___030656_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128284___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050459_ = (1U & (IData)(
                                                         (0xff00ffff07000707ULL 
                                                          >> 
                                                          (((IData)(vlSelf->reset) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050445_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048115_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050443_)))))))));
    vlSelf->wasmetal_core__DOT___050464_ = (1U & (IData)(
                                                         (0xff80808000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050403_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050402_)))))))));
    vlSelf->wasmetal_core__DOT___053543_ = (1U & (IData)(
                                                         (0x4040ff4000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050404_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050405_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050403_)))))))));
    vlSelf->__VdfgTmp_hb0023997__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___050406_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___050435_))) 
                                             << 1U)) 
                                      | (1U & (0xfeU 
                                               >> (
                                                   ((IData)(vlSelf->reset) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050389_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0)))))))));
    vlSelf->wasmetal_core__DOT___050458_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050406_)))));
    vlSelf->wasmetal_core__DOT___051225_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4b91004e__0))))));
    vlSelf->wasmetal_core__DOT___053366_ = (1U & (IData)(
                                                         (0x40ff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052655_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053261_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edone) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053260_)))))))));
    vlSelf->wasmetal_core__DOT___052658_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052655_))));
    vlSelf->wasmetal_core__DOT___053163_ = (1U & (0xb000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053015_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052906_))))));
    vlSelf->wasmetal_core__DOT___053440_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053438_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050401_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))));
    vlSelf->wasmetal_core__DOT___053248_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h0f244854__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053247_))));
    vlSelf->wasmetal_core__DOT___053088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053087_))));
    vlSelf->wasmetal_core__DOT___052684_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052680_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052660_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050363_)))));
    vlSelf->wasmetal_core__DOT___052679_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth_ready) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052660_))));
    vlSelf->wasmetal_core__DOT___051205_ = (1U & (0xccca0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051201_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051200_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051199_)))))));
    vlSelf->wasmetal_core__DOT___053506_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048431_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___051226_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051202_))));
    vlSelf->wasmetal_core__DOT___052708_ = (1U & (IData)(
                                                         (0x4400f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052702_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051202_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052701_)))))))));
    vlSelf->wasmetal_core__DOT___051239_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050441_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051204_))));
    vlSelf->wasmetal_core__DOT___053250_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044492_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052833_)))))));
    vlSelf->wasmetal_core__DOT___053514_ = (1U & (IData)(
                                                         (0x700ffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053512_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053511_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7e6b8024__0))))))));
    vlSelf->wasmetal_core__DOT___050365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050363_))));
    vlSelf->wasmetal_core__DOT___050380_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050364_))));
    vlSelf->wasmetal_core__DOT___058927_ = (1U & (0xbeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he1590a3a__0))));
    vlSelf->wasmetal_core__DOT___006248_ = (1U & (0x444fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))));
    vlSelf->wasmetal_core__DOT___060481_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060480_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___019197_)))))))));
    vlSelf->wasmetal_core__DOT___058692_ = (1U & (0x1000U 
                                                  >> 
                                                  ((8U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048727_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___048728_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((0x80000000U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h5e920d5f__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h678017d8__0)))))))))));
    vlSelf->__VdfgTmp_hb3f3e4b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___051502_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006159_))));
    vlSelf->__VdfgTmp_ha93fec6f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006065_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___048703_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___006116_))));
    vlSelf->wasmetal_core__DOT___051501_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d))));
    vlSelf->__VdfgTmp_he648fa65__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005962_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hb70db301__0 = (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050141_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005896_))));
    vlSelf->__VdfgTmp_h3500bf27__0 = (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_h21922827__0 = (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005715_));
    vlSelf->__VdfgTmp_hf8096cfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___013670_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013668_));
    vlSelf->__VdfgTmp_h009053fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___013668_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013694_));
    vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005716_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127427___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hfe0efeb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013719_));
    vlSelf->__VdfgTmp_h9b9779ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013658_));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn 
        = ((IData)(vlSelf->wasmetal_core__DOT___002636_) 
           & ((IData)(vlSelf->wasmetal_core__DOT___002635_) 
              & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hd5565504__0)))))))));
    vlSelf->__VdfgTmp_h7d2fcfb3__0 = (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013654_));
    vlSelf->__VdfgTmp_h41b1ef3d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013654_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013690_));
    vlSelf->__VdfgTmp_h81ac2e72__0 = (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013795_));
    vlSelf->wasmetal_core__DOT___003130_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005738_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbbe1bed2__0)))));
    vlSelf->__VdfgTmp_h3f696fc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013705_));
    vlSelf->wasmetal_core__DOT___000139_ = ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                            & (IData)(
                                                      (0xe00000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___002471_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002470_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h1e702231__0)))))));
    vlSelf->__VdfgTmp_h0db23397__0 = (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))));
    vlSelf->__VdfgTmp_h563e3bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))));
    vlSelf->__VdfgTmp_h13976eb2__0 = (((IData)(vlSelf->wasmetal_core__DOT___013652_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013656_));
    vlSelf->__VdfgTmp_h62ff3be8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013687_));
    vlSelf->wasmetal_core__DOT___048930_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d))))));
    vlSelf->wasmetal_core__DOT___048929_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013798_)))))));
    vlSelf->wasmetal_core__DOT___127569___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___014245_));
    vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
           | (IData)(vlSelf->wasmetal_core__DOT___127477___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___002193_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_a__02eisZeroExpIn 
        = (1U & (IData)((0x8000000000000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006144_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                << 1U) 
                                                               | (1U 
                                                                  & (0x80U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h0c779906__0))))))))))));
    vlSelf->wasmetal_core__DOT___051506_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005989_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h419b9e2f__0))));
    vlSelf->wasmetal_core__DOT___022503_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
    vlSelf->wasmetal_core__DOT___022501_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___005715_)))));
}
