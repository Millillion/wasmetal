#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__18(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__18\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128060___O;
    wasmetal_core__DOT____Vcellout___128060___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h7baa8c24__0;
    __VdfgTmp_h7baa8c24__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028286_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028221_));
    vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027334_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b10__05d));
    vlSelf->__VdfgTmp_hb514b790__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h41acf677__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hb6ef8d81__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)))))));
    vlSelf->__VdfgTmp_hc21b3046__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_h9fa4f51d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h41461f4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022506_));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013635_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___069149_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hde86d559__0)))));
    vlSelf->wasmetal_core__DOT___058863_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->wasmetal_core__DOT___023774_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___058900_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___023763_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d))));
    vlSelf->wasmetal_core__DOT___058914_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0))))));
    vlSelf->wasmetal_core__DOT___023752_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))));
    vlSelf->wasmetal_core__DOT___023741_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d))));
    vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d) {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d;
        wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127455___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022671_)))));
    vlSelf->wasmetal_core__DOT___022652_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___018080_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___017927_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018857_))));
    vlSelf->wasmetal_core__DOT___019006_ = (1U & (0xefef00efU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017414_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058694_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058693_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___006238_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)))))))));
    vlSelf->wasmetal_core__DOT___058677_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017414_))));
    vlSelf->wasmetal_core__DOT___060482_ = (1U & (0xefffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058550_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___060481_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058690_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___017414_)))))));
    vlSelf->wasmetal_core__DOT___010377_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056316_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056313_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056312_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_had4ae229__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xfa0033U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbde6c7ef__0)))))))))))));
    vlSelf->wasmetal_core__DOT___022810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))));
    vlSelf->wasmetal_core__DOT___059176_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022797_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))))));
    vlSelf->wasmetal_core__DOT___022786_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))));
    vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d;
        wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___054554_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001525_)))));
    vlSelf->wasmetal_core__DOT___054555_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001537_)))));
    vlSelf->wasmetal_core__DOT___054556_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001569_)))));
    vlSelf->wasmetal_core__DOT___054557_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128649___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001581_)))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001613_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034353_));
    vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028877_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028466_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->wasmetal_core__DOT___064721_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051928_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051927_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdf0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((0x7f00U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051700_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab6fcc6c__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051460_))))))))))));
    vlSelf->wasmetal_core__DOT___053850_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053848_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7dU 
                                                                         >> 
                                                                         ((4U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049525_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009534_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___065180_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->wasmetal_core__DOT___065052_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134173___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048349_))));
    vlSelf->__VdfgTmp_h48aaf6cb__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h60159710__0))));
    vlSelf->__VdfgTmp_hc8f262c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha0d25e26__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h60159710__0)))));
    vlSelf->wasmetal_core__DOT___053825_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053822_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf807ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053820_)))))))));
    vlSelf->wasmetal_core__DOT___068093_ = (1U & (IData)(
                                                         (0x45000000cf00cfcfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055140_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053820_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050798_))))))))))));
    vlSelf->wasmetal_core__DOT___053889_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053887_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe01ffffU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h4795829e__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___069489_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b72__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x7f80000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0))))))))))));
    vlSelf->wasmetal_core__DOT___051334_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xa802aaaaaaaaaaaaULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 4U) 
                                                                    | ((0xcU 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051322_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009506_)))));
    vlSelf->wasmetal_core__DOT___067029_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7777000000f000f0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050658_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050657_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((IData)(
                                                                                (0xcfff4000cfffcfffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b24__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050642_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050640_)))))))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___009506_))))))))))));
    vlSelf->wasmetal_core__DOT___053638_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xfe1fffffU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                           << 4U) 
                                                                          | (0xfU 
                                                                             & VL_SHIFTL_III(4,4,32, (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O), 1U)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050655_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___053819_ = (1U & (IData)(
                                                         (0xee00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053817_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051780_))))))));
    vlSelf->wasmetal_core__DOT___066961_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066957_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(
                                                                                (0xffff01ffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h73ce3765__0))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0x3700U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b23__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051297_))))))))))));
    vlSelf->wasmetal_core__DOT___069466_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051793_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051792_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b71__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051790_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051789_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___068038_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b39__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x45000000cf00cfcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___068034_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053816_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052620_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053815_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009513_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___009512_)))))))));
    vlSelf->wasmetal_core__DOT___053585_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd52a210e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h70db4808__0))))));
    vlSelf->__VdfgTmp_h47401135__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h70db4808__0))) 
                                             << 1U)) 
                                      | (1U & (0x3aU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd52a210e__0)))));
    vlSelf->wasmetal_core__DOT___066881_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfffff44400000000ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___066877_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___066876_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)))))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffffff40ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050069_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050068_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050067_)))))))))))));
    vlSelf->wasmetal_core__DOT___053556_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h72fb59a4__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))))));
    vlSelf->wasmetal_core__DOT___051110_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha2491a49__0))));
    vlSelf->wasmetal_core__DOT___069413_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051761_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ebff551__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd506ed16__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b69__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051758_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051421_)))))))))))))));
    vlSelf->wasmetal_core__DOT___053549_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h4b125034__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))))));
    vlSelf->__VdfgTmp_h37b9b4c8__0 = ((2U & ((0x5cU 
                                              >> ((4U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                      << 1U)) 
                                                  | (IData)(vlSelf->__VdfgTmp_h34f15f45__0))) 
                                             << 1U)) 
                                      | (1U & (0x5cU 
                                               >> (
                                                   (4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4b125034__0)))));
    vlSelf->wasmetal_core__DOT___066552_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053729_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0ffb000f0fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b18__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053726_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049784_))))))))))));
    vlSelf->wasmetal_core__DOT___053897_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053895_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x7cU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051371_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                             | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 2U)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051373_)))))))));
    vlSelf->wasmetal_core__DOT___053842_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053840_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffe0001fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___053804_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053800_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff80007fffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___066717_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066714_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066713_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (3U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                     >> 2U))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xf0fccaaU 
                                                                  >> 
                                                                  ((0x18U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 3U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___051466_))))))))))));
    vlSelf->wasmetal_core__DOT___053873_ = (1U & (IData)(
                                                         (0xe00ee0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053871_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff80007ffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050710_)))))))));
    vlSelf->wasmetal_core__DOT___050724_ = (1U & (IData)(
                                                         (0x777000007770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050710_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050709_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf1ffU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___050707_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___066389_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0x8f8f8f8fff00ffffULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009509_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009508_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xffcf0080ffcfffcfULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b16__05d) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___049848_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049847_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049005_)))))))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (8U 
                                                                          >> 
                                                                          ((2U 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___049694_))))))))))));
    vlSelf->wasmetal_core__DOT___053857_ = (1U & (IData)(
                                                         (0xbb00f000ff00ffULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051889_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___053797_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x7f773f333f33ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                     << 4U) 
                                                                    | ((8U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053703_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051923_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))))))));
    vlSelf->wasmetal_core__DOT___066470_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055415_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055414_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> 
                                                              (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  >> 2U))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x45cfcf00ffffffULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                               << 4U)) 
                                                                           | ((0x10U 
                                                                               & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))))))))));
    vlSelf->wasmetal_core__DOT___067103_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x153f151515151515ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3e63cb74__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___051403_)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xf4ff0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b25__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9a0c5050__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051339_))))))))))));
    vlSelf->wasmetal_core__DOT___069362_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051739_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xdU 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h53aec20d__0))))))) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xffff7f7f00ffffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051729_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaccf0f000000000ULL 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049321_)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd698a5e2__0))))))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b67__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051736_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070066_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053724_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b99__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053720_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051721_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053722_))))))))))));
    vlSelf->wasmetal_core__DOT___066637_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066633_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066627_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049607_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff0f8808ff0fff0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b19__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066629_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049879_))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009506_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x40U 
                                                                             >> 
                                                                             ((4U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049877_)))))))))))));
    vlSelf->wasmetal_core__DOT___067542_ = (1U & (IData)(
                                                         (0xff8fff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053396_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b31__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053393_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051623_))))))))))));
    vlSelf->wasmetal_core__DOT___053916_ = (1U & (IData)(
                                                         (0xfff1ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053914_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___053694_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___066303_ = (1U & ((1U 
                                                   & (0xa300U 
                                                      >> 
                                                      ((8U 
                                                        & ((1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                >> 2U))) 
                                                           << 3U)) 
                                                       | ((4U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                              << 1U)) 
                                                          | ((2U 
                                                              & ((0xf0f5533U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 4U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053388_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xacU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___053212_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___053209_))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (0xcaU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053210_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049649_))))))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___009497_))
                                                   : (IData)(
                                                             (0xcccccccccc40c0c0ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                << 5U) 
                                                               | ((0x10U 
                                                                   & ((8U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U))) 
                                                                      << 4U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009499_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((IData)(
                                                                                (0x773f3f3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b15__05d) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___009497_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___009496_))))))))));
    vlSelf->wasmetal_core__DOT___069279_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051656_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051655_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b64__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051654_)))))))));
    vlSelf->wasmetal_core__DOT___070009_ = (1U & (IData)(
                                                         (0xf8f800ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053702_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b96__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053578_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053579_)))))))));
    vlSelf->wasmetal_core__DOT___067616_ = (1U & (0xb33U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053579_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053578_))))));
    vlSelf->wasmetal_core__DOT___051894_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xa82aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))))));
    vlSelf->wasmetal_core__DOT___049696_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc669ea30__0))));
    vlSelf->wasmetal_core__DOT___069387_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051749_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051748_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b68__05d) 
                                                             << 1U) 
                                                            | (IData)(
                                                                      (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                        >> 3U) 
                                                                       & (0x7fff800000000000ULL 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))))))))));
    vlSelf->wasmetal_core__DOT___053921_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053802_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b36__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x807fffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___053538_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053533_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff807ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053531_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069582_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051854_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b76__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0x1fffe00000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0)))))))))))))));
    vlSelf->wasmetal_core__DOT___050882_ = (1U & (0xbf300000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050879_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0xe01fffffU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)))))))));
    vlSelf->wasmetal_core__DOT___070412_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b124__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xfe01ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051546_)))))))));
    vlSelf->wasmetal_core__DOT___051556_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051546_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0xfe01ffffU 
                                                               >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0))))))));
    vlSelf->wasmetal_core__DOT___067298_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052612_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfbbbf333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052608_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b28__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052610_)))))))));
    vlSelf->wasmetal_core__DOT___053668_ = (1U & (IData)(
                                                         (0xb00bb0000ffffULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfffe01ffffffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h8594c810__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052610_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___069336_ = (1U & (0xfff40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051717_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051716_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b66__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x3ab00000U 
                                                                  >> 
                                                                  ((0x10U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                       << 1U)) 
                                                                   | ((8U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                          << 2U)) 
                                                                      | ((4U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                         | ((2U 
                                                                             & ((0xa333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___050904_)))))))))))));
    vlSelf->wasmetal_core__DOT___070051_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053714_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051708_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b98__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___053715_)))))))))));
    vlSelf->wasmetal_core__DOT___054756_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053716_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053715_))))));
    vlSelf->wasmetal_core__DOT___052723_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h9b387498__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))))));
    vlSelf->wasmetal_core__DOT___049793_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc6a436e7__0))));
    vlSelf->wasmetal_core__DOT___069536_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfb07bbea__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b74__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050860_)))))))))))))));
    vlSelf->wasmetal_core__DOT___050819_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6383fd4d__0))));
    vlSelf->wasmetal_core__DOT___053650_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h228e0a62__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))))));
    vlSelf->wasmetal_core__DOT___051363_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56ff1f8b__0))));
    vlSelf->wasmetal_core__DOT___069437_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051776_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b70__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051774_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___067955_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b38__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___053814_ = (1U & (0x7033U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 2U))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053809_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053808_))))));
    vlSelf->wasmetal_core__DOT___069627_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051874_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b78__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U)) 
                                                                              | (1U 
                                                                                & (0x4aU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfe00000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___049542_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049482_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049481_))))));
    vlSelf->wasmetal_core__DOT___067473_ = (1U & (0xf0fb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfffff88800000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053186_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053185_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049048_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0x3f203f3fU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b30__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___053194_) 
                                                                      << 3U) 
                                                                     | ((4U 
                                                                         & ((8U 
                                                                             >> 
                                                                             (3U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___053192_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xaaccf000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 5U)) 
                                                                           | ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053195_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h454dd727__0)))))))))))));
    vlSelf->wasmetal_core__DOT___069971_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h41349efa__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xaa33f0f000000000ULL 
                                                                         >> 
                                                                         ((0x38U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053193_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___051616_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053689_)))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0x9f00bf00U 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b94__05d) 
                                                                       << 3U) 
                                                                      | ((4U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                             >> 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___053192_) 
                                                                             << 1U) 
                                                                            | (1U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))))))));
    vlSelf->wasmetal_core__DOT___051610_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h49696f4b__0))));
    vlSelf->wasmetal_core__DOT___067807_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055205_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050546_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049606_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053720_)))))))));
    vlSelf->wasmetal_core__DOT___053523_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h73a0c82f__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))))));
    vlSelf->wasmetal_core__DOT___049882_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2cfc9ba7__0))));
    vlSelf->wasmetal_core__DOT___051840_ = (1U & (IData)(
                                                         (0xf0a030f0f0f0f0f0ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((4U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb744a8fa__0)))))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))))));
    vlSelf->wasmetal_core__DOT___050842_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0a242e26__0))));
    vlSelf->wasmetal_core__DOT___069908_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xf050c0f0f0f0f0fULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           << 2U)) 
                                                                       | ((4U 
                                                                           & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h27becb7d__0))))))) 
                                                                              << 2U)) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xaa0a3303ff0fff0fULL 
                                                                       >> 
                                                                       ((0x30U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 2U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053658_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b91__05d) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053657_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0faaccU 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6780f3af__0)))))))))))))))));
    vlSelf->wasmetal_core__DOT___051517_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h28bc3512__0))));
    vlSelf->wasmetal_core__DOT___069650_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051887_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051886_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b79__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x5f4e0000U 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051884_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009496_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))))))));
    vlSelf->wasmetal_core__DOT___070244_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053852_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051880_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049651_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b111__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___049674_)))))))))));
    vlSelf->wasmetal_core__DOT___068469_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049676_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b47__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049650_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049649_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049651_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049674_))))))))))));
    vlSelf->wasmetal_core__DOT___053699_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf0a030f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x20U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 3U)) 
                                                                               | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_habfc584e__0))))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))))));
    vlSelf->wasmetal_core__DOT___051627_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d7ec491__0))));
    vlSelf->wasmetal_core__DOT___069311_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051703_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b65__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051701_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051700_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070032_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053708_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b97__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053705_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053704_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051692_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053706_))))))))))));
    vlSelf->wasmetal_core__DOT___052637_ = (1U & (IData)(
                                                         (0xf05030f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h37fa163f__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))))));
    vlSelf->wasmetal_core__DOT___049745_ = (1U & (0x53U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hae9934f9__0))));
    vlSelf->wasmetal_core__DOT___069512_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051814_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b73__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x3ab00000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xfa33f333U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_heaed7142__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070156_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xfff1ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 1U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053828_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051809_))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050858_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xbf300000U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b105__05d) 
                                                                 << 3U) 
                                                                | ((4U 
                                                                    & ((4U 
                                                                        >> 
                                                                        (3U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                            >> 2U))) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))))));
    vlSelf->wasmetal_core__DOT___068146_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0x7077000070777077ULL 
                                                                              >> 
                                                                              ((0x20U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 5U)) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050858_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b41__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf011fcfdU 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050847_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050846_)))))))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfed11520__0))))))));
    vlSelf->wasmetal_core__DOT___053644_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h2290cda0__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h19298f26__0))))));
    vlSelf->wasmetal_core__DOT___051343_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h19298f26__0))));
    vlSelf->wasmetal_core__DOT___065288_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00ff001f1f0000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051438_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051437_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 2U)) 
                                                                           | ((2U 
                                                                               & ((0x5300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))) 
                                                                                << 1U)) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf0f00005533ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 5U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051432_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051318_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051317_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051424_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___070096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b101__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xee00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053805_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053528_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051752_))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___053526_))))))))))));
    vlSelf->wasmetal_core__DOT___053530_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053527_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053526_))))));
    vlSelf->wasmetal_core__DOT___066114_ = (1U & (IData)(
                                                         (0xff8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x773f3f3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053731_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b13__05d)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049212_))))))))))));
    vlSelf->wasmetal_core__DOT___069605_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051862_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e945c96__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b77__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051859_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___049336_ = (1U & (0xa3U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0de2f8d5__0))));
    vlSelf->wasmetal_core__DOT___051578_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))));
    vlSelf->wasmetal_core__DOT___053687_ = (1U & (IData)(
                                                         (0xf050c0f0f0f0f0fULL 
                                                          >> 
                                                          ((0x38U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 2U)) 
                                                           | ((4U 
                                                               & ((IData)(
                                                                          (0xf050c0f0f0f0f0f0ULL 
                                                                           >> 
                                                                           ((0x38U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                                << 2U) 
                                                                               | (IData)(vlSelf->__VdfgTmp_h03f43c88__0))))) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_h0d8fe922__0))))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028121_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028088_)
                  : (vlSelf->insn_x >> 8U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127852___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026456_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026455_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026485_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026484_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026451_)))));
    vlSelf->wasmetal_core__DOT___026423_ = ((IData)(vlSelf->wasmetal_core__DOT___026456_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029134_));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031054_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031020_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    __VdfgTmp_h7baa8c24__0 = ((2U & ((0x2bU >> (IData)(vlSelf->__VdfgTmp_h839fe08c__0)) 
                                     << 1U)) | (1U 
                                                & (0x2bU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)))));
    vlSelf->__VdfgTmp_h84670069__0 = (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h39564552__0)))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011793_))))));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012224_));
    } else {
        vlSelf->wasmetal_core__DOT___011909_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hc60fc2d0__0)));
        vlSelf->wasmetal_core__DOT___012810_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011795_));
        vlSelf->wasmetal_core__DOT___011782_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011792_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011790_))))));
        vlSelf->wasmetal_core__DOT___012215_ = (1U 
                                                & (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___012070_))))));
    }
    vlSelf->wasmetal_core__DOT___011951_ = (1U & (IData)(
                                                         (0x33550f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha9c6ec44__0))))))));
    vlSelf->wasmetal_core__DOT___056772_ = (1U & (IData)(
                                                         (0xf0f335500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056767_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011791_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011790_)))))))));
    vlSelf->wasmetal_core__DOT___056909_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))));
    vlSelf->__VdfgTmp_h7d32537f__0 = (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h1c56b6c5__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011087_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057163_));
    vlSelf->__VdfgTmp_h07056034__0 = ((2U & ((IData)(
                                                     (0xf0f0ff1100000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012610_) 
                                                              << 3U) 
                                                             | ((4U 
                                                                 & (((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                                      ? 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (2U 
                                                                       >> (IData)(vlSelf->wasmetal_core__DOT___012632_))
                                                                       : 
                                                                      (0xdU 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___012632_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___012631_))))
                                                                      : 
                                                                     ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                                       ? 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0))
                                                                       : 
                                                                      (0xeU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h796615cc__0)))) 
                                                                    << 2U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011300_)))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011299_)))))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011572_))));
    vlSelf->__VdfgTmp_haf8803a1__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0xfff0fff033335555ULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011558_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011557_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdcc00e41__0)))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? (IData)(vlSelf->wasmetal_core__DOT___011572_)
                                                     : 
                                                    (0x305U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___011431_))))))));
    vlSelf->__VdfgTmp_h8088f5ad__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                        & (IData)((0x111111110f0f00ffULL 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 5U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                              << 2U) 
                                                             | ((2U 
                                                                 & ((0xf0110000U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012631_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___012630_)))))) 
                                                                    << 1U)) 
                                                                | (1U 
                                                                   & (IData)(
                                                                             (0xf00001111ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011566_))))))))))))))))) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                     ? 
                                                    (0x503U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012072_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012219_)))))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___012224_))));
    vlSelf->wasmetal_core__DOT___011080_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010396_)
                                                   ? 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hde352602__0))))
                                                   : 
                                                  (0x305U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))));
    vlSelf->wasmetal_core__DOT___011024_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056366_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056365_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca83bd04__0))))))));
    vlSelf->__VdfgTmp_h5d9b5f2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___057453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012808_))));
    vlSelf->wasmetal_core__DOT___057664_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013034_))));
    vlSelf->__VdfgTmp_h4aee2d94__0 = (((IData)(vlSelf->wasmetal_core__DOT___013034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hac971038__0 = (((IData)(vlSelf->wasmetal_core__DOT___011079_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_hdab8ca95__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011079_));
    vlSelf->__VdfgTmp_hc7461e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___011425_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h11d85c9f__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011780_));
    vlSelf->__VdfgTmp_heceb31a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012213_));
    vlSelf->__VdfgTmp_h3659b78c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012213_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h745845c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012405_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->wasmetal_core__DOT___012574_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0))))))));
    vlSelf->__VdfgTmp_h4fcaab62__0 = (((IData)(vlSelf->wasmetal_core__DOT___012531_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h2fb7cfc6__0));
    vlSelf->wasmetal_core__DOT___012818_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057389_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012808_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___012957_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057389_)))))));
    vlSelf->__VdfgTmp_h3b7e1022__0 = (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3c43f86a__0));
    vlSelf->wasmetal_core__DOT___012926_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010395_)
                                                    ? 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012779_))))
                                                    : 
                                                   (0xcaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012780_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012778_)))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012782_))));
    vlSelf->wasmetal_core__DOT___057447_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012782_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___011426_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h140002d8__0)))))))));
    vlSelf->wasmetal_core__DOT___011550_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011656_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011332_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011331_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h140002d8__0))))))));
    vlSelf->wasmetal_core__DOT___011128_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xff00ffcfffafffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0)))))))));
    vlSelf->wasmetal_core__DOT___011082_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0))))))));
    vlSelf->__VdfgTmp_hfde06fd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___010405_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb3a32b8e__0));
    vlSelf->wasmetal_core__DOT___013035_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010604_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))))))));
    vlSelf->wasmetal_core__DOT___057537_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_hdaecee48__0))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012559_)))))));
    vlSelf->__VdfgTmp_h25b48e48__0 = (((IData)(vlSelf->wasmetal_core__DOT___013056_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hdaecee48__0));
    vlSelf->wasmetal_core__DOT___065822_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011780_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___012707_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0)))))));
    vlSelf->wasmetal_core__DOT___012576_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd9ebd9b4__0))));
    vlSelf->wasmetal_core__DOT___057098_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_he11b9fc4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->__VdfgTmp_ha6c246b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___066419_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011293_)))))))));
    vlSelf->wasmetal_core__DOT___056668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___056334_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->__VdfgTmp_hf218f314__0 = (((IData)(vlSelf->wasmetal_core__DOT___057577_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___012073_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h358fed79__0))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057627_))));
    vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036841_)) 
                 & (0x69U >> (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    vlSelf->wasmetal_core__DOT___050115_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006051_))))));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005948_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023449_));
    vlSelf->__VdfgTmp_h8ac5901b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013787_));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013785_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023570_));
    wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028642_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004670_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029085_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028954_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128437___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128437___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032260_)))));
    vlSelf->wasmetal_core__DOT___032264_ = ((IData)(vlSelf->wasmetal_core__DOT___001580_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001580_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028745_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___045017_ = (1U & (IData)(
                                                         (0xfce8e8c0fffffafaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054075_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)))))))))));
    vlSelf->wasmetal_core__DOT___045041_ = (1U & (IData)(
                                                         (0x1040208f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h77f7c585__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071252_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054079_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054075_)))))))));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026667_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___070692_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027137_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b13__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127868___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026564_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026563_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026593_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026592_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026559_)))));
    vlSelf->wasmetal_core__DOT___026498_ = ((IData)(vlSelf->wasmetal_core__DOT___026564_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001426_));
    vlSelf->wasmetal_core__DOT___070795_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026937_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5a182b30__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->wasmetal_core__DOT____Vcellout___128665___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128437___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034510_)))));
    vlSelf->wasmetal_core__DOT___034514_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001580_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030124_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030284_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    wasmetal_core__DOT____Vcellout___128060___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028287_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028286_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028316_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028315_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028282_)))));
    vlSelf->wasmetal_core__DOT___028254_ = ((IData)(vlSelf->wasmetal_core__DOT___028287_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028222_));
    wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127953___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027335_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027334_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027396_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027395_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027330_)))));
    vlSelf->wasmetal_core__DOT___027270_ = ((IData)(vlSelf->wasmetal_core__DOT___027335_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b11__05d));
    vlSelf->wasmetal_core__DOT___023230_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006092_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))));
    vlSelf->wasmetal_core__DOT___023229_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc21b3046__0))));
    vlSelf->wasmetal_core__DOT___023228_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fa4f51d__0))));
    vlSelf->wasmetal_core__DOT___023227_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005982_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127463___O 
        = (((8U & ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h13976eb2__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022737_)))));
    vlSelf->wasmetal_core__DOT___022741_ = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h1e702231__0)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___023931_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023931_ = wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___023741_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT___006635_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022652_));
    vlSelf->wasmetal_core__DOT___019034_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___018274_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    vlSelf->wasmetal_core__DOT___017184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019006_))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___022889_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022889_ = wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___022786_)) 
                 & (1U >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001625_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028847_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT____Vcellout___128079___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028467_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028466_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028465_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028464_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028430_)))));
    vlSelf->wasmetal_core__DOT___028434_ = ((IData)(vlSelf->wasmetal_core__DOT___028467_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128079___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003706_));
    vlSelf->wasmetal_core__DOT___070230_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b110__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049481_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049482_)))))))));
    vlSelf->__VdfgTmp_hca11f007__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 1U)) 
                                      | (1U & (4U >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0))));
    vlSelf->__VdfgTmp_h19390f5d__0 = ((4U & ((6U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((9U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h48aaf6cb__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    vlSelf->__VdfgTmp_h0341114f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h4e2d279b__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc8f262c3__0)))));
    vlSelf->wasmetal_core__DOT___070142_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053825_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b104__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___068094_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068093_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b40__05d)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053823_)))))))));
    vlSelf->wasmetal_core__DOT___070363_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053889_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xa802aaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b120__05d)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051322_)))))))));
    vlSelf->wasmetal_core__DOT___068910_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051334_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbfbfbfU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051331_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b56__05d) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0)))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051332_)))))))));
    vlSelf->wasmetal_core__DOT___069846_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053638_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b88__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x1fe0000000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb7578f7f__0)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050641_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051330_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053634_))))))))))))));
    vlSelf->wasmetal_core__DOT___070125_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053819_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b103__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009512_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009513_)))))))));
    vlSelf->wasmetal_core__DOT___069826_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053585_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050981_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051291_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b87__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053582_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070347_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b119__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h47401135__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053883_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053581_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051293_)))))))))))));
    vlSelf->wasmetal_core__DOT___068863_ = ((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                            & (IData)(
                                                      (0xbbff33000f0f0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b55__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (0xef00efefULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___051294_) 
                                                                                << 5U) 
                                                                               | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xff55ccf0U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h35851421__0)))))))))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h47401135__0))))))));
    vlSelf->wasmetal_core__DOT___069804_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050067_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b86__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053553_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050041_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070335_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b118__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051109_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053879_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053551_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))))))));
    vlSelf->wasmetal_core__DOT___051121_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051110_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051109_))))));
    vlSelf->wasmetal_core__DOT___069782_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053549_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051063_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051062_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b85__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051065_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070323_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b117__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053875_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053545_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009523_)))))))))))));
    vlSelf->wasmetal_core__DOT___068763_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b53__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h37b9b4c8__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((~ (IData)(vlSelf->wasmetal_core__DOT___009501_)) 
                                                            & (IData)(
                                                                      (0xffffffff10ff1010ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___009524_) 
                                                                         << 5U) 
                                                                        | ((0x10U 
                                                                            & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                               << 4U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009523_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009520_))))))))))))));
    vlSelf->wasmetal_core__DOT___070200_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053842_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b108__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xe01fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050879_)))))))));
    vlSelf->wasmetal_core__DOT___070082_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053804_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b100__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0x807fffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053802_)))))))));
    vlSelf->wasmetal_core__DOT___066721_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066717_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf7770000f333f333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065163_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066715_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 1U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053531_)))))))));
    vlSelf->wasmetal_core__DOT___070310_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053873_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b116__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___068714_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050724_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((0xf807ffffU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf59791bd__0)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050722_)))))))));
    vlSelf->wasmetal_core__DOT___067680_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053797_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b33__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053706_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___009506_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053708_)))))))));
    vlSelf->wasmetal_core__DOT___066474_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066470_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf454545454545ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051593_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x44ff0fff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b17__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h558c6a5e__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (8U 
                                                                             >> 
                                                                             ((2U 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049740_))))))))))));
    vlSelf->wasmetal_core__DOT___067617_ = (1U & (IData)(
                                                         (0xff8f8f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067616_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccffffa000f0ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b32__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053730_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051654_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048676_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009537_)))))))));
    vlSelf->wasmetal_core__DOT___069671_ = (1U & (0xfe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051894_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xaa33f00000000000ULL 
                                                                      >> 
                                                                      ((0x38U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           << 2U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049719_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049718_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051889_)))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x802aaaaaaaaaaaaaULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b80__05d))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___009501_)))))));
    vlSelf->wasmetal_core__DOT___070261_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053857_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b112__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049695_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049696_)))))))));
    vlSelf->wasmetal_core__DOT___068515_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b48__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049696_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049695_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049724_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___049723_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049722_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___067859_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053921_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf4ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051843_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051842_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049217_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051841_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053798_)))))))));
    vlSelf->wasmetal_core__DOT___069761_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053538_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x70U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b84__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0x7fff80000000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h05f5edae__0))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 3U))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050705_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050704_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053534_))))))))))))));
    vlSelf->wasmetal_core__DOT___068307_ = (1U & (IData)(
                                                         (0xff00ff4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050882_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b44__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048681_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048680_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050880_)))))))));
    vlSelf->wasmetal_core__DOT___069102_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051556_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b60__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051553_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048673_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051554_)))))))));
    vlSelf->wasmetal_core__DOT___069929_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053668_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xe0U 
                                                                         >> 
                                                                         ((4U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                              >> 1U)) 
                                                                          | ((2U 
                                                                              & ((0xa300U 
                                                                                >> 
                                                                                ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051552_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053663_)))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b92__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x6020U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                               << 3U) 
                                                                              | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052601_)))))))))))));
    vlSelf->wasmetal_core__DOT___067744_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054756_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050896_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053711_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050974_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053712_)))))))));
    vlSelf->wasmetal_core__DOT___069717_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052723_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049809_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049808_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b82__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052720_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | ((2U 
                                                                                & ((0xf0880000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070285_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b114__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049792_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053863_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052718_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))))))));
    vlSelf->wasmetal_core__DOT___049823_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049793_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049792_))))));
    vlSelf->wasmetal_core__DOT___070169_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b106__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053832_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xbcU 
                                                                                >> 
                                                                                ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x35U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h52e200a0__0)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050818_))))))))))));
    vlSelf->wasmetal_core__DOT___051662_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050819_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050818_))))));
    vlSelf->wasmetal_core__DOT___069888_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053650_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x9f00df00U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b90__05d) 
                                                                              << 3U) 
                                                                             | ((6U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053647_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051370_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051369_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053646_))))))))))))));
    vlSelf->wasmetal_core__DOT___070387_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b122__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051362_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051363_)))))))));
    vlSelf->wasmetal_core__DOT___069009_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b58__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051363_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051362_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051374_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051373_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051372_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___067958_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067955_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x2202ff0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067953_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051989_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053811_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053810_)))))))));
    vlSelf->wasmetal_core__DOT___070110_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053814_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x48ccc8ccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                           << 4U) 
                                                                          | ((0xcU 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b102__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053811_))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0xbbb0U 
                                                                             >> 
                                                                             ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053810_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051764_))))))))))))));
    vlSelf->wasmetal_core__DOT___068416_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049542_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b46__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049539_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049538_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049537_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049540_)))))))));
    vlSelf->wasmetal_core__DOT___070437_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053912_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b126__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051609_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051610_)))))))));
    vlSelf->wasmetal_core__DOT___051621_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051610_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b62__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051609_))))));
    vlSelf->wasmetal_core__DOT___069739_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053523_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b83__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xd1c40000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053519_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049897_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049896_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049895_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))))))))))))));
    vlSelf->wasmetal_core__DOT___070297_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b115__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049881_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053867_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053518_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))))))));
    vlSelf->wasmetal_core__DOT___049904_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049882_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049881_))))));
    vlSelf->wasmetal_core__DOT___069558_ = (1U & (IData)(
                                                         (0xfff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051840_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051839_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b75__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x2c00U 
                                                                             >> 
                                                                             ((0xcU 
                                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051837_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009534_)))))))))))));
    vlSelf->wasmetal_core__DOT___068254_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b43__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___050841_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050832_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050831_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050830_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___070183_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050842_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xe00ee0000ffffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b107__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053836_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xe1f5U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                                                << 3U) 
                                                                                | ((6U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050825_)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050831_)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050841_))))))))))));
    vlSelf->wasmetal_core__DOT___070399_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (3U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                              >> 2U))) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b123__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((IData)(
                                                                                (0xbb00f000ff00ffULL 
                                                                                >> 
                                                                                ((0x30U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053898_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051527_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053652_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___051516_))))))))))));
    vlSelf->wasmetal_core__DOT___051529_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051517_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051516_))))));
    vlSelf->wasmetal_core__DOT___069991_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053699_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b95__05d) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (0xfe540000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053695_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053389_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55ccf0ffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051634_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051633_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053694_))))))))))))));
    vlSelf->wasmetal_core__DOT___070449_ = (1U & (IData)(
                                                         (0xfff4ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053916_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b127__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051626_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051627_)))))))));
    vlSelf->wasmetal_core__DOT___051640_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051627_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051626_))))));
    vlSelf->wasmetal_core__DOT___069695_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052637_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa33f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049761_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049760_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b81__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xab300000U 
                                                                             >> 
                                                                             ((0x1cU 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049764_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052634_)))))))))))));
    vlSelf->wasmetal_core__DOT___070273_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b113__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049744_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053859_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052633_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))))))));
    vlSelf->wasmetal_core__DOT___049771_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049745_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049744_))))));
    vlSelf->wasmetal_core__DOT___069867_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053644_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaa330f0000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051350_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051349_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b89__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xd1c40000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053641_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051351_)))))))))))))));
    vlSelf->wasmetal_core__DOT___070375_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b121__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051342_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053891_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053640_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))))))));
    vlSelf->wasmetal_core__DOT___051357_ = (1U & (0x7033U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051343_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051342_))))));
    vlSelf->wasmetal_core__DOT___067915_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053530_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaa0ccc0fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053525_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b37__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha128d41e__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053528_)))))))));
    vlSelf->wasmetal_core__DOT___070215_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b109__05d) 
                                                                << 3U) 
                                                               | ((4U 
                                                                   & ((4U 
                                                                       >> 
                                                                       (3U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                           >> 2U))) 
                                                                      << 2U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___049334_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xfff1ff00ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | ((0x10U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                            << 1U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053844_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((4U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051857_))) 
                                                                                << 2U)) 
                                                                              | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049245_)))))))))))));
    vlSelf->wasmetal_core__DOT___068361_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x5f000f0fccccccccULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___049336_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                            << 2U) 
                                                                           | ((2U 
                                                                               & ((0xd0U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xfff0e000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b45__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049244_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049243_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048679_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (1U 
                                                                                & (0x8fU 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)))) 
                                                                                << 1U)))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049245_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))))))) 
                                                                                << 1U)) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___049334_))))))))))));
    vlSelf->wasmetal_core__DOT___070424_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053908_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b125__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051577_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051578_)))))))));
    vlSelf->wasmetal_core__DOT___069152_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbf300000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b61__05d) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051578_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___051577_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0xffff88f8ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___051588_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___051587_) 
                                                                            << 3U) 
                                                                           | ((4U 
                                                                               & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051586_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009522_)))))))))))));
    vlSelf->wasmetal_core__DOT___069950_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053687_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x1111f00000000000ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053114_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x503U 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x3333aaaaf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0x5cU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049132_))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049142_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048585_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048584_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf502c6b2__0))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049747_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfbafed17__0))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049794_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049883_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4cf0cb93__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf0faaccU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051345_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7cd11e4f__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h36154466__0)))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xfeff0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053680_) 
                                                                                << 3U) 
                                                                                | (4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 2U))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b93__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfe540000U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053684_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053112_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051788_)))))))))))))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028122_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 9U)));
    vlSelf->wasmetal_core__DOT___044907_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127850___O) 
                                                               << 2U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127851___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O))))))))));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026457_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026423_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031055_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___036846_ = (1U & (IData)(
                                                         (0xff7f7f1717010100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h7baa8c24__0))))))));
    vlSelf->__VdfgTmp_h15cdecdf__0 = (((IData)(vlSelf->wasmetal_core__DOT___072165_) 
                                       << 2U) | (IData)(__VdfgTmp_h7baa8c24__0));
    vlSelf->wasmetal_core__DOT___036629_ = (1U & (0x96696996U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072201_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x69U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))))));
    vlSelf->wasmetal_core__DOT___072213_ = (1U & (0xd4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x69U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___072214_ = (1U & (IData)(
                                                         (0xb24d4db24db2b24dULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xb2U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((9U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84670069__0)))))));
    vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h9cfb33d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012405_))))));
    vlSelf->__VdfgTmp_h3b8e8d7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010085_)));
    vlSelf->__VdfgTmp_h7884ece4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056772_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0)));
    vlSelf->__VdfgTmp_hdf888c66__0 = (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0));
    vlSelf->wasmetal_core__DOT___067212_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___056988_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf4f4f4f4ffffff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012215_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___065919_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))));
    vlSelf->wasmetal_core__DOT___056906_ = (1U & (IData)(
                                                         (0xf0f000ee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))))))));
    vlSelf->wasmetal_core__DOT___057167_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012407_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h745845c2__0))));
    vlSelf->__VdfgTmp_h186e290b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h07e757d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012607_));
    vlSelf->wasmetal_core__DOT___012752_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xccffaafff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0))))))));
    vlSelf->wasmetal_core__DOT___012567_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012558_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065323_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012818_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012809_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012810_)))))));
    vlSelf->wasmetal_core__DOT___066870_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057453_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012957_)))))));
    vlSelf->wasmetal_core__DOT___012883_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012957_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057453_)))))))));
    vlSelf->__VdfgTmp_h3545ce03__0 = (((IData)(vlSelf->wasmetal_core__DOT___057380_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ccccf0f0aaaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0))))))));
    vlSelf->wasmetal_core__DOT___011907_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0)))))));
    vlSelf->wasmetal_core__DOT___068413_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hca606f65__0 = (((IData)(vlSelf->wasmetal_core__DOT___057381_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057380_))));
    vlSelf->__VdfgTmp_h4fe8c7bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___067094_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011425_)))))))));
    vlSelf->wasmetal_core__DOT___011679_ = (1U & (IData)(
                                                         (0xff110f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x330f0f0fff55ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056599_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056600_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011426_)))))))));
    vlSelf->wasmetal_core__DOT___056605_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                               ? 
                                                              (0xf0f000eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))
                                                               : 
                                                              (2U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011295_))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                ? 
                                                               (0xf0f000eeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc7461e30__0)))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011427_)))))))));
    vlSelf->wasmetal_core__DOT___011556_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011550_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7461e30__0))));
    vlSelf->__VdfgTmp_hd6248a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011656_));
    vlSelf->wasmetal_core__DOT___066990_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011130_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->__VdfgTmp_ha73aa920__0 = (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___065632_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac971038__0))));
    vlSelf->wasmetal_core__DOT___056482_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xffff4444fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011081_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011080_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->wasmetal_core__DOT___011025_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___012388_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___013114_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013035_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4aee2d94__0))));
    vlSelf->wasmetal_core__DOT___066912_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057663_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057664_)))))));
    vlSelf->__VdfgTmp_h4d745f43__0 = (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___013187_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057664_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057663_)))))))));
    vlSelf->__VdfgTmp_ha052db73__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057627_));
    vlSelf->wasmetal_core__DOT___012255_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))));
    vlSelf->wasmetal_core__DOT___068166_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065822_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___011678_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056668_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x30303000aa0000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056598_))))))))))))));
    vlSelf->wasmetal_core__DOT___066295_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf218f314__0))))));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057759_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128097___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028643_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028642_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028641_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028640_)))) 
           ^ (((IData)(wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128097___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028606_)))));
    vlSelf->wasmetal_core__DOT___028610_ = ((IData)(vlSelf->wasmetal_core__DOT___028643_)
                                             ? (IData)(wasmetal_core__DOT___128097___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003706_));
    vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029055_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128132___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT____Vcellout___128124___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028955_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028954_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028953_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028952_)))) 
           ^ (((IData)(wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128124___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028918_)))));
    vlSelf->wasmetal_core__DOT___028922_ = ((IData)(vlSelf->wasmetal_core__DOT___028955_)
                                             ? (IData)(wasmetal_core__DOT___128124___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d));
    vlSelf->wasmetal_core__DOT___128438___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001612_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001612_)
            : (IData)(vlSelf->wasmetal_core__DOT___032264_));
    vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028746_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128106___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026668_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128088___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___070694_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070693_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070692_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054344_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027138_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127937___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b14__05d));
    vlSelf->wasmetal_core__DOT___045493_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071350_))))))));
    vlSelf->wasmetal_core__DOT___045517_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071352_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071351_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071350_)))))))));
    vlSelf->wasmetal_core__DOT___045289_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071413_))))))));
    vlSelf->wasmetal_core__DOT___045313_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071415_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071414_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071413_)))))))));
    vlSelf->wasmetal_core__DOT___127869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026565_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026498_)
            : (IData)(vlSelf->wasmetal_core__DOT___001525_));
    vlSelf->wasmetal_core__DOT___070797_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)))))))))));
    vlSelf->wasmetal_core__DOT___070796_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026938_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127920___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_he974eeb2__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128070___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->__VdfgTmp_h6e8006f3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001580_));
    vlSelf->__VdfgTmp_h25861896__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001568_));
    vlSelf->__VdfgTmp_hd8f0618c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001536_));
    vlSelf->__VdfgTmp_hb05848c8__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001524_));
    vlSelf->wasmetal_core__DOT___040019_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___040018_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d)))))))));
    vlSelf->wasmetal_core__DOT___040017_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___040016_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128665___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___128666___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001612_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034514_));
    vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030094_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128233___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030222_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128247___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___063144_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063150_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063156_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128060___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063162_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128060___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128078___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128061___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028288_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028254_)
            : (IData)(vlSelf->wasmetal_core__DOT___028223_));
    vlSelf->wasmetal_core__DOT____Vcellout___127969___O 
        = (((0xeU & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O)) 
            | (IData)(vlSelf->wasmetal_core__DOT___027473_)) 
           ^ (((IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127969___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027436_)))));
    vlSelf->wasmetal_core__DOT___027466_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127969___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027336_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027270_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b12__05d));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013683_ = (1U & ((~ 
                                                   (4U 
                                                    >> 
                                                    ((2U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                         >> 1U)) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___002193_)))) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127462___O) 
                                                                     << 1U)) 
                                                                 | ((8U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013635_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (0xeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))))))))));
    vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022741_));
    vlSelf->wasmetal_core__DOT____Vcellout___127625___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024031_)))));
    vlSelf->wasmetal_core__DOT___024058_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127609___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023904_)))));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127488___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022948_)))));
    vlSelf->wasmetal_core__DOT___022952_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)
                                             : (IData)(wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022797_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127480___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022885_)))));
    vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001647_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128650___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128114___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028848_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028847_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028877_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028876_)))) 
           ^ (((IData)(wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128114___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028843_)))));
    vlSelf->wasmetal_core__DOT___028814_ = ((IData)(vlSelf->wasmetal_core__DOT___028848_)
                                             ? (IData)(wasmetal_core__DOT___128114___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->wasmetal_core__DOT___028852_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001580_))));
    vlSelf->wasmetal_core__DOT___028851_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001568_))));
    vlSelf->wasmetal_core__DOT___028850_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___028849_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128079___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001524_))));
    vlSelf->wasmetal_core__DOT___128080___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028468_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028434_)
            : (IData)(vlSelf->wasmetal_core__DOT___004004_));
    vlSelf->__VdfgTmp_h45f0a758__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134172___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> (IData)(vlSelf->__VdfgTmp_hca11f007__0))));
    vlSelf->__VdfgTmp_h1ffb08a2__0 = ((4U & ((1U >> (IData)(vlSelf->__VdfgTmp_h1065bf0b__0)) 
                                             << 2U)) 
                                      | ((2U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hca11f007__0)) 
                                                << 1U)) 
                                         | (1U & (0x2bU 
                                                  >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)))));
    vlSelf->__VdfgTmp_h5ffdcb06__0 = ((4U & ((0x69U 
                                              >> (IData)(vlSelf->__VdfgTmp_h868ae0cf__0)) 
                                             << 2U)) 
                                      | ((2U & ((0x69U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h19390f5d__0)) 
                                                << 1U)) 
                                         | (1U & (0x17U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->__VdfgTmp_h9a02691e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h9cfb7302__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h0341114f__0)))));
    vlSelf->wasmetal_core__DOT___068814_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051121_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050064_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff00ff00ff1fffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a8eb480__0))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050040_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051119_)))))))));
    vlSelf->wasmetal_core__DOT___068617_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049823_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xef00efefefefULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049820_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0xf0f0f77U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc1e7aa45__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049821_)))))))));
    vlSelf->wasmetal_core__DOT___068199_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051662_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x7f7700003f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050868_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050867_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051660_)))))))));
    vlSelf->wasmetal_core__DOT___069202_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051621_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbf00bfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___051618_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051617_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb829d41d__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051619_)))))))));
    vlSelf->wasmetal_core__DOT___068666_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049904_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049901_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049900_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049899_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049902_)))))))));
    vlSelf->wasmetal_core__DOT___069058_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051529_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051526_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051525_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051524_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051527_)))))))));
    vlSelf->wasmetal_core__DOT___069252_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051640_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b63__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051637_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                (4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 2U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((0x10U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___048676_) 
                                                                                << 2U)) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051638_)))))))));
    vlSelf->wasmetal_core__DOT___068566_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049771_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049767_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b49__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049766_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049769_)))))))));
    vlSelf->wasmetal_core__DOT___068960_ = (1U & (IData)(
                                                         (0xff4f4f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051357_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xbfbb3f333f33ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009522_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051354_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051353_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051352_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051355_)))))))));
    vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028092_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128044___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0xaU)));
    vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026458_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127853___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d));
    vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128479___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128144___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031056_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128327___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___036632_ = (1U & (IData)(
                                                         (0x188e7118e7718ee7ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))))));
}
