#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__34(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__34\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___017577_;
    wasmetal_core__DOT___017577_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017805_;
    wasmetal_core__DOT___017805_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022571_;
    wasmetal_core__DOT___022571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022575_;
    wasmetal_core__DOT___022575_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022579_;
    wasmetal_core__DOT___022579_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022584_;
    wasmetal_core__DOT___022584_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___022592_;
    wasmetal_core__DOT___022592_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023314_;
    wasmetal_core__DOT___023314_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023318_;
    wasmetal_core__DOT___023318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023322_;
    wasmetal_core__DOT___023322_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023327_;
    wasmetal_core__DOT___023327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023331_;
    wasmetal_core__DOT___023331_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023336_;
    wasmetal_core__DOT___023336_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023340_;
    wasmetal_core__DOT___023340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023344_;
    wasmetal_core__DOT___023344_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023349_;
    wasmetal_core__DOT___023349_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023353_;
    wasmetal_core__DOT___023353_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023358_;
    wasmetal_core__DOT___023358_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___023364_;
    wasmetal_core__DOT___023364_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036068_;
    wasmetal_core__DOT___036068_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036854_;
    wasmetal_core__DOT___036854_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036861_;
    wasmetal_core__DOT___036861_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036862_;
    wasmetal_core__DOT___036862_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036867_;
    wasmetal_core__DOT___036867_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036908_;
    wasmetal_core__DOT___036908_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036914_;
    wasmetal_core__DOT___036914_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036915_;
    wasmetal_core__DOT___036915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___037013_;
    wasmetal_core__DOT___037013_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058165_;
    wasmetal_core__DOT___058165_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058936_;
    wasmetal_core__DOT___058936_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058968_;
    wasmetal_core__DOT___058968_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058972_;
    wasmetal_core__DOT___058972_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058983_;
    wasmetal_core__DOT___058983_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059018_;
    wasmetal_core__DOT___059018_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059056_;
    wasmetal_core__DOT___059056_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059226_;
    wasmetal_core__DOT___059226_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059230_;
    wasmetal_core__DOT___059230_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___059232_;
    wasmetal_core__DOT___059232_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060497_;
    wasmetal_core__DOT___060497_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060511_;
    wasmetal_core__DOT___060511_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060525_;
    wasmetal_core__DOT___060525_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___060597_;
    wasmetal_core__DOT___060597_ = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d;
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry = 0;
    CData/*0:0*/ wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d;
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127444___O;
    wasmetal_core__DOT____Vcellout___127444___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127445___O;
    wasmetal_core__DOT____Vcellout___127445___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127446___O;
    wasmetal_core__DOT____Vcellout___127446___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127447___O;
    wasmetal_core__DOT____Vcellout___127447___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127448___O;
    wasmetal_core__DOT____Vcellout___127448___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127449___O;
    wasmetal_core__DOT____Vcellout___127449___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127536___O;
    wasmetal_core__DOT____Vcellout___127536___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127537___O;
    wasmetal_core__DOT____Vcellout___127537___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127538___O;
    wasmetal_core__DOT____Vcellout___127538___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127539___O;
    wasmetal_core__DOT____Vcellout___127539___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127542___O;
    wasmetal_core__DOT____Vcellout___127542___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127544___O;
    wasmetal_core__DOT____Vcellout___127544___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127546___O;
    wasmetal_core__DOT____Vcellout___127546___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127547___O;
    wasmetal_core__DOT____Vcellout___127547___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127548___O;
    wasmetal_core__DOT____Vcellout___127548___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134170___O;
    wasmetal_core__DOT____Vcellout___134170___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134171___O;
    wasmetal_core__DOT____Vcellout___134171___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___134175___O;
    wasmetal_core__DOT____Vcellout___134175___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h4ac2372d__0;
    __VdfgTmp_h4ac2372d__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7a7f7b8b__0;
    __VdfgTmp_h7a7f7b8b__0 = 0;
    CData/*1:0*/ __VdfgTmp_h2e6695c3__0;
    __VdfgTmp_h2e6695c3__0 = 0;
    CData/*2:0*/ __VdfgTmp_hc2887b39__0;
    __VdfgTmp_hc2887b39__0 = 0;
    CData/*1:0*/ __VdfgTmp_h0e008e26__0;
    __VdfgTmp_h0e008e26__0 = 0;
    CData/*4:0*/ __VdfgTmp_h3eda33ce__0;
    __VdfgTmp_h3eda33ce__0 = 0;
    // Body
    vlSelf->__VdfgTmp_h5b356604__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h155aafca__0))))));
    wasmetal_core__DOT___059226_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015094_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h52595424__0)))))))))));
    vlSelf->__VdfgTmp_h66dab408__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2549a40a__0))))));
    vlSelf->__VdfgTmp_h943c9679__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___014613_)
                                                     ? (IData)(
                                                               (0xccccf0d8f0f0cce4ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0)))
                                                     : (IData)(
                                                               (0xf0f0cce4ccccf0d8ULL 
                                                                >> (IData)(vlSelf->__VdfgTmp_h03fdecb9__0))))));
    vlSelf->wasmetal_core__DOT___059234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014791_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014792_))));
    vlSelf->wasmetal_core__DOT___014590_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8020f35b__0)))));
    vlSelf->wasmetal_core__DOT___058644_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5b0d2f75__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014745_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014746_))));
    vlSelf->wasmetal_core__DOT___058203_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h023f0a12__0)))));
    wasmetal_core__DOT___059232_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___005667_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014602_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___014601_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014602_))));
    vlSelf->__VdfgTmp_hb0ec899f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058107_));
    vlSelf->__VdfgTmp_hfd58f84f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_hc4384494__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))));
    vlSelf->__VdfgTmp_h4352298b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_h730b9e6e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058106_));
    vlSelf->__VdfgTmp_h8cb25dc3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    vlSelf->wasmetal_core__DOT____Vcellout___128772___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035710_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035709_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035708_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035707_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035694_)))));
    vlSelf->wasmetal_core__DOT___035698_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035710_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128772___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___035710_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127535___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015094_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015094_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023345_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127535___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058619_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3c2f1975__0)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127443___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014712_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022588_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127443___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___015439_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcd6303e8__0)))));
    wasmetal_core__DOT___059230_ = (1U & (0x10000U 
                                          >> (((IData)(wasmetal_core__DOT___059226_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT___015540_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66dab408__0)))));
    vlSelf->wasmetal_core__DOT___059235_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___059232_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058561_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___007129_)))))))));
    vlSelf->wasmetal_core__DOT___060217_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005666_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0fffff0bbbb8888ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___042770_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006117_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___060214_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)))))));
    vlSelf->wasmetal_core__DOT___017801_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005670_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___005669_)
                                                    ? 
                                                   (8U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0))
                                                    : 
                                                   (0x7f7f7f00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___005668_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005667_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___005666_)))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b1__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b4__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b5__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b6__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b7__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134180___O) 
                                                      >> 2U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128772___O) 
                                                        >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035711_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___035698_)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035711_))));
    vlSelf->wasmetal_core__DOT___058562_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___023345_));
    vlSelf->wasmetal_core__DOT___058946_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___058940_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___058951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127443___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___022588_));
    vlSelf->wasmetal_core__DOT___059233_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059231_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___059230_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b13__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)))))))))));
    vlSelf->wasmetal_core__DOT___060219_ = (1U & (IData)(
                                                         (0xff4f4444ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060218_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060217_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf530U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___060214_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h11374272__0))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_condition__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005670_)))))))));
    vlSelf->__VdfgTmp_hac20e9d0__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0));
    vlSelf->__VdfgTmp_h2e648f5f__0 = ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 2U)) 
                                      | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0));
    vlSelf->__VdfgTmp_hd141341a__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    __VdfgTmp_h2e6695c3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d));
    vlSelf->wasmetal_core__DOT___058172_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d))))));
    vlSelf->__VdfgTmp_h66d515d6__0 = ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058174_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_hd20fe4de__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)));
    vlSelf->__VdfgTmp_hcbc91db2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035712_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035712_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___060654_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019023_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___060219_))));
    vlSelf->wasmetal_core__DOT___060220_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016506_))));
    vlSelf->__VdfgTmp_h372a4d3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hd141341a__0));
    vlSelf->wasmetal_core__DOT___058188_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058190_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(__VdfgTmp_h2e6695c3__0)))))));
    vlSelf->wasmetal_core__DOT___058191_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h7751e274__0 = ((2U & ((1U >> (IData)(__VdfgTmp_h2e6695c3__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058163_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h2e6695c3__0))));
    vlSelf->wasmetal_core__DOT___058183_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058174_)))));
    vlSelf->wasmetal_core__DOT___058175_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))));
    vlSelf->__VdfgTmp_h639f1e1d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d));
    vlSelf->wasmetal_core__DOT___058177_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))))));
    vlSelf->wasmetal_core__DOT___058161_ = (1U & (0x7f0f0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((0xe0U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058171_ = (1U & (0xb0U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h66d515d6__0))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128825___S 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)));
    vlSelf->wasmetal_core__DOT___058184_ = (1U & (0x7f0fU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___058097_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___035702_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__)
                  : (~ (IData)(vlSelf->wasmetal_core__DOT___035702_))));
    vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___060222_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060220_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059206_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005711_))))));
    vlSelf->__VdfgTmp_h63b44d2e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058191_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))));
    vlSelf->wasmetal_core__DOT___058189_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7751e274__0))))));
    vlSelf->wasmetal_core__DOT___058164_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058163_))));
    __VdfgTmp_hc2887b39__0 = (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0));
    vlSelf->wasmetal_core__DOT___058176_ = (1U & (0xbU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h639f1e1d__0))));
    vlSelf->wasmetal_core__DOT___036073_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b12__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                                 ^ (IData)(vlSelf->wasmetal_core__DOT___036940_)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (~ 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___035703_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__)
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___035703_)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128773___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___035703_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___035702_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___035712_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035711_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128773___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035698_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127540___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b16__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023345_)))));
    wasmetal_core__DOT___023364_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127540___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127444___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022588_)))));
    wasmetal_core__DOT___022592_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___127444___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hf715e513__0 = (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058175_));
    vlSelf->wasmetal_core__DOT___036072_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b11__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b10__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                      >> 1U)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 2U))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b9__05d) 
                                                << 2U) 
                                               | ((2U 
                                                   & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O)) 
                                                  | (1U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O) 
                                                        >> 1U))))))));
    vlSelf->wasmetal_core__DOT___036071_ = (1U & (0x33550f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005670_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005669_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_exponent__05b8__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134181___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128773___O))))))));
    vlSelf->__VdfgTmp_h6ecbbe50__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hce3e66a7__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                               >> 2U)));
    vlSelf->__VdfgTmp_h7af47ace__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b19__05d));
    wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d) 
           & (IData)(wasmetal_core__DOT___023364_));
    vlSelf->wasmetal_core__DOT___058956_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___058964_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127444___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d)))));
    wasmetal_core__DOT___058968_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))));
    wasmetal_core__DOT___058983_ = (1U & (0x35U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(wasmetal_core__DOT____Vcellout___127444___O) 
                                                >> 2U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))));
    wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___022592_));
    vlSelf->wasmetal_core__DOT___015429_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d))));
    wasmetal_core__DOT___058165_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___036071_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d));
    __VdfgTmp_h7a7f7b8b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)));
    wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___058155_ = (1U & (0xbfff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___036071_)))))));
    vlSelf->wasmetal_core__DOT___015427_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x1000000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(wasmetal_core__DOT___058165_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___036072_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058097_))));
    wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
           & (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___016659_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015569_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xf8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___017059_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015521_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___015511_ = (1U & (IData)(
                                                         (0x40000000ffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_h7a7f7b8b__0)))))));
    vlSelf->wasmetal_core__DOT___058156_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_h7a7f7b8b__0)))));
    wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
           & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
           & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___015434_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015427_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058098_)))));
    vlSelf->wasmetal_core__DOT___015204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015427_))));
    wasmetal_core__DOT___036068_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036072_)) 
                                          | (IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128815___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036072_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b9__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036071_)))) 
           ^ (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128815___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036071_)) 
                                          << 1U)))));
    vlSelf->__VdfgTmp_ha1ddff2b__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058099_));
    vlSelf->wasmetal_core__DOT___015584_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058176_)))));
    vlSelf->wasmetal_core__DOT___015559_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058184_)))));
    vlSelf->wasmetal_core__DOT___015579_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf715e513__0)))));
    vlSelf->wasmetal_core__DOT___015565_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015564_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xf8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h66d515d6__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___017105_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058171_)))));
    vlSelf->wasmetal_core__DOT___015443_ = (1U & (IData)(
                                                         (0x7f000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058172_)))))))));
    vlSelf->wasmetal_core__DOT___015554_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___017072_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058171_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058172_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015589_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058095_)))))));
    vlSelf->wasmetal_core__DOT___015542_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))));
    vlSelf->wasmetal_core__DOT___015526_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7751e274__0))))))));
    vlSelf->wasmetal_core__DOT___015534_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058188_)))));
    vlSelf->wasmetal_core__DOT___015533_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058190_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (4U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h7751e274__0)))))))));
    vlSelf->wasmetal_core__DOT___015532_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h63b44d2e__0)))));
    vlSelf->wasmetal_core__DOT___015496_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0xe0U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hd141341a__0))))));
    vlSelf->wasmetal_core__DOT___016680_ = (1U & (IData)(
                                                         (0xf4ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    vlSelf->wasmetal_core__DOT___016668_ = (1U & (IData)(
                                                         (0xf8ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___015491_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058099_))))));
    vlSelf->wasmetal_core__DOT___016632_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058096_))))));
    vlSelf->wasmetal_core__DOT___015435_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058163_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (1U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_h124450b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hc2843286__0));
    vlSelf->wasmetal_core__DOT___015454_ = (1U & (IData)(
                                                         (0xef0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058174_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0))))))));
    vlSelf->__VdfgTmp_hc4af22e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___058176_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___058183_)));
    vlSelf->__VdfgTmp_hb78750ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058177_));
    vlSelf->__VdfgTmp_hb7a356d8__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058189_));
    vlSelf->wasmetal_core__DOT___016840_ = (1U & (IData)(
                                                         (0xbf000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0)))))));
    vlSelf->wasmetal_core__DOT___016828_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xe0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->wasmetal_core__DOT___016805_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058161_)))));
    vlSelf->wasmetal_core__DOT___015516_ = (1U & (IData)(
                                                         (0x4fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h187f5418__0))))))));
    vlSelf->wasmetal_core__DOT___015506_ = (1U & (IData)(
                                                         (0x8fff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xe0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h2e648f5f__0)))))));
    vlSelf->wasmetal_core__DOT___015501_ = (1U & (IData)(
                                                         (0xef000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0)))))));
    vlSelf->wasmetal_core__DOT___016706_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___015486_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xf7f00000U 
                                                            >> 
                                                            ((0x10U 
                                                              & ((8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))))))));
    vlSelf->wasmetal_core__DOT___016612_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058164_)))));
    vlSelf->wasmetal_core__DOT___016644_ = (1U & (0x7f0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2ddde49a__0))))));
    vlSelf->wasmetal_core__DOT___015266_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x8fff000000000000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((1U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015262_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xefff000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b2__05d) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0)))))))))));
    vlSelf->wasmetal_core__DOT___015451_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)))))));
    vlSelf->wasmetal_core__DOT___015522_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xbfffU 
                                                            >> 
                                                            ((0x10U 
                                                              & ((1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                 << 4U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                                 << 3U) 
                                                                | (IData)(__VdfgTmp_hc2887b39__0)))))))));
    vlSelf->wasmetal_core__DOT___015450_ = (1U & (IData)(
                                                         (0xbf0000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(__VdfgTmp_hc2887b39__0)))))));
    vlSelf->__VdfgTmp_h62a95291__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xbfff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hd20fe4de__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h372a4d3e__0))))));
    vlSelf->__VdfgTmp_h5cb76656__0 = (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                       << 1U) | (1U 
                                                 & (0xefff0000U 
                                                    >> 
                                                    ((0x10U 
                                                      & ((8U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                         << 4U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058098_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8e2d1d0c__0))))));
    vlSelf->wasmetal_core__DOT___015481_ = (1U & (IData)(
                                                         (0xfe000000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4352298b__0)))))));
    vlSelf->wasmetal_core__DOT___016578_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058095_))))));
    vlSelf->wasmetal_core__DOT___016564_ = (1U & (0x10ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058164_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf4c0ee7d__0))))));
    vlSelf->wasmetal_core__DOT___015263_ = (1U & (IData)(
                                                         (0x40ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058156_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hcbc91db2__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb1419641__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
             << 3U) | ((4U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                              << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023364_)))));
    wasmetal_core__DOT___023314_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d) 
                                    & (IData)(wasmetal_core__DOT___127541___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127445___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022592_)))));
    wasmetal_core__DOT___022571_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                    & (IData)(wasmetal_core__DOT___127445___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                 | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___014593_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014589_ = (1U & (0xffffbf00U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058097_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT___014944_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128815___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b7__05d))));
    vlSelf->wasmetal_core__DOT___015574_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc4af22e3__0))));
    vlSelf->wasmetal_core__DOT___015549_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb78750ce__0))));
    vlSelf->wasmetal_core__DOT___015442_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb7a356d8__0))));
    vlSelf->wasmetal_core__DOT___015265_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015451_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015522_))));
    vlSelf->wasmetal_core__DOT___015395_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015454_))));
    vlSelf->wasmetal_core__DOT___015531_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h62a95291__0))));
    vlSelf->wasmetal_core__DOT___016760_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058155_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5cb76656__0))));
    vlSelf->wasmetal_core__DOT___058167_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->wasmetal_core__DOT___015202_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___016578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016564_))));
    vlSelf->__VdfgTmp_hcf32a2f0__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b20__05d));
    vlSelf->wasmetal_core__DOT___058571_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b21__05d)))));
    vlSelf->__VdfgTmp_h5c254f34__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hc1e22c7f__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
           & (IData)(wasmetal_core__DOT___023314_));
    wasmetal_core__DOT___058972_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127445___O))))));
    vlSelf->wasmetal_core__DOT___059014_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059018_ = (1U & (0x53U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                               << 1U) 
                                              | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                    >> 2U))))));
    vlSelf->wasmetal_core__DOT___059022_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127445___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___022571_));
    vlSelf->wasmetal_core__DOT____Vcellout___128816___O 
        = ((3U & (- (IData)((IData)(vlSelf->wasmetal_core__DOT___036073_)))) 
           ^ (((4U & (((~ (IData)(vlSelf->wasmetal_core__DOT___036073_)) 
                       | (IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__)) 
                      << 2U)) | ((IData)(wasmetal_core__DOT___128816___DOT__CO__BRA__0__KET__) 
                                 << 1U)) | (IData)(wasmetal_core__DOT___036068_)));
    vlSelf->wasmetal_core__DOT___058104_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014944_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___058100_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b6__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014944_)))));
    wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___014845_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058096_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014917_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h6a8cbae2__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014886_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058107_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014881_ = (1U & (0xef0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h187f5418__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT___014901_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8cb25dc3__0))))));
    vlSelf->wasmetal_core__DOT___014891_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h786a2bba__0))))));
    vlSelf->wasmetal_core__DOT___014850_ = (1U & (0x40ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc4384494__0))))));
    vlSelf->wasmetal_core__DOT___014860_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0))))));
    vlSelf->wasmetal_core__DOT___014896_ = (1U & (0x80ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hac20e9d0__0)))));
    vlSelf->__VdfgTmp_h89d6ed4e__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058099_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d))));
    vlSelf->__VdfgTmp_h98bb6818__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb0ec899f__0))));
    vlSelf->__VdfgTmp_hd1e881b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h283c0448__0))));
    vlSelf->wasmetal_core__DOT___058115_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058100_))));
    __VdfgTmp_h4ac2372d__0 = (((IData)(vlSelf->wasmetal_core__DOT___058100_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b4__05d));
    wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__ 
        = ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
           & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
           & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___014987_ = (1U & (0xbf0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h89d6ed4e__0))));
    vlSelf->wasmetal_core__DOT___014719_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___058108_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h786a2bba__0)))));
    vlSelf->wasmetal_core__DOT___014720_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9949a0e3__0)))));
    vlSelf->wasmetal_core__DOT___014722_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(__VdfgTmp_h4ac2372d__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc4384494__0)))));
    vlSelf->wasmetal_core__DOT___014982_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058104_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h4ac2372d__0))));
    wasmetal_core__DOT____Vcellout___127542___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023314_)))));
    wasmetal_core__DOT___023318_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                    & (IData)(wasmetal_core__DOT___127542___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127446___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xeU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022571_)))));
    wasmetal_core__DOT___022575_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127446___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___014837_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h283c0448__0)))));
    vlSelf->wasmetal_core__DOT___014873_ = (1U & (0xef00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h730b9e6e__0)))));
    vlSelf->wasmetal_core__DOT___014927_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014982_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058115_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eexponent__05b3__05d)))));
    vlSelf->__VdfgTmp_hd9e83ce6__0 = ((4U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b24__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___015076_))) 
                                             << 2U)) 
                                      | ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                << 1U)) 
                                         | (IData)(vlSelf->wasmetal_core__DOT___015076_)));
    vlSelf->__VdfgTmp_hb3aa193a__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h52595424__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_h842e8acf__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_hb48763c1__0)) 
                                             << 1U)) 
                                      | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___058574_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b27__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127542___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
           & (IData)(wasmetal_core__DOT___023318_));
    vlSelf->wasmetal_core__DOT___059027_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127446___O))))));
    vlSelf->wasmetal_core__DOT___058992_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___058996_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___059005_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127446___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___022575_));
    wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
           & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
           & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127543___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023318_)))));
    wasmetal_core__DOT___023322_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                    & (IData)(wasmetal_core__DOT___127543___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127447___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022575_)))));
    wasmetal_core__DOT___022579_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                    & (IData)(wasmetal_core__DOT___127447___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058575_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b28__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O)))))));
    vlSelf->wasmetal_core__DOT___058584_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b29__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                               >> 1U)))))));
    wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
           & (IData)(wasmetal_core__DOT___023322_));
    vlSelf->wasmetal_core__DOT___059000_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127447___O))))));
    vlSelf->wasmetal_core__DOT___059035_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___059040_ = (1U & (IData)(
                                                         (0xff00ff1111f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058396_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058394_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058395_)))))))));
    vlSelf->wasmetal_core__DOT___059044_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127447___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___022579_));
    wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
           & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
           & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127544___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023322_)))));
    wasmetal_core__DOT___023327_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d) 
                                    & (IData)(wasmetal_core__DOT___127544___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT____Vcellout___127448___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___022579_)))));
    wasmetal_core__DOT___022584_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                    & (IData)(wasmetal_core__DOT___127448___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hca8853c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b32__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127544___O)));
    vlSelf->wasmetal_core__DOT___058589_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127544___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b33__05d))))));
    vlSelf->wasmetal_core__DOT___058590_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b34__05d))))));
    vlSelf->wasmetal_core__DOT___058593_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127544___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b35__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d) 
           & (IData)(wasmetal_core__DOT___023327_));
    vlSelf->__VdfgTmp_h0da91de8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(wasmetal_core__DOT____Vcellout___127448___O)));
    vlSelf->wasmetal_core__DOT___059059_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                            >> 1U))))));
    wasmetal_core__DOT___059056_ = (1U & (IData)((0xff00ff1111f0f0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127448___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058419_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058417_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___058418_)))))))));
    wasmetal_core__DOT____Vcellout___127449___O = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                   ^ 
                                                   ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                      & (IData)(wasmetal_core__DOT___022584_)) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___022584_)));
    wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___036915_ = (1U & (0x78U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                            << 2U) 
                                           | ((2U & (IData)(wasmetal_core__DOT____Vcellout___127449___O)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))));
    wasmetal_core__DOT___036914_ = (1U & (0x3c5aU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127449___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d))))));
    wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
           & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036914_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127545___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___023327_)))));
    wasmetal_core__DOT___023331_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d) 
                                    & (IData)(wasmetal_core__DOT___127545___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036915_) ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d));
    vlSelf->wasmetal_core__DOT___058594_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b36__05d))))));
    vlSelf->wasmetal_core__DOT___058597_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b38__05d))))));
    vlSelf->wasmetal_core__DOT___058598_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b39__05d))))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
           & (IData)(wasmetal_core__DOT___023331_));
    wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134174___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036915_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036914_)))) 
           ^ (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
           & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O))));
    wasmetal_core__DOT___036908_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134174___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT____Vcellout___127546___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((~ (IData)(vlSelf->wasmetal_core__DOT___014712_)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023331_)))));
    wasmetal_core__DOT___023336_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d) 
                                    & (IData)(wasmetal_core__DOT___127546___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036908_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    wasmetal_core__DOT____Vcellout___134175___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                                                        ? (IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__)
                                                        : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___134175___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___036908_)));
    vlSelf->__VdfgTmp_hc42a79ae__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d));
    vlSelf->wasmetal_core__DOT___058605_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(wasmetal_core__DOT____Vcellout___127546___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014712_)))));
    vlSelf->__VdfgTmp_hfa9cb9e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | ((2U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                            >> 1U)) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b42__05d))))));
    vlSelf->wasmetal_core__DOT___058613_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127546___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b43__05d))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d) 
           & (IData)(wasmetal_core__DOT___023336_));
    vlSelf->wasmetal_core__DOT____Vcellout___134188___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                          << 1U)))));
    wasmetal_core__DOT___037013_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134188___DOT__CO__BRA__2__KET__)));
    wasmetal_core__DOT___017805_ = (1U & (7U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                               >> 2U)) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___127468___O 
        = (((8U & ((~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 1U)))))) 
           ^ (1U | ((((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                          >> 3U)) & (IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__)) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127468___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    wasmetal_core__DOT___058936_ = (1U & (1U >> ((4U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                     << 2U)) 
                                                 | (3U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O) 
                                                       >> 2U)))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                 | (IData)(wasmetal_core__DOT___037013_)));
    vlSelf->wasmetal_core__DOT___059236_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (2U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 1U)) 
                                                   | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d))));
    vlSelf->wasmetal_core__DOT___017493_ = (1U & (IData)(
                                                         (0xfeff000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                  << 1U)) 
                                                              | (((IData)(wasmetal_core__DOT___058936_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(wasmetal_core__DOT____Vcellout___134175___O)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134174___O)) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                                                             >> 1U))))))))));
    wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
           & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__)));
    __VdfgTmp_h3eda33ce__0 = (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                               << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                          << 3U) | 
                                         ((4U & ((8U 
                                                  >> 
                                                  (2U 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                 << 2U)) 
                                          | (((IData)(wasmetal_core__DOT___017805_) 
                                              << 1U) 
                                             | (IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___017538_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017495_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> 
                                                              (2U 
                                                               | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017493_))))));
    vlSelf->__VdfgTmp_h1a828198__0 = (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (2U 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))));
    wasmetal_core__DOT____Vcellout___127547___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023336_)))));
    wasmetal_core__DOT___023340_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                    & (IData)(wasmetal_core__DOT___127547___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134189___O 
        = ((((IData)(wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eout__05b30__05d) 
             << 3U) | (((IData)(wasmetal_core__DOT___017805_) 
                        << 2U) | ((2U & ((~ ((IData)(wasmetal_core__DOT____Vcellout___134175___O) 
                                             >> 1U)) 
                                         << 1U)) | 
                                  (1U & (~ (IData)(wasmetal_core__DOT____Vcellout___134175___O)))))) 
           ^ ((8U & (((~ (IData)(wasmetal_core__DOT___017805_)) 
                      | (IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___134189___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(wasmetal_core__DOT___037013_)))));
    vlSelf->wasmetal_core__DOT___059065_ = (1U & ((1U 
                                                   & (4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___036825_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02eexpOut__05b7__05d))))
                                                   ? (IData)(
                                                             (0xfff4ffff00040000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017806_) 
                                                                << 5U) 
                                                               | (IData)(__VdfgTmp_h3eda33ce__0))))
                                                   : 
                                                  (0x40000U 
                                                   >> (IData)(__VdfgTmp_h3eda33ce__0))));
    vlSelf->wasmetal_core__DOT___060064_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134188___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017534_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058956_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017549_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058964_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017562_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058968_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___059238_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017805_)))));
    wasmetal_core__DOT___017577_ = (1U & (0x1000000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                  << 3U) 
                                                 | (((IData)(wasmetal_core__DOT___058972_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017664_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059014_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017677_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___059018_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017702_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059027_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017611_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058992_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017624_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058996_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017729_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059040_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))));
    vlSelf->wasmetal_core__DOT___017536_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1a828198__0))));
    vlSelf->wasmetal_core__DOT___058612_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b44__05d))))));
    vlSelf->wasmetal_core__DOT___058642_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127547___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b45__05d))))));
    vlSelf->wasmetal_core__DOT___058646_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b46__05d))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d) 
           & (IData)(wasmetal_core__DOT___023340_));
    vlSelf->wasmetal_core__DOT___060196_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059236_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h1a828198__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134189___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___059550_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058968_)))));
    vlSelf->wasmetal_core__DOT___059588_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058983_)))));
    vlSelf->wasmetal_core__DOT___059980_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___059056_))));
    vlSelf->wasmetal_core__DOT___059346_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058946_)))));
    vlSelf->wasmetal_core__DOT___018176_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058940_)))));
    vlSelf->wasmetal_core__DOT___059660_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___059018_)))));
    vlSelf->wasmetal_core__DOT___059614_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___059238_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058972_))));
    vlSelf->wasmetal_core__DOT___058950_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058947_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058946_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058945_ = (1U & (0x8800f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058941_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058940_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___058987_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058984_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___058983_)))))));
    vlSelf->wasmetal_core__DOT___058975_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___017538_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___017579_)
                                                      ? (IData)(
                                                                (0xff00ff00fffbfff0ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128850___O) 
                                                                         << 4U)) 
                                                                     | (((IData)(wasmetal_core__DOT___017577_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h5bb2fc7d__0))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(wasmetal_core__DOT___017577_)))));
    vlSelf->wasmetal_core__DOT___059009_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059006_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059005_)))))));
    vlSelf->wasmetal_core__DOT___059004_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059001_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059000_)))))));
    vlSelf->wasmetal_core__DOT___059053_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                        & (IData)(
                                                                  (0xa000c00000000ULL 
                                                                   >> 
                                                                   (8U 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b40__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017493_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h0da91de8__0)))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059049_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___017536_))))));
    vlSelf->wasmetal_core__DOT___059063_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059060_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___059059_)))))));
    vlSelf->wasmetal_core__DOT___018073_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017536_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0x1000000U 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017494_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___059056_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1a828198__0))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___059057_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018504_)))))));
    wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
           & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127548___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023340_)))));
    wasmetal_core__DOT___023344_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                    & (IData)(wasmetal_core__DOT___127548___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058649_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b48__05d))))));
    vlSelf->wasmetal_core__DOT___058656_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b49__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 1U))))));
    vlSelf->__VdfgTmp_h54a2cb2f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b50__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                    >> 2U)));
    vlSelf->wasmetal_core__DOT___058660_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b51__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127548___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
           & (IData)(wasmetal_core__DOT___023344_));
    wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__ 
        = ((0xeU >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
           & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127536___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((0xeU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023344_)))));
    wasmetal_core__DOT___023349_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                    & (IData)(wasmetal_core__DOT___127536___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058661_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127536___O))))));
    vlSelf->wasmetal_core__DOT___058631_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b53__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___058632_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7bf425d4__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___058622_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127536___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
           & (IData)(wasmetal_core__DOT___023349_));
    wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
           & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127537___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b56__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023349_)))));
    wasmetal_core__DOT___023353_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                    & (IData)(wasmetal_core__DOT___127537___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___058625_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b55__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(wasmetal_core__DOT____Vcellout___127537___O)))))));
    vlSelf->__VdfgTmp_h2932eeac__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ff1111f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                 << 4U) 
                                                                | ((8U 
                                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                                       << 2U)) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hf41b4843__0))))))));
    vlSelf->wasmetal_core__DOT___058639_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b58__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                                               >> 3U)))))));
    __VdfgTmp_h0e008e26__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b57__05d) 
                               << 1U) | (1U & ((IData)(wasmetal_core__DOT____Vcellout___127537___O) 
                                               >> 2U)));
    wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
           & (IData)(wasmetal_core__DOT___023353_));
    vlSelf->wasmetal_core__DOT___060398_ = (1U & (0xa0c0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h0e008e26__0))))));
    wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
           & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127538___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___023353_)))));
    wasmetal_core__DOT___023358_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                    & (IData)(wasmetal_core__DOT___127538___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_h01fee3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                       << 1U) | (1U 
                                                 & (0x53U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b59__05d) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(wasmetal_core__DOT____Vcellout___127538___O)))))));
    vlSelf->__VdfgTmp_h192fc191__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b60__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                    >> 1U)));
    vlSelf->wasmetal_core__DOT___058664_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b61__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___058665_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b62__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127538___O) 
                                                               >> 3U)))))));
    wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
           & (IData)(wasmetal_core__DOT___023358_));
    wasmetal_core__DOT____Vcellout___127539___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                   ^ 
                                                   (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                                       & (IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__)) 
                                                      << 2U) 
                                                     | ((IData)(wasmetal_core__DOT___127539___DOT__CO__BRA__0__KET__) 
                                                        << 1U)) 
                                                    | (IData)(wasmetal_core__DOT___023358_)));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d 
        = (1U & (8U >> ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                               >> 1U)) | (IData)(vlSelf->wasmetal_core__DOT___058423_))));
    wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b64__05d) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127539___O) 
                                                    >> 1U))))));
    wasmetal_core__DOT___036862_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b1__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d))));
    wasmetal_core__DOT___036861_ = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b0__05d) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry))));
    wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(wasmetal_core__DOT___036861_)) 
           & (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundCarry));
    wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036862_) ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__)
            : (IData)(wasmetal_core__DOT__fpu__02efp64__02econvert_integer__02eroundRawToOut__02egenblk2__02eroundedSig__05b54__05d));
    wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d)
            ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d));
    wasmetal_core__DOT___036854_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d)
                                     ? (IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__)
                                     : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d));
    wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d)
            ? (IData)(wasmetal_core__DOT___036854_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134166___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b3__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b2__05d) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036862_) 
                                   << 1U) | (IData)(wasmetal_core__DOT___036861_)))) 
           ^ (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(wasmetal_core__DOT___134166___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__ 
        = (IData)((0U != (3U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (6U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O))));
    wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__)));
    wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__ 
        = ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
               >> 3U)) & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134167___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___134167___DI) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)
                  ? (IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esExp__05b5__05d)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134167___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(wasmetal_core__DOT___036854_)));
    vlSelf->wasmetal_core__DOT____Vcellout___134169___O 
        = (((8U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                       >> 3U)) << 3U)) | ((4U & ((~ 
                                                  ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 2U)) 
                                                 << 2U)) 
                                          | ((2U & 
                                              ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                   >> 1U)) 
                                               << 1U)) 
                                             | (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O)))))) 
           ^ (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                          << 1U)))));
    wasmetal_core__DOT___036867_ = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                             >> 3U) 
                                            | (IData)(wasmetal_core__DOT___134169___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___023670_ = ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                                            & (IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127583___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)) 
                   << 3U)) | ((4U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                         >> 3U)) << 2U)) 
                              | ((2U & ((~ ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                            >> 2U)) 
                                        << 1U)) | (1U 
                                                   & (~ 
                                                      ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                       >> 1U)))))) 
           ^ (1U | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(wasmetal_core__DOT___127583___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ 
                                                 ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                  >> 1U)) 
                                                << 1U))))));
    vlSelf->__VdfgTmp_he997ff62__0 = (0x10U | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                << 3U) 
                                               | (2U 
                                                  & ((IData)(
                                                             (0x1000000000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> 
                                                                    (3U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                        >> 1U))) 
                                                                   << 5U)) 
                                                               | ((0x10U 
                                                                   & ((1U 
                                                                       >> 
                                                                       (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                           >> 3U))) 
                                                                      << 4U)) 
                                                                  | ((0xeU 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                         << 1U)) 
                                                                     | (1U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134166___O) 
                                                                           >> 3U))))))) 
                                                     << 1U))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                 | (IData)(wasmetal_core__DOT___036867_)));
    wasmetal_core__DOT___060497_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060511_ = (1U & (4U >> ((2U 
                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    wasmetal_core__DOT___060525_ = (1U & (4U >> ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134169___O) 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (0xff4fffU 
                                                       >> (IData)(vlSelf->__VdfgTmp_he997ff62__0))))));
    vlSelf->wasmetal_core__DOT___060308_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h54a2cb2f__0))))))));
    vlSelf->wasmetal_core__DOT___019073_ = (1U & (IData)(
                                                         (0xa000c00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xff4fffU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___059242_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                             >> 3U))))))))));
    vlSelf->__VdfgTmp_hdfb00432__0 = ((2U & ((0xff4fffU 
                                              >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___059242_));
    vlSelf->wasmetal_core__DOT___017018_ = (1U & (IData)(
                                                         (0xff4fff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((8U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___006127_))) 
                                                               << 5U)) 
                                                           | (IData)(vlSelf->__VdfgTmp_he997ff62__0)))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 1U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060499_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060497_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058508_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060513_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060511_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058509_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 1U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058359_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 1U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___060527_ = (1U & (IData)(
                                                         (0xefefefefefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___060525_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0x80U 
                                                                      >> 
                                                                      (4U 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf3f50000U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___060243_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017946_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058510_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128874___O) 
                                                                                >> 2U))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f0335500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127507___O) 
                                                                                >> 2U))))))))))))))))));
    vlSelf->wasmetal_core__DOT___059551_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h6ecbbe50__0))))));
    vlSelf->wasmetal_core__DOT___018432_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7af47ace__0))))))));
    vlSelf->wasmetal_core__DOT___059517_ = (1U & (IData)(
                                                         (0x3050f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127540___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___059394_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT___059686_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127541___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___059435_ = (1U & (0xca000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT___060170_ = (1U & (0x100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058605_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdfb00432__0)))));
    vlSelf->wasmetal_core__DOT___018537_ = (1U & (IData)(
                                                         (0x5030f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c254f34__0))))))));
    vlSelf->wasmetal_core__DOT___060252_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058642_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdfb00432__0))));
    vlSelf->wasmetal_core__DOT___018492_ = (1U & (0xbf00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb00432__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058571_))))));
    vlSelf->wasmetal_core__DOT___016587_ = (1U & (IData)(
                                                         (0xf088000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007129_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058561_)))))))));
    vlSelf->wasmetal_core__DOT___016538_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b15__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127535___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016798_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127543___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___016780_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hca8853c2__0))))));
    vlSelf->wasmetal_core__DOT___016801_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058593_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016836_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058594_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017018_))));
    vlSelf->wasmetal_core__DOT___016848_ = (1U & (0xac000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b37__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127545___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___016536_ = (1U & (0x7fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018306_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018382_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018964_)))))));
    wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__ 
        = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                  >> 2U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___016933_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058613_))))));
    vlSelf->wasmetal_core__DOT___016915_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058612_))))));
    vlSelf->wasmetal_core__DOT___017087_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0x3355ffff0f0f0f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058423_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(wasmetal_core__DOT____Vcellout___127547___O) 
                                                                                >> 2U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eclose_sigOut__05b47__05d)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___016536_))));
    vlSelf->wasmetal_core__DOT___017068_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058649_))))));
    vlSelf->wasmetal_core__DOT___016995_ = (1U & (0x4400f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2932eeac__0))))));
    vlSelf->wasmetal_core__DOT___017006_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017018_)
                                                   ? 
                                                  (0xac00U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015076_) 
                                                           << 2U) 
                                                          | (IData)(__VdfgTmp_h0e008e26__0)))))
                                                   : 
                                                  (2U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017017_)))));
    vlSelf->wasmetal_core__DOT___017157_ = (1U & (0xc05U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017018_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016536_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051320_))))));
    wasmetal_core__DOT____Vcellout___134170___O = (
                                                   ((8U 
                                                     & ((~ 
                                                         ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                          >> 3U)) 
                                                        << 3U)) 
                                                    | ((4U 
                                                        & ((~ 
                                                            ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                             >> 2U)) 
                                                           << 2U)) 
                                                       | ((2U 
                                                           & ((~ 
                                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                                                                >> 1U)) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O)))))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___036867_)))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__ 
        = (IData)((((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134167___O) 
                    >> 3U) | (IData)(wasmetal_core__DOT___134170___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___060555_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060553_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060552_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060569_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060567_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060566_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134170___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060586_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060584_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060583_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    wasmetal_core__DOT___060597_ = (1U & (0xdU >> (
                                                   (4U 
                                                    & ((0x80U 
                                                        >> 
                                                        (4U 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xff4fffU 
                                                           >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___134170___O) 
                                                            >> 3U))))));
    wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (7U >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                 | (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___060601_ = (1U & (IData)(
                                                         (0xff0f8808ff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___060246_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060598_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___060597_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xff00ff0077770f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017937_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127508___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058322_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015597_)))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide)))))))));
    wasmetal_core__DOT____Vcellout___134171___O = (
                                                   (1U 
                                                    | ((4U 
                                                        & ((8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                           << 2U)) 
                                                       | (2U 
                                                          & ((7U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)) 
                                                             << 1U)))) 
                                                   ^ 
                                                   ((8U 
                                                     & (((1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d)))
                                                          ? (IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__)
                                                          : 
                                                         (8U 
                                                          >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                        << 3U)) 
                                                    | (((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (3U 
                                                          & (- (IData)((IData)(wasmetal_core__DOT___134171___DOT__CO__BRA__0__KET__)))))));
    vlSelf->wasmetal_core__DOT___060617_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060615_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060614_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060643_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060640_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060639_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___134171___O) 
                                                                           >> 1U)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
    vlSelf->wasmetal_core__DOT___060627_ = (1U & (IData)(
                                                         (0xb000b0bff00ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019074_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___060624_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___060623_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x80U 
                                                                         >> 
                                                                         (4U 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_integer__02eiNToRawFN__02esig__05b63__05d))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(wasmetal_core__DOT____Vcellout___134171___O)) 
                                                                       | (1U 
                                                                          & (0xff4fffU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_he997ff62__0)))))))))));
}
