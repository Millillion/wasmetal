#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__7(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__7\n"); );
    // Body
    vlSelf->__VdfgTmp_h62d1863a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hde24342a__0));
    vlSelf->wasmetal_core__DOT___048926_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67e9fb36__0))))))));
    vlSelf->wasmetal_core__DOT___055673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055036_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->__VdfgTmp_h69484b9c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0));
    vlSelf->wasmetal_core__DOT___055671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055034_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007396_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hb4659c85__0))))));
    vlSelf->wasmetal_core__DOT___044034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050416_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050408_))));
    vlSelf->wasmetal_core__DOT___050410_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050408_))));
    vlSelf->wasmetal_core__DOT___062169_ = (1U & (IData)(
                                                         (0x3355fffff0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___057574_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))))))));
    vlSelf->wasmetal_core__DOT___055675_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055042_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007759_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hb69256f0__0))))));
    vlSelf->__VdfgTmp_h4a43ab44__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb69256f0__0));
    vlSelf->wasmetal_core__DOT___050421_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050416_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___044035_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___044036_)))));
    vlSelf->wasmetal_core__DOT___063774_ = (1U & (0xb0bbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc2efa860__0)))));
    vlSelf->wasmetal_core__DOT___048626_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc2efa860__0))))))));
    vlSelf->wasmetal_core__DOT___063772_ = (1U & (IData)(
                                                         (0xb0bb00000000b0bbULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004925_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5c8699d0__0))))))));
    vlSelf->wasmetal_core__DOT___055044_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5c8699d0__0)))));
    vlSelf->wasmetal_core__DOT___007644_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0))))));
    vlSelf->__VdfgTmp_h6127a0a0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0));
    vlSelf->wasmetal_core__DOT___055674_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___055316_))));
    vlSelf->wasmetal_core__DOT___007640_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->wasmetal_core__DOT___007399_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h6ce01618__0))))));
    vlSelf->__VdfgTmp_hb5b904ce__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hdb4c449f__0));
    vlSelf->wasmetal_core__DOT___008469_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)))));
    vlSelf->wasmetal_core__DOT___063353_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT___048661_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b63__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT___001712_ = (1U & (IData)(
                                                         (0xc0a000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))));
    vlSelf->wasmetal_core__DOT___048002_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT___061649_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->wasmetal_core__DOT___057602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007419_))));
    vlSelf->wasmetal_core__DOT___068665_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068646_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068645_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068638_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068637_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x80b000fU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b51__05d) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___066579_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065009_)))))))))))))));
    vlSelf->wasmetal_core__DOT___008357_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf523586__0)))));
    vlSelf->wasmetal_core__DOT___063329_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT___047924_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b51__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->wasmetal_core__DOT___005514_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->__VdfgTmp_hf37b3ae8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010538_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010537_));
    vlSelf->wasmetal_core__DOT___008349_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h379ad787__0)))));
    vlSelf->wasmetal_core__DOT___063327_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT___047917_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b50__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0)))));
    vlSelf->wasmetal_core__DOT___061470_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007281_))));
    vlSelf->wasmetal_core__DOT___005816_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b50__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005546_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005545_))))))))));
    vlSelf->wasmetal_core__DOT___044349_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026976_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026978_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026979_)))));
    vlSelf->__VdfgTmp_h3c2b613a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->wasmetal_core__DOT___008341_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h375e931a__0)))));
    vlSelf->wasmetal_core__DOT___063325_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT___047933_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003115_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b49__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0)))));
    if (vlSelf->wasmetal_core__DOT___000666_) {
        vlSelf->wasmetal_core__DOT___001301_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))))));
        vlSelf->wasmetal_core__DOT___001300_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hac359f24__0))))))));
        vlSelf->wasmetal_core__DOT___001299_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))));
        vlSelf->wasmetal_core__DOT___000819_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))));
        vlSelf->wasmetal_core__DOT___001288_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))));
        vlSelf->wasmetal_core__DOT___001286_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))));
        vlSelf->wasmetal_core__DOT___000718_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))));
        vlSelf->wasmetal_core__DOT___000717_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000724_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))));
        vlSelf->wasmetal_core__DOT___000920_ = (1U 
                                                & (IData)(
                                                          (0x333355550f0f00ffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___001301_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)));
        vlSelf->wasmetal_core__DOT___001300_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)));
        vlSelf->wasmetal_core__DOT___001299_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)));
        vlSelf->wasmetal_core__DOT___000819_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)));
        vlSelf->wasmetal_core__DOT___001288_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d)));
        vlSelf->wasmetal_core__DOT___001286_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)));
        vlSelf->wasmetal_core__DOT___000718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)));
        vlSelf->wasmetal_core__DOT___000717_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d)));
        vlSelf->wasmetal_core__DOT___000920_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)));
    }
    vlSelf->wasmetal_core__DOT___005903_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b49__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005538_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005537_))))))))));
    vlSelf->wasmetal_core__DOT___068516_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068513_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068512_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xef00efefULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___068506_) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068505_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064360_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___010541_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008333_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd06fbc0c__0)))));
    vlSelf->wasmetal_core__DOT___063323_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT___047941_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003113_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b48__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0)))));
    vlSelf->__VdfgTmp_hc859778d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h38ad22b9__0));
    vlSelf->wasmetal_core__DOT___005823_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b48__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005656_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005655_))))))))));
    vlSelf->wasmetal_core__DOT___050413_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050412_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))))))));
    vlSelf->wasmetal_core__DOT___008318_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2b7d2fec__0)))));
    vlSelf->wasmetal_core__DOT___063321_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT___047861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b47__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0)))));
    vlSelf->wasmetal_core__DOT___007422_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007417_))))));
    vlSelf->wasmetal_core__DOT___006274_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hac359f24__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b47__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005526_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005525_))))))))));
    vlSelf->wasmetal_core__DOT___044348_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026973_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026974_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026975_)))));
    vlSelf->wasmetal_core__DOT___008310_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb948b455__0)))));
    vlSelf->wasmetal_core__DOT___063319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT___047857_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003121_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b46__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0)))));
    vlSelf->wasmetal_core__DOT___057497_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___006226_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h132c3402__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b46__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005522_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005521_))))))))));
    vlSelf->wasmetal_core__DOT___068339_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b45__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054211_)))))));
    vlSelf->wasmetal_core__DOT___008302_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5dede88d__0)))));
    vlSelf->wasmetal_core__DOT___063317_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT___047839_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003119_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b45__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0)))));
    vlSelf->wasmetal_core__DOT___006151_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h82148a8f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b45__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005562_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005561_))))))))));
    vlSelf->wasmetal_core__DOT___008294_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8c7509c5__0)))));
    vlSelf->wasmetal_core__DOT___063315_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT___047847_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003117_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b44__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0)))));
    vlSelf->wasmetal_core__DOT___007338_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7678d7b9__0))))));
    vlSelf->wasmetal_core__DOT___006178_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h33528dbb__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b44__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005518_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005517_))))))))));
    vlSelf->wasmetal_core__DOT___044347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026970_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026971_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026972_)))));
    vlSelf->wasmetal_core__DOT___008281_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc65b9dd7__0)))));
    vlSelf->wasmetal_core__DOT___063313_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT___047897_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003107_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b43__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0)))));
    vlSelf->wasmetal_core__DOT___006058_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b43__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005509_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005508_))))))))));
    vlSelf->wasmetal_core__DOT___008273_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h483290db__0)))));
    vlSelf->wasmetal_core__DOT___063311_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT___047905_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003105_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b42__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0)))));
    vlSelf->wasmetal_core__DOT___061466_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007278_))));
    vlSelf->wasmetal_core__DOT___006044_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b42__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005505_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005504_))))))))));
    vlSelf->wasmetal_core__DOT___008265_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h268e4ef9__0)))));
    vlSelf->wasmetal_core__DOT___063309_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT___047887_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003111_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b41__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0)))));
    vlSelf->wasmetal_core__DOT___006029_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9963adf9__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b41__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005530_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005529_))))))))));
    vlSelf->wasmetal_core__DOT___044346_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026967_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026969_)))));
    vlSelf->wasmetal_core__DOT___010781_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008257_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he040c9e4__0)))));
    vlSelf->wasmetal_core__DOT___063307_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT___047879_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b40__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0)))));
    vlSelf->wasmetal_core__DOT___007770_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h81bae7c4__0))))));
    vlSelf->wasmetal_core__DOT___006051_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc231438f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b40__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005534_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005533_))))))))));
    vlSelf->wasmetal_core__DOT___068039_ = (1U & (IData)(
                                                         (0xef000000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068017_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068016_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x70330000U 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___068010_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___068009_))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x7033U 
                                                                             >> 
                                                                             ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067580_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065484_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065493_)))))))))))))));
    vlSelf->wasmetal_core__DOT___008243_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h877e6c65__0)))));
    vlSelf->wasmetal_core__DOT___063305_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT___047819_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003103_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b39__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0)))));
    vlSelf->wasmetal_core__DOT___005948_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b39__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005566_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005565_))))))))));
    vlSelf->wasmetal_core__DOT___008235_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h218f194f__0)))));
    vlSelf->wasmetal_core__DOT___063303_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT___047827_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003101_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b38__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0)))));
    vlSelf->wasmetal_core__DOT___005809_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b38__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005550_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005549_))))))))));
    vlSelf->wasmetal_core__DOT___044345_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026963_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026965_)))));
    vlSelf->wasmetal_core__DOT___008227_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd87e5f33__0)))));
    vlSelf->wasmetal_core__DOT___063301_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT___047809_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003099_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b37__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0)))));
    vlSelf->wasmetal_core__DOT___005882_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b37__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005542_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005541_))))))))));
    vlSelf->wasmetal_core__DOT___008219_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)))));
    vlSelf->wasmetal_core__DOT___063299_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT___047800_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003097_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b36__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0)))));
    vlSelf->wasmetal_core__DOT___005802_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b36__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005558_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005557_))))))))));
    vlSelf->wasmetal_core__DOT___063792_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h45ac64ad__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb0eafd09__0))))));
    vlSelf->wasmetal_core__DOT___008206_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb0eafd09__0)))));
    vlSelf->wasmetal_core__DOT___063297_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT___048686_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b35__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0)))));
    vlSelf->__VdfgTmp_h37472320__0 = (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007305_));
    vlSelf->wasmetal_core__DOT___005955_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b35__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005648_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005647_))))))))));
    vlSelf->wasmetal_core__DOT___044344_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026960_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026961_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026962_)))));
    vlSelf->wasmetal_core__DOT___008198_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)))));
    vlSelf->wasmetal_core__DOT___063295_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT___048915_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b34__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0)))));
    vlSelf->wasmetal_core__DOT___061464_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007279_))));
    vlSelf->__VdfgTmp_h05980b33__0 = (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007278_));
    vlSelf->wasmetal_core__DOT___005788_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b34__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005660_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005659_))))))))));
    vlSelf->wasmetal_core__DOT___063791_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9dd568d9__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h4bc445dd__0))))));
    vlSelf->wasmetal_core__DOT___008190_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4bc445dd__0)))));
    vlSelf->wasmetal_core__DOT___063293_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT___048910_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003095_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))))))));
    vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b33__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->wasmetal_core__DOT___005653_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->__VdfgTmp_h860ce20a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007252_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007251_));
    vlSelf->__VdfgTmp_h3a577ede__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->__VdfgTmp_h312c1c6b__0 = (((IData)(vlSelf->wasmetal_core__DOT___005651_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005652_));
    vlSelf->wasmetal_core__DOT___067614_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067590_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067589_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xbf00bfbfULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___067582_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064447_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___019407_)))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___011605_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008182_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h80fb591c__0)))));
    vlSelf->wasmetal_core__DOT___063287_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->wasmetal_core__DOT___048908_ = ((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003091_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))))));
    vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b32__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0)))));
    vlSelf->wasmetal_core__DOT___001774_ = ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                               & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000693_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9a79492f__0)))))))));
    vlSelf->wasmetal_core__DOT___061465_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007252_))));
    vlSelf->wasmetal_core__DOT___005795_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h9a79492f__0))))) 
                                                  & (IData)(
                                                            (0xffff0f0fffff11ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b32__05d) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005554_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005553_))))))))));
    vlSelf->wasmetal_core__DOT___067543_ = (1U & (0xaf3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067538_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__query_table) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048520_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b31__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___054178_)))))));
    vlSelf->wasmetal_core__DOT___045828_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x19U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x1aU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h946ed16f__0))))))));
    vlSelf->wasmetal_core__DOT___069234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___026478_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___044343_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026957_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026958_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026959_)))));
    vlSelf->wasmetal_core__DOT___063805_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h80fb591c__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6a330ca__0))))));
    vlSelf->wasmetal_core__DOT___008168_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd6a330ca__0)))));
    vlSelf->wasmetal_core__DOT___028244_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___063281_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b31__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT___001735_ = ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                               & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0)))))))));
    vlSelf->wasmetal_core__DOT___005711_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff1fffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005572_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005571_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h92d236ac__0))))))));
    vlSelf->wasmetal_core__DOT___061650_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048402_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007414_)))));
    vlSelf->wasmetal_core__DOT___057671_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007414_))));
    vlSelf->wasmetal_core__DOT___067659_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053925_))));
    vlSelf->wasmetal_core__DOT___026465_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053925_))));
    vlSelf->wasmetal_core__DOT___007870_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8dfb864__0)))));
    vlSelf->wasmetal_core__DOT___063101_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT___028231_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT___048807_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h47317805__0)))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b1__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT___005928_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h47317805__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b1__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003221_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h534a5d27__0)))))));
    vlSelf->wasmetal_core__DOT___061763_ = (1U & (0x7f7f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048385_)))))));
    vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028648_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128094___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003270_));
    vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028960_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128121___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b1__05d));
    vlSelf->wasmetal_core__DOT___064461_ = (1U & (0xdf0f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064456_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064455_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019394_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0xc0cca0aa00ff00ffULL 
                                                                         >> 
                                                                         ((0x20U 
                                                                           & ((1U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                              << 5U)) 
                                                                          | ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064447_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff00ff00f0f0eeeeULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064445_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064444_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000000077ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0x40U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064437_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128534___O)))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & vlSelf->mem_rdata[0U])))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064436_))))))))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___064453_)))))));
    vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001874_)
            : (IData)(vlSelf->wasmetal_core__DOT___128434___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___045827_ = (1U & (0x9009U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_y 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h521b28ea__0)))));
    vlSelf->wasmetal_core__DOT___128103___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___028741_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___067607_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053924_))));
    vlSelf->wasmetal_core__DOT___127876___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___026663_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___127927___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___027133_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b0__05d));
    vlSelf->wasmetal_core__DOT___045815_ = (1U & (0x7150U 
                                                  >> 
                                                  ((8U 
                                                    & (vlSelf->insn_y 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h644f4591__0)))));
    vlSelf->wasmetal_core__DOT___071914_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h644f4591__0))));
    vlSelf->wasmetal_core__DOT___026562_ = (1U & (0xef10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071911_))))));
    vlSelf->wasmetal_core__DOT___127910___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_hc01d1a00__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___127893___DOT__CO__BRA__0__KET__ 
        = ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h93039dba__0))) 
           & (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d));
    vlSelf->wasmetal_core__DOT___007882_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h93039dba__0)))));
    vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001874_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128656___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___063095_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT___028220_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT___048796_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0)))));
    vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b0__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT___005731_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b0__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003135_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003134_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003133_)))))))));
    vlSelf->wasmetal_core__DOT___061450_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007247_))));
    vlSelf->__VdfgTmp_hcbbf7a95__0 = (((IData)(vlSelf->wasmetal_core__DOT___001285_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___001662_));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b62__05d)));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b61__05d)));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b60__05d)));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b58__05d)));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b54__05d)));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b53__05d)));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b52__05d)));
    } else if (vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005457_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005456_)))));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005420_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005419_)))));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005410_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005409_)))));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005390_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005389_)))));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005487_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005486_)))));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005477_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005476_)))));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005467_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___005466_)))));
    } else {
        vlSelf->wasmetal_core__DOT___005429_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd81cbf50__0))));
        vlSelf->wasmetal_core__DOT___048205_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h65f01eca__0))));
        vlSelf->wasmetal_core__DOT___048166_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hb5adad38__0))));
        vlSelf->wasmetal_core__DOT___048164_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5dfa9ecf__0))));
        vlSelf->wasmetal_core__DOT___048049_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hd852066e__0))));
        vlSelf->wasmetal_core__DOT___048062_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h5779821b__0))));
        vlSelf->wasmetal_core__DOT___048051_ = (1U 
                                                & (0x1fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h63c99640__0))));
    }
    vlSelf->__VdfgTmp_h6b2c9c37__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005456_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005457_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048172_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048171_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048170_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048169_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd81cbf50__0))))))))));
    vlSelf->wasmetal_core__DOT___069163_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010523_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063351_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h46733dea__0))));
    vlSelf->wasmetal_core__DOT___052778_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h46733dea__0)))))))))));
    vlSelf->wasmetal_core__DOT___008461_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b62__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT___001317_ = ((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                               & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000418_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))))))));
    vlSelf->wasmetal_core__DOT___005430_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT___007395_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007390_))))));
    vlSelf->wasmetal_core__DOT___057531_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->__VdfgTmp_h9b25c217__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005419_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005420_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048239_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048238_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048241_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048240_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h65f01eca__0))))))))));
    vlSelf->wasmetal_core__DOT___044354_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026990_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026991_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026992_)))));
    vlSelf->wasmetal_core__DOT___010518_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4f90e104__0 = (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d)));
    vlSelf->wasmetal_core__DOT___069133_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008454_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063349_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))));
    vlSelf->wasmetal_core__DOT___008453_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b61__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT___048206_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT___007369_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007364_))))));
    vlSelf->__VdfgTmp_h651d6523__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005409_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005410_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048184_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048183_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048182_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048181_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hb5adad38__0))))))))));
    vlSelf->wasmetal_core__DOT___010513_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h8f6175c0__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d));
    vlSelf->wasmetal_core__DOT___069084_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008446_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063347_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0))));
    vlSelf->wasmetal_core__DOT___008445_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b60__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___048167_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT___054339_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hd0975535__0))))));
    vlSelf->__VdfgTmp_h504ea901__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hd0975535__0));
    vlSelf->__VdfgTmp_ha80d5d1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___034505_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034504_));
    vlSelf->wasmetal_core__DOT___069045_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010500_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hd5d1004a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d));
    vlSelf->wasmetal_core__DOT___069033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008433_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0))));
    vlSelf->wasmetal_core__DOT___008432_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b59__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT___048209_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->__VdfgTmp_hfcd73105__0 = (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->__VdfgTmp_hb4c136ee__0 = (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007307_));
    vlSelf->wasmetal_core__DOT___007310_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007305_))))));
    vlSelf->__VdfgTmp_h9b410c9d__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005389_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005390_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048178_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048177_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048180_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048179_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h5dfa9ecf__0))))))))));
    vlSelf->wasmetal_core__DOT___044353_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026986_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026987_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026989_)))));
    vlSelf->wasmetal_core__DOT___068973_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042353_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7b89d77c__0))))))));
    vlSelf->wasmetal_core__DOT___042152_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7b89d77c__0))))))));
    vlSelf->wasmetal_core__DOT___042176_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001080_)))))))));
    vlSelf->wasmetal_core__DOT___010495_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hfe7af35a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d));
    vlSelf->wasmetal_core__DOT___068961_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008425_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063343_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h56116db4__0))));
    vlSelf->wasmetal_core__DOT___008424_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b58__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___048165_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT___061472_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007307_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007280_))));
    vlSelf->__VdfgTmp_h05777dd7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->__VdfgTmp_h797b2590__0 = (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007280_));
    vlSelf->wasmetal_core__DOT___007283_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007280_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___007278_))))));
    vlSelf->wasmetal_core__DOT___052801_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___034487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___034486_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___034481_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___034502_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___034480_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___034503_)))))))));
    vlSelf->wasmetal_core__DOT___063806_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026851_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026850_)))));
    vlSelf->wasmetal_core__DOT___010572_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068947_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010490_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h131eee20__0 = (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d)));
    vlSelf->wasmetal_core__DOT___068935_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008417_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063341_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0))));
    vlSelf->wasmetal_core__DOT___008416_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b57__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT___005431_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->__VdfgTmp_hf1275c5a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->__VdfgTmp_hca913760__0 = (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007253_));
    vlSelf->__VdfgTmp_hf8957689__0 = (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007253_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___007251_))));
    vlSelf->wasmetal_core__DOT___010597_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068903_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h60f9d0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d));
    vlSelf->wasmetal_core__DOT___068891_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008409_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063339_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h139d3776__0))));
    vlSelf->wasmetal_core__DOT___008408_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b56__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___005432_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT___054150_ = ((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                            & (IData)(
                                                      (0xccaa0000f0f0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                            << 4U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hce5bccc4__0))))));
    vlSelf->__VdfgTmp_h528a2190__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hce5bccc4__0));
    vlSelf->wasmetal_core__DOT___044351_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026983_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026984_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026985_)))));
    vlSelf->wasmetal_core__DOT___068856_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042351_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h59235eaf__0))))))));
    vlSelf->wasmetal_core__DOT___042150_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h59235eaf__0))))))));
    vlSelf->wasmetal_core__DOT___042174_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001014_)))))))));
    vlSelf->__VdfgTmp_h1811a1bb__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d)));
    vlSelf->wasmetal_core__DOT___010472_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4fe6474e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d));
    vlSelf->wasmetal_core__DOT___068844_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008395_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063337_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3378cabf__0))));
    vlSelf->wasmetal_core__DOT___008394_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b55__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT___048149_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->__VdfgTmp_h2df8dd7f__0 = (((IData)(vlSelf->wasmetal_core__DOT___007420_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007419_));
    vlSelf->__VdfgTmp_hd44758f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005486_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005487_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048047_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048046_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048045_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048044_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_hd852066e__0))))))))));
    vlSelf->__VdfgTmp_h2f9ca2ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___010529_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT___068801_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->__VdfgTmp_h74f7a068__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d)));
    vlSelf->wasmetal_core__DOT___010467_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h67451104__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d));
    vlSelf->wasmetal_core__DOT___068789_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008387_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008386_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha541df85__0)))));
    vlSelf->wasmetal_core__DOT___063335_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))));
    vlSelf->wasmetal_core__DOT___048621_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b54__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->wasmetal_core__DOT___048050_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->__VdfgTmp_h447558a7__0 = (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007392_));
    vlSelf->__VdfgTmp_hadae1421__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005476_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005477_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048060_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048059_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048058_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048057_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h5779821b__0))))))))));
    vlSelf->wasmetal_core__DOT___010534_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___068757_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___010462_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4575751b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d)));
    vlSelf->wasmetal_core__DOT___068745_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008379_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063807_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___026854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___026852_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___026849_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___026848_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_ha541df85__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_heb331328__0)))))))))));
    vlSelf->wasmetal_core__DOT___008378_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb331328__0)))));
    vlSelf->wasmetal_core__DOT___063333_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))));
    vlSelf->wasmetal_core__DOT___048638_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b53__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->wasmetal_core__DOT___048063_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->wasmetal_core__DOT___010140_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007366_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007364_)))))))));
    vlSelf->__VdfgTmp_h372c3d93__0 = (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007366_));
    vlSelf->__VdfgTmp_he4dfb545__0 = (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xfff00000eeee0000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005466_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___005467_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048043_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___048042_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff0ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048041_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048040_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h63c99640__0))))))))));
    vlSelf->wasmetal_core__DOT___050434_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050429_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050428_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___044350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026980_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026981_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026982_)))));
    vlSelf->__VdfgTmp_he2e0905c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010538_));
    vlSelf->wasmetal_core__DOT___068708_ = (1U & (IData)(
                                                         (0x500330003ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h42143724__0))))));
    vlSelf->wasmetal_core__DOT___042350_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h388edf60__0))))))));
    vlSelf->wasmetal_core__DOT___042149_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001327_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h388edf60__0))))))));
    vlSelf->wasmetal_core__DOT___042173_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000980_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000992_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___001327_)))))))));
    vlSelf->wasmetal_core__DOT___010457_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h1a9e6a0c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___068696_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___008371_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063812_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbf523586__0))))));
    vlSelf->wasmetal_core__DOT___008370_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc67fdbf4__0)))));
    vlSelf->wasmetal_core__DOT___063331_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))));
    vlSelf->wasmetal_core__DOT___048633_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b52__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->wasmetal_core__DOT___048052_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->__VdfgTmp_h3c09d3eb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_h2cdc7e5b__0));
    vlSelf->wasmetal_core__DOT___044503_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_had9a86ff__0))))))));
    vlSelf->wasmetal_core__DOT___045816_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x18U)) 
                                                           | ((0x18U 
                                                               & (vlSelf->insn_y 
                                                                  >> 0x1bU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_had9a86ff__0)))))));
    vlSelf->wasmetal_core__DOT___069160_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___026477_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___063938_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000657_))));
    vlSelf->wasmetal_core__DOT___010159_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___008161_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___028243_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___063275_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___008160_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hec1752e3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b30__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT___057461_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007387_))));
    vlSelf->wasmetal_core__DOT___009780_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007390_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007393_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007391_)))))))));
    vlSelf->wasmetal_core__DOT___069141_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___026475_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___071971_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3b20cbca__0))));
    vlSelf->wasmetal_core__DOT___010964_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056436_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->wasmetal_core__DOT___002760_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048848_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb73e868c__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0))))))))))))))));
    vlSelf->__VdfgTmp_h15099632__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d));
    vlSelf->wasmetal_core__DOT___063937_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000635_))));
    vlSelf->wasmetal_core__DOT___010165_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h2bd8c9ed__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    vlSelf->wasmetal_core__DOT___055268_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1cU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008153_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___028241_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT___063269_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT___008152_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b29__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT___009815_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007364_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007367_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007365_)))))))));
    vlSelf->wasmetal_core__DOT___026495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071973_))));
    vlSelf->wasmetal_core__DOT___069092_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053952_))));
    vlSelf->wasmetal_core__DOT___026474_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053952_))));
    vlSelf->wasmetal_core__DOT___044342_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026953_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026954_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026956_)))));
    vlSelf->wasmetal_core__DOT___002720_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048855_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1bd58642__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___070509_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d))));
    vlSelf->__VdfgTmp_ha86315e0__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d));
    vlSelf->__VdfgTmp_h4b9b5b32__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000613_));
    vlSelf->wasmetal_core__DOT___010206_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h717e9861__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b29__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT___055265_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1bU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063263_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT___028240_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT___008144_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT___052576_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052267_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052266_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (1ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052142_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052141_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052140_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052139_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052138_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052137_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052264_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052263_)))))));
    vlSelf->wasmetal_core__DOT___044512_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb6080b41__0))))))));
    vlSelf->__VdfgTmp_h22be3b3b__0 = (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb6080b41__0));
    vlSelf->wasmetal_core__DOT___069042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053951_))));
    vlSelf->wasmetal_core__DOT___026473_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053951_))));
    vlSelf->__VdfgTmp_hbd466e7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d));
    vlSelf->wasmetal_core__DOT___063932_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000591_))));
    vlSelf->wasmetal_core__DOT___010208_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_had26118d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    vlSelf->wasmetal_core__DOT___055262_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x1aU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008132_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063257_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT___028239_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT___008131_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT___005989_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b27__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004981_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h6305c07b__0)))))));
    vlSelf->wasmetal_core__DOT___009794_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007305_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007308_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007306_)))))))));
    vlSelf->wasmetal_core__DOT___045837_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x17U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x18U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17df9f02__0))))))));
    vlSelf->wasmetal_core__DOT___068970_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053950_))));
    vlSelf->wasmetal_core__DOT___026472_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053950_))));
    vlSelf->wasmetal_core__DOT___071966_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h879a663d__0))));
    vlSelf->wasmetal_core__DOT___042304_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b28__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb6080b41__0))))))));
    vlSelf->__VdfgTmp_h992e16df__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d));
    vlSelf->wasmetal_core__DOT___063931_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000564_))));
    vlSelf->wasmetal_core__DOT___010199_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hdba97a87__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    vlSelf->wasmetal_core__DOT___055259_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x19U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063251_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT___028238_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT___008123_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b26__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT___061457_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007275_))));
    vlSelf->wasmetal_core__DOT___009792_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007278_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007281_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007279_)))))))));
    vlSelf->wasmetal_core__DOT___056823_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___068944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053949_))));
    vlSelf->wasmetal_core__DOT___026471_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053949_))));
    vlSelf->wasmetal_core__DOT___071969_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071968_)))));
    vlSelf->wasmetal_core__DOT___044362_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026950_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026951_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026952_)))));
    vlSelf->wasmetal_core__DOT___002681_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048845_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h339d407e__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0))))))))))))))));
    vlSelf->__VdfgTmp_hd9e2f527__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d));
    vlSelf->wasmetal_core__DOT___070508_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d))));
    vlSelf->__VdfgTmp_hd856a856__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___000542_));
    vlSelf->wasmetal_core__DOT___010216_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hf4e6deac__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b26__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    vlSelf->wasmetal_core__DOT___055256_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x18U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008116_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063245_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT___028237_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT___008115_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h975aebd1__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b25__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT___006022_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b25__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005321_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hea3adbd3__0)))))));
    vlSelf->wasmetal_core__DOT___010214_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007251_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007254_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007248_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007252_)))))))));
    vlSelf->wasmetal_core__DOT___044511_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h00038af9__0))))))));
    vlSelf->__VdfgTmp_h3948b92c__0 = (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h00038af9__0));
    vlSelf->wasmetal_core__DOT___068900_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053948_))));
    vlSelf->wasmetal_core__DOT___026470_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053948_))));
    vlSelf->wasmetal_core__DOT___002642_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048865_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8aa65d09__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h139d3776__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___066976_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->__VdfgTmp_hfc0b7a98__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d));
    vlSelf->wasmetal_core__DOT___010181_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h6cb2731d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    vlSelf->wasmetal_core__DOT___055253_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x17U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008108_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063239_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT___028236_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT___008107_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b24__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT___006106_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b24__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005049_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h04914456__0)))))));
    vlSelf->wasmetal_core__DOT___061458_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007248_))));
    vlSelf->wasmetal_core__DOT___052761_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5ee6f21__0))));
    vlSelf->wasmetal_core__DOT___050423_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf5ee6f21__0))))))));
    vlSelf->wasmetal_core__DOT___045836_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x14U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x15U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5d86514__0))))))));
    vlSelf->wasmetal_core__DOT___068853_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053947_))));
    vlSelf->wasmetal_core__DOT___026469_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053947_))));
    vlSelf->wasmetal_core__DOT___071965_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071960_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071964_)))));
    vlSelf->wasmetal_core__DOT___002924_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048840_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc2efa860__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3378cabf__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___066902_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->__VdfgTmp_h3c78c397__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    vlSelf->wasmetal_core__DOT___042303_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h00038af9__0))))))));
    vlSelf->wasmetal_core__DOT___063942_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000498_))))));
    vlSelf->__VdfgTmp_h2e3bd00c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b27__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d)));
    vlSelf->wasmetal_core__DOT___010180_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h4438b1a5__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT___055250_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x16U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008094_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063233_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT___028235_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT___008093_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT___005868_ = (1U & ((~ 
                                                   (0xac00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b23__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___005117_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hc2abfe6d__0)))))));
    vlSelf->__VdfgTmp_h5b76ab14__0 = (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007414_));
    vlSelf->wasmetal_core__DOT___068798_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053946_))));
    vlSelf->wasmetal_core__DOT___026468_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053946_))));
    vlSelf->wasmetal_core__DOT___071963_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071958_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071962_)))));
    vlSelf->wasmetal_core__DOT___044361_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026947_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026949_)))));
    vlSelf->wasmetal_core__DOT___042361_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h81203724__0))))))));
    vlSelf->wasmetal_core__DOT___042160_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h81203724__0))))))));
    vlSelf->__VdfgTmp_h7cc94077__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT___063952_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000476_))));
    vlSelf->wasmetal_core__DOT___010185_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hf22a37d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    vlSelf->wasmetal_core__DOT___055247_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x15U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008086_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008085_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hf0334e7f__0)))));
    vlSelf->wasmetal_core__DOT___063227_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->wasmetal_core__DOT___028234_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b22__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->__VdfgTmp_ha38d193b__0 = (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007387_));
    vlSelf->wasmetal_core__DOT___068754_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053945_))));
    vlSelf->wasmetal_core__DOT___026467_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053945_))));
    vlSelf->wasmetal_core__DOT___044510_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000926_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000993_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000981_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h745b6e5d__0))))))));
    vlSelf->__VdfgTmp_hbb13730a__0 = (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h745b6e5d__0));
    vlSelf->wasmetal_core__DOT___071956_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h745b6e5d__0))));
    vlSelf->wasmetal_core__DOT___066778_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->__VdfgTmp_h1479cba4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    vlSelf->wasmetal_core__DOT___010184_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h2a3dbf89__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    vlSelf->wasmetal_core__DOT___055244_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x14U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008078_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063813_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((6U 
                                                                >> (IData)(vlSelf->__VdfgTmp_he040c9e4__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((6U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h877e6c65__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h218f194f__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___026818_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h2be29f89__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9cad1664__0)))))))))));
    vlSelf->wasmetal_core__DOT___008077_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cad1664__0)))));
    vlSelf->wasmetal_core__DOT___063221_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->wasmetal_core__DOT___028233_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b21__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->__VdfgTmp_hf20faaf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007361_));
    vlSelf->wasmetal_core__DOT___045835_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x10U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd7080d55__0))))))));
    vlSelf->wasmetal_core__DOT___068705_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053944_))));
    vlSelf->wasmetal_core__DOT___026466_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053944_))));
    vlSelf->wasmetal_core__DOT___071959_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071954_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071958_)))));
    vlSelf->__VdfgTmp_hadb47ff7__0 = (((IData)(vlSelf->wasmetal_core__DOT___011125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011124_));
    vlSelf->wasmetal_core__DOT___066656_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->wasmetal_core__DOT___042302_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h745b6e5d__0))))))));
    vlSelf->__VdfgTmp_h19f2f351__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    vlSelf->wasmetal_core__DOT___063953_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000432_))))));
    vlSelf->wasmetal_core__DOT___010189_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h8b010904__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    vlSelf->wasmetal_core__DOT___008070_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008069_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd86a0826__0)))));
    vlSelf->wasmetal_core__DOT___063215_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->wasmetal_core__DOT___028232_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b20__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->__VdfgTmp_hb187f8bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___007336_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007335_));
    vlSelf->wasmetal_core__DOT___054543_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003269_)))));
    vlSelf->wasmetal_core__DOT___054544_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          >> 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001875_)))));
    vlSelf->wasmetal_core__DOT___054545_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001887_)))));
    vlSelf->wasmetal_core__DOT___054542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02esign_a) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128640___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003189_)))));
    vlSelf->wasmetal_core__DOT___128647___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001438_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034380_));
    vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028483_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128076___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___004818_));
    vlSelf->wasmetal_core__DOT___045834_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xcU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xfU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe93be6e__0))))))));
    vlSelf->wasmetal_core__DOT___068657_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053943_))));
    vlSelf->wasmetal_core__DOT___026464_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053943_))));
    vlSelf->wasmetal_core__DOT___044360_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026943_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026945_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026946_)))));
    vlSelf->wasmetal_core__DOT___000156_ = (1U & (IData)(
                                                         (0xcc0caa0aff0fff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048881_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))))))))))))))));
    vlSelf->__VdfgTmp_h5145bf91__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    vlSelf->wasmetal_core__DOT___042360_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2c65ce9e__0))))))));
    vlSelf->wasmetal_core__DOT___042159_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2c65ce9e__0))))))));
    vlSelf->wasmetal_core__DOT___063950_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000419_))));
    vlSelf->wasmetal_core__DOT___010188_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h898e287a__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT___008057_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063737_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd86a0826__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0))))));
    vlSelf->wasmetal_core__DOT___008056_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e3e53ad__0)))));
    vlSelf->wasmetal_core__DOT___063209_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT___028230_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b19__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT___003805_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b19__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003815_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he16d2f4f__0)))))));
    vlSelf->__VdfgTmp_h8499ba72__0 = (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007302_));
    vlSelf->wasmetal_core__DOT___068608_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053942_))));
    vlSelf->wasmetal_core__DOT___026463_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053942_))));
    vlSelf->wasmetal_core__DOT___044509_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000896_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000927_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000897_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h877be1c6__0))))))));
    vlSelf->__VdfgTmp_h4c89c552__0 = (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h877be1c6__0));
    vlSelf->wasmetal_core__DOT___071950_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h877be1c6__0))));
    vlSelf->wasmetal_core__DOT___066534_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->__VdfgTmp_hb776b144__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT___011052_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h3613bfb2__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    vlSelf->wasmetal_core__DOT___008049_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008048_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0cc9f882__0)))));
    vlSelf->wasmetal_core__DOT___063203_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT___028229_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b18__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT___003808_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h95830544__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b18__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004031_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d95a729__0)))))));
    vlSelf->wasmetal_core__DOT___061455_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007276_))));
    vlSelf->__VdfgTmp_h80fea7fc__0 = (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007275_));
    vlSelf->wasmetal_core__DOT___068555_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053941_))));
    vlSelf->wasmetal_core__DOT___026462_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053941_))));
    vlSelf->wasmetal_core__DOT___071948_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf05757ff__0))));
    vlSelf->wasmetal_core__DOT___066409_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->wasmetal_core__DOT___042301_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h877be1c6__0))))))));
    vlSelf->__VdfgTmp_h061491a4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    vlSelf->wasmetal_core__DOT___063951_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001646_))))));
    vlSelf->wasmetal_core__DOT___072034_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d))));
    vlSelf->wasmetal_core__DOT___010194_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h9e6b526c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    vlSelf->wasmetal_core__DOT___055217_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0x10U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008041_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008040_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h63306680__0)))));
    vlSelf->wasmetal_core__DOT___063197_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT___028228_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT___048759_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b17__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT___003811_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b17__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004253_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1fced7c0__0)))))));
    vlSelf->__VdfgTmp_h551248b6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007249_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007248_));
    vlSelf->wasmetal_core__DOT___052833_ = (1U & (0x80000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052758_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052779_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x1000000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___052830_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___052776_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___052829_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052770_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004709_)))))))) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052757_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h4c543443__0)) 
                                                                               << 5U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052768_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052826_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052820_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052819_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005197_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005215_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004783_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x100000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052818_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005061_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001330_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005599_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005581_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052817_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052816_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052815_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___004043_))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___003109_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003745_)))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___068478_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053940_))));
    vlSelf->wasmetal_core__DOT___026461_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053940_))));
    vlSelf->wasmetal_core__DOT___044359_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026940_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026941_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026942_)))));
    vlSelf->wasmetal_core__DOT___042359_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf05757ff__0))))))));
    vlSelf->wasmetal_core__DOT___042158_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf05757ff__0))))))));
    vlSelf->__VdfgTmp_hd14327b4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    vlSelf->wasmetal_core__DOT___063945_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001612_))));
    vlSelf->wasmetal_core__DOT___010232_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_he924c244__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    vlSelf->wasmetal_core__DOT___055203_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xfU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008032_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h560b7672__0)))));
    vlSelf->wasmetal_core__DOT___063191_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT___028227_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT___048820_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h652edcf1__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b16__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT___003807_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b16__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003957_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2852ec0c__0)))))));
    vlSelf->wasmetal_core__DOT___061456_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007430_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007249_))));
    vlSelf->__VdfgTmp_hd163f969__0 = (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007430_));
    vlSelf->wasmetal_core__DOT___068426_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053939_))));
    vlSelf->wasmetal_core__DOT___026460_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053939_))));
    vlSelf->wasmetal_core__DOT___044508_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000849_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000873_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000872_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb150d0ab__0))))))));
    vlSelf->__VdfgTmp_hc87c06e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb150d0ab__0));
    vlSelf->wasmetal_core__DOT___071944_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb150d0ab__0))));
    vlSelf->wasmetal_core__DOT___066286_ = (1U & (0xa0ccc0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc55be417__0)))));
    vlSelf->__VdfgTmp_h89e0a965__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    vlSelf->wasmetal_core__DOT___066319_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d))));
    vlSelf->wasmetal_core__DOT___010222_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h238b010e__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT___055198_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xeU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___008008_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___008007_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb96516e6__0)))));
    vlSelf->wasmetal_core__DOT___063185_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT___028226_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT___048732_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e46481a__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b15__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT___006400_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b15__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003659_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_had67ef57__0)))))));
    vlSelf->wasmetal_core__DOT___061651_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007412_))));
    vlSelf->wasmetal_core__DOT___009650_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007418_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007415_)))))))));
    vlSelf->wasmetal_core__DOT___057675_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___045833_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 0xaU)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8243d19d__0))))))));
    vlSelf->wasmetal_core__DOT___068402_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053938_))));
    vlSelf->wasmetal_core__DOT___026459_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053938_))));
    vlSelf->wasmetal_core__DOT___071947_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071942_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071946_)))));
    vlSelf->wasmetal_core__DOT___042300_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001568_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb150d0ab__0))))))));
    vlSelf->__VdfgTmp_h688ac52f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d));
    vlSelf->wasmetal_core__DOT___063935_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001580_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001568_))))));
    vlSelf->wasmetal_core__DOT___057686_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010243_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h7dd7d539__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    vlSelf->wasmetal_core__DOT___008000_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007999_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he974eeb2__0)))));
    vlSelf->wasmetal_core__DOT___063179_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT___028225_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT___048825_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b14__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT___006204_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b14__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004623_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcbae1cfc__0)))))));
    vlSelf->wasmetal_core__DOT___010240_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007391_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007385_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007388_)))))))));
    vlSelf->wasmetal_core__DOT___068347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053937_))));
    vlSelf->wasmetal_core__DOT___026458_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053937_))));
    vlSelf->wasmetal_core__DOT___044358_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026937_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026939_)))));
    vlSelf->wasmetal_core__DOT___042358_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha7a1e5c8__0))))))));
    vlSelf->wasmetal_core__DOT___042157_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha7a1e5c8__0))))))));
    vlSelf->__VdfgTmp_h09210432__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d));
    vlSelf->wasmetal_core__DOT___063954_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001536_))));
    vlSelf->wasmetal_core__DOT___057685_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010254_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h9040377d__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT___055179_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xcU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___007992_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063738_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he974eeb2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5a182b30__0))))));
    vlSelf->wasmetal_core__DOT___007991_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5a182b30__0)))));
    vlSelf->wasmetal_core__DOT___063173_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT___028224_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT___048812_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5bc17448__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b13__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT___003810_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b13__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004179_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1f7a3fb7__0)))))));
    vlSelf->wasmetal_core__DOT___010250_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007365_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007362_)))))))));
    vlSelf->wasmetal_core__DOT___057376_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007359_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___044507_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000825_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000824_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000848_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h48afdd44__0))))))));
    vlSelf->__VdfgTmp_hdd349d37__0 = (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h48afdd44__0));
    vlSelf->wasmetal_core__DOT___068293_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053936_))));
    vlSelf->wasmetal_core__DOT___026457_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053936_))));
    vlSelf->wasmetal_core__DOT___071943_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071942_)))));
    vlSelf->__VdfgTmp_hea943ba9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d));
    vlSelf->wasmetal_core__DOT___057684_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010273_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hb5d0a138__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___055157_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 0xbU)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___007984_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007983_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)))));
    vlSelf->wasmetal_core__DOT___063167_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT___028223_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT___048836_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h840c74b0__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b12__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT___003809_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b12__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004105_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1f83dfd6__0)))))));
    vlSelf->__VdfgTmp_hc5a57f40__0 = (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007335_));
    vlSelf->wasmetal_core__DOT___010269_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007335_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007339_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007333_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007336_)))))))));
    vlSelf->wasmetal_core__DOT___045832_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 8U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001536_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 9U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he8f67c93__0))))))));
    vlSelf->wasmetal_core__DOT___068240_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053935_))));
    vlSelf->wasmetal_core__DOT___026456_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053935_))));
    vlSelf->wasmetal_core__DOT___071941_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071936_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071940_)))));
    vlSelf->wasmetal_core__DOT___042299_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h48afdd44__0))))))));
    vlSelf->__VdfgTmp_hdfdfbee0__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d));
    vlSelf->wasmetal_core__DOT___063955_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001524_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001425_))))));
    vlSelf->__VdfgTmp_h5b878e76__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b15__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b13__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d)));
    vlSelf->wasmetal_core__DOT___057683_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010282_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hdd9104ee__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT___007971_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007970_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hce5538fe__0)))));
    vlSelf->wasmetal_core__DOT___063161_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT___028222_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT___048775_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b11__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT___005982_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b11__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003511_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h07f42939__0)))))));
    vlSelf->__VdfgTmp_hdc04b3f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007302_));
    vlSelf->wasmetal_core__DOT___010278_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007306_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007303_)))))))));
    vlSelf->wasmetal_core__DOT___045831_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 6U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_haf096c00__0))))))));
    vlSelf->wasmetal_core__DOT___068155_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053934_))));
    vlSelf->wasmetal_core__DOT___026455_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053934_))));
    vlSelf->wasmetal_core__DOT___071939_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071934_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071938_)))));
    vlSelf->wasmetal_core__DOT___044357_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026934_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026935_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026936_)))));
    vlSelf->wasmetal_core__DOT___042357_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4143e379__0))))))));
    vlSelf->wasmetal_core__DOT___042156_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4143e379__0))))))));
    vlSelf->__VdfgTmp_h0e67285f__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d));
    vlSelf->wasmetal_core__DOT___063939_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001413_))));
    vlSelf->wasmetal_core__DOT___057682_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010291_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h9d768121__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___007963_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007962_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)))));
    vlSelf->wasmetal_core__DOT___063155_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT___028221_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT___048782_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4172973d__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b10__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT___006085_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4172973d__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b10__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003437_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d126061__0)))))));
    vlSelf->wasmetal_core__DOT___061451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007300_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007273_))));
    vlSelf->wasmetal_core__DOT___010288_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f333300ff5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007275_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007279_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007276_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007273_)))))))));
    vlSelf->wasmetal_core__DOT___056766_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007273_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011740_)))));
    vlSelf->wasmetal_core__DOT___050353_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050344_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050343_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050342_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003400_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003382_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003936_)))))))));
    vlSelf->wasmetal_core__DOT___068104_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053933_))));
    vlSelf->wasmetal_core__DOT___026485_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053933_))));
    vlSelf->wasmetal_core__DOT___044506_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000796_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000795_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8f3a812b__0))))))));
    vlSelf->__VdfgTmp_h4b9179fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8f3a812b__0));
    vlSelf->wasmetal_core__DOT___071932_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8f3a812b__0))));
    vlSelf->__VdfgTmp_hadcc7972__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d));
    vlSelf->wasmetal_core__DOT___057681_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010262_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h06dc5af9__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT___007955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063733_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (6U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5011624a__0))))));
    vlSelf->wasmetal_core__DOT___007954_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5011624a__0)))));
    vlSelf->wasmetal_core__DOT___063149_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT___028251_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT___048767_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b9__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT___006015_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b9__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003585_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h74bfec90__0)))))));
    vlSelf->__VdfgTmp_ha1697357__0 = (((IData)(vlSelf->wasmetal_core__DOT___007246_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007248_));
    vlSelf->__VdfgTmp_hf8763693__0 = (((IData)(vlSelf->wasmetal_core__DOT___007247_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007246_));
    vlSelf->wasmetal_core__DOT___068079_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053932_))));
    vlSelf->wasmetal_core__DOT___026484_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053932_))));
    vlSelf->wasmetal_core__DOT___071930_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6be648c5__0))));
    vlSelf->wasmetal_core__DOT___042298_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8f3a812b__0))))))));
    vlSelf->__VdfgTmp_h42e273c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d));
    vlSelf->wasmetal_core__DOT___063940_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001381_))))));
    vlSelf->wasmetal_core__DOT___057680_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010301_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_haa154e86__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d));
    vlSelf->wasmetal_core__DOT___055113_ = (1U & (0xbbbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             >> 7U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054745_))))));
    vlSelf->wasmetal_core__DOT___007947_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007946_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h30cac7a1__0)))));
    vlSelf->wasmetal_core__DOT___063143_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT___028250_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT___048739_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b8__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT___006092_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b8__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003733_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hbe250e1d__0)))))));
    vlSelf->wasmetal_core__DOT___061452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007431_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007246_))));
    vlSelf->__VdfgTmp_h5d6eeee4__0 = (((IData)(vlSelf->wasmetal_core__DOT___007881_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007431_));
    vlSelf->wasmetal_core__DOT___056539_ = (1U & (0x5f3f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011976_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007433_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___007431_)))))));
    vlSelf->wasmetal_core__DOT___068020_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053931_))));
    vlSelf->wasmetal_core__DOT___026483_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053931_))));
    vlSelf->wasmetal_core__DOT___044356_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___026994_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___026995_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___026996_)))));
    vlSelf->__VdfgTmp_h470ae9e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___011519_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011518_));
    vlSelf->wasmetal_core__DOT___065619_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___042356_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6be648c5__0))))))));
    vlSelf->wasmetal_core__DOT___042155_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6be648c5__0))))))));
    vlSelf->wasmetal_core__DOT___065607_ = (1U & (0x8000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d))))));
    vlSelf->__VdfgTmp_h8926b37c__0 = (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d))));
    vlSelf->wasmetal_core__DOT___063949_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___057678_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054746_))));
    vlSelf->wasmetal_core__DOT___010312_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h61294ca4__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b8__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT___007932_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007931_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5fd7d7a9__0)))));
    vlSelf->wasmetal_core__DOT___063137_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT___028249_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT___048752_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b7__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT___005875_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b7__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004549_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hb5c2181f__0)))))));
    vlSelf->wasmetal_core__DOT___062163_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007413_))));
    vlSelf->wasmetal_core__DOT___010308_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007415_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007413_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007412_)))))))));
    vlSelf->wasmetal_core__DOT___044505_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000748_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000747_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000771_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcbda1b46__0))))))));
    vlSelf->__VdfgTmp_hbe9a07d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hcbda1b46__0));
    vlSelf->wasmetal_core__DOT___067963_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053930_))));
    vlSelf->wasmetal_core__DOT___026482_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053930_))));
    vlSelf->__VdfgTmp_hf2f5c69c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d));
    vlSelf->wasmetal_core__DOT___063947_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->__VdfgTmp_h03893f91__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___007924_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___007923_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))));
    vlSelf->wasmetal_core__DOT___063131_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT___028248_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT___048892_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b6__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT___005745_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b6__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004401_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h3bba44d5__0)))))));
    vlSelf->wasmetal_core__DOT___010331_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007388_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007387_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007386_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007385_)))))))));
    vlSelf->wasmetal_core__DOT___045830_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->insn_y 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_y 
                                                                     >> 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfcd21fa2__0))))))));
    vlSelf->wasmetal_core__DOT___067897_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053929_))));
    vlSelf->wasmetal_core__DOT___026481_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053929_))));
    vlSelf->wasmetal_core__DOT___071929_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071924_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071928_)))));
    vlSelf->wasmetal_core__DOT___062054_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f333300ff5555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056324_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010552_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010860_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5555333300ff0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010918_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056425_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011125_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056436_)))))))))))));
    vlSelf->wasmetal_core__DOT___042297_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcbda1b46__0))))))));
    vlSelf->__VdfgTmp_h46c82ccf__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___063946_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->__VdfgTmp_hdbb03d5c__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d)));
    vlSelf->wasmetal_core__DOT___010323_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hbfd77ec1__0 = (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->wasmetal_core__DOT___007916_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___008018_))));
    vlSelf->wasmetal_core__DOT___063732_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3daf64ed__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hce5538fe__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (6U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)))))));
    vlSelf->wasmetal_core__DOT___007915_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007436_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2b4ef23a__0)))));
    vlSelf->wasmetal_core__DOT___063125_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053496_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT___028247_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052839_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT___048885_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1656da2e__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b5__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT___005921_ = (1U & ((~ 
                                                   (0xca00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___047996_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047995_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_product__05b5__05d)))
                                                      : 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___004327_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h4ff79496__0)))))));
    vlSelf->wasmetal_core__DOT___010319_ = ((IData)(vlSelf->wasmetal_core__DOT___007235_) 
                                            & (IData)(
                                                      (0xf0f0aaaaff00ccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___007204_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007234_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007362_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007361_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___007359_)))))))));
    vlSelf->wasmetal_core__DOT___001809_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h33bf650d__0))))));
    vlSelf->wasmetal_core__DOT___001900_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)))))));
    vlSelf->wasmetal_core__DOT___001949_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))))));
    vlSelf->wasmetal_core__DOT___001252_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d)))))));
    vlSelf->wasmetal_core__DOT___001677_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d)))))));
}
