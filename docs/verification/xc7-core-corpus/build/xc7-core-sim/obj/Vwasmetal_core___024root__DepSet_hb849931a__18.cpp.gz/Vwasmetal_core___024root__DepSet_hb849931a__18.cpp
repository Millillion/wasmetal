#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__24(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__24\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___006729_;
    wasmetal_core__DOT___006729_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___027405_;
    wasmetal_core__DOT___027405_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___033425_;
    wasmetal_core__DOT___033425_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034397_;
    wasmetal_core__DOT___034397_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___034558_;
    wasmetal_core__DOT___034558_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036630_;
    wasmetal_core__DOT___036630_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036842_;
    wasmetal_core__DOT___036842_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036843_;
    wasmetal_core__DOT___036843_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___036844_;
    wasmetal_core__DOT___036844_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044382_;
    wasmetal_core__DOT___044382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044758_;
    wasmetal_core__DOT___044758_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044767_;
    wasmetal_core__DOT___044767_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044770_;
    wasmetal_core__DOT___044770_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044779_;
    wasmetal_core__DOT___044779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___056735_;
    wasmetal_core__DOT___056735_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057091_;
    wasmetal_core__DOT___057091_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063192_;
    wasmetal_core__DOT___063192_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063198_;
    wasmetal_core__DOT___063198_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063204_;
    wasmetal_core__DOT___063204_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063210_;
    wasmetal_core__DOT___063210_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063216_;
    wasmetal_core__DOT___063216_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063222_;
    wasmetal_core__DOT___063222_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063228_;
    wasmetal_core__DOT___063228_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063234_;
    wasmetal_core__DOT___063234_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063522_;
    wasmetal_core__DOT___063522_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063530_;
    wasmetal_core__DOT___063530_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063538_;
    wasmetal_core__DOT___063538_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063546_;
    wasmetal_core__DOT___063546_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063679_;
    wasmetal_core__DOT___063679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063687_;
    wasmetal_core__DOT___063687_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063695_;
    wasmetal_core__DOT___063695_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063703_;
    wasmetal_core__DOT___063703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070657_;
    wasmetal_core__DOT___070657_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070660_;
    wasmetal_core__DOT___070660_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070663_;
    wasmetal_core__DOT___070663_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127436___O;
    wasmetal_core__DOT____Vcellout___127436___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127870___O;
    wasmetal_core__DOT____Vcellout___127870___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127970___O;
    wasmetal_core__DOT____Vcellout___127970___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128062___O;
    wasmetal_core__DOT____Vcellout___128062___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128063___O;
    wasmetal_core__DOT____Vcellout___128063___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128412___O;
    wasmetal_core__DOT____Vcellout___128412___O = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128413___O;
    wasmetal_core__DOT____Vcellout___128413___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_h5013759b__0;
    __VdfgTmp_h5013759b__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd2b66780__0;
    __VdfgTmp_hd2b66780__0 = 0;
    CData/*1:0*/ __VdfgTmp_h8a9ed06f__0;
    __VdfgTmp_h8a9ed06f__0 = 0;
    CData/*1:0*/ __VdfgTmp_h29c879e7__0;
    __VdfgTmp_h29c879e7__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___054520_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x13U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054522_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054521_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x14U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054524_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054523_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x15U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127831___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063616_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063615_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063624_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063623_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063632_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063631_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063640_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063639_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026374_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d));
    wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031941_));
    vlSelf->__VdfgTmp_h9cfb33d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___057090_) 
                                       << 2U) | ((2U 
                                                  & ((0x5300U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (1U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___012405_))))));
    vlSelf->__VdfgTmp_h3b8e8d7c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011091_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010085_)));
    vlSelf->__VdfgTmp_h7884ece4__0 = (((IData)(vlSelf->wasmetal_core__DOT___056772_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___056771_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0)));
    vlSelf->__VdfgTmp_hdf888c66__0 = (((IData)(vlSelf->wasmetal_core__DOT___011781_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h11d85c9f__0));
    vlSelf->wasmetal_core__DOT___067212_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___056988_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf4f4f4f4ffffff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012215_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_heceb31a8__0))))))));
    vlSelf->wasmetal_core__DOT___065919_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012214_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))));
    vlSelf->wasmetal_core__DOT___056906_ = (1U & (IData)(
                                                         (0xf0f000ee00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056892_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056891_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3659b78c__0))))))));
    vlSelf->wasmetal_core__DOT___057167_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012407_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h745845c2__0))));
    vlSelf->__VdfgTmp_h186e290b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010085_));
    vlSelf->__VdfgTmp_h07e757d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012574_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012607_));
    vlSelf->wasmetal_core__DOT___012752_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010407_)) 
                                                  & (IData)(
                                                            (0xccffaafff0fff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0))))))));
    vlSelf->wasmetal_core__DOT___012567_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x335500000f0fULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 3U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h4fcaab62__0)))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012558_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065323_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012818_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012809_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012810_)))))));
    vlSelf->wasmetal_core__DOT___066870_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057453_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012957_)))))));
    vlSelf->wasmetal_core__DOT___012883_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012957_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057454_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057453_)))))))));
    vlSelf->__VdfgTmp_h3545ce03__0 = (((IData)(vlSelf->wasmetal_core__DOT___057380_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xff00ccccf0f0aaaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012781_) 
                                                                    << 3U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0))))))));
    vlSelf->wasmetal_core__DOT___011907_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056716_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h3b7e1022__0)))))));
    vlSelf->wasmetal_core__DOT___068413_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hca606f65__0 = (((IData)(vlSelf->wasmetal_core__DOT___057381_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___012926_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___057380_))));
    vlSelf->__VdfgTmp_h4fe8c7bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___067094_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011425_)))))))));
    vlSelf->wasmetal_core__DOT___011679_ = (1U & (IData)(
                                                         (0xff110f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x330f0f0fff55ffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056599_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056600_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011426_)))))))));
    vlSelf->wasmetal_core__DOT___056605_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & (((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                               ? 
                                                              (0xf0f000eeU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011296_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011294_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))))
                                                               : 
                                                              (2U 
                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011295_))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                ? 
                                                               (0xf0f000eeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011428_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011426_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_hc7461e30__0)))))
                                                                : 
                                                               (2U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011427_)))))))));
    vlSelf->wasmetal_core__DOT___011556_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011550_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7461e30__0))));
    vlSelf->__VdfgTmp_hd6248a2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011656_));
    vlSelf->wasmetal_core__DOT___066990_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011130_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->__VdfgTmp_ha73aa920__0 = (((IData)(vlSelf->wasmetal_core__DOT___011128_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___065632_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac971038__0))));
    vlSelf->wasmetal_core__DOT___056482_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xffff4444fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011081_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011080_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))));
    vlSelf->wasmetal_core__DOT___011025_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010406_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___012388_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hfde06fd4__0)))))));
    vlSelf->wasmetal_core__DOT___013114_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013035_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4aee2d94__0))));
    vlSelf->wasmetal_core__DOT___066912_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057663_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057664_)))))));
    vlSelf->__VdfgTmp_h4d745f43__0 = (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012559_));
    vlSelf->wasmetal_core__DOT___013187_ = (1U & (IData)(
                                                         (0xf0feeee00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057537_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057664_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057663_)))))))));
    vlSelf->__VdfgTmp_ha052db73__0 = ((2U & ((IData)(
                                                     (0xff00ccccf0f0aaaaULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013057_) 
                                                              << 3U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057627_));
    vlSelf->wasmetal_core__DOT___012255_ = (1U & (IData)(
                                                         (0xf0f0cccc00aa00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012106_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25b48e48__0)))))));
    vlSelf->wasmetal_core__DOT___068166_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065822_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___011678_ = (1U & (0x3a00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056668_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0x30303000aa0000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056598_))))))))))))));
    vlSelf->wasmetal_core__DOT___066295_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf218f314__0))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128549___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033480_)))));
    vlSelf->wasmetal_core__DOT___033421_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128549___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___036632_ = (1U & (IData)(
                                                         (0x188e7118e7718ee7ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072167_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))))));
    __VdfgTmp_h5013759b__0 = ((2U & ((0x69969669U >> 
                                      ((0x10U & ((1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                 << 4U)) 
                                       | (((IData)(vlSelf->wasmetal_core__DOT___072217_) 
                                           << 3U) | (IData)(vlSelf->__VdfgTmp_h15cdecdf__0)))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xbfab2a022a02bfabULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___072212_) 
                                                             << 5U) 
                                                            | ((0x10U 
                                                                & ((9U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha7d2f4a8__0)) 
                                                                   << 4U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___072198_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072199_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0x96U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h39564552__0)) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (0xb2U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h39564552__0))))))))))));
    wasmetal_core__DOT___036842_ = (1U & (0x4db2U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___036629_) 
                                            << 3U) 
                                           | (IData)(vlSelf->__VdfgTmp_h1399f995__0))));
    wasmetal_core__DOT___036630_ = (1U & (0x96U >> 
                                          ((4U & ((0xe8U 
                                                   >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                  << 2U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___072213_)))));
    wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030100_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030067_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030228_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030163_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b16__05d));
    wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036976_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)
                  : (0x96U >> (IData)(vlSelf->__VdfgTmp_h009676e6__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128183___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029585_)))));
    vlSelf->wasmetal_core__DOT___029589_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128285___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128183___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128286___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030660_)))));
    vlSelf->wasmetal_core__DOT___017453_ = (1U & (IData)(
                                                         (0xf351000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___017452_ = (1U & (IData)(
                                                         (0xb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058852_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058851_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058850_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b25__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006099_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127618___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127602___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___023904_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d) {
        vlSelf->wasmetal_core__DOT___024031_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024031_ = vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023904_;
    }
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___013775_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___013783_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___013778_))))))))));
    vlSelf->wasmetal_core__DOT___057757_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013783_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013740_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___059134_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059111_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059110_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059109_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005875_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___059162_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059158_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059157_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059156_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b23__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006106_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127487___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127479___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d)) 
                                                    << 1U)) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___022885_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) {
        vlSelf->wasmetal_core__DOT___022948_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022948_ = vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022885_;
    }
    wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128412___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128284___S) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032030_)))));
    vlSelf->wasmetal_core__DOT___032003_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128412___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044908_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127852___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026461_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026427_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d));
    vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036770_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h17547017__0))));
    wasmetal_core__DOT____Vcellout___128062___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028295_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028294_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028293_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028292_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028258_)))));
    vlSelf->wasmetal_core__DOT___028262_ = ((IData)(vlSelf->wasmetal_core__DOT___028295_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128062___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028230_));
    vlSelf->wasmetal_core__DOT___045494_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071353_))))))));
    vlSelf->wasmetal_core__DOT___045518_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071355_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071354_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071353_)))))))));
    vlSelf->wasmetal_core__DOT___045290_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071416_))))))));
    vlSelf->wasmetal_core__DOT___045314_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127868___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071418_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071417_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071416_)))))))));
    wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026569_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026502_)
            : (IData)(vlSelf->wasmetal_core__DOT___001613_));
    vlSelf->wasmetal_core__DOT____Vcellout___128350___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031340_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031339_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031338_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031337_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031304_)))));
    vlSelf->wasmetal_core__DOT___031308_ = ((IData)(vlSelf->wasmetal_core__DOT___031340_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128350___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034331_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034497_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127954___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027339_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027338_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027337_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027336_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027270_)))));
    vlSelf->wasmetal_core__DOT___027274_ = ((IData)(vlSelf->wasmetal_core__DOT___027339_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127954___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b15__05d));
    wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_z >> 0x1cU) & (IData)(vlSelf->wasmetal_core__DOT___027948_));
    wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__ 
        = (1U & ((0x10000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1cU)
                  : (IData)(vlSelf->wasmetal_core__DOT___030483_)));
    wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032884_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027819_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d));
    vlSelf->wasmetal_core__DOT___067075_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067153_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067194_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___066970_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128056___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__ 
        = ((vlSelf->insn_x >> 0x1cU) & (IData)(vlSelf->wasmetal_core__DOT___028174_));
    vlSelf->wasmetal_core__DOT____Vcellout___128047___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028106_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028105_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028104_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028103_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028069_)))));
    vlSelf->wasmetal_core__DOT___028074_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028106_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___128047___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x17U)));
    vlSelf->wasmetal_core__DOT___044766_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_locals 
                                                               >> 0x12U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                        << 1U)) 
                                                                    | (3U 
                                                                       & (vlSelf->function_locals 
                                                                          >> 0x18U)))))))));
    vlSelf->wasmetal_core__DOT___044778_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                               << 4U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x15U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->function_locals 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128319___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (vlSelf->function_locals 
                                                                             >> 0x17U))))))))));
    wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__ 
        = ((~ (vlSelf->function_params >> 0x1cU)) & (IData)(vlSelf->wasmetal_core__DOT___030965_));
    vlSelf->wasmetal_core__DOT___044811_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___044799_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070654_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070652_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O))))))))));
    wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032692_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037202_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h4679be83__0))));
    vlSelf->wasmetal_core__DOT___063621_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063616_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b20__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O))))))));
    vlSelf->wasmetal_core__DOT___063629_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063624_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b21__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063637_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063632_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b22__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063645_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063640_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b23__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128495___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026375_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d));
    wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b17__05d) {
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b17__05d;
    } else {
        wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__sp__05b18__05d) {
        wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b18__05d;
    } else {
        wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___067326_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9cfb33d2__0)))));
    vlSelf->wasmetal_core__DOT___067172_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h7884ece4__0))))));
    wasmetal_core__DOT___056735_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                    & (IData)((0xf4f4f4f4ffffff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011782_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hdf888c66__0)))))));
    vlSelf->wasmetal_core__DOT___012206_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056988_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056987_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xfaf3U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b3d01ff__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056985_)))))))));
    vlSelf->wasmetal_core__DOT___065920_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065919_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012216_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012215_)))))));
    vlSelf->__VdfgTmp_h895eb4d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___057167_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xff110f0f00000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057161_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011047_)))))))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x503U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h1c56b6c5__0)))))));
    vlSelf->wasmetal_core__DOT___066103_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h186e290b__0))));
    vlSelf->__VdfgTmp_h4eea07db__0 = (((IData)(vlSelf->wasmetal_core__DOT___012752_) 
                                       << 3U) | ((((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                   & (IData)(
                                                             (0x55550f0f00ff3333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011302_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011301_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011432_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___011299_))))))))) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___012558_))));
    vlSelf->wasmetal_core__DOT___065210_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h07056034__0))))));
    vlSelf->wasmetal_core__DOT___067913_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012567_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___057330_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                           & (IData)(
                                                                     (0xff33ff00f0f0f5f5ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012576_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___012608_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h07e757d2__0)))))))) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057322_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xf0feU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2163f181__0)) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057320_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012567_)
                                                                    : 
                                                                   (1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h07056034__0)))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012620_))))))))));
    vlSelf->wasmetal_core__DOT___067472_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3545ce03__0)))));
    vlSelf->wasmetal_core__DOT___012894_ = (1U & (IData)(
                                                         (0xf0f0ccaa00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057447_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3545ce03__0))))))));
    vlSelf->wasmetal_core__DOT___011949_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011907_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    __VdfgTmp_h8a9ed06f__0 = (((IData)(vlSelf->wasmetal_core__DOT___011908_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011907_));
    vlSelf->wasmetal_core__DOT___066148_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))));
    vlSelf->wasmetal_core__DOT___057397_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012452_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xf0fff1100000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                           << 4U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hca606f65__0))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((0xf4U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___057388_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & (((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                                             & (IData)(
                                                                                (0xff00ffaafff0fff3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012804_))))))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___057386_))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT___010376_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                                    ? (IData)(vlSelf->wasmetal_core__DOT___012818_)
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012810_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012809_))))
                                                                   : 
                                                                  (2U 
                                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012811_))))))))));
    vlSelf->wasmetal_core__DOT___065719_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haf8803a1__0))))));
    vlSelf->wasmetal_core__DOT___068115_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011556_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    if (vlSelf->wasmetal_core__DOT___010376_) {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___011556_)
                                                    : 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_haf8803a1__0))));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (0xf0f000eeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011951_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011949_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h5d9b5f2a__0))))));
    } else {
        vlSelf->wasmetal_core__DOT___056628_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011549_)));
        vlSelf->wasmetal_core__DOT___056783_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011950_)));
    }
    vlSelf->wasmetal_core__DOT___064529_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd6248a2d__0))));
    vlSelf->wasmetal_core__DOT___068090_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___065632_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->wasmetal_core__DOT___056483_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056482_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hf72e2656__0)))))));
    vlSelf->wasmetal_core__DOT___056464_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0xf0f00ff11111111ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011024_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he19177ad__0))))))));
    __VdfgTmp_hd2b66780__0 = (((IData)(vlSelf->wasmetal_core__DOT___011025_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011024_));
    vlSelf->__VdfgTmp_h8267970c__0 = (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012387_));
    wasmetal_core__DOT___057091_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012388_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___065434_ = (1U & (0xf00eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013114_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8088f5ad__0))))));
    vlSelf->wasmetal_core__DOT___057542_ = (1U & (IData)(
                                                         (0x5f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057538_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4d745f43__0))))))));
    vlSelf->wasmetal_core__DOT___057661_ = (1U & (IData)(
                                                         (0xfafc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha052db73__0))))))));
    vlSelf->wasmetal_core__DOT___056908_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010407_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012255_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_he65514a2__0 = (((IData)(vlSelf->wasmetal_core__DOT___012256_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012255_));
    vlSelf->wasmetal_core__DOT___011076_ = (1U & (0xcfaf0000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128549___O))))))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033421_));
    vlSelf->wasmetal_core__DOT___036845_ = (1U & (0xb4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036632_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h5013759b__0))));
    wasmetal_core__DOT___036844_ = (1U & (0x8e71U >> 
                                          ((8U & ((9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0)) 
                                                  << 3U)) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___072214_) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((0xe8U 
                                                      >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___072213_))))));
    wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__ 
        = ((IData)(wasmetal_core__DOT___036842_) ? (IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036629_));
    wasmetal_core__DOT___036843_ = (1U & (IData)((0x8ee8e88e71171771ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___036630_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072203_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072202_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x69U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h84670069__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x17U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___072201_)))))))));
    wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030101_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030229_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b17__05d));
    wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036977_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036651_));
    vlSelf->wasmetal_core__DOT___063588_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___063596_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___063604_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___063612_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128151___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029589_));
    vlSelf->wasmetal_core__DOT___030664_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128286___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030664_));
    vlSelf->wasmetal_core__DOT___030699_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___030699_));
    vlSelf->wasmetal_core__DOT___031945_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___031945_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d) {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024031_;
        vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__;
    }
    vlSelf->__VdfgTmp_h8e8edf3a__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_h674d61dd__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_haa9bafe9__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hc2de3b41__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127602___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT____Vcellout___127435___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hbc1c04e5__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022565_)))));
    vlSelf->wasmetal_core__DOT___022506_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013786_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022948_;
        vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__;
    }
    vlSelf->__VdfgTmp_h7e209046__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005935_));
    vlSelf->__VdfgTmp_he1214f4e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005716_));
    vlSelf->__VdfgTmp_he2a95d7a__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005928_));
    vlSelf->__VdfgTmp_hae3fb8cb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127479___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005731_));
    vlSelf->wasmetal_core__DOT____Vcellout___127464___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013690_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3f696fc8__0))) 
           ^ (((IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127464___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022741_)))));
    vlSelf->wasmetal_core__DOT___022722_ = ((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                            & (IData)(wasmetal_core__DOT___127464___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006029_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127455___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005982_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006204_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022671_)))));
    vlSelf->wasmetal_core__DOT___022652_ = ((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___063522_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063530_ = (1U & (8U >> ((2U 
                                                  & (IData)(wasmetal_core__DOT____Vcellout___128412___O)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063538_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    wasmetal_core__DOT___063546_ = (1U & (8U >> ((2U 
                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128412___O) 
                                                     >> 2U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032003_));
    vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026462_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d));
    vlSelf->wasmetal_core__DOT___036739_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036771_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134156___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2b80e318__0))));
    wasmetal_core__DOT___063192_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063198_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063204_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128062___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063210_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128062___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128080___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028297_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028262_)
            : (IData)(vlSelf->wasmetal_core__DOT___028232_));
    wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026570_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001625_));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031342_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031308_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034332_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034498_) 
           & (IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___127970___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___027466_)))));
    wasmetal_core__DOT___027405_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127953___O) 
                                     >> 3U) & (IData)(vlSelf->wasmetal_core__DOT___127970___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027340_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027274_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b16__05d));
    wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 0x1dU) & (IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20000000U & vlSelf->mem_rdata[0U])
                  ? (vlSelf->mem_rdata[0U] >> 0x1dU)
                  : (IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128488___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032885_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032884_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032883_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032882_)))) 
           ^ (((IData)(wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128488___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032849_)))));
    vlSelf->wasmetal_core__DOT___032853_ = ((IData)(vlSelf->wasmetal_core__DOT___032885_)
                                             ? (IData)(wasmetal_core__DOT___128488___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128016___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027820_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027819_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027818_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027817_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027784_)))));
    vlSelf->wasmetal_core__DOT___027788_ = ((IData)(vlSelf->wasmetal_core__DOT___027820_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128016___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d));
    vlSelf->wasmetal_core__DOT___067078_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067075_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054135_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x18U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067156_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067153_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054158_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x19U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067197_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067194_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054162_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___066973_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066970_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054131_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x17U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 0x1dU) & (IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028107_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028074_)
                  : (vlSelf->insn_x >> 0x18U)));
    wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 0x1dU)) & (IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128472___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032693_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032692_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h42a8fe82__0))) 
           ^ (((IData)(wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128472___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032657_)))));
    vlSelf->wasmetal_core__DOT___032661_ = ((IData)(vlSelf->wasmetal_core__DOT___032693_)
                                             ? (IData)(wasmetal_core__DOT___128472___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134214___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037203_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037202_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037201_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037200_)))) 
           ^ (((IData)(wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134214___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037168_)))));
    vlSelf->wasmetal_core__DOT___037172_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037203_)
                                                   ? (IData)(wasmetal_core__DOT___134214___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4312483e__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127848___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026376_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026375_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026374_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026373_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026340_)))));
    vlSelf->wasmetal_core__DOT___026344_ = ((IData)(vlSelf->wasmetal_core__DOT___026376_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127848___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128174___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
           ^ (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128174___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029479_)))));
    vlSelf->wasmetal_core__DOT___029483_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128174___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128294___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128294___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128294___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030695_)))));
    vlSelf->wasmetal_core__DOT___056736_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___056735_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he54a047f__0)))))));
    vlSelf->wasmetal_core__DOT___012451_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h895eb4d9__0)))));
    vlSelf->wasmetal_core__DOT___066787_ = (1U & (IData)(
                                                         (0xff0000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h4eea07db__0))))));
    vlSelf->wasmetal_core__DOT___012899_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012895_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012894_)))));
    vlSelf->wasmetal_core__DOT___056887_ = (1U & (IData)(
                                                         (0xff11f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x30303000aa0000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011955_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056769_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011949_)))))))));
    vlSelf->wasmetal_core__DOT___064775_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h8a9ed06f__0))));
    vlSelf->wasmetal_core__DOT___056860_ = (1U & (IData)(
                                                         (0xf0f3f0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___056750_ = ((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                            & (IData)(
                                                      (0x33335555000f000fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011910_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011909_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h8a9ed06f__0))))))));
    vlSelf->wasmetal_core__DOT___064540_ = (1U & (0xf0011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064529_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h95aabd6f__0))))));
    vlSelf->wasmetal_core__DOT___064018_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hd2b66780__0))));
    vlSelf->wasmetal_core__DOT___056389_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056388_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff00fff400000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011082_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdab8ca95__0))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f5f0f300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                                                << 2U) 
                                                                                | (IData)(__VdfgTmp_hd2b66780__0))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff8000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056384_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfb2d71e__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057177_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8267970c__0))));
    vlSelf->wasmetal_core__DOT___012476_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xccaaf0f0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012387_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h7d32537f__0))))))))));
    vlSelf->wasmetal_core__DOT___057099_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011743_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___057091_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011026_)))));
    vlSelf->wasmetal_core__DOT___066619_ = (1U & (IData)(
                                                         (0xf0f0000ff11ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019385_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056909_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012256_)))))))));
    vlSelf->wasmetal_core__DOT___057046_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056908_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012559_)))));
    vlSelf->wasmetal_core__DOT___012171_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he65514a2__0))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__ 
        = ((IData)(wasmetal_core__DOT___036843_) ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__)
            : (IData)(wasmetal_core__DOT___036630_));
    wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030102_)
            ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030230_)
            ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d));
    wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036978_)
            ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036652_));
    vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b21__05d) {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b21__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d) {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d;
        wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___058863_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->wasmetal_core__DOT___023774_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___058900_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d))));
    vlSelf->wasmetal_core__DOT___023763_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d))));
    vlSelf->wasmetal_core__DOT___058914_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h674d61dd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0))))));
    vlSelf->wasmetal_core__DOT___023752_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))));
    vlSelf->wasmetal_core__DOT___023741_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d))));
    vlSelf->__VdfgTmp_hb514b790__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h41acf677__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_hb6ef8d81__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)))))));
    vlSelf->__VdfgTmp_hc21b3046__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006015_));
    vlSelf->__VdfgTmp_h9fa4f51d__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006085_));
    vlSelf->__VdfgTmp_h41461f4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127435___O) 
                                                                >> 3U)))))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022506_));
    vlSelf->wasmetal_core__DOT____Vcellout___127575___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h097d2f7b__0))) 
           ^ (((IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023618_)))));
    vlSelf->wasmetal_core__DOT___023570_ = ((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                            & (IData)(wasmetal_core__DOT___127575___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d;
        wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___022810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))))));
    vlSelf->wasmetal_core__DOT___059176_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))))));
    vlSelf->wasmetal_core__DOT___022797_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))))));
    vlSelf->wasmetal_core__DOT___022786_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02eunit_bit__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))))));
    vlSelf->__VdfgTmp_h87a694d3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013690_));
    vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013654_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022722_));
    vlSelf->wasmetal_core__DOT____Vcellout___127558___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___006051_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006058_)))) 
           ^ (((IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023497_)))));
    vlSelf->wasmetal_core__DOT___023449_ = ((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                            & (IData)(wasmetal_core__DOT___127558___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___006635_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___003810_))))));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022652_));
    vlSelf->wasmetal_core__DOT___063523_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063522_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063521_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063531_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063529_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063539_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063538_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063537_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063547_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063546_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063545_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128292___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026463_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d));
    vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036772_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036739_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hf6334cf8__0))));
    vlSelf->wasmetal_core__DOT___063195_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063192_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001612_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063191_)))))));
    vlSelf->wasmetal_core__DOT___063201_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063198_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001624_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063197_)))))));
    vlSelf->wasmetal_core__DOT___063207_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063204_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063203_)))))));
    vlSelf->wasmetal_core__DOT___063213_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063210_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063209_)))))));
    vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028298_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028233_));
    wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026571_)
            ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001647_));
    vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031343_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128644___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034333_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034332_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034331_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034330_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034393_)))));
    wasmetal_core__DOT___034397_ = ((IData)(vlSelf->wasmetal_core__DOT___034333_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128644___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128660___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034499_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034498_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034497_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034496_)))) 
           ^ (((IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128660___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034554_)))));
    wasmetal_core__DOT___034558_ = ((IData)(vlSelf->wasmetal_core__DOT___034499_) 
                                    & (IData)(wasmetal_core__DOT___128660___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044885_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                       << 1U)) 
                                                   | ((2U 
                                                       & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                          >> 1U)) 
                                                      | (1U 
                                                         & ((IData)(wasmetal_core__DOT____Vcellout___127970___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___044884_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127969___O) 
                                                          >> 2U)) 
                                                      | (1U 
                                                         & (IData)(wasmetal_core__DOT____Vcellout___127970___O))))));
    wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           & (IData)(wasmetal_core__DOT___027405_));
    wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027341_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b17__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128033___O 
        = (0xfU & ((vlSelf->insn_z >> 0x1cU) ^ ((0x18U 
                                                 & ((vlSelf->insn_z 
                                                     >> 0x1bU) 
                                                    & ((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__) 
                                                       << 3U))) 
                                                | (((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128033___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___027948_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128273___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0x1fU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0x1eU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 0x1dU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 0x1cU)))))) 
           ^ ((8U & (((0x40000000U & vlSelf->mem_rdata[0U])
                       ? (vlSelf->mem_rdata[0U] >> 0x1eU)
                       : (IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(wasmetal_core__DOT___128273___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___030483_)))));
    vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032886_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032853_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___062881_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x18U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062873_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O))))))));
    vlSelf->wasmetal_core__DOT___062892_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x19U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062884_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062903_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1aU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062895_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062914_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128016___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1bU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128169___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128024___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027821_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027788_)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d));
    vlSelf->wasmetal_core__DOT___066977_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066973_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066972_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066971_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128057___O 
        = (0xfU & ((vlSelf->insn_x >> 0x1cU) ^ ((0x18U 
                                                 & ((vlSelf->insn_x 
                                                     >> 0x1bU) 
                                                    & ((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__) 
                                                       << 3U))) 
                                                | (((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__1__KET__) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___128057___DOT__CO__BRA__0__KET__) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___028174_))))));
    wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028108_)
                  ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x19U)));
    vlSelf->wasmetal_core__DOT____Vcellout___128321___O 
        = (((8U & ((~ (vlSelf->function_params >> 0x1fU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->function_params 
                                         >> 0x1eU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->function_params 
                                                      >> 0x1dU)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->function_params 
                                                       >> 0x1cU)))))) 
           ^ ((((~ (vlSelf->function_params >> 0x1eU)) 
                & (IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128321___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030965_)))));
    vlSelf->wasmetal_core__DOT___070655_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O))))));
    vlSelf->wasmetal_core__DOT___070658_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                            >> 3U))))));
    vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032694_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032661_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037204_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___037172_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hbc309d1b__0))));
    vlSelf->wasmetal_core__DOT___054525_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054527_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054529_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054531_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128599___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127840___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___063647_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063655_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___063671_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    vlSelf->wasmetal_core__DOT___044381_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                     << 2U)) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127847___O) 
                                                                          >> 2U)))))))));
    vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026377_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026344_)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128406___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128406___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031941_)))));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029483_));
    vlSelf->wasmetal_core__DOT___067742_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064017_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064775_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012559_))))));
    vlSelf->__VdfgTmp_hb961a9be__0 = (((IData)(vlSelf->wasmetal_core__DOT___011026_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057177_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((0xc0aU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h7d32537f__0)))) 
                                                        << 1U)) 
                                                    | (1U 
                                                       & (IData)(
                                                                 (0xf0fe00000000ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057174_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057162_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___011047_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))))))));
    vlSelf->wasmetal_core__DOT___012166_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___011026_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012171_))
                                                   : 
                                                  (0xf0faf0fcU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xf0fe00000000ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056962_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012221_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012218_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h75e79c91__0)))))));
    vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___134164___O 
        = ((((IData)(wasmetal_core__DOT___036844_) 
             << 3U) | (((IData)(wasmetal_core__DOT___036843_) 
                        << 2U) | (((IData)(wasmetal_core__DOT___036842_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036841_)))) 
           ^ (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___134164___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___036837_ = (1U & ((IData)(wasmetal_core__DOT___036844_)
                                                   ? (IData)(wasmetal_core__DOT___134164___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(__VdfgTmp_h5013759b__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128235___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030103_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030102_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030101_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030100_)))) 
           ^ (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030067_)))));
    vlSelf->wasmetal_core__DOT___030071_ = ((IData)(vlSelf->wasmetal_core__DOT___030103_)
                                             ? (IData)(wasmetal_core__DOT___128235___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128249___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030231_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030230_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030229_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030228_)))) 
           ^ (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030163_)))));
    vlSelf->wasmetal_core__DOT___030167_ = ((IData)(vlSelf->wasmetal_core__DOT___030231_)
                                             ? (IData)(wasmetal_core__DOT___128249___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134183___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036979_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036978_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036977_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036976_)))) 
           ^ (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0)))));
    vlSelf->wasmetal_core__DOT___036972_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036979_)
                                                   ? (IData)(wasmetal_core__DOT___134183___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hab776b02__0))));
    wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b22__05d) {
        wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
        wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b22__05d;
    } else {
        wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___023931_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023931_ = wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___023741_)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT___023230_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___006092_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb6ef8d81__0)))));
    vlSelf->wasmetal_core__DOT___023229_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc21b3046__0))));
    vlSelf->wasmetal_core__DOT___023228_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9fa4f51d__0))));
    vlSelf->wasmetal_core__DOT___023227_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005982_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h41461f4e__0)))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003810_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h8ac5901b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013787_));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013785_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023570_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
        vlSelf->wasmetal_core__DOT___022889_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d;
    } else {
        wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022889_ = wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___022786_)) 
                 & (1U >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0))));
    wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013648_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050115_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006051_))))));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005948_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023449_));
    vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127854___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026464_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026463_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026462_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026461_)))) 
           ^ (((IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127854___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026427_)))));
    vlSelf->wasmetal_core__DOT___026431_ = ((IData)(vlSelf->wasmetal_core__DOT___026464_)
                                             ? (IData)(wasmetal_core__DOT___127854___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d));
    wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036773_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h4835143f__0))));
    wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028299_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028234_));
    wasmetal_core__DOT____Vcellout___127870___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___026572_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___026571_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___026570_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026569_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___026502_)))));
    vlSelf->wasmetal_core__DOT___026506_ = ((IData)(vlSelf->wasmetal_core__DOT___026572_)
                                             ? (IData)(wasmetal_core__DOT___127870___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000420_));
    wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031344_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034334_) 
           & (IData)(wasmetal_core__DOT___034397_));
    wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034500_) 
           & (IData)(wasmetal_core__DOT___034558_));
    wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027342_)
            ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b18__05d));
    wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032887_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027822_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d));
    vlSelf->wasmetal_core__DOT___067312_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067454_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067342_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048277_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000358_)))))))));
    vlSelf->wasmetal_core__DOT___067478_ = (1U & (0x7077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128057___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000358_))))));
    wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028109_)
                  ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 0x1aU)));
    wasmetal_core__DOT___044758_ = (1U & (IData)((0xc8e8ecf0c8e0c8eULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (vlSelf->function_locals 
                                                       >> 0x18U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                          << 3U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                                >> 1U)) 
                                                            | (vlSelf->function_locals 
                                                               >> 0x1eU))))))));
    wasmetal_core__DOT___044770_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & (vlSelf->function_locals 
                                                          >> 0x1bU)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                             << 1U)) 
                                                         | ((4U 
                                                             & (vlSelf->function_locals 
                                                                >> 0x1cU)) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O)) 
                                                               | (1U 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x1dU))))))))));
    wasmetal_core__DOT___044767_ = (1U & (IData)((0xc8e8ecf0c8e0c8eULL 
                                                  >> 
                                                  ((0x20U 
                                                    & (vlSelf->function_locals 
                                                       >> 0x15U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                                << 2U)) 
                                                            | (3U 
                                                               & (vlSelf->function_locals 
                                                                  >> 0x1bU)))))))));
    wasmetal_core__DOT___044779_ = (1U & (IData)((0x9009000000009009ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128321___O) 
                                                       << 5U)) 
                                                   | ((0x10U 
                                                       & (vlSelf->function_locals 
                                                          >> 0x18U)) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O)) 
                                                         | ((4U 
                                                             & (vlSelf->function_locals 
                                                                >> 0x19U)) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128320___O) 
                                                                   >> 1U)) 
                                                               | (1U 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x1aU))))))))));
    wasmetal_core__DOT___070657_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070655_)))))))));
    wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032695_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037205_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h09206f3f__0))));
    vlSelf->wasmetal_core__DOT___054526_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054525_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x16U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054528_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054527_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x17U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054530_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054529_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x18U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054532_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x19U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127832___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063648_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063647_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063656_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063655_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063664_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063663_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063672_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063671_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026378_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128550___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033421_)))));
    wasmetal_core__DOT___033425_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d)) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___128550___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036845_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036837_)
            : (IData)(vlSelf->wasmetal_core__DOT___036632_));
    wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030105_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030071_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030233_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030167_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d));
    vlSelf->wasmetal_core__DOT___064905_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064472_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___064737_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134183___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036980_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036972_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h935fcb03__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128184___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
           ^ (((IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128184___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029589_)))));
    vlSelf->wasmetal_core__DOT___029593_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128286___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___128184___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128287___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128287___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030664_)))));
    if (vlSelf->wasmetal_core__DOT__sp__05b23__05d) {
        vlSelf->wasmetal_core__DOT___030669_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
        vlSelf->wasmetal_core__DOT___031950_ = vlSelf->wasmetal_core__DOT__sp__05b23__05d;
    } else {
        vlSelf->wasmetal_core__DOT___030669_ = wasmetal_core__DOT___128287___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___030704_ = vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___031950_ = wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127625___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127625___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024031_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d) {
        vlSelf->wasmetal_core__DOT___024058_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024058_ = wasmetal_core__DOT___127625___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023931_;
    }
    vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023752_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127609___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127609___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127609___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023904_)))));
    vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057759_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127488___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127488___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022948_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) {
        vlSelf->wasmetal_core__DOT___022952_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d;
    } else {
        vlSelf->wasmetal_core__DOT___022952_ = wasmetal_core__DOT___127488___DOT__CO__BRA__2__KET__;
        wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022889_;
    }
    vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022797_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he2a95d7a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127480___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127480___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127480___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022885_)))));
    wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013666_) 
           & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005809_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006092_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT____Vcellout___128413___O = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128285___S) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128413___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___032003_)))));
    vlSelf->wasmetal_core__DOT___032007_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)
                                             : (IData)(wasmetal_core__DOT___128413___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___032007_));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___032011_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026466_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026431_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d));
    wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036774_)
                  ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h93f91ca8__0))));
    wasmetal_core__DOT____Vcellout___128063___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028300_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028299_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028298_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028297_)))) 
                                                   ^ 
                                                   (((IData)(wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128063___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028262_)))));
    vlSelf->wasmetal_core__DOT___028267_ = ((IData)(vlSelf->wasmetal_core__DOT___028300_)
                                             ? (IData)(wasmetal_core__DOT___128063___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028235_));
    vlSelf->wasmetal_core__DOT___045496_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071359_))))))));
    vlSelf->wasmetal_core__DOT___045520_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071361_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071360_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071359_)))))))));
    vlSelf->wasmetal_core__DOT___045495_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045519_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071358_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071357_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071356_)))))))));
    vlSelf->wasmetal_core__DOT___045292_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___127870___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071422_))))))));
    vlSelf->wasmetal_core__DOT___045316_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071424_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071422_)))))))));
    vlSelf->wasmetal_core__DOT___045291_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___045315_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071421_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127869___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071420_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(wasmetal_core__DOT____Vcellout___127870___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071419_)))))))));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026574_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026506_)
            : (IData)(vlSelf->wasmetal_core__DOT___000433_));
    vlSelf->wasmetal_core__DOT____Vcellout___128351___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___031345_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___031344_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___031343_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031342_)))) 
           ^ (((IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128351___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031308_)))));
    vlSelf->wasmetal_core__DOT___031313_ = ((IData)(vlSelf->wasmetal_core__DOT___031345_)
                                             ? (IData)(wasmetal_core__DOT___128351___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034335_) 
           & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034501_) 
           & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127955___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027343_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027342_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027341_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027340_)))) 
           ^ (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027274_)))));
    vlSelf->wasmetal_core__DOT___027278_ = ((IData)(vlSelf->wasmetal_core__DOT___027343_)
                                             ? (IData)(wasmetal_core__DOT___127955___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b19__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128489___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032890_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032889_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032887_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032886_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032889_)
                 ? (IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032853_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128017___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027825_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027824_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027822_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027821_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___027824_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128017___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027788_)))));
    vlSelf->wasmetal_core__DOT___067314_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067312_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054166_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1bU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067456_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067454_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054174_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1dU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067344_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067342_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (vlSelf->insn_imm[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___053485_)))))));
    vlSelf->wasmetal_core__DOT___067482_ = (1U & (0x70U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xd000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___067479_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067478_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067477_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((4U 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___000359_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054178_))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053485_) 
                                                                              << 1U) 
                                                                             | (vlSelf->insn_imm[0U] 
                                                                                >> 0x1fU)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128048___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028110_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028109_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028108_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028107_)))) 
           ^ (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028074_)))));
    vlSelf->wasmetal_core__DOT___028078_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028110_)
                                                   ? (IData)(wasmetal_core__DOT___128048___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (vlSelf->insn_x 
                                                   >> 0x1bU)));
    vlSelf->wasmetal_core__DOT___044747_ = ((IData)(wasmetal_core__DOT___044770_)
                                             ? ((IData)(wasmetal_core__DOT___044779_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___044778_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___044777_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044776_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044775_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044774_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044773_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044772_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044771_)
                                                         ? 
                                                        ((~ (IData)(vlSelf->wasmetal_core__DOT___044769_)) 
                                                         & (IData)(vlSelf->wasmetal_core__DOT___044757_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044759_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044760_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044761_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044762_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044763_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044764_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044765_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___044766_))
                                                 : (IData)(wasmetal_core__DOT___044767_))
                                             : (IData)(wasmetal_core__DOT___044758_));
    vlSelf->wasmetal_core__DOT___044812_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070657_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT___044800_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070657_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134213___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070655_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128471___O) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128473___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032698_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032697_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032695_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032694_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___032697_)
                 ? (IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128473___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128473___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032661_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___134215___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037208_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037207_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037205_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___037204_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___037207_)
                       ? (IData)(wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__)
                       : (6U >> (IData)(vlSelf->__VdfgTmp_h08c26bfc__0))) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___134215___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134215___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___037172_)))));
    vlSelf->wasmetal_core__DOT___063653_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063648_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b24__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O))))))));
    vlSelf->wasmetal_core__DOT___063661_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b25__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063669_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063664_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b26__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063677_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063672_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b27__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128496___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127849___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026381_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026380_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026378_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026377_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___026380_)
                 ? (IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127849___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026344_)))));
    vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___012774_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011740_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff00aaaaf0f03333ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128550___O) 
                                                                              << 1U)) 
                                                                          | ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128548___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)) 
           & (IData)(wasmetal_core__DOT___033425_));
    vlSelf->wasmetal_core__DOT____Vcellout___134165___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036846_) 
             << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036845_)) 
           ^ (((((IData)(vlSelf->wasmetal_core__DOT___036846_)
                  ? (IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__)
                  : (IData)(vlSelf->wasmetal_core__DOT___036627_)) 
                << 2U) | ((IData)(wasmetal_core__DOT___134165___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___036837_)));
    wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030106_)
            ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030234_)
            ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b21__05d));
    vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036981_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0))));
    vlSelf->wasmetal_core__DOT___063620_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___063628_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___063636_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b22__05d)))))))));
    vlSelf->wasmetal_core__DOT___063644_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051016_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128152___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048484_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029593_));
    if (vlSelf->wasmetal_core__DOT__sp__05b24__05d) {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b24__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030669_;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___030704_;
        vlSelf->wasmetal_core__DOT___128408___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___031950_;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024058_;
        wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023763_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d));
    vlSelf->__VdfgTmp_hd6d3a7f5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_h96e8cece__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_h3a9f8450__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_ha0adc294__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127609___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    wasmetal_core__DOT____Vcellout___127436___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_hadeaba1a__0))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022506_)))));
    vlSelf->wasmetal_core__DOT___022510_ = ((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127436___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013796_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___022952_;
        wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022808_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_he1214f4e__0))));
    vlSelf->__VdfgTmp_h916673f4__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->__VdfgTmp_hed8e8f6b__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005745_));
    vlSelf->__VdfgTmp_hbac08a4b__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005921_));
    vlSelf->__VdfgTmp_h5774c299__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127480___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005738_));
    vlSelf->wasmetal_core__DOT____Vcellout___127465___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013658_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013666_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7d2fcfb3__0))) 
           ^ (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127465___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022722_)))));
    vlSelf->wasmetal_core__DOT___022726_ = ((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                            & (IData)(wasmetal_core__DOT___127465___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005882_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127456___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005875_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006085_)))) 
           ^ (((IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127456___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022652_)))));
    vlSelf->wasmetal_core__DOT___022656_ = ((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                            & (IData)(wasmetal_core__DOT___127456___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063554_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063562_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___128413___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063570_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___063578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___128413___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052990_))));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026467_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134157___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036775_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036774_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036773_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036772_)))) 
           ^ (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134157___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036739_)))));
    vlSelf->wasmetal_core__DOT___036743_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036775_)
                                                   ? (IData)(wasmetal_core__DOT___134157___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hd2526c88__0))));
    wasmetal_core__DOT___063216_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063222_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063228_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___128063___O) 
                                                             << 1U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    wasmetal_core__DOT___063234_ = (1U & (IData)((0x707770777077ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___128063___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128081___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028301_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028267_)
            : (IData)(vlSelf->wasmetal_core__DOT___028236_));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026575_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000465_));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031313_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034336_) 
           & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034502_) 
           & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127971___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
           ^ (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___027405_)))));
    vlSelf->wasmetal_core__DOT___027409_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127954___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127971___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027345_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027278_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b20__05d));
    vlSelf->wasmetal_core__DOT___062925_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1cU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062917_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O))))))));
    vlSelf->wasmetal_core__DOT___062936_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 2U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1dU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062928_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___062947_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O) 
                                                                                << 1U)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1eU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062939_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                                << 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 1U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___062958_ = (1U & (0x3355f0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xff00ff44440f0fULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128017___O)) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x1fU)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb00000fff0fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___062605_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062950_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___062606_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062602_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___062609_))))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128170___O) 
                                                                >> 2U)) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128025___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___067461_ = (1U & (IData)(
                                                         (0x3f15000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067457_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))));
    vlSelf->wasmetal_core__DOT___067490_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x2a3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067481_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053011_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3edf8090__0))))))));
    vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028111_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028078_)
                  : (vlSelf->insn_x >> 0x1cU)));
    vlSelf->wasmetal_core__DOT___070661_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                            >> 2U))))));
    wasmetal_core__DOT___070660_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                             << 3U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070658_)))))))));
    vlSelf->wasmetal_core__DOT___054533_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054535_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054537_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    vlSelf->wasmetal_core__DOT___054539_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128600___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___046571_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127841___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048484_)))))))));
    wasmetal_core__DOT___063679_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 5U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                   >> 2U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063687_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063695_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___063703_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062602_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___063447_)))))))));
    wasmetal_core__DOT___044382_ = (1U & (IData)((1ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                       << 4U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                          << 2U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127849___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127848___O) 
                                                                  >> 2U)))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128175___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029483_)))));
    vlSelf->wasmetal_core__DOT___029487_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128294___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128175___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128295___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128295___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030699_)))));
    wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030107_)
            ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030235_)
            ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134184___O 
        = (((4U & ((8U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                   << 2U)) | (((IData)(vlSelf->wasmetal_core__DOT___036981_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036980_))) 
           ^ ((((8U >> (IData)(vlSelf->__VdfgTmp_h0bfb68a4__0)) 
                & (IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134184___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036972_)))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__sp__05b25__05d) {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__sp__05b25__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128296___DOT__CO__BRA__0__KET__;
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127585___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023774_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023763_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023752_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023741_)))) 
           ^ (((IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127585___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023711_ = ((IData)(vlSelf->wasmetal_core__DOT___023774_)
                                             ? (IData)(wasmetal_core__DOT___127585___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d));
    vlSelf->wasmetal_core__DOT___058750_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                       >> 2U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0))))));
    vlSelf->wasmetal_core__DOT___023801_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058864_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b6__05d))));
    vlSelf->wasmetal_core__DOT___058736_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127618___O) 
                                                       << 2U)) 
                                                   | ((4U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0))))))));
    vlSelf->wasmetal_core__DOT___023800_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))));
    vlSelf->wasmetal_core__DOT___058872_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_haa9bafe9__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___023796_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3a9f8450__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))));
    vlSelf->wasmetal_core__DOT___058913_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd6d3a7f5__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h96e8cece__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)))))));
    vlSelf->wasmetal_core__DOT___023785_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d))));
    vlSelf->__VdfgTmp_h201788e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 3U)))))));
    vlSelf->__VdfgTmp_h16a355a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 2U)))))));
    vlSelf->__VdfgTmp_h3cbf3996__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(wasmetal_core__DOT____Vcellout___127436___O)))))));
    vlSelf->__VdfgTmp_h6ec85b19__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___003809_));
    vlSelf->__VdfgTmp_h21955c47__0 = (((IData)(vlSelf->wasmetal_core__DOT___005715_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                                                >> 1U)))))));
    vlSelf->__VdfgTmp_h6d7fd34d__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006204_));
    vlSelf->__VdfgTmp_h445a0824__0 = ((2U & ((IData)(wasmetal_core__DOT____Vcellout___127436___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___006400_));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003807_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022510_));
    vlSelf->wasmetal_core__DOT____Vcellout___127576___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013797_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h7faa2984__0))) 
           ^ (((IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127576___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023570_)))));
    vlSelf->wasmetal_core__DOT___023574_ = ((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                            & (IData)(wasmetal_core__DOT___127576___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127469___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022810_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022808_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022797_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022786_)))) 
           ^ (((IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127469___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022779_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022810_)
                                                   ? (IData)(wasmetal_core__DOT___127469___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h7e209046__0))));
    vlSelf->wasmetal_core__DOT___059189_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hae3fb8cb__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059165_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___022814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h916673f4__0))))));
    vlSelf->wasmetal_core__DOT___059103_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       >> 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hed8e8f6b__0))))));
    vlSelf->wasmetal_core__DOT___022812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))))));
    vlSelf->wasmetal_core__DOT___059082_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127488___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___059166_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    vlSelf->wasmetal_core__DOT___022811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))))));
    __VdfgTmp_h29c879e7__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___013654_));
    vlSelf->__VdfgTmp_h6ae1a845__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013666_));
    vlSelf->__VdfgTmp_haeb5561e__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013658_));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013719_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022726_));
    vlSelf->wasmetal_core__DOT____Vcellout___127559___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005802_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005948_)))) 
           ^ (((IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127559___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023449_)))));
    vlSelf->wasmetal_core__DOT___023453_ = ((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                            & (IData)(wasmetal_core__DOT___127559___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___050131_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___006092_))))));
    vlSelf->__VdfgTmp_h0d021fbc__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005875_));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022656_));
    vlSelf->wasmetal_core__DOT___063555_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063554_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063553_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063563_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063562_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063561_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063571_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063570_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063569_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___063579_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063578_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063577_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128293___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h803b5189__0))))))));
    vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026468_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036776_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___036743_)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h364ba349__0))));
    vlSelf->wasmetal_core__DOT___063219_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063216_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063215_)))))));
    vlSelf->wasmetal_core__DOT___063225_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063222_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063221_)))))));
    vlSelf->wasmetal_core__DOT___063231_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063228_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063227_)))))));
    vlSelf->wasmetal_core__DOT___063237_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063234_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063077_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063233_)))))));
    vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028302_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028237_));
    vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026576_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___000477_));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031347_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128645___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034337_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034336_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034335_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034334_)))) 
           ^ (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034397_)))));
    vlSelf->wasmetal_core__DOT___034401_ = ((IData)(vlSelf->wasmetal_core__DOT___034337_) 
                                            & (IData)(wasmetal_core__DOT___128645___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128661___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034503_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034502_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___034501_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034500_)))) 
           ^ (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___034558_)))));
    vlSelf->wasmetal_core__DOT___034562_ = ((IData)(vlSelf->wasmetal_core__DOT___034503_) 
                                            & (IData)(wasmetal_core__DOT___128661___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___044886_ = (1U & (1U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127971___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027409_));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027346_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b21__05d));
    wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028112_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 0x1dU)));
    wasmetal_core__DOT___070663_ = (1U & (IData)((0x6060660006060066ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                   >> 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___070661_)))))))));
    vlSelf->wasmetal_core__DOT___044813_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070660_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                          << 1U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT___044801_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070660_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134214___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070658_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128472___O) 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___054534_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054533_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1aU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054536_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054535_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1bU)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054538_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054537_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1cU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___054540_ = (1U & (IData)(
                                                         (0xf888ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054481_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054539_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051017_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->result_index 
                                                                        >> 0x1dU)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127833___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051016_)))))))));
    vlSelf->wasmetal_core__DOT___063680_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063688_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063687_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063696_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063695_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063704_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___063703_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___044368_ = (1U & ((IData)(wasmetal_core__DOT___044382_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044381_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044380_)
                                                     ? 
                                                    (0xcU 
                                                     >> (IData)(vlSelf->__VdfgTmp_hd4f12848__0))
                                                     : 
                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044380_)))
                                                    : 
                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044381_)))
                                                   : 
                                                  (~ (IData)(wasmetal_core__DOT___044382_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128407___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128287___S) 
           ^ (((IData)(wasmetal_core__DOT___128407___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128407___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___031945_)))));
    vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029487_));
    wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
           & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128236___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030108_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030107_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030106_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030105_)))) 
           ^ (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030071_)))));
    vlSelf->wasmetal_core__DOT___030076_ = ((IData)(vlSelf->wasmetal_core__DOT___030108_)
                                             ? (IData)(wasmetal_core__DOT___128236___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128250___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030236_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030235_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030234_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030233_)))) 
           ^ (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030167_)))));
    vlSelf->wasmetal_core__DOT___030172_ = ((IData)(vlSelf->wasmetal_core__DOT___030236_)
                                             ? (IData)(wasmetal_core__DOT___128250___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b23__05d));
    vlSelf->wasmetal_core__DOT___065179_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134184___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___065051_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134184___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048350_))));
    vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___023873_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023873_ = wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023785_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023711_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b3__05d));
    vlSelf->wasmetal_core__DOT___023226_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6ec85b19__0))));
    vlSelf->wasmetal_core__DOT___023225_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___003810_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h21955c47__0)))));
    vlSelf->wasmetal_core__DOT___023223_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d7fd34d__0))));
    vlSelf->wasmetal_core__DOT___023222_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h445a0824__0))));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___057763_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))))));
    vlSelf->wasmetal_core__DOT___013774_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8ac5901b__0)))));
    vlSelf->wasmetal_core__DOT___057755_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013797_))));
    vlSelf->wasmetal_core__DOT___013776_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127576___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013786_))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013795_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023574_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
        vlSelf->wasmetal_core__DOT___022863_ = vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d;
    } else {
        wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___022863_ = wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022811_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___022779_)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_h5774c299__0))));
    vlSelf->wasmetal_core__DOT___013709_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013648_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013663_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127465___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013658_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127463___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013656_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_h29c879e7__0))))))));
    vlSelf->wasmetal_core__DOT___013716_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013690_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0))))))));
    vlSelf->wasmetal_core__DOT___013682_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6ae1a845__0)))));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013701_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___050114_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___005882_))))));
    vlSelf->wasmetal_core__DOT___050102_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___005948_))));
    wasmetal_core__DOT___006729_ = (1U & (IData)((0xb0bb0000b0bbb0bbULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127558___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 4U) 
                                                      | ((8U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->__VdfgTmp_hfb6e9604__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005802_));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005955_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023453_));
    vlSelf->wasmetal_core__DOT___050130_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0d021fbc__0)))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005921_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127855___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026469_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026468_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026467_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026466_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026431_)))));
    vlSelf->wasmetal_core__DOT___026436_ = ((IData)(vlSelf->wasmetal_core__DOT___026469_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127855___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d));
    vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036777_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134158___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_h586b57d5__0))));
    wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028303_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028238_));
    vlSelf->wasmetal_core__DOT____Vcellout___127871___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026577_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026576_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026575_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026574_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026506_)))));
    vlSelf->wasmetal_core__DOT___026511_ = ((IData)(vlSelf->wasmetal_core__DOT___026577_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127871___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___000499_));
    vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031348_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128352___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___128646___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034339_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034401_));
    vlSelf->wasmetal_core__DOT___128662___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034504_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034562_));
    vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127955___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127972___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027347_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127956___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b22__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128049___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028115_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028114_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028112_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028111_)))) 
           ^ ((8U & (((IData)(vlSelf->wasmetal_core__DOT___028114_)
                       ? (IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__)
                       : (vlSelf->insn_x >> 0x1eU)) 
                     << 3U)) | (((IData)(wasmetal_core__DOT___128049___DOT__CO__BRA__1__KET__) 
                                 << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128049___DOT__CO__BRA__0__KET__) 
                                            << 1U) 
                                           | (IData)(vlSelf->wasmetal_core__DOT___028078_)))));
    vlSelf->wasmetal_core__DOT___044804_ = (1U & (0xac530000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___070663_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___044792_ = (1U & (IData)(
                                                         (0xfcf0faf0f0f0f0fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___070663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f5f550f3f3f330ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__call_kind__05b1__05d) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070661_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134215___O) 
                                                                                >> 1U)) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128473___O) 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___063685_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063680_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b28__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O))))))));
    vlSelf->wasmetal_core__DOT___063693_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063688_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b29__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___063701_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063696_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b30__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___063709_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052913_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b31__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128497___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___053499_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052847_)))));
    vlSelf->wasmetal_core__DOT___053480_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048397_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___050363_)))))))));
    vlSelf->wasmetal_core__DOT___052849_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052847_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048278_)))));
    vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128295___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128176___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128551___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(wasmetal_core__DOT___033425_)))));
    vlSelf->wasmetal_core__DOT___033429_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d)) 
                                            & (IData)(wasmetal_core__DOT___128551___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128237___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030109_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030076_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    vlSelf->wasmetal_core__DOT___128251___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030237_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030172_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128185___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___029593_)))));
    vlSelf->wasmetal_core__DOT___029598_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128287___O) 
                                             >> 3U) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128185___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128288___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128288___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030669_)))));
    vlSelf->wasmetal_core__DOT___030673_ = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128288___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127626___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024058_)))));
    vlSelf->wasmetal_core__DOT___024000_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___127626___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023796_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127592___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127610___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127610___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023931_)))));
    vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003808_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127437___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057762_ = (1U & (0xd000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057759_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013776_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127575___O)))))));
    vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013798_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127577___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127489___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022952_)))));
    vlSelf->wasmetal_core__DOT___022926_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
                                             ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b11__05d)
                                             : (IData)(wasmetal_core__DOT___127489___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___022812_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___127470___DOT__CO__BRA__0__KET__)
                  : (1U >> (IData)(vlSelf->__VdfgTmp_hbac08a4b__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127481___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b7__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127481___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022889_)))));
    vlSelf->wasmetal_core__DOT___057742_ = ((1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___013709_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___013709_));
    vlSelf->wasmetal_core__DOT___057743_ = ((4U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127464___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___013712_) 
                                                & (IData)(vlSelf->wasmetal_core__DOT___013716_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___013716_));
    vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013722_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127466___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___006707_ = ((8U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O))
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                & (IData)(wasmetal_core__DOT___006729_))
                                             : (IData)(wasmetal_core__DOT___006729_));
    vlSelf->wasmetal_core__DOT___050104_ = (1U & (0xb0bbU 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127559___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005809_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfb6e9604__0)))));
    vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005788_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127560___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___006622_ = (1U & (IData)(
                                                         (0xd00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050131_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006635_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050130_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         ((2U 
                                                                           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127456___O)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___006015_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127455___O))))))))));
    vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127457___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128414___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128286___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128414___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032007_)))));
    vlSelf->__VdfgTmp_hcfac9f06__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127855___O) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               ((0x10U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127853___O) 
                                                    << 1U)) 
                                                | ((8U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                          << 1U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                             >> 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127854___O) 
                                                               >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___127856___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026470_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026436_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128064___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028304_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028303_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028302_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028301_)))) 
           ^ (((IData)(wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128064___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028267_)))));
    vlSelf->wasmetal_core__DOT___028271_ = ((IData)(vlSelf->wasmetal_core__DOT___028304_)
                                             ? (IData)(wasmetal_core__DOT___128064___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028239_));
    vlSelf->wasmetal_core__DOT___045497_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071364_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127871___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071363_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071362_))))))));
}
