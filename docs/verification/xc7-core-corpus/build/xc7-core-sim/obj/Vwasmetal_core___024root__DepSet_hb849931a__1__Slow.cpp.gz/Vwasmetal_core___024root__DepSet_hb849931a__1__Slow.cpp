#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___eval_final(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___eval_final\n"); );
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vwasmetal_core___024root___dump_triggers__stl(Vwasmetal_core___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vwasmetal_core___024root___eval_phase__stl(Vwasmetal_core___024root* vlSelf);

VL_ATTR_COLD void Vwasmetal_core___024root___eval_settle(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___eval_settle\n"); );
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelf->__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vwasmetal_core___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("/tmp/wasmetal-xc7-core/build/xc7-core-sim/core.v", 3, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vwasmetal_core___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelf->__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vwasmetal_core___024root___dump_triggers__stl(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__0(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__0\n"); );
    // Init
    VlWide<3>/*95:0*/ __Vtemp_1;
    VlWide<3>/*95:0*/ __Vtemp_17;
    VlWide<4>/*127:0*/ __Vtemp_49;
    // Body
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e14__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b127__05d) 
            << 1U) | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b126__05d));
    vlSelf->wasmetal_core__DOT___062506_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d)))));
    vlSelf->mem_kind = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129004___Q) 
                         << 2U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129003___Q) 
                                    << 1U) | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129002___Q)));
    vlSelf->__VdfgTmp_h1cca9b8e__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b107__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b106__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b105__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b104__05d))));
    vlSelf->__VdfgTmp_h6d54506a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b111__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b110__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b109__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b108__05d))));
    vlSelf->__VdfgTmp_hd508e470__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b123__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b122__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b121__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b120__05d))));
    vlSelf->__VdfgTmp_hd7287eb7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b127__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b126__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b125__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b124__05d))));
    vlSelf->__VdfgTmp_h420e04a5__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b183__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b182__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b181__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b180__05d))));
    vlSelf->__VdfgTmp_h7de567cd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b187__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b186__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b185__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b184__05d))));
    vlSelf->__VdfgTmp_h60282e5c__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b191__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b190__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b189__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b188__05d))));
    vlSelf->__VdfgTmp_h7bd28ecf__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b135__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b134__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b133__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b132__05d))));
    vlSelf->__VdfgTmp_h211ae39f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b143__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b142__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b141__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b140__05d))));
    vlSelf->__VdfgTmp_hfc797c55__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b239__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b238__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b237__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b236__05d))));
    vlSelf->__VdfgTmp_h4bfa6f09__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b227__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b226__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b225__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b224__05d))));
    vlSelf->__VdfgTmp_hea78939d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b251__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b250__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b249__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b248__05d))));
    vlSelf->__VdfgTmp_h8e3eac18__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b255__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b254__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b253__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b252__05d))));
    vlSelf->__VdfgTmp_h40722c77__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b107__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b106__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b105__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b104__05d))));
    vlSelf->__VdfgTmp_h5ad4ffc8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b111__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b110__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b109__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b108__05d))));
    vlSelf->__VdfgTmp_h5f14f02d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b123__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b122__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b121__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b120__05d))));
    vlSelf->__VdfgTmp_h768acb46__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b127__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b126__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b125__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b124__05d))));
    vlSelf->__VdfgTmp_hd8834afb__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b183__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b182__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b181__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b180__05d))));
    vlSelf->__VdfgTmp_h210ef7f0__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b187__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b186__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b185__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b184__05d))));
    vlSelf->__VdfgTmp_h3ab327aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b191__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b190__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b189__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b188__05d))));
    vlSelf->__VdfgTmp_h18020398__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b135__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b134__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b133__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b132__05d))));
    vlSelf->__VdfgTmp_h8901ecaf__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b143__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b142__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b141__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b140__05d))));
    vlSelf->__VdfgTmp_hfbc99fdd__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b239__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b238__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b237__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b236__05d))));
    vlSelf->__VdfgTmp_hee5ebf6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b227__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b226__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b225__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b224__05d))));
    vlSelf->__VdfgTmp_h69f02119__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b251__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b250__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b249__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b248__05d))));
    vlSelf->__VdfgTmp_h872406d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b255__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b254__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b253__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b252__05d))));
    vlSelf->mem_bytes = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129105___Q) 
                          << 4U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129104___Q) 
                                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129103___Q) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129102___Q) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129101___Q)))));
    vlSelf->wasmetal_core__DOT___036619_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_x 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->trap = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128903___Q) 
                     << 7U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128902___Q) 
                                << 6U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128901___Q) 
                                           << 5U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128900___Q) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128899___Q) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128898___Q) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128897___Q) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128896___Q))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__ADDRBWRADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d) 
                       << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                    << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d) 
                                                 << 0xbU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d) 
                                                    << 0xaU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d) 
                                                       << 9U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                                          << 8U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d) 
                                                             << 7U) 
                                                            | ((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d) 
                                                               << 6U)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b7__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b6__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b5__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b4__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b3__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b2__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b1__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b0__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e1__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b16__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b15__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b14__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b13__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b12__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b11__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b10__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b9__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e10__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b97__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b96__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b95__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b94__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b93__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b92__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b91__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b90__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e11__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b106__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b105__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b104__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b103__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b102__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b101__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b100__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b99__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e12__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b115__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b114__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b113__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b112__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b111__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b110__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b109__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b108__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e13__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b124__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b123__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b122__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b121__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b120__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b119__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b118__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b117__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e2__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b25__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b24__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b23__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b22__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b21__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b20__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b19__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b18__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e3__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b34__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b33__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b32__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b31__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b30__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b29__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b28__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b27__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e4__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b43__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b42__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b41__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b40__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b39__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b38__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b37__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b36__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e5__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b52__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b51__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b50__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b49__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b48__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b47__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b46__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b45__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e6__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b61__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b60__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b59__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b58__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b57__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b56__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b55__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b54__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e7__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b70__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b69__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b68__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b67__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b66__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b65__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b64__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b63__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e8__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b79__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b78__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b77__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b76__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b75__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b74__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b73__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b72__05d))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e9__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b88__05d) 
            << 7U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b87__05d) 
                       << 6U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b86__05d) 
                                  << 5U) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b85__05d) 
                                             << 4U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b84__05d) 
                                                << 3U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b83__05d) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b82__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_data__05b81__05d))))))));
    vlSelf->wasmetal_core__DOT___063355_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_source_kind__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill))));
    vlSelf->wasmetal_core__DOT____Vcellinp__frames_memory__02e0__02e0__ADDRBWRADDR 
        = (0x803fU | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d) 
                       << 0xeU) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                    << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                                                 << 0xcU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                                    << 0xbU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) 
                                                       << 0xaU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                                          << 9U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d) 
                                                             << 8U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d) 
                                                                << 7U) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                                                  << 6U))))))))));
    vlSelf->wasmetal_core__DOT___128230___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d));
    vlSelf->wasmetal_core__DOT___128814___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d));
    vlSelf->__VdfgTmp_h6e193d9b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b99__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b98__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b97__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b96__05d))));
    vlSelf->__VdfgTmp_h2b062dd4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b103__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b102__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b101__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b100__05d))));
    vlSelf->__VdfgTmp_h79496643__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b119__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b118__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b117__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b116__05d))));
    vlSelf->__VdfgTmp_h8dc4790b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b115__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b114__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b113__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b112__05d))));
    vlSelf->__VdfgTmp_h3eb04205__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b131__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b130__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b129__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b128__05d))));
    vlSelf->__VdfgTmp_h4f25bbf3__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b139__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b138__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b137__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b136__05d))));
    vlSelf->__VdfgTmp_he25b67d8__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b235__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b234__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b233__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b232__05d))));
    vlSelf->__VdfgTmp_hc793c4ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b231__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b230__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b229__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b228__05d))));
    vlSelf->__VdfgTmp_h89ddcfc9__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b247__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b246__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b245__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b244__05d))));
    vlSelf->__VdfgTmp_hff3ab0b7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b243__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b242__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b241__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b240__05d))));
    vlSelf->__VdfgTmp_h6ec6b47d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b99__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b98__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b97__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b96__05d))));
    vlSelf->__VdfgTmp_h7982dd07__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b103__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b102__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b101__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b100__05d))));
    vlSelf->__VdfgTmp_h8555f3e8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b119__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b118__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b117__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b116__05d))));
    vlSelf->__VdfgTmp_h1157f8a3__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b115__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b114__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b113__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b112__05d))));
    vlSelf->__VdfgTmp_h0a192e7e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b131__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b130__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b129__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b128__05d))));
    vlSelf->__VdfgTmp_h51560923__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b139__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b138__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b137__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b136__05d))));
    vlSelf->__VdfgTmp_hcafe333f__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b235__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b234__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b233__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b232__05d))));
    vlSelf->__VdfgTmp_h7d1b01d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b231__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b230__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b229__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b228__05d))));
    vlSelf->__VdfgTmp_h236ea405__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b247__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b246__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b245__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b244__05d))));
    vlSelf->__VdfgTmp_h38f4df47__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b243__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b242__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b241__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b240__05d))));
    vlSelf->__VdfgTmp_hf9e7c209__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1dU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__labels_memory__02e0__02e0__ADDRARDADDR 
        = (0x800fU | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d) 
                       << 0xeU) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                    << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                 << 0xcU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                                    << 0xbU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d) 
                                                       << 0xaU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                                          << 9U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d) 
                                                             << 8U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                                                << 7U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                                                                   << 6U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d) 
                                                                      << 5U) 
                                                                     | ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
                                                                        << 4U))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIPBDIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b62__05d) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b44__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp__value_file__02ebanks__05b0__05d__02ewords__02e0__02e0__ADDRARDADDR 
        = (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b12__05d) 
            << 0xdU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b11__05d) 
                         << 0xcU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b10__05d) 
                                      << 0xbU) | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b9__05d) 
                                                   << 0xaU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b8__05d) 
                                                      << 9U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b7__05d) 
                                                         << 8U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b6__05d) 
                                                            << 7U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b5__05d) 
                                                               << 6U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b4__05d) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b3__05d) 
                                                                     << 4U) 
                                                                    | ((IData)(vlSelf->wasmetal_core__DOT__value_file__02ewrite_index__05b2__05d) 
                                                                       << 3U)))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIPADIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b35__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b26__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b8__05d))));
    vlSelf->__VdfgTmp_h36e63769__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b91__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b90__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b89__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b88__05d))));
    vlSelf->__VdfgTmp_hbcd45513__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b95__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b94__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b93__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b92__05d))));
    vlSelf->__VdfgTmp_h0f8ff227__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b79__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b78__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b77__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b76__05d))));
    vlSelf->__VdfgTmp_hed4d342a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b67__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b66__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b65__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b64__05d))));
    vlSelf->__VdfgTmp_h28f7b227__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b71__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b70__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b69__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b68__05d))));
    vlSelf->__VdfgTmp_h964144cd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b175__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b174__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b173__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b172__05d))));
    vlSelf->__VdfgTmp_h73f4a931__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b163__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b162__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b161__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b160__05d))));
    vlSelf->__VdfgTmp_hb256bb9f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b179__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b178__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b177__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b176__05d))));
    vlSelf->__VdfgTmp_h473eb647__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b147__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b146__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b145__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b144__05d))));
    vlSelf->__VdfgTmp_h1387689e__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b155__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b154__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b153__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b152__05d))));
    vlSelf->__VdfgTmp_h6ce46baf__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b159__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b158__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b157__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b156__05d))));
    vlSelf->__VdfgTmp_hc7f628da__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b219__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b218__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b217__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b216__05d))));
    vlSelf->__VdfgTmp_he2a57136__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b223__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b222__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b221__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b220__05d))));
    vlSelf->__VdfgTmp_h4f9812e4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b199__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b198__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b197__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b196__05d))));
    vlSelf->__VdfgTmp_h63b8fe6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b207__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b206__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b205__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b204__05d))));
    vlSelf->__VdfgTmp_h947ab6b4__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b91__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b90__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b89__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b88__05d))));
    vlSelf->__VdfgTmp_h71547b26__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b95__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b94__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b93__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b92__05d))));
    vlSelf->__VdfgTmp_h43fa682b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b79__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b78__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b77__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b76__05d))));
    vlSelf->__VdfgTmp_h0b1aa625__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b67__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b66__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b65__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b64__05d))));
    vlSelf->__VdfgTmp_hbdf51c76__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b71__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b70__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b69__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b68__05d))));
    vlSelf->__VdfgTmp_h6286ac7f__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b175__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b174__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b173__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b172__05d))));
    vlSelf->__VdfgTmp_hc66bf11b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b163__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b162__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b161__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b160__05d))));
    vlSelf->__VdfgTmp_hc0d4cc40__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b179__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b178__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b177__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b176__05d))));
    vlSelf->__VdfgTmp_h28b8e598__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b147__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b146__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b145__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b144__05d))));
    vlSelf->__VdfgTmp_h51b306d7__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b155__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b154__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b153__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b152__05d))));
    vlSelf->__VdfgTmp_h3b58ae94__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b159__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b158__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b157__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b156__05d))));
    vlSelf->__VdfgTmp_hcb35a5f1__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b219__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b218__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b217__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b216__05d))));
    vlSelf->__VdfgTmp_h3885fdb9__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b223__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b222__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b221__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b220__05d))));
    vlSelf->__VdfgTmp_hf4526f03__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b199__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b198__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b197__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b196__05d))));
    vlSelf->__VdfgTmp_h6d99021a__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b207__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b206__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b205__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b204__05d))));
    vlSelf->__VdfgTmp_hd8443bfe__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b87__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b86__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b85__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b84__05d))));
    vlSelf->__VdfgTmp_h295e0579__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b83__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b82__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b81__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b80__05d))));
    vlSelf->__VdfgTmp_h1aa87dc1__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b171__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b170__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b169__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b168__05d))));
    vlSelf->__VdfgTmp_hc4635290__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b167__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b166__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b165__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b164__05d))));
    vlSelf->__VdfgTmp_h139eafce__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b215__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b214__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b213__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b212__05d))));
    vlSelf->__VdfgTmp_h738a13de__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b211__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b210__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b209__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b208__05d))));
    vlSelf->__VdfgTmp_h40ae3a4f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b195__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b194__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b193__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b192__05d))));
    vlSelf->__VdfgTmp_he052d4e7__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b203__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b202__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b201__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b200__05d))));
    vlSelf->__VdfgTmp_hef41fa97__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b87__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b86__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b85__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b84__05d))));
    vlSelf->__VdfgTmp_h8b69f170__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b83__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b82__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b81__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b80__05d))));
    vlSelf->__VdfgTmp_h47e0de34__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b171__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b170__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b169__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b168__05d))));
    vlSelf->__VdfgTmp_h29fa0da7__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b167__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b166__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b165__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b164__05d))));
    vlSelf->__VdfgTmp_hc408f28d__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b215__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b214__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b213__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b212__05d))));
    vlSelf->__VdfgTmp_h1dd2dede__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b211__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b210__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b209__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b208__05d))));
    vlSelf->__VdfgTmp_hc7c61c07__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b195__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b194__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b193__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b192__05d))));
    vlSelf->__VdfgTmp_h1968304e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b203__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b202__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b201__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b200__05d))));
    vlSelf->wasmetal_core__DOT___062983_ = (1U & (0xfecf05ecU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))));
    vlSelf->__VdfgTmp_h586b57d5__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1cU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d));
    vlSelf->__VdfgTmp_h2f7c3620__0 = (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b6__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b5__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b4__05d)));
    vlSelf->wasmetal_core__DOT___062996_ = (1U & (IData)(
                                                         (0xfff44ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->mem_fault) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))))));
    vlSelf->__VdfgTmp_h5760b542__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b75__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b74__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b73__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b72__05d))));
    vlSelf->__VdfgTmp_h7a6ef80c__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b151__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b150__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b149__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b148__05d))));
    vlSelf->__VdfgTmp_h0a9f8029__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b75__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b74__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b73__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b72__05d))));
    vlSelf->__VdfgTmp_h5864b2ba__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b151__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b150__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b149__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b148__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIPBDIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIPADIP 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d))));
    vlSelf->wasmetal_core__DOT___053739_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b18__05d))));
    vlSelf->wasmetal_core__DOT___053740_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b30__05d))));
    vlSelf->wasmetal_core__DOT___053745_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b2__05d))));
    vlSelf->__VdfgTmp_heb1fb9b9__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b21__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b20__05d));
    vlSelf->__VdfgTmp_hf90c45d9__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b29__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b28__05d));
    vlSelf->__VdfgTmp_h63180e3e__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b5__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b4__05d));
    vlSelf->result_count = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128935___Q) 
                             << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128934___Q) 
                                           << 0x1eU) 
                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128933___Q) 
                                              << 0x1dU) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128932___Q) 
                                                 << 0x1cU) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128931___Q) 
                                                    << 0x1bU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128930___Q) 
                                                       << 0x1aU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128929___Q) 
                                                          << 0x19U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128928___Q) 
                                                             << 0x18U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128927___Q) 
                                                                << 0x17U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128926___Q) 
                                                                   << 0x16U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128925___Q) 
                                                                      << 0x15U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128924___Q) 
                                                                         << 0x14U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128923___Q) 
                                                                            << 0x13U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128922___Q) 
                                                                               << 0x12U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128921___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128920___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128919___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128918___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128917___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128916___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128915___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128914___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128913___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128912___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128911___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128910___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128909___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128908___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128907___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128906___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128905___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128904___Q))))))))))))))))))))))))))))))));
    vlSelf->pc = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128967___Q) 
                   << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128966___Q) 
                                 << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128965___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128964___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128963___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128962___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128961___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128960___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128959___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128958___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128957___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128956___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128955___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128954___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128953___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128952___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128951___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128950___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128949___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128948___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128947___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128946___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128945___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128944___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128943___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128942___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128941___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128940___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128939___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128938___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q))))))))))))))))))))))))))))))));
    vlSelf->function_index = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128999___Q) 
                               << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128998___Q) 
                                             << 0x1eU) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128997___Q) 
                                                << 0x1dU) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128996___Q) 
                                                   << 0x1cU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128995___Q) 
                                                      << 0x1bU) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128994___Q) 
                                                         << 0x1aU) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128993___Q) 
                                                            << 0x19U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128992___Q) 
                                                               << 0x18U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128991___Q) 
                                                                  << 0x17U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128990___Q) 
                                                                     << 0x16U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128989___Q) 
                                                                        << 0x15U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128988___Q) 
                                                                           << 0x14U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128987___Q) 
                                                                              << 0x13U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128986___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128985___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128984___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128983___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128982___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128981___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128980___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128979___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128978___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128977___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128976___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128975___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128974___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128973___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128972___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128971___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128970___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128969___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128968___Q))))))))))))))))))))))))))))))));
    vlSelf->mem_index = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129036___Q) 
                          << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129035___Q) 
                                        << 0x1eU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129034___Q) 
                                         << 0x1dU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129033___Q) 
                                            << 0x1cU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129032___Q) 
                                               << 0x1bU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129031___Q) 
                                                  << 0x1aU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129030___Q) 
                                                     << 0x19U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129029___Q) 
                                                        << 0x18U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129028___Q) 
                                                           << 0x17U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129027___Q) 
                                                              << 0x16U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129026___Q) 
                                                                 << 0x15U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129025___Q) 
                                                                    << 0x14U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129024___Q) 
                                                                       << 0x13U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129023___Q) 
                                                                          << 0x12U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129022___Q) 
                                                                             << 0x11U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129021___Q) 
                                                                                << 0x10U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129020___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129019___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129018___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129017___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129016___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129015___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129014___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129013___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129012___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129011___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129010___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129009___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129008___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129007___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129006___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129005___Q))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIBDI 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b64__05d) 
            << 0x19U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b63__05d) 
                          << 0x18U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d) 
                                        << 0x17U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b60__05d) 
                                         << 0x16U) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b59__05d) 
                                            << 0x15U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                               << 0x14U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                  << 0x13U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                     << 0x12U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                        << 0x11U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b54__05d) 
                                                           << 0x10U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                              << 0xfU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b51__05d) 
                                                                 << 0xeU) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                    << 0xdU) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d) 
                                                                       << 0xcU) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b48__05d) 
                                                                          << 0xbU) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b47__05d) 
                                                                             << 0xaU) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d) 
                                                                                << 9U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b45__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b42__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b41__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b36__05d))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h364ba349__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1bU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d));
    vlSelf->wasmetal_core__DOT___053742_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b14__05d))));
    vlSelf->__VdfgTmp_he3290929__0 = (((IData)(vlSelf->wasmetal_core__DOT__init_left__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__init_left__05b12__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp__memory_bounds__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d) 
            << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b33__05d) 
                          << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b32__05d) 
                                        << 0x1dU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d) 
                                         << 0x1cU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b30__05d) 
                                            << 0x1bU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b29__05d) 
                                               << 0x1aU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d) 
                                                  << 0x19U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b27__05d) 
                                                     << 0x18U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d) 
                                                        << 0x17U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b24__05d) 
                                                           << 0x16U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b23__05d) 
                                                              << 0x15U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d) 
                                                                 << 0x14U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b21__05d) 
                                                                    << 0x13U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b20__05d) 
                                                                       << 0x12U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d) 
                                                                          << 0x11U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b18__05d) 
                                                                             << 0x10U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d) 
                                                                                << 0xfU) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b15__05d) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b14__05d) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b12__05d) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b11__05d) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b9__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d))))))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___032540_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b63__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b63__05d)))));
    vlSelf->wasmetal_core__DOT___032539_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b62__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b62__05d)))));
    vlSelf->wasmetal_core__DOT___045785_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->cmd_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->cmd_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->cmd_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(
                                                                      (0x100000000ULL 
                                                                       >> 
                                                                       (0x3fU 
                                                                        & (vlSelf->cmd_index 
                                                                           >> 8U))))) 
                                                           & (~ 
                                                              (vlSelf->cmd_index 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___032890_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032889_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->__VdfgTmp_h87f17c6b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b19__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b18__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b17__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b16__05d))));
    vlSelf->__VdfgTmp_h60760575__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b27__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b26__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b25__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b24__05d))));
    vlSelf->__VdfgTmp_h6239803f__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b30__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b29__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b28__05d))));
    vlSelf->__VdfgTmp_hfa693494__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b55__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b54__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b53__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b52__05d))));
    vlSelf->__VdfgTmp_h7031c855__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b59__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b58__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b57__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b56__05d))));
    vlSelf->__VdfgTmp_hb1756308__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b63__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b62__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b61__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b60__05d))));
    vlSelf->__VdfgTmp_h9adc8e2b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b19__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b18__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b17__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b16__05d))));
    vlSelf->__VdfgTmp_h35252d63__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b27__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b26__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b25__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b24__05d))));
    vlSelf->__VdfgTmp_hac7d774c__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b31__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b30__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b29__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b28__05d))));
    vlSelf->__VdfgTmp_h5ee84e09__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b55__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b54__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b53__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b52__05d))));
    vlSelf->__VdfgTmp_h05fef25b__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b59__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b58__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b57__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b56__05d))));
    vlSelf->__VdfgTmp_hf75b3db8__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b63__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b62__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b61__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b60__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIBDI 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
            << 0x18U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                          << 0x17U) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                        << 0x16U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                         << 0x15U) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                            << 0x14U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                               << 0x13U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                  << 0x12U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                     << 0x11U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                        << 0x10U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                           << 0xfU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                              << 0xeU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                                 << 0xdU) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                                    << 0xcU) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                                       << 0xbU) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                                          << 0xaU) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                                             << 9U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                                                << 8U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___029938_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp__data_sizes__02ewords__02e0__02e0__DIADI 
        = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
            << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                          << 0x1eU) | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                        << 0x1dU) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                         << 0x1cU) 
                                        | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                            << 0x1bU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                               << 0x1aU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                  << 0x19U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                     << 0x18U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                        << 0x17U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                           << 0x16U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                              << 0x15U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                                 << 0x14U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                                    << 0x13U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                                       << 0x12U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                                          << 0x11U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                                             << 0x10U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                                                << 0xfU) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_h980fd1a4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b7__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b6__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b5__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b4__05d))));
    vlSelf->__VdfgTmp_h12f13bc4__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b11__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b10__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b9__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b8__05d))));
    vlSelf->__VdfgTmp_h3ca396d5__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b15__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b14__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b13__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b12__05d))));
    vlSelf->__VdfgTmp_h02a1ae9a__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b23__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b22__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b21__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b20__05d))));
    vlSelf->__VdfgTmp_hf690becd__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b47__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b46__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b45__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b44__05d))));
    vlSelf->__VdfgTmp_h6a500089__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b39__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b38__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b37__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b36__05d))));
    vlSelf->__VdfgTmp_he6124d0b__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b35__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b34__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b33__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b32__05d))));
    vlSelf->__VdfgTmp_h8546e85d__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b51__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b50__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b49__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b48__05d))));
    vlSelf->__VdfgTmp_hb13e555e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b7__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b6__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b5__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b4__05d))));
    vlSelf->__VdfgTmp_h4fc63e3e__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b11__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b10__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b9__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b8__05d))));
    vlSelf->__VdfgTmp_h5b3781b6__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b15__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b14__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b13__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b12__05d))));
    vlSelf->__VdfgTmp_hefac84ff__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b23__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b22__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b21__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b20__05d))));
    vlSelf->__VdfgTmp_hc9d2c329__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b47__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b46__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b45__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b44__05d))));
    vlSelf->__VdfgTmp_h745b6463__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b39__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b38__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b37__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b36__05d))));
    vlSelf->__VdfgTmp_h41f0b476__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b35__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b34__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b33__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b32__05d))));
    vlSelf->__VdfgTmp_h6727edf3__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b51__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b50__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b49__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b48__05d))));
    vlSelf->__VdfgTmp_hd2526c88__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x1aU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d));
    vlSelf->mem_address = (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129100___Q)) 
                            << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129099___Q)) 
                                          << 0x3eU) 
                                         | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129098___Q)) 
                                             << 0x3dU) 
                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129097___Q)) 
                                                << 0x3cU) 
                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129096___Q)) 
                                                   << 0x3bU) 
                                                  | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129095___Q)) 
                                                      << 0x3aU) 
                                                     | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129094___Q)) 
                                                         << 0x39U) 
                                                        | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129093___Q)) 
                                                            << 0x38U) 
                                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129092___Q)) 
                                                               << 0x37U) 
                                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129091___Q)) 
                                                                  << 0x36U) 
                                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129090___Q)) 
                                                                     << 0x35U) 
                                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129089___Q)) 
                                                                        << 0x34U) 
                                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129088___Q)) 
                                                                           << 0x33U) 
                                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129087___Q)) 
                                                                              << 0x32U) 
                                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129086___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129085___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129084___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129083___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129082___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129081___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129080___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129079___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129078___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129077___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129076___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129075___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129074___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129073___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129072___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129071___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129070___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129069___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129068___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129067___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129066___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129065___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129064___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129063___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129062___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129061___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129060___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129059___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129058___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129057___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129056___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129055___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129054___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129053___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129052___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129051___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129050___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129049___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129048___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129047___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129046___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129045___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129044___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129043___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129042___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129041___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129040___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129039___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129038___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129037___Q))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    vlSelf->__VdfgTmp_hf05a0261__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b3__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b2__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b1__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b0__05d))));
    vlSelf->__VdfgTmp_h8c9e90c9__0 = (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b43__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b42__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b41__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid__05b40__05d))));
    vlSelf->__VdfgTmp_haf724a20__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b3__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b2__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b1__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b0__05d))));
    vlSelf->__VdfgTmp_hf782be94__0 = (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b43__05d) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b42__05d) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b41__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid__05b40__05d))));
    vlSelf->wasmetal_core__DOT___029769_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b31__05d))));
    vlSelf->wasmetal_core__DOT___052984_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x17U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 9U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 5U)))))));
    vlSelf->wasmetal_core__DOT___052959_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x10U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[2U] 
                                                                  >> 0xcU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[2U] 
                                                                    >> 8U)))))));
    vlSelf->wasmetal_core__DOT___052960_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[3U]))))));
    vlSelf->wasmetal_core__DOT___052977_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0x11U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0xdU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 9U)))))));
    vlSelf->wasmetal_core__DOT___052978_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[1U]))))));
    vlSelf->wasmetal_core__DOT___052969_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->mem_rdata[1U] 
                                                                    >> 0xeU))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->mem_rdata[1U] 
                                                                       >> 0x14U))) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->mem_rdata[1U] 
                                                                     >> 0xaU)) 
                                                                 | (3U 
                                                                    & (vlSelf->mem_rdata[1U] 
                                                                       >> 8U))))))));
    vlSelf->wasmetal_core__DOT___052970_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0xeU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[2U] 
                                                                  >> 5U)) 
                                                              | (1U 
                                                                 & vlSelf->mem_rdata[2U]))))));
    vlSelf->wasmetal_core__DOT___029406_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029405_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d))));
    vlSelf->wasmetal_core__DOT___027825_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->function_params 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___027824_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1eU)))));
    vlSelf->wasmetal_core__DOT___026285_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b31__05d))));
    vlSelf->wasmetal_core__DOT___026284_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b30__05d))));
    vlSelf->wasmetal_core__DOT___052957_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               << 5U)) 
                                                           | ((0x1cU 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 0x1bU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 0x19U)))))));
    vlSelf->wasmetal_core__DOT___052967_ = (1U & (1U 
                                                  >> 
                                                  ((0xcU 
                                                    & (vlSelf->mem_rdata[1U] 
                                                       >> 0x1cU)) 
                                                   | (3U 
                                                      & (vlSelf->mem_rdata[1U] 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___052964_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->mem_rdata[2U] 
                                                               >> 0x1aU)) 
                                                           | (3U 
                                                              & (vlSelf->mem_rdata[2U] 
                                                                 >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___052973_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x1aU)) 
                                                           | (3U 
                                                              & (vlSelf->mem_rdata[3U] 
                                                                 >> 0x18U))))));
    vlSelf->wasmetal_core__DOT___052974_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x10U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 0xcU)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[3U] 
                                                                    >> 8U)))))));
    vlSelf->wasmetal_core__DOT___052961_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[3U] 
                                                               >> 0x16U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[3U] 
                                                                  >> 8U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[3U] 
                                                                    >> 4U)))))));
    vlSelf->wasmetal_core__DOT___052962_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x38U 
                                                            & (vlSelf->mem_rdata[0U] 
                                                               >> 0xfU)) 
                                                           | ((6U 
                                                               & (vlSelf->mem_rdata[0U] 
                                                                  >> 6U)) 
                                                              | (1U 
                                                                 & (vlSelf->mem_rdata[0U] 
                                                                    >> 1U)))))));
    vlSelf->wasmetal_core__DOT___052963_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & (vlSelf->mem_rdata[1U] 
                                                               >> 0x16U)) 
                                                           | ((0xcU 
                                                               & (vlSelf->mem_rdata[1U] 
                                                                  >> 8U)) 
                                                              | (3U 
                                                                 & (vlSelf->mem_rdata[1U] 
                                                                    >> 4U)))))));
    vlSelf->wasmetal_core__DOT___045803_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->cmd_index 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (1U 
                                                         >> 
                                                         (0x1fU 
                                                          & (vlSelf->cmd_index 
                                                             >> 9U)))))));
    vlSelf->wasmetal_core__DOT___032538_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b61__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b61__05d)))));
    vlSelf->wasmetal_core__DOT___032887_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___045604_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d))));
    vlSelf->wasmetal_core__DOT___045607_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045606_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b12__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045605_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045609_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045608_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b24__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b23__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b20__05d)))))))));
    vlSelf->__VdfgTmp_h93f91ca8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x19U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d));
    vlSelf->wasmetal_core__DOT___029937_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d))));
    vlSelf->wasmetal_core__DOT___128793___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02ecycleNum__05b0__05d));
    __Vtemp_1[0U] = (IData)((((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129169___Q)) 
                              << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129168___Q)) 
                                            << 0x3eU) 
                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129167___Q)) 
                                               << 0x3dU) 
                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129166___Q)) 
                                                  << 0x3cU) 
                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129165___Q)) 
                                                     << 0x3bU) 
                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129164___Q)) 
                                                        << 0x3aU) 
                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129163___Q)) 
                                                           << 0x39U) 
                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129162___Q)) 
                                                              << 0x38U) 
                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129161___Q)) 
                                                                 << 0x37U) 
                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129160___Q)) 
                                                                    << 0x36U) 
                                                                   | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129159___Q)) 
                                                                       << 0x35U) 
                                                                      | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129158___Q)) 
                                                                          << 0x34U) 
                                                                         | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129157___Q)) 
                                                                             << 0x33U) 
                                                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129156___Q)) 
                                                                                << 0x32U) 
                                                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129155___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129154___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129153___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129152___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129151___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129150___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129149___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129148___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129147___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129146___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129145___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129144___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129143___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129142___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129141___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129140___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129139___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129138___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129137___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129136___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129135___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129134___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129133___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129132___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129131___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129130___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129129___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129128___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129127___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129126___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129125___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129124___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129123___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129122___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129121___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129120___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129119___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129118___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129117___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129116___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129115___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129114___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129113___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129112___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129111___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129110___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129109___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129108___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129107___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129106___Q)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))));
    __Vtemp_1[1U] = (IData)(((((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129169___Q)) 
                               << 0x3fU) | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129168___Q)) 
                                             << 0x3eU) 
                                            | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129167___Q)) 
                                                << 0x3dU) 
                                               | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129166___Q)) 
                                                   << 0x3cU) 
                                                  | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129165___Q)) 
                                                      << 0x3bU) 
                                                     | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129164___Q)) 
                                                         << 0x3aU) 
                                                        | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129163___Q)) 
                                                            << 0x39U) 
                                                           | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129162___Q)) 
                                                               << 0x38U) 
                                                              | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129161___Q)) 
                                                                  << 0x37U) 
                                                                 | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129160___Q)) 
                                                                     << 0x36U) 
                                                                    | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129159___Q)) 
                                                                        << 0x35U) 
                                                                       | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129158___Q)) 
                                                                           << 0x34U) 
                                                                          | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129157___Q)) 
                                                                              << 0x33U) 
                                                                             | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129156___Q)) 
                                                                                << 0x32U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129155___Q)) 
                                                                                << 0x31U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129154___Q)) 
                                                                                << 0x30U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129153___Q)) 
                                                                                << 0x2fU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129152___Q)) 
                                                                                << 0x2eU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129151___Q)) 
                                                                                << 0x2dU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129150___Q)) 
                                                                                << 0x2cU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129149___Q)) 
                                                                                << 0x2bU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129148___Q)) 
                                                                                << 0x2aU) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129147___Q)) 
                                                                                << 0x29U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129146___Q)) 
                                                                                << 0x28U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129145___Q)) 
                                                                                << 0x27U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129144___Q)) 
                                                                                << 0x26U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129143___Q)) 
                                                                                << 0x25U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129142___Q)) 
                                                                                << 0x24U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129141___Q)) 
                                                                                << 0x23U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129140___Q)) 
                                                                                << 0x22U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129139___Q)) 
                                                                                << 0x21U) 
                                                                                | (((QData)((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129138___Q)) 
                                                                                << 0x20U) 
                                                                                | (QData)((IData)(
                                                                                (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129137___Q) 
                                                                                << 0x1fU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129136___Q) 
                                                                                << 0x1eU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129135___Q) 
                                                                                << 0x1dU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129134___Q) 
                                                                                << 0x1cU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129133___Q) 
                                                                                << 0x1bU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129132___Q) 
                                                                                << 0x1aU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129131___Q) 
                                                                                << 0x19U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129130___Q) 
                                                                                << 0x18U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129129___Q) 
                                                                                << 0x17U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129128___Q) 
                                                                                << 0x16U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129127___Q) 
                                                                                << 0x15U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129126___Q) 
                                                                                << 0x14U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129125___Q) 
                                                                                << 0x13U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129124___Q) 
                                                                                << 0x12U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129123___Q) 
                                                                                << 0x11U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129122___Q) 
                                                                                << 0x10U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129121___Q) 
                                                                                << 0xfU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129120___Q) 
                                                                                << 0xeU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129119___Q) 
                                                                                << 0xdU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129118___Q) 
                                                                                << 0xcU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129117___Q) 
                                                                                << 0xbU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129116___Q) 
                                                                                << 0xaU) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129115___Q) 
                                                                                << 9U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129114___Q) 
                                                                                << 8U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129113___Q) 
                                                                                << 7U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129112___Q) 
                                                                                << 6U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129111___Q) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129110___Q) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129109___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129108___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129107___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129106___Q)))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) 
                             >> 0x20U));
    __Vtemp_17[2U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129186___Q) 
                       << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129185___Q) 
                                     << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129184___Q) 
                                                  << 0xeU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129183___Q) 
                                                     << 0xdU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129182___Q) 
                                                        << 0xcU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129181___Q) 
                                                           << 0xbU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129180___Q) 
                                                              << 0xaU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129179___Q) 
                                                                 << 9U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129178___Q) 
                                                                    << 8U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129177___Q) 
                                                                       << 7U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129176___Q) 
                                                                          << 6U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129175___Q) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129174___Q) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129173___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129172___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129171___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129170___Q)))))))))))))))));
    __Vtemp_49[3U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129218___Q) 
                       << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129217___Q) 
                                     << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129216___Q) 
                                                  << 0xeU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129215___Q) 
                                                     << 0xdU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129214___Q) 
                                                        << 0xcU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129213___Q) 
                                                           << 0xbU) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129212___Q) 
                                                              << 0xaU) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129211___Q) 
                                                                 << 9U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129210___Q) 
                                                                    << 8U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129209___Q) 
                                                                       << 7U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129208___Q) 
                                                                          << 6U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129207___Q) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129206___Q) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129205___Q) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129204___Q) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129203___Q) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT____Vcellout___129202___Q)))))))))))))))));
    vlSelf->mem_wdata[0U] = __Vtemp_1[0U];
    vlSelf->mem_wdata[1U] = __Vtemp_1[1U];
    vlSelf->mem_wdata[2U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129201___Q) 
                              << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129200___Q) 
                                            << 0x1eU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129199___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129198___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129197___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129196___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129195___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129194___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129193___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129192___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129191___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129190___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129189___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129188___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129187___Q) 
                                                                                << 0x11U) 
                                                                                | __Vtemp_17[2U])))))))))))))));
    vlSelf->mem_wdata[3U] = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129233___Q) 
                              << 0x1fU) | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129232___Q) 
                                            << 0x1eU) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129231___Q) 
                                               << 0x1dU) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129230___Q) 
                                                  << 0x1cU) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129229___Q) 
                                                     << 0x1bU) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129228___Q) 
                                                        << 0x1aU) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129227___Q) 
                                                           << 0x19U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129226___Q) 
                                                              << 0x18U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129225___Q) 
                                                                 << 0x17U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129224___Q) 
                                                                    << 0x16U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129223___Q) 
                                                                       << 0x15U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129222___Q) 
                                                                          << 0x14U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129221___Q) 
                                                                             << 0x13U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129220___Q) 
                                                                                << 0x12U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___129219___Q) 
                                                                                << 0x11U) 
                                                                                | __Vtemp_49[3U])))))))))))))));
    vlSelf->wasmetal_core__DOT___029768_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b30__05d))));
    vlSelf->wasmetal_core__DOT___032537_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b60__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b60__05d)))));
    vlSelf->wasmetal_core__DOT___045744_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->result_index 
                                                            >> 0x1aU))) 
                                                  & ((IData)(
                                                             (1ULL 
                                                              >> 
                                                              (0x3fU 
                                                               & (vlSelf->result_index 
                                                                  >> 0x14U)))) 
                                                     & ((IData)(
                                                                (1ULL 
                                                                 >> 
                                                                 (0x3fU 
                                                                  & (vlSelf->result_index 
                                                                     >> 0xeU)))) 
                                                        & ((~ (IData)(
                                                                      (0x100000000ULL 
                                                                       >> 
                                                                       (0x3fU 
                                                                        & (vlSelf->result_index 
                                                                           >> 8U))))) 
                                                           & (~ 
                                                              (vlSelf->result_index 
                                                               >> 0xdU)))))));
    vlSelf->wasmetal_core__DOT___032886_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___063390_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0x17U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x19U))) 
                                                                  << 4U)) 
                                                              | ((0xcU 
                                                                  & (vlSelf->function_locals 
                                                                     >> 0x19U)) 
                                                                 | (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x15U))))))));
    vlSelf->wasmetal_core__DOT___063391_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                            << 5U) 
                                                           | (0x1fU 
                                                              & vlSelf->function_locals)))));
    vlSelf->wasmetal_core__DOT___063385_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0x13U))) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> 
                                                                   (3U 
                                                                    & (vlSelf->function_locals 
                                                                       >> 0x11U))) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (vlSelf->function_locals 
                                                                    >> 0xdU)))))));
    vlSelf->__VdfgTmp_h4835143f__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x18U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d));
    vlSelf->wasmetal_core__DOT___029403_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d))));
    vlSelf->wasmetal_core__DOT___027822_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___026282_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029935_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d))));
    vlSelf->wasmetal_core__DOT___032535_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b59__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b59__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128330___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b3__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b2__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b1__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_left__05b0__05d))));
    vlSelf->wasmetal_core__DOT___128720___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__divider__02eremaining__05b0__05d));
    vlSelf->__VdfgTmp_h26309c84__0 = ((2U & (vlSelf->function_params 
                                             >> 0xcU)) 
                                      | (1U & (1U >> 
                                               (0x1fU 
                                                & (vlSelf->function_params 
                                                   >> 8U)))));
    vlSelf->wasmetal_core__DOT___032885_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029766_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b29__05d))));
    vlSelf->__VdfgTmp_hf6334cf8__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x17U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___052872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__check_type) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->type_matches))));
    vlSelf->wasmetal_core__DOT___029245_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d))));
    vlSelf->wasmetal_core__DOT___029244_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d))));
    vlSelf->wasmetal_core__DOT___026189_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d))));
    vlSelf->wasmetal_core__DOT___026188_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d))));
    vlSelf->wasmetal_core__DOT___032534_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b58__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b58__05d)))));
    vlSelf->wasmetal_core__DOT___029934_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b28__05d))));
    vlSelf->__VdfgTmp_h2b80e318__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x16U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d));
    vlSelf->wasmetal_core__DOT___032884_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029402_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d))));
    vlSelf->wasmetal_core__DOT___027821_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1cU)))));
    vlSelf->wasmetal_core__DOT___026281_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b28__05d))));
    vlSelf->__VdfgTmp_h17547017__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x15U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d));
    vlSelf->wasmetal_core__DOT___029765_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b28__05d))));
    vlSelf->__VdfgTmp_hed077be7__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x14U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d));
    vlSelf->wasmetal_core__DOT___054474_ = (1U & (0x35006bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___029933_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d))));
    vlSelf->wasmetal_core__DOT___032533_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b57__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b57__05d)))));
    vlSelf->wasmetal_core__DOT___050399_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->insn_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->reset))));
    vlSelf->wasmetal_core__DOT___048545_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d))));
    vlSelf->wasmetal_core__DOT___048570_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d))));
    vlSelf->wasmetal_core__DOT___048539_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d))));
    vlSelf->wasmetal_core__DOT___048295_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d))));
    vlSelf->__VdfgTmp_h1872cc15__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x13U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d));
    vlSelf->wasmetal_core__DOT___044684_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (vlSelf->cmd_aux 
                                                                >> 0xdU)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> 
                                                           (7U 
                                                            & (IData)(
                                                                      (vlSelf->cmd_aux 
                                                                       >> 0xaU)))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & (IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0xeU)))))))));
    vlSelf->wasmetal_core__DOT___044672_ = (1U & (0x4fU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & (IData)(
                                                                   (vlSelf->cmd_aux 
                                                                    >> 0xeU)))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (vlSelf->cmd_aux 
                                                                   >> 0xdU)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (7U 
                                                             & (IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0xaU)))))))));
    vlSelf->wasmetal_core__DOT___044689_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x28U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x29U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x2aU)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2bU)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2cU)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x2dU)))))))))));
    vlSelf->wasmetal_core__DOT___044688_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x22U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x23U)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x24U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x25U)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x26U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x27U)))))))))));
    vlSelf->wasmetal_core__DOT___044687_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x20U)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x21U)) 
                                                                  << 4U)) 
                                                              | (0xfU 
                                                                 & (IData)(
                                                                           (vlSelf->cmd_aux 
                                                                            >> 0x1cU))))))));
    vlSelf->wasmetal_core__DOT___044682_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x3aU)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x3cU)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x3dU)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3eU)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3bU)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x3fU)))))))))));
    vlSelf->wasmetal_core__DOT___044691_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x30U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x34U)) 
                                                               << 4U)) 
                                                           | ((8U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x37U)) 
                                                                  << 3U)) 
                                                              | ((4U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x38U)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x36U)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x39U))))))))));
    vlSelf->wasmetal_core__DOT___044690_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(
                                                                       (vlSelf->cmd_aux 
                                                                        >> 0x2eU)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(
                                                                          (vlSelf->cmd_aux 
                                                                           >> 0x2fU)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (vlSelf->cmd_aux 
                                                                              >> 0x30U)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x31U)) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & (IData)(
                                                                                (vlSelf->cmd_aux 
                                                                                >> 0x32U))))))))));
    vlSelf->wasmetal_core__DOT___044707_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 5U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 7U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___044706_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & vlSelf->function_params) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 2U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___044705_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  << 1U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___044711_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xfU)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x11U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x13U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___044710_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0xcU)) 
                                                           | ((0x18U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xfU)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))))))));
    vlSelf->wasmetal_core__DOT___044709_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 9U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0xbU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0xdU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___044704_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x18U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x1aU)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x1cU)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___044713_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & (vlSelf->function_params 
                                                               >> 0x15U)) 
                                                           | ((0x10U 
                                                               & (vlSelf->function_params 
                                                                  >> 0x17U)) 
                                                              | ((8U 
                                                                  & (vlSelf->function_params 
                                                                     >> 0x19U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___032883_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT___128179___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d));
    vlSelf->__VdfgTmp_h9473bd37__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x12U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d));
    vlSelf->wasmetal_core__DOT___128026___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & vlSelf->insn_z)));
    vlSelf->wasmetal_core__DOT___128266___DOT__CO__BRA__1__KET__ 
        = (1U & ((2U & vlSelf->mem_rdata[0U]) ? (vlSelf->mem_rdata[0U] 
                                                 >> 1U)
                  : vlSelf->mem_rdata[0U]));
    vlSelf->wasmetal_core__DOT___044272_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___044274_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___029764_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029401_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d))));
    vlSelf->wasmetal_core__DOT___027820_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___026280_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029932_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d))));
    vlSelf->wasmetal_core__DOT___052954_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02etrap__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032532_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b56__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b56__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128431___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___032882_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->__VdfgTmp_hfd696a08__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x11U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d));
    vlSelf->wasmetal_core__DOT___029931_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d))));
    vlSelf->wasmetal_core__DOT___032531_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b55__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b55__05d)))));
    vlSelf->wasmetal_core__DOT___128002___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d));
    vlSelf->wasmetal_core__DOT___029763_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b26__05d))));
    vlSelf->wasmetal_core__DOT___032881_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___128034___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___128155___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d));
    vlSelf->wasmetal_core__DOT___053303_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b27__05d)))))))));
    vlSelf->__VdfgTmp_hb0a19382__0 = ((2U & (vlSelf->insn_x 
                                             >> 0x10U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___029400_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d))));
    vlSelf->wasmetal_core__DOT___027819_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___026279_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b26__05d))));
    vlSelf->wasmetal_core__DOT___045951_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))))));
    vlSelf->wasmetal_core__DOT___045963_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))))));
    vlSelf->wasmetal_core__DOT___053296_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b4__05d))));
    vlSelf->wasmetal_core__DOT___053297_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->__VdfgTmp_h9a5fea4e__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->wasmetal_core__DOT___045955_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___045954_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___045953_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___045959_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___045958_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___045957_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___045952_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___045961_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___045967_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___045966_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___045965_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___045971_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___045970_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___045969_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___045968_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___045964_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___045973_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___045972_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___128188___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_result_slot__05b1__05d));
    vlSelf->wasmetal_core__DOT___128205___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___128370___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__catch_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___053290_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053293_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b22__05d))))))))))));
    vlSelf->wasmetal_core__DOT___053300_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b24__05d))));
    vlSelf->wasmetal_core__DOT___053301_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029930_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d))));
    vlSelf->wasmetal_core__DOT___053299_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__gc_count__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__gc_count__05b11__05d)))))))));
    vlSelf->__VdfgTmp_h950b0747__0 = (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d));
    vlSelf->__VdfgTmp_he45fe6bb__0 = (((IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d));
    vlSelf->wasmetal_core__DOT___032530_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b54__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b54__05d)))));
    vlSelf->wasmetal_core__DOT___029242_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d))));
    vlSelf->wasmetal_core__DOT___026186_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b29__05d))));
    vlSelf->wasmetal_core__DOT___032880_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___044209_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029762_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b25__05d))));
    vlSelf->wasmetal_core__DOT___044210_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b5__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b2__05d)))))))));
    vlSelf->__VdfgTmp_h959d8796__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xfU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___029929_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d))));
    vlSelf->wasmetal_core__DOT___128418___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b0__05d));
    vlSelf->wasmetal_core__DOT___032529_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b53__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b53__05d)))));
    vlSelf->wasmetal_core__DOT___032879_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->__VdfgTmp_h6d2d9567__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xeU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d));
    vlSelf->wasmetal_core__DOT___029399_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b25__05d))));
    vlSelf->wasmetal_core__DOT___027818_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___026278_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b25__05d))));
    vlSelf->__VdfgTmp_h291433ac__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xdU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___029928_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d))));
    vlSelf->wasmetal_core__DOT___029761_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b24__05d))));
    vlSelf->__VdfgTmp_hbd028268__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xcU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d));
    vlSelf->wasmetal_core__DOT___032528_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b52__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b52__05d)))));
    vlSelf->__VdfgTmp_ha938949d__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->__VdfgTmp_hd225b533__0 = (((IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___032878_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->__VdfgTmp_h6265db41__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xbU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___029927_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b21__05d))));
    vlSelf->__VdfgTmp_h7b2f5a0d__0 = ((2U & (vlSelf->insn_x 
                                             >> 0xaU)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d));
    vlSelf->wasmetal_core__DOT___032527_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b51__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___029760_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b23__05d))));
    vlSelf->wasmetal_core__DOT___029398_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b24__05d))));
    vlSelf->wasmetal_core__DOT___027817_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___026277_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b24__05d))));
    vlSelf->wasmetal_core__DOT___032876_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029926_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d))));
    vlSelf->wasmetal_core__DOT___026381_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b31__05d) 
                                                    << 1U) 
                                                   | (vlSelf->insn_x 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___026380_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b30__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1eU)))));
    vlSelf->__VdfgTmp_h73f978ac__0 = ((2U & ((IData)(vlSelf->cmd_kind) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->cmd_kind) 
                                               >> 3U)));
    vlSelf->__VdfgTmp_h86617c98__0 = ((2U & (vlSelf->insn_x 
                                             >> 9U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d));
    vlSelf->wasmetal_core__DOT___044214_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___052942_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032526_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b50__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___052934_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b31__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b30__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128422___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b19__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b18__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b17__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b16__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128423___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b23__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b22__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b21__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b20__05d))));
    vlSelf->__VdfgTmp_h5a9aeb48__0 = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b8__05d));
    vlSelf->__VdfgTmp_ha5b552f8__0 = (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b24__05d));
    vlSelf->wasmetal_core__DOT___052931_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___052932_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d))));
    vlSelf->wasmetal_core__DOT___052921_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b20__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b20__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b16__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d))))))))))));
    vlSelf->wasmetal_core__DOT___052924_ = (1U & (IData)(
                                                         (0x1001000000001001ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b25__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((6U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b23__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b23__05d))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (6U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b22__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b22__05d))))))))))));
    vlSelf->wasmetal_core__DOT___052929_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b24__05d))));
    vlSelf->wasmetal_core__DOT___052930_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029759_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b22__05d))));
    vlSelf->wasmetal_core__DOT___052928_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b14__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__catch_values__05b11__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___032875_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029924_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029241_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026185_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b28__05d))));
    vlSelf->wasmetal_core__DOT___070607_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___029397_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b23__05d))));
    vlSelf->wasmetal_core__DOT___027816_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x17U)))));
    vlSelf->wasmetal_core__DOT___026276_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b23__05d))));
    vlSelf->__VdfgTmp_h20c332a4__0 = ((2U & (vlSelf->insn_x 
                                             >> 8U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___032524_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b49__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___032874_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___029923_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b18__05d))));
    vlSelf->wasmetal_core__DOT___029758_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b21__05d))));
    vlSelf->__VdfgTmp_h1c8d20fd__0 = ((2U & (vlSelf->insn_x 
                                             >> 7U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d));
    vlSelf->wasmetal_core__DOT___032523_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b48__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___053317_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b90__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___053318_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b88__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___053325_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b76__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___053326_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b91__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___053313_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b72__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___053314_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b74__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___029922_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b17__05d))));
    vlSelf->wasmetal_core__DOT___053322_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b83__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 0x11U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b82__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 0x12U)))))));
    vlSelf->wasmetal_core__DOT___053323_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b68__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b64__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & vlSelf->insn_y))))));
    vlSelf->wasmetal_core__DOT___053324_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b69__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b65__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 1U)))))));
    vlSelf->wasmetal_core__DOT___032873_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT___029396_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b22__05d))));
    vlSelf->wasmetal_core__DOT___027815_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___026275_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b22__05d))));
    vlSelf->wasmetal_core__DOT___053311_ = (1U & (0x9009U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b71__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & (vlSelf->insn_y 
                                                          >> 5U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b70__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (vlSelf->insn_y 
                                                               >> 6U)))))));
    vlSelf->__VdfgTmp_h5736dc67__0 = ((2U & (vlSelf->insn_x 
                                             >> 6U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d));
    vlSelf->wasmetal_core__DOT___053310_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b93__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_y 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___052991_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02etrap__05b0__05d))));
    vlSelf->wasmetal_core__DOT___029757_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b20__05d))));
    vlSelf->__VdfgTmp_h13987860__0 = ((2U & (vlSelf->insn_x 
                                             >> 5U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d));
    vlSelf->wasmetal_core__DOT___032522_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b47__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b47__05d)))));
    vlSelf->__VdfgTmp_haa7ff968__0 = ((2U & (vlSelf->insn_x 
                                             >> 4U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d));
    vlSelf->wasmetal_core__DOT___029921_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b16__05d))));
    vlSelf->wasmetal_core__DOT___052944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b13__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b12__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__call_depth__05b11__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__call_depth__05b10__05d))))));
    vlSelf->wasmetal_core__DOT___032872_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->__VdfgTmp_h85ffa972__0 = ((2U & (vlSelf->insn_x 
                                             >> 3U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->__VdfgTmp_h83e5aafb__0 = ((2U & (vlSelf->insn_x 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___032521_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b46__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___029755_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b19__05d))));
    vlSelf->__VdfgTmp_hcb9fc16c__0 = ((2U & (vlSelf->insn_x 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___029920_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b15__05d))));
    vlSelf->wasmetal_core__DOT___029395_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b21__05d))));
    vlSelf->wasmetal_core__DOT___027814_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___026274_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b21__05d))));
    vlSelf->wasmetal_core__DOT___032871_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->__VdfgTmp_h8befad22__0 = ((2U & vlSelf->insn_x) 
                                      | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->__VdfgTmp_hc3285b0a__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b1__05d));
    vlSelf->__VdfgTmp_h46faf1d8__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b2__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b3__05d));
    vlSelf->__VdfgTmp_hf7906078__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b4__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b5__05d));
    vlSelf->__VdfgTmp_h5a8db87d__0 = (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b6__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ebounds__05b0__05d__02eindex__05b7__05d));
    vlSelf->wasmetal_core__DOT___032520_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b45__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___045572_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b10__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b9__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___045571_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___045570_ = (1U & (IData)(
                                                         (0x8ae8aef08ae08aeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b4__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___045576_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___045575_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___045574_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d)))))))));
    vlSelf->wasmetal_core__DOT___045569_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___045578_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___029919_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b14__05d))));
    vlSelf->__VdfgTmp_h17166267__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d));
    vlSelf->wasmetal_core__DOT___029754_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b18__05d))));
    vlSelf->wasmetal_core__DOT___032870_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029394_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b20__05d))));
    vlSelf->wasmetal_core__DOT___027813_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___026273_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b20__05d))));
    vlSelf->wasmetal_core__DOT___032519_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b44__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___029918_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b13__05d))));
    vlSelf->wasmetal_core__DOT___032869_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029753_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b17__05d))));
    vlSelf->wasmetal_core__DOT___032518_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b43__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___029917_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b12__05d))));
    vlSelf->wasmetal_core__DOT___032868_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xaU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029392_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b19__05d))));
    vlSelf->wasmetal_core__DOT___027811_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___026271_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b19__05d))));
    vlSelf->wasmetal_core__DOT___029916_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029752_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b16__05d))));
    vlSelf->wasmetal_core__DOT___032517_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b42__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b42__05d)))));
    vlSelf->wasmetal_core__DOT___032867_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 9U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___029240_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d))));
    vlSelf->wasmetal_core__DOT___026184_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b27__05d))));
    vlSelf->wasmetal_core__DOT___029915_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b10__05d))));
    vlSelf->wasmetal_core__DOT___032516_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b41__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___029751_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b15__05d))));
    vlSelf->wasmetal_core__DOT___029391_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b18__05d))));
    vlSelf->wasmetal_core__DOT___027810_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT___026270_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b18__05d))));
    vlSelf->wasmetal_core__DOT___032897_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 8U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___029945_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032515_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b40__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___032896_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___029750_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b14__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128289___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))))));
    vlSelf->wasmetal_core__DOT___029944_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b8__05d))));
    vlSelf->wasmetal_core__DOT___032513_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b39__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___029390_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b17__05d))));
    vlSelf->wasmetal_core__DOT___027809_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___026269_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b17__05d))));
    vlSelf->wasmetal_core__DOT___032895_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 6U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029943_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029749_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b13__05d))));
    vlSelf->wasmetal_core__DOT___032512_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b38__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___026378_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b29__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1dU)))));
    vlSelf->wasmetal_core__DOT___032894_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 5U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029942_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029389_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b16__05d))));
    vlSelf->wasmetal_core__DOT___027808_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0x10U)))));
    vlSelf->wasmetal_core__DOT___026268_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b16__05d))));
    vlSelf->wasmetal_core__DOT___032511_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b37__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___029748_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b12__05d))));
    vlSelf->wasmetal_core__DOT___128274___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__init_left__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__init_left__05b0__05d));
    vlSelf->wasmetal_core__DOT___029941_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b5__05d))));
    vlSelf->wasmetal_core__DOT___032893_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 4U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___032510_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b36__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___029747_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b11__05d))));
    vlSelf->wasmetal_core__DOT___029940_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b4__05d))));
    vlSelf->wasmetal_core__DOT___029388_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b15__05d))));
    vlSelf->wasmetal_core__DOT___027807_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT___032892_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 3U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032509_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b35__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b35__05d)))));
    vlSelf->wasmetal_core__DOT___065583_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b6__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b1__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b0__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__load_width__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__load_width__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___029939_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b3__05d))));
    vlSelf->wasmetal_core__DOT___032891_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___029746_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b10__05d))));
    vlSelf->wasmetal_core__DOT___128222___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d));
    vlSelf->wasmetal_core__DOT___026267_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b15__05d))));
    vlSelf->wasmetal_core__DOT___032508_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b34__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___029387_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b14__05d))));
    vlSelf->wasmetal_core__DOT___027806_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xeU)))));
    vlSelf->wasmetal_core__DOT___029936_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b2__05d))));
    vlSelf->wasmetal_core__DOT___032888_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___029239_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026183_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b26__05d))));
    vlSelf->wasmetal_core__DOT___029776_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032507_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b33__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b33__05d)))));
    vlSelf->wasmetal_core__DOT___029925_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b1__05d))));
    vlSelf->wasmetal_core__DOT___032877_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & vlSelf->insn_y) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029386_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b13__05d))));
    vlSelf->wasmetal_core__DOT___027805_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___029914_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__exception_reference__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__catch_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT___029775_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b8__05d))));
    vlSelf->wasmetal_core__DOT___032506_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b32__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___032866_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d))));
    vlSelf->__VdfgTmp_he965b193__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d));
    vlSelf->wasmetal_core__DOT___026266_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032505_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b31__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b31__05d)))));
    vlSelf->wasmetal_core__DOT___029774_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b7__05d))));
    vlSelf->wasmetal_core__DOT___029385_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b12__05d))));
    vlSelf->wasmetal_core__DOT___027804_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___036716_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1eU)) 
                                                   | (vlSelf->function_locals 
                                                      >> 0x1fU))));
    vlSelf->wasmetal_core__DOT___032504_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b30__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b30__05d)))));
    vlSelf->wasmetal_core__DOT___029773_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029384_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b11__05d))));
    vlSelf->wasmetal_core__DOT___027803_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___032502_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b29__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b29__05d)))));
    vlSelf->wasmetal_core__DOT___029772_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b5__05d))));
    vlSelf->wasmetal_core__DOT___026265_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029383_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b10__05d))));
    vlSelf->wasmetal_core__DOT___027802_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___032501_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b28__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b28__05d)))));
    vlSelf->wasmetal_core__DOT___029771_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b4__05d))));
    vlSelf->__VdfgTmp_h14e88ecb__0 = (((IData)(vlSelf->mem_ready) 
                                       << 1U) | (IData)(vlSelf->mem_fault));
    vlSelf->wasmetal_core__DOT___032500_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b27__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b27__05d)))));
    vlSelf->wasmetal_core__DOT___029770_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b3__05d))));
    vlSelf->__VdfgTmp_hc52368c6__0 = ((2U & vlSelf->insn_x) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 1U)));
    vlSelf->wasmetal_core__DOT___029413_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b9__05d))));
    vlSelf->wasmetal_core__DOT___027832_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___029238_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026182_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026377_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b28__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1cU)))));
    vlSelf->wasmetal_core__DOT___032499_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b26__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b26__05d)))));
    vlSelf->wasmetal_core__DOT___029767_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b2__05d))));
    vlSelf->wasmetal_core__DOT___026264_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029412_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b8__05d))));
    vlSelf->wasmetal_core__DOT___027831_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___127994___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128936___Q) 
           & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128937___Q));
    vlSelf->wasmetal_core__DOT___032498_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b25__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b25__05d)))));
    vlSelf->wasmetal_core__DOT___029756_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b1__05d))));
    vlSelf->__VdfgTmp_h673d32f0__0 = (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d));
    vlSelf->wasmetal_core__DOT___029411_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b7__05d))));
    vlSelf->wasmetal_core__DOT___027830_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___032497_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b24__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b24__05d)))));
    vlSelf->wasmetal_core__DOT___029745_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_reference__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_position__05b0__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128288___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))))));
    vlSelf->wasmetal_core__DOT___032496_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b23__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b23__05d)))));
    vlSelf->wasmetal_core__DOT___029410_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b6__05d))));
    vlSelf->wasmetal_core__DOT___027829_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___032495_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b22__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b22__05d)))));
    vlSelf->__VdfgTmp_hd0f5eb35__0 = ((2U & (vlSelf->insn_x 
                                             >> 6U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 7U)));
    vlSelf->wasmetal_core__DOT___029409_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b5__05d))));
    vlSelf->wasmetal_core__DOT___027828_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 5U)))));
    vlSelf->wasmetal_core__DOT___032494_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b21__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b21__05d)))));
    vlSelf->wasmetal_core__DOT___029237_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d))));
    vlSelf->wasmetal_core__DOT___026181_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b24__05d))));
    vlSelf->wasmetal_core__DOT___032493_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b20__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b20__05d)))));
    vlSelf->wasmetal_core__DOT___029408_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b4__05d))));
    vlSelf->wasmetal_core__DOT___027827_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___026263_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b11__05d))));
    vlSelf->__VdfgTmp_hd6f0d46f__0 = ((2U & (vlSelf->insn_x 
                                             >> 4U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 5U)));
    vlSelf->wasmetal_core__DOT___032491_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b19__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b19__05d)))));
    vlSelf->wasmetal_core__DOT___029407_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b3__05d))));
    vlSelf->wasmetal_core__DOT___027826_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___032218_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032217_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b30__05d))));
    vlSelf->wasmetal_core__DOT___032490_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b18__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b18__05d)))));
    vlSelf->wasmetal_core__DOT___029404_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b2__05d))));
    vlSelf->wasmetal_core__DOT___027823_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___032489_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b17__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b17__05d)))));
    vlSelf->wasmetal_core__DOT___029393_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029236_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026180_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b23__05d))));
    vlSelf->wasmetal_core__DOT___027812_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b1__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->function_params 
                                                         >> 1U)))));
    vlSelf->wasmetal_core__DOT___032488_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b16__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b16__05d)))));
    vlSelf->wasmetal_core__DOT___029382_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_len__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032487_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b15__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b15__05d)))));
    vlSelf->wasmetal_core__DOT___027801_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__callee_base__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & vlSelf->function_params))));
    vlSelf->wasmetal_core__DOT___032486_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b14__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b14__05d)))));
    vlSelf->wasmetal_core__DOT___026262_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b10__05d))));
    vlSelf->__VdfgTmp_hefae6eba__0 = ((2U & (vlSelf->insn_x 
                                             >> 1U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 2U)));
    vlSelf->wasmetal_core__DOT___029235_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d))));
    vlSelf->wasmetal_core__DOT___026179_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b22__05d))));
    vlSelf->__VdfgTmp_hec90fad7__0 = ((2U & (vlSelf->insn_x 
                                             >> 2U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 3U)));
    vlSelf->wasmetal_core__DOT___032485_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b13__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b13__05d)))));
    vlSelf->wasmetal_core__DOT___032484_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b12__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b12__05d)))));
    vlSelf->wasmetal_core__DOT___032483_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b11__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b11__05d)))));
    vlSelf->wasmetal_core__DOT___032698_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1eU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b31__05d))));
    vlSelf->wasmetal_core__DOT___032697_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1dU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b30__05d))));
    vlSelf->__VdfgTmp_ha0b2a3dd__0 = ((2U & (vlSelf->insn_z 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x1aU)));
    vlSelf->__VdfgTmp_h1ce9b3c5__0 = ((2U & (vlSelf->insn_z 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->insn_x 
                                               >> 0x17U)));
    vlSelf->wasmetal_core__DOT___032482_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b10__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b10__05d)))));
    vlSelf->wasmetal_core__DOT___029234_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026178_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026376_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b27__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1bU)))));
    vlSelf->wasmetal_core__DOT___032544_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b9__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b9__05d)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128287___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))))));
    vlSelf->wasmetal_core__DOT___032543_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b8__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b8__05d)))));
    vlSelf->wasmetal_core__DOT___032542_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b7__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b7__05d)))));
    vlSelf->wasmetal_core__DOT___026292_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b9__05d))));
    vlSelf->wasmetal_core__DOT___052005_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b85__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b84__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b79__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b78__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b73__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b72__05d)))))))));
    vlSelf->wasmetal_core__DOT___052006_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b115__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b114__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b113__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b103__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b102__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___052012_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b21__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b14__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___052013_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b49__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b39__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___052020_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___052021_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b83__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b82__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b81__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b71__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b70__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b64__05d)))))))));
    vlSelf->wasmetal_core__DOT___052016_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b44__05d))));
    vlSelf->wasmetal_core__DOT___052017_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b63__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b62__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b61__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b60__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___052018_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b53__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b52__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b47__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___052003_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b30__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b29__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b25__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___052025_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b95__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b94__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b93__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b92__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b89__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b88__05d)))))))));
    vlSelf->wasmetal_core__DOT___052022_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b123__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b122__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b107__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b106__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b101__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b100__05d)))))))));
    vlSelf->wasmetal_core__DOT___052023_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b18__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b17__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b0__05d)))))))));
    vlSelf->wasmetal_core__DOT___052008_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b117__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b116__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b111__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b110__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b105__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b104__05d)))))))));
    vlSelf->wasmetal_core__DOT___052009_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b91__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b90__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b75__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b74__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b69__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b68__05d)))))))));
    vlSelf->wasmetal_core__DOT___052010_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b127__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b126__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b125__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b124__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b121__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b120__05d)))))))));
    vlSelf->wasmetal_core__DOT___032541_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b6__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b6__05d)))));
    vlSelf->wasmetal_core__DOT___029233_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d))));
    vlSelf->wasmetal_core__DOT___026177_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b20__05d))));
    vlSelf->wasmetal_core__DOT___032536_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b5__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b5__05d)))));
    vlSelf->wasmetal_core__DOT___029231_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026175_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b19__05d))));
    vlSelf->wasmetal_core__DOT___026291_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b8__05d))));
    vlSelf->wasmetal_core__DOT___128255___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___029230_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d))));
    vlSelf->wasmetal_core__DOT___026174_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b18__05d))));
    vlSelf->wasmetal_core__DOT___032215_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029229_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d))));
    vlSelf->wasmetal_core__DOT___026173_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b17__05d))));
    vlSelf->wasmetal_core__DOT___026290_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b7__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128286___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))))));
    vlSelf->__VdfgTmp_hc3828814__0 = ((2U & (vlSelf->insn_x 
                                             << 1U)) 
                                      | (1U & vlSelf->insn_y));
    vlSelf->wasmetal_core__DOT___026375_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b26__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x1aU)))));
    vlSelf->wasmetal_core__DOT___029228_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026172_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026289_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b6__05d))));
    vlSelf->__VdfgTmp_hd3ff3db1__0 = ((2U & (vlSelf->insn_x 
                                             >> 5U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 6U)));
    vlSelf->wasmetal_core__DOT___029227_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d))));
    vlSelf->__VdfgTmp_he98db662__0 = ((2U & (vlSelf->insn_x 
                                             >> 3U)) 
                                      | (1U & (vlSelf->insn_y 
                                               >> 4U)));
    vlSelf->wasmetal_core__DOT___026171_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b15__05d))));
    vlSelf->wasmetal_core__DOT___026288_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b5__05d))));
    vlSelf->__VdfgTmp_h6b18dcfd__0 = (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b33__05d));
    vlSelf->__VdfgTmp_hb8b9c084__0 = (((IData)(vlSelf->wasmetal_core__DOT__fifth__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fifth__05b36__05d));
    vlSelf->wasmetal_core__DOT___029226_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d))));
    vlSelf->__VdfgTmp_h08c26bfc__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1dU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1eU)));
    vlSelf->wasmetal_core__DOT___026170_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b14__05d))));
    vlSelf->wasmetal_core__DOT___026287_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__gc_position__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__gc_source__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032214_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026374_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b25__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x19U)))));
    vlSelf->wasmetal_core__DOT___032695_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1cU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b29__05d))));
    vlSelf->wasmetal_core__DOT___029225_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128285___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))))));
    vlSelf->wasmetal_core__DOT___026169_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b13__05d))));
    vlSelf->wasmetal_core__DOT___029224_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029223_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d))));
    vlSelf->wasmetal_core__DOT___026168_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b12__05d))));
    vlSelf->wasmetal_core__DOT___029222_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d))));
    vlSelf->wasmetal_core__DOT___026373_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b24__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x18U)))));
    vlSelf->wasmetal_core__DOT___061598_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x17U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 8U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x11U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___061602_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x18U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 9U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x12U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___061616_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x19U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 0xaU)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x13U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 4U))))))))));
    vlSelf->wasmetal_core__DOT___029252_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032213_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b27__05d))));
    vlSelf->__VdfgTmp_h09206f3f__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1cU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1dU)));
    vlSelf->wasmetal_core__DOT___026167_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b11__05d))));
    vlSelf->wasmetal_core__DOT___032397_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b4__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b4__05d)))));
    vlSelf->wasmetal_core__DOT___029251_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d))));
    vlSelf->wasmetal_core__DOT___128050___DOT__CO__BRA__1__KET__ 
        = (IData)((3U == (3U & vlSelf->insn_x)));
    vlSelf->wasmetal_core__DOT___029250_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d))));
    vlSelf->wasmetal_core__DOT___032386_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b3__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___029249_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d))));
    vlSelf->wasmetal_core__DOT___029248_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d))));
    vlSelf->wasmetal_core__DOT___029247_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d))));
    vlSelf->wasmetal_core__DOT___032375_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b2__05d)))));
    vlSelf->__VdfgTmp_h9fa2de6d__0 = (((IData)(vlSelf->wasmetal_core__DOT__bulk_table) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill));
    vlSelf->wasmetal_core__DOT___026372_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b23__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x17U)))));
    vlSelf->wasmetal_core__DOT___029246_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b3__05d))));
    vlSelf->wasmetal_core__DOT___029243_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b2__05d))));
    vlSelf->wasmetal_core__DOT___032364_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b1__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b1__05d)))));
    vlSelf->wasmetal_core__DOT___029232_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b1__05d))));
    vlSelf->wasmetal_core__DOT___029221_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_dst__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032353_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__bulk_fill) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__bulk_destination__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__bulk_source__05b0__05d)))));
    vlSelf->wasmetal_core__DOT___026166_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b10__05d))));
    vlSelf->wasmetal_core__DOT___128018___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT__sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___026371_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b22__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x16U)))));
    vlSelf->wasmetal_core__DOT___032694_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1bU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b28__05d))));
    vlSelf->wasmetal_core__DOT___026196_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032212_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___026370_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b21__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x15U)))));
    vlSelf->wasmetal_core__DOT___026195_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b8__05d))));
    vlSelf->wasmetal_core__DOT___026194_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b7__05d))));
    vlSelf->wasmetal_core__DOT___026369_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b20__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x14U)))));
    vlSelf->wasmetal_core__DOT___026193_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b6__05d))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128284___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b11__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b10__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b8__05d))))));
    vlSelf->wasmetal_core__DOT___032211_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026192_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b5__05d))));
    vlSelf->wasmetal_core__DOT___026367_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b19__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x13U)))));
    vlSelf->wasmetal_core__DOT___026191_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__copy_src__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__copy_pos__05b4__05d))));
    vlSelf->wasmetal_core__DOT___044291_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_y 
                                                       >> 7U)) 
                                                   | (1U 
                                                      & (0xfffffffeU 
                                                         >> 
                                                         (0x1fU 
                                                          & (vlSelf->insn_y 
                                                             >> 9U)))))));
    vlSelf->wasmetal_core__DOT___026366_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b18__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x12U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128533___O 
        = ((3U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b1__05d)) 
                         << 3U)) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                                          << 2U)))) 
           ^ (7U | (8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d)) 
                          << 3U))));
    vlSelf->wasmetal_core__DOT___032693_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x1aU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b27__05d))));
    vlSelf->wasmetal_core__DOT___032210_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT___026365_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b17__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x11U)))));
    vlSelf->wasmetal_core__DOT___026364_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b16__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0x10U)))));
    vlSelf->__VdfgTmp_hbc309d1b__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1bU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1cU)));
    vlSelf->wasmetal_core__DOT___032209_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___026363_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b15__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xfU)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI 
        = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
            << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                  << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032692_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x19U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b26__05d))));
    vlSelf->wasmetal_core__DOT___032208_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___026362_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b14__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xeU)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___128283___S 
        = ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b7__05d)) 
                  << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b6__05d)) 
                                    << 2U)) | ((2U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b5__05d)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d))))));
    vlSelf->wasmetal_core__DOT___032207_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b21__05d))));
    vlSelf->wasmetal_core__DOT___026361_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b13__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xdU)))));
    vlSelf->wasmetal_core__DOT___032691_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x18U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b25__05d))));
    vlSelf->wasmetal_core__DOT___026360_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b12__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xcU)))));
    vlSelf->wasmetal_core__DOT___032206_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b20__05d))));
    vlSelf->__VdfgTmp_h4312483e__0 = ((2U & (vlSelf->function_params 
                                             >> 0x1aU)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1bU)));
    vlSelf->wasmetal_core__DOT___026359_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b11__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xbU)))));
    vlSelf->wasmetal_core__DOT___032204_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___065561_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b16__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b21__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b23__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b22__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b17__05d)))))));
    vlSelf->wasmetal_core__DOT___061588_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x15U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 6U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0xfU)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_imm[3U])))))))));
    vlSelf->wasmetal_core__DOT___061592_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (vlSelf->insn_imm[3U] 
                                                                     >> 0x16U)) 
                                                                 | ((4U 
                                                                     & (vlSelf->insn_imm[3U] 
                                                                        >> 7U)) 
                                                                    | ((2U 
                                                                        & (vlSelf->insn_imm[3U] 
                                                                           >> 0x10U)) 
                                                                       | (1U 
                                                                          & (vlSelf->insn_imm[3U] 
                                                                             >> 1U))))))))));
    vlSelf->wasmetal_core__DOT___026358_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b10__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 0xaU)))));
    vlSelf->wasmetal_core__DOT___032690_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x17U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b24__05d))));
    vlSelf->wasmetal_core__DOT____Vcellout___128508___O 
        = ((3U | ((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d)) 
                         << 3U)) | (4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                                          << 2U)))) 
           ^ (7U | (8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d)) 
                          << 3U))));
    vlSelf->wasmetal_core__DOT___032203_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b18__05d))));
    vlSelf->wasmetal_core__DOT___026388_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b9__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 9U)))));
    vlSelf->wasmetal_core__DOT___026387_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b8__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 8U)))));
    vlSelf->wasmetal_core__DOT___032689_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x16U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b23__05d))));
    vlSelf->wasmetal_core__DOT___032202_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___064088_ = (1U & (0x1000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b6__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b4__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b7__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___026386_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b7__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 7U)))));
    vlSelf->wasmetal_core__DOT___026385_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b6__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 6U)))));
    vlSelf->wasmetal_core__DOT___064095_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_op__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_op__05b1__05d))));
    vlSelf->wasmetal_core__DOT___026384_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b5__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 5U)))));
    vlSelf->__VdfgTmp_h4679be83__0 = ((2U & (vlSelf->function_params 
                                             >> 0x19U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x1aU)));
    vlSelf->wasmetal_core__DOT___032201_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT___026383_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fp__05b4__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_x 
                                                         >> 4U)))));
    vlSelf->wasmetal_core__DOT___032688_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x15U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b22__05d))));
    vlSelf->wasmetal_core__DOT___032200_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b15__05d))));
    vlSelf->wasmetal_core__DOT___032199_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___032687_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x14U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b21__05d))));
    vlSelf->wasmetal_core__DOT___032198_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b13__05d))));
    vlSelf->__VdfgTmp_h137eceb9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x18U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x19U)));
    vlSelf->wasmetal_core__DOT___032686_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x13U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b20__05d))));
    vlSelf->wasmetal_core__DOT___128314___DOT__CO__BRA__1__KET__ 
        = (IData)((0U == (3U & vlSelf->function_params)));
    vlSelf->wasmetal_core__DOT___032197_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___032196_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b11__05d))));
    vlSelf->wasmetal_core__DOT___032684_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x12U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b19__05d))));
    vlSelf->wasmetal_core__DOT___032195_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b10__05d))));
    vlSelf->wasmetal_core__DOT___128632___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d)) 
                 & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032225_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b9__05d))));
    vlSelf->wasmetal_core__DOT___032683_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x11U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b18__05d))));
    vlSelf->__VdfgTmp_h590821b5__0 = ((2U & (vlSelf->function_params 
                                             >> 0x17U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x18U)));
    vlSelf->wasmetal_core__DOT___042496_ = (1U & (0xaeefaeaeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b62__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b63__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b63__05d)))))));
    vlSelf->wasmetal_core__DOT___042498_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b9__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___042497_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b6__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___042494_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b2__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b3__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b3__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT___042502_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b20__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b21__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b22__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b20__05d)))))))));
    vlSelf->wasmetal_core__DOT___042501_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b16__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b17__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b18__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b19__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b18__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___042500_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b14__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b15__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b16__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b15__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___042499_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b12__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b13__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___042485_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b32__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b33__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___042484_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b29__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b30__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b31__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___042504_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b26__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b27__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b28__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b27__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___042503_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b23__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b24__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b25__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___042489_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___042488_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b41__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___042487_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b38__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b39__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b40__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b39__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___042486_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b34__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b35__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b37__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b36__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___042493_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___042492_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___042491_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___042490_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d)))))))));
    vlSelf->wasmetal_core__DOT___042495_ = (1U & (IData)(
                                                         (0xc8e8ecf0c8e0c8eULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b59__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b60__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b61__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d)))))))));
    vlSelf->wasmetal_core__DOT___035143_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b63__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b62__05d))));
    vlSelf->wasmetal_core__DOT___035142_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b62__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b61__05d))));
    vlSelf->wasmetal_core__DOT___035141_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b61__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b60__05d))));
    vlSelf->wasmetal_core__DOT___032224_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b8__05d))));
    vlSelf->wasmetal_core__DOT___035140_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b60__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b59__05d))));
    vlSelf->wasmetal_core__DOT___035138_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b59__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b58__05d))));
    vlSelf->wasmetal_core__DOT___035137_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b58__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b57__05d))));
    vlSelf->wasmetal_core__DOT___032682_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0x10U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d))));
    vlSelf->wasmetal_core__DOT___035136_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b57__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b56__05d))));
    vlSelf->wasmetal_core__DOT___032223_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b7__05d))));
    vlSelf->wasmetal_core__DOT___035135_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b56__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b55__05d))));
    vlSelf->wasmetal_core__DOT___035134_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b55__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b54__05d))));
    vlSelf->wasmetal_core__DOT___032222_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b6__05d))));
    vlSelf->wasmetal_core__DOT___035133_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b54__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b53__05d))));
    vlSelf->wasmetal_core__DOT___032681_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xfU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d))));
    vlSelf->wasmetal_core__DOT___035132_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b53__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b52__05d))));
    vlSelf->__VdfgTmp_h5a255a66__0 = ((2U & (vlSelf->function_params 
                                             >> 0x16U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x17U)));
    vlSelf->wasmetal_core__DOT___035131_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b52__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b51__05d))));
    vlSelf->wasmetal_core__DOT___032221_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b5__05d))));
    vlSelf->wasmetal_core__DOT___035130_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b51__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b50__05d))));
    vlSelf->wasmetal_core__DOT___032220_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b4__05d))));
    vlSelf->wasmetal_core__DOT___035129_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b50__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b49__05d))));
    vlSelf->wasmetal_core__DOT___032680_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xeU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b15__05d))));
    vlSelf->wasmetal_core__DOT___035127_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b49__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b48__05d))));
    vlSelf->wasmetal_core__DOT___032219_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b3__05d))));
    vlSelf->wasmetal_core__DOT___035126_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b48__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b47__05d))));
    vlSelf->__VdfgTmp_hbc3091a9__0 = ((2U & (vlSelf->function_params 
                                             >> 0x15U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x16U)));
    vlSelf->wasmetal_core__DOT___032216_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b2__05d))));
    vlSelf->wasmetal_core__DOT___035125_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b47__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b46__05d))));
    vlSelf->wasmetal_core__DOT___032679_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xdU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d))));
    vlSelf->wasmetal_core__DOT___035124_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b46__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b45__05d))));
    vlSelf->__VdfgTmp_hbf5bedf6__0 = (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b1__05d));
    vlSelf->wasmetal_core__DOT___035123_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b45__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b44__05d))));
    vlSelf->wasmetal_core__DOT___032194_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__control_base__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__control_sp__05b0__05d))));
    vlSelf->wasmetal_core__DOT___032678_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xcU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b13__05d))));
    vlSelf->wasmetal_core__DOT___035122_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b44__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b43__05d))));
    vlSelf->__VdfgTmp_h092cd911__0 = ((2U & (vlSelf->function_params 
                                             >> 0x14U)) 
                                      | (1U & (vlSelf->function_locals 
                                               >> 0x15U)));
    vlSelf->wasmetal_core__DOT___035121_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b43__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b42__05d))));
    vlSelf->wasmetal_core__DOT___032677_ = (1U & (9U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->function_params 
                                                       >> 0xbU)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__sp__05b12__05d))));
    vlSelf->wasmetal_core__DOT___035120_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b42__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02erem_value__05b41__05d))));
    vlSelf->__VdfgTmp_h2d9d1f69__0 = ((2U & (vlSelf->function_params 
                                             << 1U)) 
                                      | (1U & vlSelf->function_locals));
}
