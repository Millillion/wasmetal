#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__12(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__12\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___002315_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))))));
    vlSelf->wasmetal_core__DOT___002592_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h8ae31ec8__0))))));
    vlSelf->wasmetal_core__DOT___002553_ = (1U & (0xc0a0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b1__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000666_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d)))))));
    vlSelf->__VdfgTmp_h0643d6d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000180_))));
    vlSelf->__VdfgTmp_h703a7a56__0 = ((2U & ((4U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___002235_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___000181_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___000180_));
    vlSelf->wasmetal_core__DOT___002069_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001287_)))))))));
    vlSelf->wasmetal_core__DOT___002272_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000720_)))))))));
    vlSelf->wasmetal_core__DOT___002289_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001288_)))))))));
    vlSelf->wasmetal_core__DOT___000168_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___000819_)))))))));
    vlSelf->__VdfgTmp_he03432df__0 = (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___000170_))));
    vlSelf->wasmetal_core__DOT___002562_ = ((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                            & (IData)(
                                                      (0xf0f3333ff00ff55ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001285_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001662_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___001661_)))))))));
    vlSelf->wasmetal_core__DOT___002231_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000820_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000720_))))));
    vlSelf->wasmetal_core__DOT___000721_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000719_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000717_))))));
    vlSelf->wasmetal_core__DOT___002465_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001300_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001288_))))));
    vlSelf->wasmetal_core__DOT___001846_ = (1U & (0xdcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001663_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001662_))))));
    vlSelf->wasmetal_core__DOT___001705_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000819_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000719_))))));
    vlSelf->wasmetal_core__DOT___001289_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001287_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001285_))))));
    vlSelf->wasmetal_core__DOT___002387_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000821_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000819_))))));
    vlSelf->wasmetal_core__DOT___001780_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001299_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001287_))))));
    vlSelf->wasmetal_core__DOT___000722_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000720_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000718_))))));
    vlSelf->wasmetal_core__DOT___002110_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001301_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001299_))))));
    vlSelf->wasmetal_core__DOT___001290_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001288_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001286_))))));
    vlSelf->wasmetal_core__DOT___002181_ = (1U & (0xcdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001774_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001661_))))));
    vlSelf->wasmetal_core__DOT___002147_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000822_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000820_))))));
    vlSelf->wasmetal_core__DOT___002385_ = (1U & (0xdcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000575_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000574_))))));
    vlSelf->wasmetal_core__DOT___002111_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001302_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001300_))))));
    vlSelf->wasmetal_core__DOT___002148_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000181_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000180_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000920_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000821_))))));
    vlSelf->wasmetal_core__DOT___063428_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063007_))));
    vlSelf->wasmetal_core__DOT___050401_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050398_))));
    vlSelf->wasmetal_core__DOT___063825_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063824_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___010423_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048370_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___054752_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007034_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___008018_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048505_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h66357502__0))))));
    vlSelf->wasmetal_core__DOT___062968_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053019_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c8f7b91__0))));
    vlSelf->wasmetal_core__DOT___053360_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053349_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053348_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053347_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccf0fc3fc00cfff7ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053343_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053345_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053344_)))))))));
    vlSelf->wasmetal_core__DOT___053491_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053344_))));
    vlSelf->__VdfgTmp_h5c1295c2__0 = (((IData)(vlSelf->wasmetal_core__DOT___052991_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___053575_));
    vlSelf->wasmetal_core__DOT___063380_ = (1U & (0xd0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063375_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053575_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d)))));
    vlSelf->__VdfgTmp_h5d9fd2de__0 = (((IData)(vlSelf->wasmetal_core__DOT___048629_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048618_));
    vlSelf->wasmetal_core__DOT___051345_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051344_))));
    vlSelf->__VdfgTmp_h4f58838a__0 = (((IData)(vlSelf->wasmetal_core__DOT___048618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048617_));
    vlSelf->wasmetal_core__DOT___051365_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051344_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051364_))));
    vlSelf->wasmetal_core__DOT___051519_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051518_))));
    vlSelf->__VdfgTmp_h58306e5b__0 = (((IData)(vlSelf->wasmetal_core__DOT___048617_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048606_));
    vlSelf->wasmetal_core__DOT___049026_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004913_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b410c9d__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b26__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_)))))))));
    vlSelf->wasmetal_core__DOT___051548_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051518_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051547_))));
    vlSelf->__VdfgTmp_hce73595f__0 = (((IData)(vlSelf->wasmetal_core__DOT___048606_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048605_));
    vlSelf->__VdfgTmp_h36154466__0 = (((IData)(vlSelf->wasmetal_core__DOT___051547_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051579_));
    vlSelf->__VdfgTmp_h1dedb610__0 = (((IData)(vlSelf->wasmetal_core__DOT___048605_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048660_));
    vlSelf->wasmetal_core__DOT___049016_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___004845_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h651d6523__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b28__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_)))))))));
    vlSelf->wasmetal_core__DOT___051612_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051579_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051611_))));
    vlSelf->__VdfgTmp_ha9985ff6__0 = (((IData)(vlSelf->wasmetal_core__DOT___048660_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048659_));
    vlSelf->wasmetal_core__DOT___049019_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005253_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h9b25c217__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b29__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002760_)))))))));
    vlSelf->wasmetal_core__DOT___051648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048663_))));
    vlSelf->wasmetal_core__DOT___048669_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048663_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___051629_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051611_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051628_))));
    vlSelf->__VdfgTmp_h309182ec__0 = (((IData)(vlSelf->wasmetal_core__DOT___048659_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048670_));
    vlSelf->wasmetal_core__DOT___049008_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___005185_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h6b2c9c37__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002884_)))))))));
    vlSelf->wasmetal_core__DOT___049152_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___049321_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048562_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049151_))));
    vlSelf->wasmetal_core__DOT___049367_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049129_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049130_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049129_))));
    vlSelf->wasmetal_core__DOT___049159_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___049312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049158_))));
    vlSelf->wasmetal_core__DOT___049136_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3355330f0000ffffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0xe0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___003093_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h312c1c6b__0))) 
                                                                               << 2U)) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b33__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___048910_))))))))))));
    vlSelf->wasmetal_core__DOT___049156_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___049311_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049155_))));
    vlSelf->wasmetal_core__DOT___049365_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049138_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049139_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049138_))));
    vlSelf->wasmetal_core__DOT___049164_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->wasmetal_core__DOT___049316_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049163_))));
    vlSelf->wasmetal_core__DOT___048689_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048688_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049141_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048688_))));
    vlSelf->wasmetal_core__DOT___049095_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003889_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_he4dfb545__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b20__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002317_)))))))));
    vlSelf->wasmetal_core__DOT___049274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___049069_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049068_))));
    vlSelf->wasmetal_core__DOT___049167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___049315_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049166_))));
    vlSelf->wasmetal_core__DOT___047814_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047804_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048586_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047804_))));
    vlSelf->__VdfgTmp_hb2b84c00__0 = (((IData)(vlSelf->wasmetal_core__DOT___048642_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048641_));
    vlSelf->wasmetal_core__DOT___051112_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051054_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051111_))));
    vlSelf->wasmetal_core__DOT___049063_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003369_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hadae1421__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b21__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002594_)))))))));
    vlSelf->__VdfgTmp_hb043089c__0 = (((IData)(vlSelf->wasmetal_core__DOT___048630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048629_));
    vlSelf->__VdfgTmp_hc673eb53__0 = (((IData)(vlSelf->wasmetal_core__DOT___048641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048630_));
    vlSelf->__VdfgTmp_h7cd11e4f__0 = (((IData)(vlSelf->wasmetal_core__DOT___051111_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051286_));
    vlSelf->wasmetal_core__DOT___051325_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051324_))));
    vlSelf->wasmetal_core__DOT___049060_ = (1U & (IData)(
                                                         (0x33aa33f00000ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047793_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___003301_) 
                                                                           << 3U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hd44758f6__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eresult__05b22__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_)))))))));
    vlSelf->wasmetal_core__DOT___049038_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___049070_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049037_))));
    vlSelf->wasmetal_core__DOT___049035_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->wasmetal_core__DOT___049076_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049034_))));
    vlSelf->wasmetal_core__DOT___049176_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___049291_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049175_))));
    vlSelf->wasmetal_core__DOT___047813_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047812_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048585_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047812_))));
    vlSelf->wasmetal_core__DOT___049030_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->wasmetal_core__DOT___049079_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049029_))));
    vlSelf->wasmetal_core__DOT___049179_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    vlSelf->wasmetal_core__DOT___049292_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049178_))));
    vlSelf->wasmetal_core__DOT___047832_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047830_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048584_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047830_))));
    vlSelf->wasmetal_core__DOT___049187_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___049296_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049186_))));
    vlSelf->wasmetal_core__DOT___047831_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047822_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048583_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047822_))));
    vlSelf->wasmetal_core__DOT___049012_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___049126_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049011_))));
    vlSelf->wasmetal_core__DOT___049184_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___049295_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049183_))));
    vlSelf->wasmetal_core__DOT___047892_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047882_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048580_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047882_))));
    vlSelf->wasmetal_core__DOT___049197_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___049302_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049196_))));
    vlSelf->wasmetal_core__DOT___047891_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047890_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048579_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047890_))));
    vlSelf->wasmetal_core__DOT___049194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___049301_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049193_))));
    vlSelf->wasmetal_core__DOT___047910_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047908_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048578_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047908_))));
    vlSelf->wasmetal_core__DOT___049200_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___048984_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048983_))));
    vlSelf->wasmetal_core__DOT___047909_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047900_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___048577_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047900_))));
    vlSelf->wasmetal_core__DOT___049201_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->wasmetal_core__DOT___048987_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048986_))));
    vlSelf->wasmetal_core__DOT___047852_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047850_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049115_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047850_))));
    vlSelf->wasmetal_core__DOT___049101_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___048992_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048991_))));
    vlSelf->wasmetal_core__DOT___047851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047842_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049497_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047842_))));
    vlSelf->wasmetal_core__DOT___049102_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___048995_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048994_))));
    vlSelf->wasmetal_core__DOT___047872_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047860_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049613_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047860_))));
    vlSelf->wasmetal_core__DOT___049105_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___048969_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048968_))));
    vlSelf->wasmetal_core__DOT___047871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047870_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049697_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047870_))));
    vlSelf->wasmetal_core__DOT___049106_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___048966_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048965_))));
    vlSelf->wasmetal_core__DOT___047946_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049746_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047944_))));
    vlSelf->wasmetal_core__DOT___049088_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___048977_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048976_))));
    vlSelf->wasmetal_core__DOT___047945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047936_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049794_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047936_))));
    vlSelf->wasmetal_core__DOT___049087_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->wasmetal_core__DOT___048974_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048973_))));
    vlSelf->wasmetal_core__DOT___047928_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047919_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___049883_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047919_))));
    vlSelf->wasmetal_core__DOT___049093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047803_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___049261_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049092_))));
    vlSelf->wasmetal_core__DOT___047927_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047926_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O)))));
    vlSelf->wasmetal_core__DOT___050690_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128509___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047926_))));
    vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___128282___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050405_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050397_))));
    vlSelf->wasmetal_core__DOT___053512_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___044526_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052837_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___052677_))))));
    if (vlSelf->wasmetal_core__DOT___003035_) {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___003035_)));
    } else {
        vlSelf->wasmetal_core__DOT___035237_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___035253_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__));
        vlSelf->wasmetal_core__DOT___036925_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128722___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                                << 1U)) 
                                         | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128722___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128724___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___003030_) 
                                          << 1U) | 
                                         (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___003034_)))))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128724___DOT__CO__BRA__1__KET__) 
                                << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                                << 1U))))));
    vlSelf->wasmetal_core__DOT____Vcellout___134177___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003033_)) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_hefabe8e1__0))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134177___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___037030_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003035_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___134190___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___003035_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                        << 2U) | ((2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003030_)) 
                                         << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___003034_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134190___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003034_)) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___042546_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070623_))));
    vlSelf->wasmetal_core__DOT___070618_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003029_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___070604_)))));
    vlSelf->wasmetal_core__DOT___042535_ = (1U & (0x4fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___042723_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070623_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___042616_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070603_))));
    vlSelf->wasmetal_core__DOT___042646_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003033_))));
    vlSelf->wasmetal_core__DOT___070631_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___070613_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070612_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042558_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070617_))));
    vlSelf->wasmetal_core__DOT___042694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070614_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070612_))));
    vlSelf->wasmetal_core__DOT___018382_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003031_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___048210_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc058618d__0))))))))));
    vlSelf->wasmetal_core__DOT___058938_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___070605_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003035_))));
    vlSelf->wasmetal_core__DOT___042740_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070606_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058559_))));
    vlSelf->wasmetal_core__DOT___042581_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058525_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003033_)))));
    vlSelf->wasmetal_core__DOT___070630_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003035_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058525_))));
    vlSelf->wasmetal_core__DOT___067607_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053924_))));
    vlSelf->wasmetal_core__DOT___069234_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___026478_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b31__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053923_))));
    vlSelf->wasmetal_core__DOT___069160_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___026477_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b30__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053954_))));
    vlSelf->wasmetal_core__DOT___069141_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___026475_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b29__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053953_))));
    vlSelf->wasmetal_core__DOT___069092_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053952_))));
    vlSelf->wasmetal_core__DOT___026474_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b28__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053952_))));
    vlSelf->wasmetal_core__DOT___069042_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053951_))));
    vlSelf->wasmetal_core__DOT___026473_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b27__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053951_))));
    vlSelf->wasmetal_core__DOT___068970_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053950_))));
    vlSelf->wasmetal_core__DOT___026472_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b26__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053950_))));
    vlSelf->wasmetal_core__DOT___068944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053949_))));
    vlSelf->wasmetal_core__DOT___026471_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b25__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053949_))));
    vlSelf->wasmetal_core__DOT___068900_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053948_))));
    vlSelf->wasmetal_core__DOT___026470_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b24__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053948_))));
    vlSelf->wasmetal_core__DOT___068853_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053947_))));
    vlSelf->wasmetal_core__DOT___026469_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b23__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053947_))));
    vlSelf->wasmetal_core__DOT___068798_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053946_))));
    vlSelf->wasmetal_core__DOT___026468_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b22__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053946_))));
    vlSelf->wasmetal_core__DOT___068754_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053945_))));
    vlSelf->wasmetal_core__DOT___026467_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b21__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053945_))));
    vlSelf->wasmetal_core__DOT___068705_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053944_))));
    vlSelf->wasmetal_core__DOT___026466_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b20__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053944_))));
    vlSelf->wasmetal_core__DOT___068657_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053943_))));
    vlSelf->wasmetal_core__DOT___026464_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b19__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053943_))));
    vlSelf->wasmetal_core__DOT___068608_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053942_))));
    vlSelf->wasmetal_core__DOT___026463_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b18__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053942_))));
    vlSelf->wasmetal_core__DOT___068555_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053941_))));
    vlSelf->wasmetal_core__DOT___026462_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b17__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053941_))));
    vlSelf->wasmetal_core__DOT___068478_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053940_))));
    vlSelf->wasmetal_core__DOT___026461_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b16__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053940_))));
    vlSelf->wasmetal_core__DOT___068426_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053939_))));
    vlSelf->wasmetal_core__DOT___026460_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053939_))));
    vlSelf->wasmetal_core__DOT___068402_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053938_))));
    vlSelf->wasmetal_core__DOT___026459_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b14__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053938_))));
    vlSelf->wasmetal_core__DOT___068347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053937_))));
    vlSelf->wasmetal_core__DOT___026458_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b13__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053937_))));
    vlSelf->wasmetal_core__DOT___068293_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053936_))));
    vlSelf->wasmetal_core__DOT___026457_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b12__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053936_))));
    vlSelf->wasmetal_core__DOT___068240_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053935_))));
    vlSelf->wasmetal_core__DOT___026456_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b11__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053935_))));
    vlSelf->wasmetal_core__DOT___068155_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053934_))));
    vlSelf->wasmetal_core__DOT___026455_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b10__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053934_))));
    vlSelf->wasmetal_core__DOT___068104_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053933_))));
    vlSelf->wasmetal_core__DOT___026485_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b9__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053933_))));
    vlSelf->wasmetal_core__DOT___068079_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053932_))));
    vlSelf->wasmetal_core__DOT___026484_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053932_))));
    vlSelf->wasmetal_core__DOT___068020_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053931_))));
    vlSelf->wasmetal_core__DOT___026483_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053931_))));
    vlSelf->wasmetal_core__DOT___067963_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053930_))));
    vlSelf->wasmetal_core__DOT___026482_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b6__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053930_))));
    vlSelf->wasmetal_core__DOT___067897_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053929_))));
    vlSelf->wasmetal_core__DOT___026481_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053929_))));
    vlSelf->wasmetal_core__DOT___067810_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053928_))));
    vlSelf->wasmetal_core__DOT___026480_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b4__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053928_))));
    vlSelf->wasmetal_core__DOT___067749_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053927_))));
    vlSelf->wasmetal_core__DOT___026479_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b3__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053927_))));
    vlSelf->wasmetal_core__DOT___026476_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053926_))));
    vlSelf->wasmetal_core__DOT___067659_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053925_))));
    vlSelf->wasmetal_core__DOT___026465_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b1__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053925_))));
    vlSelf->wasmetal_core__DOT___026454_ = (1U & (0x7f0080ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__heap_next__05b0__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053924_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0x8000000000000000ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___053945_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___053944_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053939_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053938_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053933_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053932_)))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x8000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053941_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053937_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053936_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053947_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053946_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053927_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053925_)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053953_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053952_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053935_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053934_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053929_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053928_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053943_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053942_))))))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___053954_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053951_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053950_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053949_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053948_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x80U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053923_)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036783_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134152___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_haa7ff968__0))));
    vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028307_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128058___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___028242_));
    vlSelf->wasmetal_core__DOT___063398_ = (1U & (0x3050000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052905_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052906_)))))));
    vlSelf->__VdfgTmp_hca0be130__0 = (((IData)(vlSelf->wasmetal_core__DOT___070452_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052700_));
    vlSelf->wasmetal_core__DOT___069508_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc0be46f7__0)))));
    vlSelf->wasmetal_core__DOT___069532_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hfd746550__0)))));
    vlSelf->wasmetal_core__DOT___069601_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h3e014765__0)))));
    vlSelf->wasmetal_core__DOT___070025_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5702c3be__0)))));
    vlSelf->wasmetal_core__DOT___063452_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063451_))));
    vlSelf->wasmetal_core__DOT___069645_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5f949c7c__0)))));
    vlSelf->wasmetal_core__DOT___069712_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2e498b5e__0)))));
    vlSelf->wasmetal_core__DOT___069734_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc135e20a__0)))));
    vlSelf->wasmetal_core__DOT___069756_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h74dbdf51__0)))));
    vlSelf->wasmetal_core__DOT___069777_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha6dc66a3__0)))));
    vlSelf->wasmetal_core__DOT___069799_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0f5e432a__0)))));
    vlSelf->wasmetal_core__DOT___069821_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h26cb2e9d__0)))));
    vlSelf->wasmetal_core__DOT___069966_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h77d6a635__0)))));
    vlSelf->wasmetal_core__DOT___069986_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h66a2df13__0)))));
    vlSelf->wasmetal_core__DOT___063464_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063463_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             << 1U)) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063472_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063471_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___063480_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063479_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                             >> 1U)) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128490___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063448_)))))));
    vlSelf->wasmetal_core__DOT___069407_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d34c5b9__0)))));
    vlSelf->wasmetal_core__DOT___069552_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1b5c1c30__0)))));
    vlSelf->wasmetal_core__DOT___065937_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h71467b4f__0)))));
    vlSelf->wasmetal_core__DOT___066082_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h20a47ce2__0)))));
    vlSelf->wasmetal_core__DOT___066400_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h57521c49__0)))));
    vlSelf->wasmetal_core__DOT___066526_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h68543eec__0)))));
    vlSelf->wasmetal_core__DOT___066648_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4a3667e8__0)))));
    vlSelf->wasmetal_core__DOT___066770_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5d92aff2__0)))));
    vlSelf->wasmetal_core__DOT___066894_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heec1cc96__0)))));
    vlSelf->wasmetal_core__DOT___065188_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc6273ca__0)))));
    vlSelf->wasmetal_core__DOT___066314_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b995397__0)))));
    vlSelf->wasmetal_core__DOT___066603_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2653381__0)))));
    vlSelf->wasmetal_core__DOT___066853_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h898dd08d__0)))));
    vlSelf->wasmetal_core__DOT___066124_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11733417__0)))));
    vlSelf->wasmetal_core__DOT___067076_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h27758395__0)))));
    vlSelf->wasmetal_core__DOT___067154_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2c2ac443__0)))));
    vlSelf->wasmetal_core__DOT___067195_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc7b7ff9d__0)))));
    vlSelf->wasmetal_core__DOT___066971_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h09cdcbfb__0)))));
    vlSelf->wasmetal_core__DOT___064731_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hff7a62d4__0)))));
    vlSelf->wasmetal_core__DOT___063822_ = (1U & (IData)(
                                                         (0x33305550fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052902_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he3cb924f__0))))))));
    vlSelf->wasmetal_core__DOT___026495_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071973_))));
    vlSelf->wasmetal_core__DOT___071972_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071968_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071971_)))));
    vlSelf->wasmetal_core__DOT___071970_ = (1U & (0xf0f03355U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071910_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071966_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000635_)))))));
    vlSelf->wasmetal_core__DOT___071969_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071968_)))));
    vlSelf->wasmetal_core__DOT___071967_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071962_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071966_)))));
    vlSelf->wasmetal_core__DOT___071965_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071960_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071964_)))));
    vlSelf->wasmetal_core__DOT___071963_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071958_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071962_)))));
    vlSelf->wasmetal_core__DOT___071961_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071956_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071960_)))));
    vlSelf->wasmetal_core__DOT___071959_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071954_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071958_)))));
    vlSelf->wasmetal_core__DOT___071957_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071952_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071956_)))));
    vlSelf->wasmetal_core__DOT___071955_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071950_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071954_)))));
    vlSelf->wasmetal_core__DOT___071953_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071948_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071952_)))));
    vlSelf->wasmetal_core__DOT___071951_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071946_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071950_)))));
    vlSelf->wasmetal_core__DOT___071949_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071944_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071948_)))));
    vlSelf->wasmetal_core__DOT___071947_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071942_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071946_)))));
    vlSelf->wasmetal_core__DOT___071945_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071940_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071944_)))));
    vlSelf->wasmetal_core__DOT___071943_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071938_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071942_)))));
    vlSelf->wasmetal_core__DOT___071941_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071936_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071940_)))));
    vlSelf->wasmetal_core__DOT___071939_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071934_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071938_)))));
    vlSelf->wasmetal_core__DOT___071937_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071932_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071936_)))));
    vlSelf->wasmetal_core__DOT___071935_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071930_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071934_)))));
    vlSelf->wasmetal_core__DOT___071933_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071928_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071932_)))));
    vlSelf->wasmetal_core__DOT___071931_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071926_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071930_)))));
    vlSelf->wasmetal_core__DOT___071929_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071924_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071928_)))));
    vlSelf->wasmetal_core__DOT___071927_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071922_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071926_)))));
    vlSelf->wasmetal_core__DOT___071925_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071920_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071924_)))));
    vlSelf->wasmetal_core__DOT___071923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071918_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071922_)))));
    vlSelf->wasmetal_core__DOT___071921_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071916_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071920_)))));
    vlSelf->wasmetal_core__DOT___071919_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071914_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071918_)))));
    vlSelf->wasmetal_core__DOT___071915_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071914_))));
    vlSelf->wasmetal_core__DOT___026562_ = (1U & (0xef10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071912_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071911_))))));
    vlSelf->wasmetal_core__DOT___071917_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071911_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071913_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___071916_)))));
    vlSelf->wasmetal_core__DOT___051686_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051043_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051031_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfa693494__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7031c855__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb1756308__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051035_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h87f17c6b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h60760575__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6239803f__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051039_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h980fd1a4__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h12f13bc4__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3ca396d5__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050775_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050755_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050738_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5ee84e09__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h05fef25b__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf75b3db8__0))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050728_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9adc8e2b__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h35252d63__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hac7d774c__0))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050751_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb13e555e__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4fc63e3e__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5b3781b6__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___053472_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053452_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053448_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051878_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049430_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___072255_ = (1U & (IData)(
                                                         (0xf0f0ccccff00aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b5__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072251_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051442_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b55__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b54__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b52__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b59__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b58__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b56__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b63__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b62__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b60__05d)))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072243_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b18__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b16__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b27__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b26__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b30__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b29__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b28__05d)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b2__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072239_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b6__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b5__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b4__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b11__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b10__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b9__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b8__05d)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ebounds__05b1__05d__02eindex__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b14__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b13__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid__05b12__05d)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___071249_ = (1U & (IData)(
                                                         (0xf088000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))))));
    vlSelf->wasmetal_core__DOT___071251_ = (1U & (IData)(
                                                         (0xf088000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071004_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02evalid_b)))))))));
    vlSelf->wasmetal_core__DOT___070953_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b2__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 2U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbba81ae3__0))))))));
    vlSelf->wasmetal_core__DOT___070954_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b1__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 1U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5dfde09f__0))))))));
    vlSelf->wasmetal_core__DOT___070989_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b11__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xaU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h670f6b42__0))))))));
    vlSelf->wasmetal_core__DOT___070990_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b10__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 9U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb8649aac__0))))))));
    vlSelf->wasmetal_core__DOT___070991_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b9__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 8U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd389bfd2__0))))))));
    vlSelf->wasmetal_core__DOT___071001_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b14__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xdU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb8717f5__0))))))));
    vlSelf->wasmetal_core__DOT___071002_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b13__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xcU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0201c3e9__0))))))));
    vlSelf->wasmetal_core__DOT___071003_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b12__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xbU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbc582c17__0))))))));
    vlSelf->wasmetal_core__DOT___070955_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b0__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___070950_)))))))));
    vlSelf->wasmetal_core__DOT___071047_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071035_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b23__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x15U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5b1f350b__0))))))));
    vlSelf->wasmetal_core__DOT___071048_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071039_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b22__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x14U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1915a5ff__0))))))));
    vlSelf->wasmetal_core__DOT___071049_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071043_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b21__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x13U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h70b63d5e__0))))))));
    vlSelf->wasmetal_core__DOT___071062_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071050_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b26__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h852d6a23__0))))))));
    vlSelf->wasmetal_core__DOT___071063_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071054_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b25__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x17U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9685a33e__0))))))));
    vlSelf->wasmetal_core__DOT___071064_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071058_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b24__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x16U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hee7ba675__0))))))));
    vlSelf->wasmetal_core__DOT___071107_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071095_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b35__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ba16cdb__0))))))));
    vlSelf->wasmetal_core__DOT___071108_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071099_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b34__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1fU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1473a3fc__0))))))));
    vlSelf->wasmetal_core__DOT___071109_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071103_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b33__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1eU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbbedaddf__0))))))));
    vlSelf->wasmetal_core__DOT___071122_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071110_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b38__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x22U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3006d0f0__0))))))));
    vlSelf->wasmetal_core__DOT___071123_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071114_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b37__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x21U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0919c673__0))))))));
    vlSelf->wasmetal_core__DOT___071124_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071118_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b36__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x20U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc7238523__0))))))));
    vlSelf->wasmetal_core__DOT___071167_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b47__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2aU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h73075b94__0))))))));
    vlSelf->wasmetal_core__DOT___071168_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071159_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b46__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x29U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h17228d9d__0))))))));
    vlSelf->wasmetal_core__DOT___071169_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071163_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b45__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x28U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7ee7d44c__0))))))));
    vlSelf->wasmetal_core__DOT___071182_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071170_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b50__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb3e6303e__0))))))));
    vlSelf->wasmetal_core__DOT___071183_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071174_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b49__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2cU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd266b697__0))))))));
    vlSelf->wasmetal_core__DOT___071184_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b48__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2bU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h123a295b__0))))))));
    vlSelf->wasmetal_core__DOT___071227_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071215_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b59__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x35U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h5dc57786__0))))))));
    vlSelf->wasmetal_core__DOT___071228_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071219_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b58__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x34U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h86abd4f4__0))))))));
    vlSelf->wasmetal_core__DOT___071229_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071223_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b57__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h966a07d3__0))))))));
    vlSelf->wasmetal_core__DOT___071242_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071230_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b62__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 5U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h48de7988__0))))))));
    vlSelf->wasmetal_core__DOT___071243_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071234_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b61__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x37U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a64daef__0))))))));
    vlSelf->wasmetal_core__DOT___071244_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071238_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b60__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x36U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h966312d4__0))))))));
    vlSelf->wasmetal_core__DOT___070965_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b5__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 5U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf7e0b807__0))))))));
    vlSelf->wasmetal_core__DOT___070966_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b4__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 4U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h31b47573__0))))))));
    vlSelf->wasmetal_core__DOT___070967_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b3__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hedf8c8b5__0))))))));
    vlSelf->wasmetal_core__DOT___070977_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b8__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he127cdd2__0))))))));
    vlSelf->wasmetal_core__DOT___070978_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b7__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 7U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd8bdfcc6__0))))))));
    vlSelf->wasmetal_core__DOT___070979_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b6__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bf68f44__0))))))));
    vlSelf->wasmetal_core__DOT___071019_ = (1U & (IData)(
                                                         (0xf5f3f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0880000U 
                                                                         >> 
                                                                         ((0x10U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                              << 4U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b15__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xeU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h978cb234__0))))))));
    vlSelf->wasmetal_core__DOT___071017_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071006_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b17__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h83bd92c8__0))))))));
    vlSelf->wasmetal_core__DOT___071018_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071010_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b16__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0xfU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4dc6a706__0))))))));
    vlSelf->wasmetal_core__DOT___071032_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b20__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x12U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf6358f59__0))))))));
    vlSelf->wasmetal_core__DOT___071033_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071024_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b19__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x11U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h65437cee__0))))))));
    vlSelf->wasmetal_core__DOT___071034_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071028_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b18__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x10U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4c7f02d9__0))))))));
    vlSelf->wasmetal_core__DOT___071077_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071065_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b29__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1aU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h370a9404__0))))))));
    vlSelf->wasmetal_core__DOT___071078_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071069_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b28__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x19U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2c74d244__0))))))));
    vlSelf->wasmetal_core__DOT___071079_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071073_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b27__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x18U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf5aac232__0))))))));
    vlSelf->wasmetal_core__DOT___071092_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071080_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b32__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1dU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h098d62f8__0))))))));
    vlSelf->wasmetal_core__DOT___071093_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071084_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b31__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1cU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hdf9c0a20__0))))))));
    vlSelf->wasmetal_core__DOT___071094_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071088_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b30__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x1bU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he08c96ba__0))))))));
    vlSelf->wasmetal_core__DOT___071137_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071125_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b41__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x25U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha300b05f__0))))))));
    vlSelf->wasmetal_core__DOT___071138_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071129_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b40__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x24U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc1d04e55__0))))))));
    vlSelf->wasmetal_core__DOT___071139_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071133_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b39__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x23U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha31457b4__0))))))));
    vlSelf->wasmetal_core__DOT___071152_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071140_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b44__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha431143d__0))))))));
    vlSelf->wasmetal_core__DOT___071153_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071144_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b43__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x27U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2535fff2__0))))))));
    vlSelf->wasmetal_core__DOT___071154_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071148_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b42__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x26U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed7c6d19__0))))))));
    vlSelf->wasmetal_core__DOT___071197_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071185_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b53__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8a6dc29d__0))))))));
    vlSelf->wasmetal_core__DOT___071198_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071189_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b52__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2fU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he372c179__0))))))));
    vlSelf->wasmetal_core__DOT___071199_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071193_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b51__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2eU)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8fd79857__0))))))));
    vlSelf->wasmetal_core__DOT___071212_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071200_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b56__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hbceb8814__0))))))));
    vlSelf->wasmetal_core__DOT___071213_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b55__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x31U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bbfb27a__0))))))));
    vlSelf->wasmetal_core__DOT___071214_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071208_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b54__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x30U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d7f942c__0))))))));
    vlSelf->wasmetal_core__DOT___071250_ = (1U & (IData)(
                                                         (0x3f5f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048519_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf007700ff00ffULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hbdf577ad__0)) 
                                                                                << 5U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___070941_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___071245_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__data_sizes__02ewrite_data__05b63__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_sizes__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x38U)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__table_sizes__02evalid_b)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_heb46fbcb__0))))))));
    if (vlSelf->wasmetal_core__DOT___044467_) {
        if (vlSelf->wasmetal_core__DOT___044466_) {
            if (vlSelf->wasmetal_core__DOT___044465_) {
                vlSelf->wasmetal_core__DOT___044456_ 
                    = (1U & ((1U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0)) 
                             | (IData)(vlSelf->wasmetal_core__DOT___044459_)));
                vlSelf->wasmetal_core__DOT___045759_ 
                    = (1U & ((~ (1U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0))) 
                             & (4U >> (IData)(vlSelf->__VdfgTmp_h654859ed__0))));
            } else {
                vlSelf->wasmetal_core__DOT___044456_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044465_)));
                vlSelf->wasmetal_core__DOT___045759_ = 0U;
            }
        } else {
            vlSelf->wasmetal_core__DOT___044456_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044466_)));
            vlSelf->wasmetal_core__DOT___045759_ = 0U;
        }
    } else {
        vlSelf->wasmetal_core__DOT___044456_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044467_)));
        vlSelf->wasmetal_core__DOT___045759_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031352_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128346___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b2__05d));
    vlSelf->wasmetal_core__DOT___054188_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054186_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003288_)))))))));
    vlSelf->wasmetal_core__DOT___054190_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054189_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004832_)))))))));
    vlSelf->wasmetal_core__DOT___054192_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054191_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004758_)))))))));
    vlSelf->wasmetal_core__DOT___054194_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054193_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004536_)))))))));
    vlSelf->wasmetal_core__DOT___054196_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054195_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004388_)))))))));
    vlSelf->wasmetal_core__DOT___054198_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054197_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004462_)))))))));
    vlSelf->wasmetal_core__DOT___054200_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054199_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127892___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004610_)))))))));
    vlSelf->wasmetal_core__DOT___054202_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003794_)))))))));
    vlSelf->wasmetal_core__DOT___054204_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054203_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003646_)))))))));
    vlSelf->wasmetal_core__DOT___054206_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054205_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003498_)))))))));
    vlSelf->wasmetal_core__DOT___054208_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054207_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127877___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003572_)))))))));
    vlSelf->wasmetal_core__DOT___054210_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054209_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004166_)))))))));
    vlSelf->wasmetal_core__DOT___054212_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054211_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004240_)))))))));
    vlSelf->wasmetal_core__DOT___054214_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054213_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004684_)))))))));
    vlSelf->wasmetal_core__DOT___054216_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127878___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003720_)))))))));
    vlSelf->wasmetal_core__DOT___054218_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054217_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004018_)))))))));
    vlSelf->wasmetal_core__DOT___054220_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054219_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004314_)))))))));
    vlSelf->wasmetal_core__DOT___054222_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054221_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004092_)))))))));
    vlSelf->wasmetal_core__DOT___054224_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054223_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127879___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003876_)))))))));
    vlSelf->wasmetal_core__DOT___054226_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054225_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003948_)))))))));
    vlSelf->wasmetal_core__DOT___054228_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054227_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003428_)))))))));
    vlSelf->wasmetal_core__DOT___054230_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___003360_)))))))));
    vlSelf->wasmetal_core__DOT___054232_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005176_)))))))));
    vlSelf->wasmetal_core__DOT___054234_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054233_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005108_)))))))));
    vlSelf->wasmetal_core__DOT___054236_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005380_)))))))));
    vlSelf->wasmetal_core__DOT___054238_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004972_)))))))));
    vlSelf->wasmetal_core__DOT___054240_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054239_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005040_)))))))));
    vlSelf->wasmetal_core__DOT___054242_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054241_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004904_)))))))));
    vlSelf->wasmetal_core__DOT___054244_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054243_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005312_)))))))));
    vlSelf->wasmetal_core__DOT___054246_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054245_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005244_)))))))));
    vlSelf->wasmetal_core__DOT___054248_ = (1U & (IData)(
                                                         (0xff0f3303ff0f5505ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054247_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053991_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005636_)))))))));
    vlSelf->wasmetal_core__DOT___054319_ = (1U & (IData)(
                                                         (0x33305550fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054187_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128120___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000693_)))))))));
    vlSelf->wasmetal_core__DOT___054317_ = (1U & (0xca00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127908___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000665_))))));
    vlSelf->wasmetal_core__DOT___054249_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003189_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O))))))));
    vlSelf->wasmetal_core__DOT___054251_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003269_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054253_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054255_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054257_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001438_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O))))))));
    vlSelf->wasmetal_core__DOT___054259_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001444_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054261_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001476_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054263_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001488_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054265_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001370_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O))))))));
    vlSelf->wasmetal_core__DOT___054267_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001382_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054269_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001414_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054271_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001426_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127902___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054273_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001525_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O))))))));
    vlSelf->wasmetal_core__DOT___054279_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001537_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054281_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001569_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054283_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001581_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127903___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054285_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001613_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O))))))));
    vlSelf->wasmetal_core__DOT___054287_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001625_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054289_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054291_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127904___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054293_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O))))))));
    vlSelf->wasmetal_core__DOT___054295_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054297_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054299_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127905___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054301_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O))))))));
    vlSelf->wasmetal_core__DOT___054303_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054305_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054307_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127906___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054309_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O))))))));
    vlSelf->wasmetal_core__DOT___054311_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 1U))))))));
    vlSelf->wasmetal_core__DOT___054313_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 2U))))))));
    vlSelf->wasmetal_core__DOT___054315_ = (1U & (0x405fccffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052651_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052646_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127907___O) 
                                                                  >> 3U))))))));
    vlSelf->wasmetal_core__DOT___054183_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127891___O) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___003208_)))));
    vlSelf->wasmetal_core__DOT___062619_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062618_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062617_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062631_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062630_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062629_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062642_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062641_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062640_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128394___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062653_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062652_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062651_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128458___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062664_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062663_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062662_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062675_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062674_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062673_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062686_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062685_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062684_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128395___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062697_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062696_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062695_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128459___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062708_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062707_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062706_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062719_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062718_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062717_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062730_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062729_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062728_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128396___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062741_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062740_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062739_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128460___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062752_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062751_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062750_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062763_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062762_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062761_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062774_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062772_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128397___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062785_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062784_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128461___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062796_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062795_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062794_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062807_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062806_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062805_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062818_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062817_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062816_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128398___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062829_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062827_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128462___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062840_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062839_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062838_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062851_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062850_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062849_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062862_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062861_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062860_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128399___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062873_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062872_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062871_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128463___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062884_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062883_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062882_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062895_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062894_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062893_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062906_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062905_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062904_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128400___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062917_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062916_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062915_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128464___O) 
                                                                        >> 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062928_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062927_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062926_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062939_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062938_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062937_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___062950_ = (1U & (IData)(
                                                         (0x8acf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062949_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062948_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128401___O)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128465___O)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd6897962__0))))))));
    vlSelf->wasmetal_core__DOT___054037_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053993_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003190_)))))));
    vlSelf->wasmetal_core__DOT___054041_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054040_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003270_)))))));
    vlSelf->wasmetal_core__DOT___054045_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054044_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004818_)))))));
    vlSelf->wasmetal_core__DOT___054049_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054048_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127876___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004744_)))))));
    vlSelf->wasmetal_core__DOT___054053_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054052_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004522_)))))));
    vlSelf->wasmetal_core__DOT___054057_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054056_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004374_)))))));
    vlSelf->wasmetal_core__DOT___054061_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004448_)))))));
    vlSelf->wasmetal_core__DOT___054065_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054064_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127884___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004596_)))))));
    vlSelf->wasmetal_core__DOT___054069_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054068_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003780_)))))));
    vlSelf->wasmetal_core__DOT___054073_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054072_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003632_)))))));
    vlSelf->wasmetal_core__DOT___054077_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054076_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003484_)))))));
    vlSelf->wasmetal_core__DOT___054081_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054080_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127885___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003558_)))))));
    vlSelf->wasmetal_core__DOT___054085_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054084_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004152_)))))));
    vlSelf->wasmetal_core__DOT___054089_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054088_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004226_)))))));
    vlSelf->wasmetal_core__DOT___054093_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054092_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004670_)))))));
    vlSelf->wasmetal_core__DOT___054097_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054096_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127886___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003706_)))))));
    vlSelf->wasmetal_core__DOT___054101_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054100_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004004_)))))));
    vlSelf->wasmetal_core__DOT___054105_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054104_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004300_)))))));
    vlSelf->wasmetal_core__DOT___054109_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054108_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004078_)))))));
    vlSelf->wasmetal_core__DOT___054113_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054112_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127887___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003862_)))))));
    vlSelf->wasmetal_core__DOT___054117_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054116_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003936_)))))));
    vlSelf->wasmetal_core__DOT___054121_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054120_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003416_)))))));
    vlSelf->wasmetal_core__DOT___054125_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054124_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___003348_)))))));
    vlSelf->wasmetal_core__DOT___054129_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054128_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127888___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005164_)))))));
    vlSelf->wasmetal_core__DOT___054133_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054132_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005096_)))))));
    vlSelf->wasmetal_core__DOT___054137_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054136_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005368_)))))));
    vlSelf->wasmetal_core__DOT___054160_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054159_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004960_)))))));
    vlSelf->wasmetal_core__DOT___054164_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054163_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127889___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005028_)))))));
    vlSelf->wasmetal_core__DOT___054168_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054167_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___004892_)))))));
    vlSelf->wasmetal_core__DOT___054172_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054171_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005300_)))))));
    vlSelf->wasmetal_core__DOT___054176_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054175_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                >> 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005232_)))))));
    vlSelf->wasmetal_core__DOT___054180_ = (1U & (0xf3f50000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054179_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053992_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052650_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127890___O) 
                                                                >> 2U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___005618_)))))));
    vlSelf->wasmetal_core__DOT___061687_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061678_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8be24d75__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he719985b__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h528d6985__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061637_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061631_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2142849a__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd4ed2ab6__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he798fe47__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061705_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061696_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h401bf3cf__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf366d942__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb0afff05__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061674_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061673_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84babf9f__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf785b2f__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_he2d6a2af__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061688_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061682_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ab1d453__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hed924a08__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782ee59f__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061708_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061692_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2014cd64__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4ad5bd42__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h64c25376__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061707_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061704_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hebd182eb__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfa295b2__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7c0fb6b2__0))))))))))))));
    vlSelf->wasmetal_core__DOT___061706_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061700_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce1a9eab__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h92c59f9e__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f4f4420__0))))))))))))));
    vlSelf->wasmetal_core__DOT___128655___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034312_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034375_));
    vlSelf->wasmetal_core__DOT___128671___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034480_) 
           & (IData)(vlSelf->wasmetal_core__DOT___034536_));
    vlSelf->wasmetal_core__DOT___063059_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063054_))));
    vlSelf->wasmetal_core__DOT___063078_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_y 
                                                       >> 0xfU)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063077_)))));
    vlSelf->__VdfgTmp_h277c2e25__0 = (((IData)(vlSelf->wasmetal_core__DOT___062959_) 
                                       << 1U) | (1U 
                                                 & (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___063054_)))));
    vlSelf->wasmetal_core__DOT___053573_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050448_))));
    vlSelf->wasmetal_core__DOT___050452_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((1U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h508bc82d__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050448_)))));
    vlSelf->wasmetal_core__DOT__access_size__05b3__05d 
        = (1U & (IData)((0xffffffff00010000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___054466_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054465_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048430_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054460_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054457_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054463_)))))))));
    vlSelf->wasmetal_core__DOT__access_base__05b63__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8696f73b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b62__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h46733dea__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b61__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3493c9ec__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b60__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd25ddcc6__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b59__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha7b9d4b3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b58__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h56116db4__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b57__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf21aaa1b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b56__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h139d3776__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b55__05d 
        = (1U & (0xc0aU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h3378cabf__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b54__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h8df5578a__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b53__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b52__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b51__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b50__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hb40a316f__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b49__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h461c5ceb__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b48__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h38e0bed2__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b47__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hac359f24__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b46__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h132c3402__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b45__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h82148a8f__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b44__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h33528dbb__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b43__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9319fdaf__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b42__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h17bd1a59__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b41__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9963adf9__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b40__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hc231438f__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b39__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h0e28c49d__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b38__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hde05f3fa__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b37__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h866cdbfa__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b36__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hcfe971ad__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b35__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b34__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b33__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_hd40e4c18__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b32__05d 
        = (1U & (0xa0cU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___054479_) 
                                        << 2U) | (IData)(vlSelf->__VdfgTmp_h9a79492f__0)))));
    vlSelf->wasmetal_core__DOT__access_base__05b31__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0118c8b7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b30__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hec1752e3__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b29__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h9206c0aa__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b28__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hbf5b2f76__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b27__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hbaf6c8a7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b26__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h6e881f1b__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b25__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h975aebd1__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b24__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8670d2e8__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b23__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h3e1a5258__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b22__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h434b0db3__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b21__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf1e329c9__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b20__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8476215a__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b19__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h4d6951f5__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b18__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h95830544__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b17__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b16__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h652edcf1__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b15__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h5e46481a__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b14__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b13__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h5bc17448__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b12__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h840c74b0__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b11__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b10__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h4172973d__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b9__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b8__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b7__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b6__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b5__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h1656da2e__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b4__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b3__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hf0092dd5__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b2__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h989e4977__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b1__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h47317805__0))));
    vlSelf->wasmetal_core__DOT__access_base__05b0__05d 
        = (1U & (0xacU >> (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128028___O 
        = (0xfU & ((vlSelf->insn_z >> 8U) ^ (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__2__KET__) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__1__KET__) 
                                                 << 2U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__0__KET__) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___027958_))))));
    vlSelf->wasmetal_core__DOT___027931_ = ((vlSelf->insn_z 
                                             >> 0xbU) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128028___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128268___O 
        = (((8U & ((~ (vlSelf->mem_rdata[0U] >> 0xbU)) 
                   << 3U)) | ((4U & ((~ (vlSelf->mem_rdata[0U] 
                                         >> 0xaU)) 
                                     << 2U)) | ((2U 
                                                 & ((~ 
                                                     (vlSelf->mem_rdata[0U] 
                                                      >> 9U)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ 
                                                      (vlSelf->mem_rdata[0U] 
                                                       >> 8U)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030493_)))));
    vlSelf->wasmetal_core__DOT___030466_ = (1U & ((0x800U 
                                                   & vlSelf->mem_rdata[0U])
                                                   ? 
                                                  (vlSelf->mem_rdata[0U] 
                                                   >> 0xbU)
                                                   : (IData)(vlSelf->wasmetal_core__DOT___128268___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032897_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128484___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b9__05d));
    vlSelf->wasmetal_core__DOT___065791_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065785_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065784_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064453_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0xcccccccc5f000f0fULL 
                                                                          >> 
                                                                          ((0x20U 
                                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                               << 2U)) 
                                                                           | ((0x10U 
                                                                               & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (7U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O))) 
                                                                                << 1U))) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((0x5cU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h23108600__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x20003fffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b10__05d) 
                                                                                << 4U) 
                                                                                | ((0xcU 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065780_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___065779_))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064072_) 
                                                                                << 1U))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___069672_ = (1U & (IData)(
                                                         (0xf4ff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069665_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x802aaaaaaaaaaaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___019408_) 
                                                                                << 5U) 
                                                                                | ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 1U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__load_vector__05b80__05d))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                           >> 2U)) 
                                                                       | (1U 
                                                                          & (0x55cc0fffU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 2U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066342_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068504_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___069662_))))))))))))));
    vlSelf->wasmetal_core__DOT___070260_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070252_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___070251_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x20000000fcffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b112__05d) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h54c4945a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___068512_ = (1U & (0xbb0b0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068498_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068497_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x20000000fcffffffULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b48__05d) 
                                                                            << 5U) 
                                                                           | ((0x10U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 4U)) 
                                                                              | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h54c4945a__0)))))))))))));
    vlSelf->wasmetal_core__DOT___068540_ = (1U & (IData)(
                                                         (0x33bf3f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068534_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hea3a75f9__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b49__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064993_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h1dd3182a__0)))))))))));
    vlSelf->wasmetal_core__DOT___069230_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069226_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b63__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069223_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))) 
                                                                                << 1U))) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069224_)))))))));
    vlSelf->wasmetal_core__DOT___068813_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068788_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc80dfdfU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b54__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068785_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065371_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066836_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068786_)))))))));
    vlSelf->wasmetal_core__DOT___068595_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068591_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xcc80dfdfU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b50__05d) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___068588_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___066507_)))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068589_)))))))));
    vlSelf->wasmetal_core__DOT___068694_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068690_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xffcf0040ffcfffcfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b52__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068687_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___065139_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> 
                                                                                (3U 
                                                                                & (- (IData)(
                                                                                (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068688_)))))))));
    vlSelf->wasmetal_core__DOT___069082_ = (1U & (IData)(
                                                         (0x4fff00ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067588_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___019390_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069078_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff3f0020ff3fff3fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b60__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069075_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064356_)) 
                                                                                << 1U))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064438_) 
                                                                                << 1U)) 
                                                                                << 1U))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (3U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                                >> 2U))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___069076_)))))))));
    vlSelf->wasmetal_core__DOT___068889_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___068873_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068872_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfdff050000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b56__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6d71fd2__0))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x18U))))))))));
    vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027832_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128012___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b9__05d));
    vlSelf->wasmetal_core__DOT___069503_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069498_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069497_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 7U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf0a030f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b73__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc947a4ab__0))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0e48eaa1__0))))))))))))));
    vlSelf->wasmetal_core__DOT___070155_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070148_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068129_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b105__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h712d7252__0))))))));
    vlSelf->wasmetal_core__DOT___068338_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068322_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068321_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b45__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064247_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___068320_)))))))));
    vlSelf->wasmetal_core__DOT___069549_ = (1U & (IData)(
                                                         (0x2a3f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___069544_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069543_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064978_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (vlSelf->mem_rdata[2U] 
                                                                        >> 9U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___069262_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0a030f0f0f0f0fULL 
                                                                                >> 
                                                                                ((0x38U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0xf050c0f0f0f0f0f0ULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 2U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 3U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                                << 1U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b75__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h20f14479__0))))))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28baf300__0))))))))))))));
    vlSelf->wasmetal_core__DOT___068231_ = (1U & (IData)(
                                                         (0x7f333f3f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068216_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> 
                                                                   (3U 
                                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                                       >> 2U))) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068215_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b43__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hed3b8a65__0))))))));
}
