#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__14(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__14\n"); );
    // Body
    vlSelf->wasmetal_core__DOT___049657_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049283_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049251_))));
    vlSelf->wasmetal_core__DOT___052590_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0))))));
    vlSelf->wasmetal_core__DOT___049623_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049083_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0))))));
    vlSelf->__VdfgTmp_h336e35bc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012981_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012980_));
    vlSelf->wasmetal_core__DOT___010849_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8f305c7__0)))));
    vlSelf->wasmetal_core__DOT___013142_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011379_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hcf7ded40__0))))))));
    vlSelf->__VdfgTmp_h14d4af94__0 = (((IData)(vlSelf->wasmetal_core__DOT___011380_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011379_));
    vlSelf->__VdfgTmp_hf4d8b80a__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                         ? (IData)(vlSelf->wasmetal_core__DOT___011973_)
                                         : (IData)(vlSelf->wasmetal_core__DOT___011197_)) 
                                       << 1U) | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                 & (IData)(
                                                           (0xff00ffaaf0f0fcfcULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010185_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010184_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d))))))))));
    vlSelf->wasmetal_core__DOT___056826_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010810_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___010389_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056286_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h658ce6a4__0)))));
    vlSelf->__VdfgTmp_h4284cb76__0 = (((IData)(vlSelf->wasmetal_core__DOT___011920_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011919_));
    vlSelf->wasmetal_core__DOT___012422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010717_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010718_))));
    vlSelf->__VdfgTmp_hdeb472fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010718_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010717_));
    vlSelf->wasmetal_core__DOT___010392_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___056825_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))))))));
    vlSelf->wasmetal_core__DOT___056641_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056285_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056286_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hb9280dfa__0)))));
    vlSelf->wasmetal_core__DOT___012632_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056553_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_hf8199cb0__0)))));
    vlSelf->__VdfgTmp_h3fe4e0c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3820fb89__0)));
    vlSelf->__VdfgTmp_h42ead4cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010199_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hca8ac9e4__0));
    vlSelf->wasmetal_core__DOT___012175_ = (1U & (IData)(
                                                         (0xf0f000bb00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010574_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hab0a7d16__0))))))));
    vlSelf->wasmetal_core__DOT___053640_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051690_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->__VdfgTmp_h2994a26e__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                               ? (0x305U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0))
                                               : (0x503U 
                                                  >> (IData)(vlSelf->__VdfgTmp_hf1841993__0))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                         & (IData)(
                                                   (0x333355550f0f00ffULL 
                                                    >> (IData)(vlSelf->__VdfgTmp_hcf7af3c2__0)))));
    vlSelf->wasmetal_core__DOT___012184_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056375_)))))))));
    vlSelf->__VdfgTmp_h1055e951__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056368_)));
    if (vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010103_)));
        vlSelf->wasmetal_core__DOT___010125_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010123_)));
    } else {
        vlSelf->wasmetal_core__DOT___012293_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010103_))
                                                    : (IData)(
                                                              (0x11010000ff0fULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010103_) 
                                                                    << 4U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_hb67d963d__0)))))));
        vlSelf->wasmetal_core__DOT___010125_ = (1U 
                                                & (IData)(
                                                          (0xff00ff00fffefff0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010123_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h39adae05__0)))))));
    }
    vlSelf->__VdfgTmp_h16c112d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hb67d963d__0));
    vlSelf->__VdfgTmp_h7e112ed5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___056380_))));
    vlSelf->wasmetal_core__DOT___056829_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)))))))));
    vlSelf->__VdfgTmp_h0931b472__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->wasmetal_core__DOT___056616_ = (1U & (IData)(
                                                         (0xf0faf0f3ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                  << 3U) 
                                                                 | ((((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         (2U 
                                                                          >> (IData)(vlSelf->wasmetal_core__DOT___011503_))
                                                                          : (IData)(vlSelf->wasmetal_core__DOT___010374_))) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6a02124a__0))))))));
    vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___010045_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6af19a3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0));
    vlSelf->wasmetal_core__DOT___011906_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011537_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011519_)))))))));
    vlSelf->__VdfgTmp_hf6c0bd72__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011537_));
    vlSelf->wasmetal_core__DOT___011207_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffccf0f0fafaULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___010298_)))))))));
    vlSelf->__VdfgTmp_h493dc6bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->__VdfgTmp_he09ec1d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_hee315f88__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d));
    vlSelf->__VdfgTmp_h2790f0bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___011898_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010530_));
    vlSelf->__VdfgTmp_ha5884336__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012124_));
    vlSelf->__VdfgTmp_h99697672__0 = (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h7b0cb704__0));
    vlSelf->wasmetal_core__DOT___056280_ = (1U & (IData)(
                                                         (0xaacc00000f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d)))))))));
    vlSelf->wasmetal_core__DOT___010220_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf0eU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___008810_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___010243_))
                                                    : 
                                                   (0xf01U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))))));
    vlSelf->wasmetal_core__DOT___010198_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___011697_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010209_));
    vlSelf->wasmetal_core__DOT___056440_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011017_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011020_)));
    vlSelf->__VdfgTmp_h25f5437e__0 = (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)));
    vlSelf->wasmetal_core__DOT___056369_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010770_)));
    vlSelf->wasmetal_core__DOT___011478_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h39adae05__0)))));
    vlSelf->wasmetal_core__DOT___012845_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011539_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011530_)))))))));
    vlSelf->wasmetal_core__DOT___010260_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010282_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                      ? 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c968075__0)))
                                                      : 
                                                     (0xfff1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hffef1e62__0)))))));
    vlSelf->__VdfgTmp_hb211d2c2__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d));
    vlSelf->wasmetal_core__DOT___061946_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061882_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007414_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055510_)))))))));
    vlSelf->wasmetal_core__DOT___054892_ = (1U & (IData)(
                                                         (0xf0fcc5500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054890_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019303_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___033390_)))))))));
    vlSelf->wasmetal_core__DOT___057049_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012044_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012043_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h7fb5afda__0)))));
    vlSelf->wasmetal_core__DOT___062007_ = (1U & (IData)(
                                                         (0x30f020a030f03000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062001_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf5f3ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061995_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061994_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061645_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___061653_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2447f2cc__0)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___061646_) 
                                                                                << 5U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4212348e__0)))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048316_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___061708_)))))))));
    vlSelf->wasmetal_core__DOT___061985_ = (1U & (0xff455554U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___061708_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061971_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4abf7b91__0)))));
    vlSelf->wasmetal_core__DOT___054930_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___054920_))));
    vlSelf->wasmetal_core__DOT___050675_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h40926396__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0))))));
    vlSelf->wasmetal_core__DOT___049487_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfc74b95b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049483_))));
    vlSelf->wasmetal_core__DOT___050599_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049836_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049843_))));
    vlSelf->wasmetal_core__DOT___049460_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049459_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049458_))));
    vlSelf->wasmetal_core__DOT___056499_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->wasmetal_core__DOT___056593_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010964_)) 
                                            & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                               & (IData)(vlSelf->wasmetal_core__DOT___011119_)));
    vlSelf->wasmetal_core__DOT___053209_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0))))));
    vlSelf->wasmetal_core__DOT___051429_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0))))));
    vlSelf->__VdfgTmp_h28b05b3d__0 = ((2U & ((0xcaU 
                                              >> ((2U 
                                                   & ((0xacU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 1U)) 
                                      | (1U & (0xcaU 
                                               >> (
                                                   (2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0)))))));
    vlSelf->wasmetal_core__DOT___050542_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h69fe2c1e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hd957e182__0))))));
    vlSelf->wasmetal_core__DOT___050674_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0))))));
    vlSelf->wasmetal_core__DOT___049857_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h6e22e397__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0))))));
    vlSelf->wasmetal_core__DOT___049494_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049491_))));
    vlSelf->wasmetal_core__DOT___049703_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049483_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc8d2269b__0))))));
    vlSelf->wasmetal_core__DOT___049621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049099_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049074_))));
    vlSelf->wasmetal_core__DOT___049086_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049074_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049073_))));
    vlSelf->wasmetal_core__DOT___049844_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049842_))));
    vlSelf->wasmetal_core__DOT___050598_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049042_))));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010854_)));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010860_)));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010741_)));
    } else {
        vlSelf->wasmetal_core__DOT___056378_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h658ce6a4__0))));
        vlSelf->wasmetal_core__DOT___056377_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb9280dfa__0))));
        vlSelf->wasmetal_core__DOT___011390_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf8199cb0__0))));
    }
    vlSelf->wasmetal_core__DOT___050527_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050525_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050524_))));
    vlSelf->wasmetal_core__DOT___051410_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050524_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050523_))));
    vlSelf->wasmetal_core__DOT___049588_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049458_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049453_))));
    vlSelf->wasmetal_core__DOT___049455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049453_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049452_))));
    vlSelf->wasmetal_core__DOT___049286_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049278_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049277_))));
    vlSelf->wasmetal_core__DOT___049655_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049266_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049278_))));
    vlSelf->wasmetal_core__DOT___011998_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___012287_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010161_));
    vlSelf->wasmetal_core__DOT___011602_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010969_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___010972_)));
    vlSelf->wasmetal_core__DOT___072006_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb25114eb__0)))));
    vlSelf->__VdfgTmp_h4cd16820__0 = (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb25114eb__0));
    vlSelf->wasmetal_core__DOT___056636_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))));
    vlSelf->wasmetal_core__DOT___057067_ = (1U & (IData)(
                                                         (0xf0f0aaaaff00ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012028_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012991_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd5a37d8d__0))))))));
    vlSelf->wasmetal_core__DOT___056899_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056898_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056897_)))))));
    vlSelf->wasmetal_core__DOT___061806_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061727_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007412_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055411_)))))))));
    vlSelf->__VdfgTmp_hf996b543__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h146131dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___011857_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056381_));
    vlSelf->wasmetal_core__DOT___057102_ = (1U & (IData)(
                                                         (0xa0c000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->wasmetal_core__DOT___011205_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ff0faaaaccccULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010341_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010338_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h88263545__0))))))));
    vlSelf->__VdfgTmp_h95d3d0ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h88263545__0));
    if (vlSelf->wasmetal_core__DOT___010092_) {
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x305U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3f5e9baf__0)));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xc0aU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h03ce55f8__0)));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010925_)));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___011017_))));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_))));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010735_)));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010969_))));
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010773_)));
        vlSelf->wasmetal_core__DOT___011473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010767_))));
    } else {
        vlSelf->wasmetal_core__DOT___056720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
        vlSelf->wasmetal_core__DOT___011922_ = (1U 
                                                & (0x503U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hbe17c4c8__0)));
        vlSelf->wasmetal_core__DOT___012720_ = (1U 
                                                & (0xa0cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1841993__0)));
        vlSelf->wasmetal_core__DOT___011529_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007693_)
                                                    ? 
                                                   (0xfeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h4965d650__0)))
                                                    : 
                                                   (0xf1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___008810_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h6748fbc1__0)))));
        vlSelf->wasmetal_core__DOT___013096_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011020_)));
        vlSelf->wasmetal_core__DOT___056596_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010770_)));
        vlSelf->wasmetal_core__DOT___011471_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h7fb5afda__0))));
        vlSelf->wasmetal_core__DOT___011859_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___010972_)));
        vlSelf->wasmetal_core__DOT___012749_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                   | (0x1101ff0fU 
                                                      >> (IData)(vlSelf->__VdfgTmp_h16c112d2__0))));
        vlSelf->wasmetal_core__DOT___011473_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                   & (IData)(vlSelf->wasmetal_core__DOT___011478_)));
    }
    vlSelf->wasmetal_core__DOT___013099_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hbc86843d__0)))))));
    vlSelf->wasmetal_core__DOT___053368_ = (1U & (0x78U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052731_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___053367_)))));
    vlSelf->wasmetal_core__DOT___049043_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049024_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049023_))));
    vlSelf->wasmetal_core__DOT___049688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049450_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049447_))));
    vlSelf->wasmetal_core__DOT___052600_ = (1U & (0xf0f0aaccU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0xff00ccccf0f0aaaaULL 
                                                                >> 
                                                                ((8U 
                                                                  & ((0xacU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_hc36aba22__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((0xacU 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87becbe1__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h96c76ab3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xacU 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h211aef5c__0)))))))) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((0xcaU 
                                                           >> 
                                                           ((2U 
                                                             & ((0xacU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> 
                                                            ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h09589e24__0))))))))));
    vlSelf->wasmetal_core__DOT___050059_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0))))));
    vlSelf->__VdfgTmp_h7f4141b2__0 = ((2U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h4d50854c__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0))))) 
                                             << 1U)) 
                                      | (1U & (0xacU 
                                               >> (
                                                   (2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc4ac601e__0)))))));
    vlSelf->wasmetal_core__DOT___049363_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h94c83f35__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h20ec44fd__0))))));
    vlSelf->wasmetal_core__DOT___051427_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0))))));
    vlSelf->wasmetal_core__DOT___052591_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))));
    vlSelf->wasmetal_core__DOT___051918_ = (1U & (0xcaU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))));
    vlSelf->__VdfgTmp_h10726817__0 = ((4U & ((0xacU 
                                              >> ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6ae5baa5__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h249d4881__0))))) 
                                             << 2U)) 
                                      | ((2U & ((0xacU 
                                                 >> 
                                                 ((2U 
                                                   & ((0x53U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h45e6cf8e__0)) 
                                                      << 1U)) 
                                                  | (1U 
                                                     & (0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h57526782__0))))) 
                                                << 1U)) 
                                         | (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h15ceac3d__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2b3afffd__0))))))));
    vlSelf->wasmetal_core__DOT___049505_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049501_))));
    vlSelf->wasmetal_core__DOT___049705_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3b672e02__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049502_))));
    vlSelf->wasmetal_core__DOT___049145_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0x53U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc0f91dc6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049132_))));
    vlSelf->wasmetal_core__DOT___049618_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049132_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x53U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h0a02dc0e__0))))));
    vlSelf->wasmetal_core__DOT___062173_ = (1U & (0xfafc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062171_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___062170_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048308_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___062157_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061706_)))))));
    vlSelf->wasmetal_core__DOT___011912_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010302_))));
    vlSelf->wasmetal_core__DOT___011771_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010302_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))))));
    vlSelf->wasmetal_core__DOT___011206_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056552_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011666_)))));
    vlSelf->__VdfgTmp_hb44ad26b__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h362b458b__0));
    vlSelf->__VdfgTmp_h450c5ec1__0 = (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_ha569c0f1__0));
    vlSelf->wasmetal_core__DOT___055108_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0))))));
    vlSelf->wasmetal_core__DOT___011939_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011470_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056368_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h375c9c07__0))))))));
    vlSelf->wasmetal_core__DOT___056347_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_heb18a766__0)))));
    vlSelf->__VdfgTmp_hc9438d71__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011869_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h51371d7f__0)))));
    vlSelf->__VdfgTmp_h6cc2c965__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h51371d7f__0));
    vlSelf->wasmetal_core__DOT___051779_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051631_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___051648_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___012804_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011924_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010721_))));
    vlSelf->wasmetal_core__DOT___055277_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055271_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 1U)))));
    vlSelf->__VdfgTmp_h8b4e795d__0 = ((2U & ((0xfef0U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_));
    vlSelf->__VdfgTmp_h08c644ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0xfef0U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT___010413_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009653_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h2133c371__0)))));
    vlSelf->wasmetal_core__DOT___056895_ = (1U & (IData)(
                                                         (0xf4f4000000ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h479e0c47__0)))))));
    vlSelf->wasmetal_core__DOT___012182_ = (1U & (IData)(
                                                         (0x55330000f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009842_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056325_)))))))));
    vlSelf->__VdfgTmp_hede7bfa8__0 = (((IData)(vlSelf->wasmetal_core__DOT___012729_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011389_));
    vlSelf->__VdfgTmp_h7bcb9cab__0 = (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011388_));
    vlSelf->wasmetal_core__DOT___011722_ = (1U & (0xceU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d))))));
    vlSelf->wasmetal_core__DOT___057050_ = ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                            & (IData)(
                                                      (0xff00ffaaf0f0fcfcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)))))))));
    vlSelf->__VdfgTmp_hb1f92188__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)));
    vlSelf->wasmetal_core__DOT___056341_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d))));
    vlSelf->__VdfgTmp_hdcd859be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011527_)));
    vlSelf->__VdfgTmp_he9d803b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010222_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010092_)));
    vlSelf->wasmetal_core__DOT___011032_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010222_)) 
                                                  & (IData)(
                                                            (0xff00ffddff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h362b458b__0)))))))));
    vlSelf->wasmetal_core__DOT___055199_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055122_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___055194_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_ha569c0f1__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010412_)))));
    vlSelf->wasmetal_core__DOT___019292_ = (1U & (0xf40000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h058d1256__0))));
    vlSelf->wasmetal_core__DOT___057687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048453_))));
    vlSelf->wasmetal_core__DOT___055063_ = (1U & (IData)(
                                                         (0xf0fcf0f500000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055061_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010044_)))))))));
    vlSelf->wasmetal_core__DOT___055734_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0xf4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___053902_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053663_))));
    vlSelf->wasmetal_core__DOT___053634_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___051651_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006226_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013918_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___048680_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h84446dc0__0))));
    vlSelf->wasmetal_core__DOT___049531_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049526_))));
    vlSelf->wasmetal_core__DOT___051989_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050787_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050789_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049815_)))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xff55ccf0U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___049814_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_h951148c2__0))))))));
    vlSelf->wasmetal_core__DOT___050791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050789_))));
    vlSelf->wasmetal_core__DOT___049927_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047952_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047950_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___047949_)))))));
    vlSelf->wasmetal_core__DOT___049384_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047951_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___047950_))));
    vlSelf->wasmetal_core__DOT___050855_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050849_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050848_)))))));
    vlSelf->__VdfgTmp_he62a830e__0 = ((2U & ((IData)(
                                                     (0xf0f0aaaaccccff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049644_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))) 
                                             << 1U)) 
                                      | (1U & (0x10U 
                                               >> (4U 
                                                   & ((4U 
                                                       >> 
                                                       (2U 
                                                        & ((4U 
                                                            >> 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___048669_) 
                                                             << 1U)) 
                                                           << 1U))) 
                                                      << 2U)))));
    vlSelf->wasmetal_core__DOT___050829_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049645_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf09b90d7__0))))));
    vlSelf->__VdfgTmp_had82d15e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___049054_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___049440_)))))) 
                                             << 1U)) 
                                      | (1U & (0xff55ccf0U 
                                               >> (IData)(vlSelf->__VdfgTmp_h35851421__0))));
    vlSelf->wasmetal_core__DOT___050543_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049056_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049055_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049054_)))))));
    vlSelf->wasmetal_core__DOT___049241_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xcaU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___049227_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___049226_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbd292e75__0))))));
    vlSelf->wasmetal_core__DOT___051907_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049226_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051905_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051904_)))))));
    vlSelf->wasmetal_core__DOT___051057_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049748_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051056_))));
    vlSelf->wasmetal_core__DOT___049749_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049120_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049748_))));
    vlSelf->wasmetal_core__DOT___049886_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049615_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049885_))));
    vlSelf->wasmetal_core__DOT___051289_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049885_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051288_))));
    vlSelf->wasmetal_core__DOT___049797_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049499_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049796_))));
    vlSelf->wasmetal_core__DOT___051114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051113_))));
    vlSelf->wasmetal_core__DOT___049701_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048589_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049699_))));
    vlSelf->wasmetal_core__DOT___050693_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049699_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050692_))));
    vlSelf->__VdfgTmp_habccd4be__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049152_));
    vlSelf->__VdfgTmp_hebb238d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049161_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049160_));
    vlSelf->wasmetal_core__DOT___049464_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049321_))));
    vlSelf->wasmetal_core__DOT___010577_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010575_))
                                                   : 
                                                  (0xf4U 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha620249b__0))));
    vlSelf->__VdfgTmp_hd698a5e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___049314_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049313_));
    vlSelf->wasmetal_core__DOT___065944_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065932_))));
    vlSelf->wasmetal_core__DOT___067466_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066134_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f000033aaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067162_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067306_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b0__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15099632__0))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___066862_)))))))));
    vlSelf->wasmetal_core__DOT___066135_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066134_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128095___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028666_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028665_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028664_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028663_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028630_)))));
    vlSelf->wasmetal_core__DOT___028634_ = ((IData)(vlSelf->wasmetal_core__DOT___028666_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128095___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___004596_));
    vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029076_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128130___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001874_));
    vlSelf->wasmetal_core__DOT____Vcellout___128122___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028978_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028977_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028976_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028975_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028942_)))));
    vlSelf->wasmetal_core__DOT___028946_ = ((IData)(vlSelf->wasmetal_core__DOT___028978_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128122___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b7__05d));
    vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001369_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001369_)
            : (IData)(vlSelf->wasmetal_core__DOT___032287_));
    vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028769_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128104___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026723_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128086___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___045206_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070681_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011413_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h479e0c47__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011360_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___012721_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010575_)));
            vlSelf->wasmetal_core__DOT___012722_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011389_)));
        }
    } else if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___011360_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
        vlSelf->wasmetal_core__DOT___012721_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012742_)));
        vlSelf->wasmetal_core__DOT___012722_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012729_)));
    } else {
        vlSelf->wasmetal_core__DOT___011360_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
        vlSelf->wasmetal_core__DOT___012721_ = (1U 
                                                & (0xbU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010572_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
        vlSelf->wasmetal_core__DOT___012722_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011390_)));
    }
    if (vlSelf->wasmetal_core__DOT___010530_) {
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h00b060af__0)));
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011380_)));
    } else {
        vlSelf->wasmetal_core__DOT___012718_ = (1U 
                                                & (0xceU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___011404_ = (1U 
                                                & (0x31U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hfba46556__0)));
        vlSelf->wasmetal_core__DOT___011636_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
    }
    if (vlSelf->wasmetal_core__DOT___010531_) {
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hbc86843d__0)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012131_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
        } else {
            vlSelf->wasmetal_core__DOT___011633_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011379_)));
            vlSelf->wasmetal_core__DOT___011595_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011604_)));
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___011633_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011636_));
        vlSelf->wasmetal_core__DOT___011595_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011603_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011602_))));
        if (vlSelf->wasmetal_core__DOT___010530_) {
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
        } else {
            vlSelf->wasmetal_core__DOT___056910_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___056618_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011530_)));
        }
    }
    if (vlSelf->wasmetal_core__DOT___010530_) {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_ha7112868__0))));
            vlSelf->wasmetal_core__DOT___011405_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011413_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011868_)));
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011381_)));
        } else {
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011388_)));
            vlSelf->wasmetal_core__DOT___011405_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010574_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (0xacU >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0)));
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (0x53U >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
        }
        vlSelf->wasmetal_core__DOT___010841_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___010531_) {
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011389_)));
            vlSelf->wasmetal_core__DOT___010841_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010574_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011869_)));
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011528_)));
        } else {
            vlSelf->wasmetal_core__DOT___011445_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011390_)));
            vlSelf->wasmetal_core__DOT___010841_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010573_)));
            vlSelf->wasmetal_core__DOT___012800_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
            vlSelf->wasmetal_core__DOT___011889_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011870_)));
            vlSelf->wasmetal_core__DOT___012799_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011529_)));
        }
        vlSelf->wasmetal_core__DOT___011405_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___010577_));
        vlSelf->wasmetal_core__DOT___011649_ = (1U 
                                                & (0x53U 
                                                   >> (IData)(vlSelf->__VdfgTmp_hdcd859be__0)));
    }
    vlSelf->wasmetal_core__DOT___045230_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071867_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054323_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h387d079a__0)))))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010302_)) 
                                                   & (0xfbfU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                           << 2U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h73f89ba5__0))))));
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010340_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010339_))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011660_) 
                                                   | (0xf010U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010197_))));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010342_)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
        } else {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___010198_)));
            vlSelf->wasmetal_core__DOT___011770_ = 
                (1U & (0x302U >> (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                   << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010342_) 
                                              << 2U) 
                                             | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___012383_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010299_))));
        vlSelf->wasmetal_core__DOT___056291_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010342_)) 
                                                   & (0xf0feU 
                                                      >> (IData)(vlSelf->__VdfgTmp_hcba8f5cb__0))));
        vlSelf->wasmetal_core__DOT___056624_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___011658_))));
        if (vlSelf->wasmetal_core__DOT___010124_) {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
        } else {
            vlSelf->wasmetal_core__DOT___010393_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010196_)));
            vlSelf->wasmetal_core__DOT___012373_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
        }
        vlSelf->wasmetal_core__DOT___011770_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                                   | (0x53U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
    }
    if (vlSelf->wasmetal_core__DOT___010124_) {
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011197_));
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___012983_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012028_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011198_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
        } else {
            vlSelf->wasmetal_core__DOT___012983_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012027_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010259_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_he9d803b7__0)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010219_)));
        }
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d))))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010672_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011992_))))));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___011194_;
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010434_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d))))));
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xcdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h45be7681__0)))));
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___012042_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011722_));
    } else {
        vlSelf->wasmetal_core__DOT___011181_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011052_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d))))));
        if (vlSelf->wasmetal_core__DOT___010182_) {
            vlSelf->wasmetal_core__DOT___012983_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012029_)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010260_)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010221_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
        } else {
            vlSelf->wasmetal_core__DOT___012983_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_hc9e45bda__0)));
            vlSelf->wasmetal_core__DOT___012384_ = 
                (1U & (0xbU >> (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)));
            vlSelf->wasmetal_core__DOT___011186_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010220_)));
            vlSelf->wasmetal_core__DOT___056924_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010261_)));
        }
        vlSelf->wasmetal_core__DOT___056929_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))));
        vlSelf->wasmetal_core__DOT___056827_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011728_));
        vlSelf->wasmetal_core__DOT___056642_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010831_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d))))));
        vlSelf->wasmetal_core__DOT___011183_ = vlSelf->wasmetal_core__DOT___010187_;
        vlSelf->wasmetal_core__DOT___056800_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011194_));
        vlSelf->wasmetal_core__DOT___057048_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012042_));
        vlSelf->wasmetal_core__DOT___056930_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0))));
        vlSelf->wasmetal_core__DOT___012979_ = vlSelf->wasmetal_core__DOT___011722_;
        vlSelf->wasmetal_core__DOT___056638_ = (1U 
                                                & (0xceU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010705_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d))))));
    }
    vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027193_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127935___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b6__05d));
    vlSelf->wasmetal_core__DOT___045478_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071343_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045502_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071343_)))))))));
    vlSelf->wasmetal_core__DOT___045274_ = (1U & (IData)(
                                                         (0xfaa0fcc0f000f000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071406_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h6ddd7671__0))))))));
    vlSelf->wasmetal_core__DOT___045298_ = (1U & (IData)(
                                                         (0x606006660606600ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062971_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___070951_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071406_)))))))));
    vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026588_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026529_)
            : (IData)(vlSelf->wasmetal_core__DOT___001438_));
    vlSelf->wasmetal_core__DOT___044934_ = (1U & (IData)(
                                                         (0xff555500ff3f3f00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070784_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___044958_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054322_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hee073a4e__0)))))));
    vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026993_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127918___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h47fa9bfe__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128068___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT___067086_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064499_)))));
    vlSelf->wasmetal_core__DOT___067164_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064755_)))));
    vlSelf->wasmetal_core__DOT___067205_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                          >> 2U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___064924_)))));
    vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001369_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034569_));
    vlSelf->__VdfgTmp_heaadd324__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001487_));
    vlSelf->__VdfgTmp_h6f4f7aa5__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->__VdfgTmp_h4482002c__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001443_));
    vlSelf->__VdfgTmp_hc5cbe3a9__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_));
    vlSelf->wasmetal_core__DOT___039996_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___039995_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001443_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b5__05d)))))))));
    vlSelf->wasmetal_core__DOT___039994_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001475_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___040006_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128663___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001487_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___063836_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063825_))));
    vlSelf->wasmetal_core__DOT___063837_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___063861_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063825_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O))))));
    vlSelf->wasmetal_core__DOT___066538_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064761_))));
    vlSelf->wasmetal_core__DOT___064763_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064761_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf0f0ccaaU 
                                                                            >> 
                                                                            ((0x18U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064756_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063985_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064759_)))))))));
    vlSelf->wasmetal_core__DOT___067308_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065950_))));
    vlSelf->wasmetal_core__DOT___066660_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065081_))));
    vlSelf->wasmetal_core__DOT___065085_ = (1U & (IData)(
                                                         (0xf3f5f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___065076_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___065081_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xf0f0aaccU 
                                                                             >> 
                                                                             ((0x18U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065079_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063994_))))))))))))));
    vlSelf->wasmetal_core__DOT___064001_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007033_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xff0000f4f4ULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                           << 3U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___063997_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xf0f000055ccULL 
                                                                                >> 
                                                                                ((0x20U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 1U)) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063988_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h78ac86a2__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063986_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                >> 2U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063995_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063835_)))));
    vlSelf->wasmetal_core__DOT___065429_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___065423_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064928_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064926_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___065421_)))))))));
    vlSelf->wasmetal_core__DOT___066906_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065423_))));
    vlSelf->wasmetal_core__DOT___065205_ = (1U & (0x4f44U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064476_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xcaU 
                                                              >> 
                                                              ((4U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___065198_) 
                                                                   << 1U) 
                                                                  | (1U 
                                                                     & (0xf0f0aaccU 
                                                                        >> 
                                                                        ((0x18U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                             << 1U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___065196_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___064503_) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___064510_))))))))) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___065201_))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___001437_)))))));
    vlSelf->wasmetal_core__DOT___066782_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065198_))));
    vlSelf->wasmetal_core__DOT___067338_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066095_))));
    vlSelf->wasmetal_core__DOT___066413_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064513_))));
    vlSelf->wasmetal_core__DOT___064516_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064514_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134219___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___064513_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xacU 
                                                                            >> 
                                                                            ((4U 
                                                                              & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O)) 
                                                                             | ((2U 
                                                                                & ((0xf0f05533U 
                                                                                >> 
                                                                                ((0x18U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064500_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h769a413d__0)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064503_)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___064511_)))))))));
    vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030115_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128231___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030243_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128239___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d));
    vlSelf->wasmetal_core__DOT___068423_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068027_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068422_)))));
    vlSelf->wasmetal_core__DOT___068399_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067970_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068398_)))));
    vlSelf->wasmetal_core__DOT___068290_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067817_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068289_)))));
    vlSelf->wasmetal_core__DOT___068344_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068343_)))));
    vlSelf->wasmetal_core__DOT___068152_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067732_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068151_)))));
    vlSelf->wasmetal_core__DOT___068076_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068075_)))));
    vlSelf->wasmetal_core__DOT___067971_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067970_)))));
    vlSelf->wasmetal_core__DOT___067818_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067302_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067817_)))));
    vlSelf->wasmetal_core__DOT___067733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067147_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067732_)))));
    vlSelf->wasmetal_core__DOT___067595_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066964_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067594_)))));
    vlSelf->wasmetal_core__DOT___068237_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067756_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068236_)))));
    vlSelf->wasmetal_core__DOT___067450_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066845_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067449_)))));
    vlSelf->wasmetal_core__DOT___068101_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067666_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068100_)))));
    vlSelf->wasmetal_core__DOT___067303_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066640_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067302_)))));
    vlSelf->wasmetal_core__DOT___068028_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067498_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___068027_)))));
    vlSelf->wasmetal_core__DOT___067905_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067332_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067904_)))));
    vlSelf->wasmetal_core__DOT___067148_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066518_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067147_)))));
    vlSelf->wasmetal_core__DOT___067757_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067188_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067756_)))));
    vlSelf->wasmetal_core__DOT___067667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067069_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067666_)))));
    vlSelf->wasmetal_core__DOT___066965_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066306_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066964_)))));
    vlSelf->wasmetal_core__DOT___067499_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066886_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067498_)))));
    vlSelf->wasmetal_core__DOT___066846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066118_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066845_)))));
    vlSelf->wasmetal_core__DOT___067333_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066762_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067332_)))));
    vlSelf->wasmetal_core__DOT___067189_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066595_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067188_)))));
    vlSelf->wasmetal_core__DOT___066641_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066640_)))));
    vlSelf->wasmetal_core__DOT___066519_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065795_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066518_)))));
    vlSelf->wasmetal_core__DOT___067070_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066392_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___067069_)))));
    vlSelf->wasmetal_core__DOT___066887_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066262_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066886_)))));
    vlSelf->wasmetal_core__DOT___066763_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___066072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066762_)))));
    vlSelf->wasmetal_core__DOT___066596_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066595_)))));
    vlSelf->wasmetal_core__DOT___066307_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066306_)))));
    vlSelf->wasmetal_core__DOT___066393_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065693_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066392_)))));
    vlSelf->wasmetal_core__DOT___065407_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065406_))));
    vlSelf->wasmetal_core__DOT___066263_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065406_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066262_)))));
    vlSelf->wasmetal_core__DOT___064893_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064892_))));
    vlSelf->wasmetal_core__DOT___065892_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064892_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065891_)))));
    vlSelf->wasmetal_core__DOT___065178_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065177_))));
    vlSelf->wasmetal_core__DOT___066073_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065177_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066072_)))));
    vlSelf->wasmetal_core__DOT___064485_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064484_))));
    vlSelf->wasmetal_core__DOT___065694_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064484_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065693_)))));
    vlSelf->wasmetal_core__DOT___065294_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065293_))));
    vlSelf->wasmetal_core__DOT___066119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___066118_)))));
    vlSelf->wasmetal_core__DOT___065796_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064725_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065795_)))));
    vlSelf->wasmetal_core__DOT___064726_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064725_))));
    vlSelf->wasmetal_core__DOT___065073_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065072_))));
    vlSelf->wasmetal_core__DOT___065928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065072_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065927_)))));
    vlSelf->wasmetal_core__DOT___065598_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___063831_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___065597_)))));
    vlSelf->wasmetal_core__DOT___063863_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___063831_))));
    vlSelf->wasmetal_core__DOT___063096_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063102_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063108_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063114_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127893___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128058___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128076___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028311_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028278_)
            : (IData)(vlSelf->wasmetal_core__DOT___028246_));
    vlSelf->wasmetal_core__DOT___066089_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066077_))));
    vlSelf->wasmetal_core__DOT___066272_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066269_))));
    vlSelf->wasmetal_core__DOT___064915_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048372_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064904_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001437_)))));
    vlSelf->wasmetal_core__DOT___064918_ = (1U & (IData)(
                                                         (0xdf0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063908_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064770_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063923_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063909_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___064911_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063924_)))))))));
    vlSelf->wasmetal_core__DOT___065192_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063926_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___065065_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___063929_)))));
    vlSelf->wasmetal_core__DOT___027472_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d))));
    vlSelf->wasmetal_core__DOT___027471_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d))));
    vlSelf->wasmetal_core__DOT___027470_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b1__05d))));
    vlSelf->wasmetal_core__DOT___027469_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127944___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b0__05d))));
    vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027377_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027301_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b4__05d));
    vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___005745_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127434___DOT__CO__BRA__1__KET__));
    if (vlSelf->wasmetal_core__DOT__simd_phase) {
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001950_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001949_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001948_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001947_))))))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002280_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h85a07a94__0))))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002355_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002354_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002353_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002352_))))))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001995_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000155_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_h91cc03bd__0))))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002198_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002197_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002196_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002195_))))))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001253_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001252_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001251_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001250_))))))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002078_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002077_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002076_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002075_))))))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___001810_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___001809_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___001808_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___001807_))))))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff1ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002040_) 
                                                           << 3U) 
                                                          | (IData)(vlSelf->__VdfgTmp_hf699b114__0))))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002518_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002517_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002516_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002515_))))))));
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (0xfff4ff00U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___002433_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___002432_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002431_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002430_))))))));
    } else {
        vlSelf->wasmetal_core__DOT___001798_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001951_))));
        vlSelf->wasmetal_core__DOT___002189_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002281_))));
        vlSelf->wasmetal_core__DOT___048787_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002356_))));
        vlSelf->wasmetal_core__DOT___001799_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001996_))));
        vlSelf->wasmetal_core__DOT___000141_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___000156_))));
        vlSelf->wasmetal_core__DOT___002187_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002199_))));
        vlSelf->wasmetal_core__DOT___000142_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001254_))));
        vlSelf->wasmetal_core__DOT___002028_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002079_))));
        vlSelf->wasmetal_core__DOT___001796_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___001811_))));
        vlSelf->wasmetal_core__DOT___002027_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002041_))));
        vlSelf->wasmetal_core__DOT___002471_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002519_))));
        vlSelf->wasmetal_core__DOT___048789_ = (1U 
                                                & ((~ (IData)(vlSelf->wasmetal_core__DOT___000158_)) 
                                                   & (1U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___002434_))));
    }
    vlSelf->wasmetal_core__DOT___002633_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002801_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002799_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002798_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002800_))))));
    vlSelf->wasmetal_core__DOT___001741_ = (1U & (IData)(
                                                         (0xff000f00ff00eeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h07469665__0)))))));
    vlSelf->wasmetal_core__DOT___002473_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002556_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002554_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002553_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002555_))))));
    vlSelf->wasmetal_core__DOT___064936_ = (1U & (0xf4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048287_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbcea2b7__0))));
    vlSelf->wasmetal_core__DOT___018278_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058932_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058931_))));
    vlSelf->wasmetal_core__DOT___061517_ = (1U & (0x1000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048384_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___061514_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___061505_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___061504_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___061491_)))))));
    vlSelf->wasmetal_core__DOT___061518_ = (1U & (IData)(
                                                         (0xfefffefffeffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___061513_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___061512_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061511_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___061510_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf56802d2__0))))))));
    vlSelf->wasmetal_core__DOT___012176_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0))))));
    vlSelf->__VdfgTmp_h88f91f2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 4U) | (IData)(vlSelf->__VdfgTmp_hba8ce1a4__0));
    vlSelf->wasmetal_core__DOT___012377_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                      ? (IData)(vlSelf->wasmetal_core__DOT___010187_)
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010186_)) 
                                                    << 1U) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      & (IData)(
                                                                (0xff00ffaaf0f0fcfcULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010180_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d))))))))))));
    vlSelf->__VdfgTmp_h00eaf9c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010181_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___010092_))));
    vlSelf->__VdfgTmp_h9c39d480__0 = (((IData)(vlSelf->wasmetal_core__DOT___010715_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010716_));
    vlSelf->wasmetal_core__DOT___010727_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010715_))));
    vlSelf->wasmetal_core__DOT___071991_ = (1U & (IData)(
                                                         (0xff00ff00eeee0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xccccaaaaf0f0ff00ULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hedc6bc1e__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011389_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010541_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)))))))))));
    vlSelf->wasmetal_core__DOT___056281_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_ha7112868__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010429_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010710_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010092_))))))))))));
    vlSelf->wasmetal_core__DOT___056923_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011198_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010221_)))));
    vlSelf->wasmetal_core__DOT___055200_ = (1U & (IData)(
                                                         (0xccaaf0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d 
        = (1U & (IData)((0xccaa0000f0f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                   << 4U) 
                                                  | (IData)(vlSelf->__VdfgTmp_h3cc7dcfe__0))))));
    vlSelf->wasmetal_core__DOT___062182_ = (1U & (IData)(
                                                         (0xfcf0faf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___062129_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((7U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007419_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___048412_)))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h058d1256__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055712_)))))))));
    vlSelf->wasmetal_core__DOT___050064_ = (1U & (0xc0aU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> 
                                                           (2U 
                                                            & ((4U 
                                                                >> 
                                                                (2U 
                                                                 & ((0xacU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                                    << 1U))) 
                                                               << 1U))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049530_)))));
    vlSelf->wasmetal_core__DOT___051763_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051614_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> 
                                                              (1U 
                                                               & (0x53U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hb6137419__0)))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b30__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT___050255_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050254_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051305_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051301_))));
    vlSelf->wasmetal_core__DOT___051307_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051301_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050176_))));
    vlSelf->wasmetal_core__DOT___050272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050176_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051311_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051303_))));
    vlSelf->wasmetal_core__DOT___051304_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051303_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050273_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050261_))));
    vlSelf->wasmetal_core__DOT___050262_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050261_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051312_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051309_))));
    vlSelf->wasmetal_core__DOT___051530_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051309_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051278_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050265_))));
    vlSelf->wasmetal_core__DOT___050266_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050265_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050140_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050139_))));
    vlSelf->wasmetal_core__DOT___051306_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050139_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051280_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050275_))));
    vlSelf->wasmetal_core__DOT___050276_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050275_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050166_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050165_))));
    vlSelf->wasmetal_core__DOT___051308_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050165_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051283_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050277_))));
    vlSelf->wasmetal_core__DOT___050278_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050277_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050155_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050154_))));
    vlSelf->wasmetal_core__DOT___051310_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050154_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051300_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051284_))));
    vlSelf->wasmetal_core__DOT___051285_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051284_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050274_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050168_))));
    vlSelf->wasmetal_core__DOT___050268_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050168_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___051299_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051281_))));
    vlSelf->wasmetal_core__DOT___051282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051281_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___050144_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050143_))));
    vlSelf->wasmetal_core__DOT___051380_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050143_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127601___O) 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___003811_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127454___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013805_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___003056_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___003054_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___003053_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___003055_))))));
    vlSelf->__VdfgTmp_h1e702231__0 = (((IData)(vlSelf->wasmetal_core__DOT___002469_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002468_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___000158_)));
    vlSelf->__VdfgTmp_ha128d41e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___051433_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___050851_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050850_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___050849_)))))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___009520_));
    vlSelf->wasmetal_core__DOT___051751_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051582_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051689_))))));
    vlSelf->wasmetal_core__DOT___002631_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___047996_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_phase)
                                                      ? 
                                                     (0xff00ff1fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___002721_) 
                                                        << 4U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                           << 3U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000157_) 
                                                              << 2U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___002719_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___002718_))))))
                                                      : 
                                                     (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___002720_))))));
    vlSelf->wasmetal_core__DOT___002883_ = (1U & ((1U 
                                                   & (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___001787_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___000182_) 
                                                                   << 4U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_he03432df__0))))))
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___000152_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___000169_)
                                                    ? 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))
                                                    : 
                                                   (0xe0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))));
    vlSelf->__VdfgTmp_h3fe5e3ea__0 = ((2U & ((IData)(
                                                     (0xff00ff00ff000eULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___048829_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___000152_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_h912dcb78__0))))))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0x1111fff000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000170_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___000169_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048828_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & (((IData)(vlSelf->wasmetal_core__DOT___000182_)
                                                                       ? 
                                                                      (0xc0aU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h8fa00ac2__0))
                                                                       : (IData)(vlSelf->wasmetal_core__DOT___002106_)) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h471ef662__0)))))))));
    vlSelf->wasmetal_core__DOT___050709_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049926_))));
    vlSelf->wasmetal_core__DOT___049721_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049383_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xacU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___049901_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049898_))));
    vlSelf->wasmetal_core__DOT___049768_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)))));
    vlSelf->wasmetal_core__DOT___051691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051347_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051690_))));
    vlSelf->wasmetal_core__DOT___051720_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051719_))));
    vlSelf->wasmetal_core__DOT___051652_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051327_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051651_))));
    vlSelf->wasmetal_core__DOT___051741_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051550_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___051650_))))));
    vlSelf->wasmetal_core__DOT___051707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051706_))));
    vlSelf->__VdfgTmp_haf508d85__0 = (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010300_));
    vlSelf->__VdfgTmp_h6f308c91__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010300_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010299_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010339_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010340_))))));
    vlSelf->wasmetal_core__DOT___056961_ = (1U & (IData)(
                                                         (0xf111100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056552_)))))))));
    vlSelf->__VdfgTmp_ha429fd09__0 = (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011659_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011658_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011660_))))));
    vlSelf->__VdfgTmp_h98e4ab16__0 = (((IData)(vlSelf->wasmetal_core__DOT___056553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011659_));
    vlSelf->wasmetal_core__DOT___011899_ = (1U & (0x50cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))));
    vlSelf->wasmetal_core__DOT___013692_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002033_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002029_))));
    vlSelf->wasmetal_core__DOT___057922_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___017384_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013648_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048791_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048788_))));
    vlSelf->wasmetal_core__DOT___017425_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_hd5565504__0 = (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002629_));
    vlSelf->wasmetal_core__DOT___017426_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002629_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___050457_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050400_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x7fff00007fff7fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___050452_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050398_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___050450_))))))))))));
    vlSelf->wasmetal_core__DOT___053369_ = (1U & (IData)(
                                                         (0xbfbfbfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053163_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053088_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053092_)))))))));
    vlSelf->wasmetal_core__DOT___019803_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xbbbU 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___050451_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___052988_))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052688_)))));
    vlSelf->wasmetal_core__DOT___039820_ = (1U & (IData)(
                                                         (0xeaea2aea2a2a2a2aULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050449_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xfdf00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___052688_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050446_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048518_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050451_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053440_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__check_type)))))))));
    vlSelf->wasmetal_core__DOT___053249_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053248_))));
    vlSelf->wasmetal_core__DOT___017409_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___056088_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d)))));
    vlSelf->wasmetal_core__DOT___056095_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000980_)))));
    vlSelf->wasmetal_core__DOT___056098_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000992_)))));
    vlSelf->wasmetal_core__DOT___056101_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001014_)))));
    vlSelf->wasmetal_core__DOT___056118_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001102_)))));
    vlSelf->wasmetal_core__DOT___056128_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001146_)))));
    vlSelf->wasmetal_core__DOT___056132_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001168_)))));
    vlSelf->wasmetal_core__DOT___056017_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d)))));
    vlSelf->wasmetal_core__DOT___056025_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d)))));
    vlSelf->wasmetal_core__DOT___056029_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d)))));
    vlSelf->wasmetal_core__DOT___056033_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___056037_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d)))));
    vlSelf->wasmetal_core__DOT___056041_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d)))));
    vlSelf->wasmetal_core__DOT___056047_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d)))));
    vlSelf->wasmetal_core__DOT___056055_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d)))));
    vlSelf->wasmetal_core__DOT___056060_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d)))));
    vlSelf->wasmetal_core__DOT___056065_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d)))));
    vlSelf->wasmetal_core__DOT___056069_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d)))));
    vlSelf->wasmetal_core__DOT___056073_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d)))));
    vlSelf->wasmetal_core__DOT___056077_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d)))));
    vlSelf->wasmetal_core__DOT___056082_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d)))));
    vlSelf->wasmetal_core__DOT___056085_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d)))));
    vlSelf->wasmetal_core__DOT___056007_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d)))));
    vlSelf->wasmetal_core__DOT___056013_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055714_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b29__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050493_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050493_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b21__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___049868_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___049868_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b25__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___051271_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___051271_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d 
        = (1U & (8U >> ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O) 
                               << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___050487_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___050487_) 
                         << 1U) | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d 
        = (1U & (0x40U >> (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                             >> 2U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127478___O))))));
    vlSelf->wasmetal_core__DOT___049918_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049917_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___050492_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049865_))));
    vlSelf->wasmetal_core__DOT___049913_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049865_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051269_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049944_))));
    vlSelf->wasmetal_core__DOT___049945_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049944_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051270_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050484_))));
    vlSelf->wasmetal_core__DOT___050486_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050484_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___049925_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049924_))));
    vlSelf->wasmetal_core__DOT___051274_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049924_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___051272_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049921_))));
    vlSelf->wasmetal_core__DOT___050494_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049921_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127477___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT___055126_ = (1U & (IData)(
                                                         (0xffff000000fe0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccaaaaff00f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055118_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xf5533ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5e28409c__0)))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xff33330f0f5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054757_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054758_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xc0aU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2ba92b9e__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054760_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054762_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054759_))))))))))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x1111000f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86da9f86__0))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf800U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___008974_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055122_))))))))))))));
    vlSelf->wasmetal_core__DOT___017284_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___013701_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000147_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000143_))));
    vlSelf->wasmetal_core__DOT___058005_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001414_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128648___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128112___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028871_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028868_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028857_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028846_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___028839_ = ((IData)(vlSelf->wasmetal_core__DOT___028871_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128112___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001886_));
    vlSelf->wasmetal_core__DOT___028875_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001487_))));
    vlSelf->wasmetal_core__DOT___028874_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001475_))));
    vlSelf->wasmetal_core__DOT___028873_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001443_))));
    vlSelf->wasmetal_core__DOT___028872_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001437_))));
    vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028491_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028458_)
            : (IData)(vlSelf->wasmetal_core__DOT___003780_));
    vlSelf->wasmetal_core__DOT___013670_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001801_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001797_))));
    vlSelf->wasmetal_core__DOT___013652_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___002188_))));
    vlSelf->__VdfgTmp_h15d2df15__0 = (((IData)(vlSelf->wasmetal_core__DOT___049567_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049566_));
    vlSelf->wasmetal_core__DOT___049100_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049090_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049089_))));
    vlSelf->wasmetal_core__DOT___048980_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048979_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048978_))));
    vlSelf->__VdfgTmp_h32efca0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___049265_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049264_));
    vlSelf->__VdfgTmp_h65c50ed7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049564_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049567_));
    vlSelf->wasmetal_core__DOT___049485_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049107_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049090_))));
    vlSelf->wasmetal_core__DOT___049837_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048970_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048979_))));
    vlSelf->wasmetal_core__DOT___049456_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049254_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049265_))));
    vlSelf->__VdfgTmp_hd992aaf0__0 = (((IData)(vlSelf->wasmetal_core__DOT___049565_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049564_));
    vlSelf->wasmetal_core__DOT___049109_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049108_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049107_))));
    vlSelf->wasmetal_core__DOT___048981_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048971_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048970_))));
    vlSelf->wasmetal_core__DOT___049258_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049255_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049254_))));
    vlSelf->__VdfgTmp_h6f0935bb__0 = (((IData)(vlSelf->wasmetal_core__DOT___049554_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049565_));
    vlSelf->__VdfgTmp_h337a7e76__0 = (((IData)(vlSelf->wasmetal_core__DOT___049103_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049108_));
    vlSelf->wasmetal_core__DOT___050602_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048996_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048971_))));
    vlSelf->wasmetal_core__DOT___049457_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049256_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049255_))));
    vlSelf->__VdfgTmp_hd0aa9c81__0 = (((IData)(vlSelf->wasmetal_core__DOT___049555_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049554_));
    vlSelf->__VdfgTmp_hf7ec4412__0 = (((IData)(vlSelf->wasmetal_core__DOT___049104_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049103_));
    vlSelf->wasmetal_core__DOT___048998_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048996_))));
    vlSelf->wasmetal_core__DOT___049259_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049256_))));
    vlSelf->__VdfgTmp_h92ec5796__0 = (((IData)(vlSelf->wasmetal_core__DOT___049552_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049555_));
    vlSelf->__VdfgTmp_h97f76463__0 = (((IData)(vlSelf->wasmetal_core__DOT___049202_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049104_));
    vlSelf->wasmetal_core__DOT___050607_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048997_))));
    vlSelf->wasmetal_core__DOT___049469_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049305_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049257_))));
    vlSelf->wasmetal_core__DOT___036900_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h2f60644c__0)) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h826c8569__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xe8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h4598addd__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x2bU 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0))))))));
    vlSelf->wasmetal_core__DOT___036899_ = (1U & (0x8e71U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036636_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x69U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h2a821aa8__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x17U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h0033f05e__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0x17U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4720a72d__0))))))));
    vlSelf->wasmetal_core__DOT___036898_ = (1U & (0x17e8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___036635_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h79b76beb__0))));
    vlSelf->wasmetal_core__DOT___036897_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h79b76beb__0))))));
    vlSelf->__VdfgTmp_h2cac88ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___049553_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049552_));
    vlSelf->wasmetal_core__DOT___049204_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049203_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049202_))));
    vlSelf->wasmetal_core__DOT___048999_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048988_))));
    vlSelf->wasmetal_core__DOT___049307_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049306_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049305_))));
    vlSelf->wasmetal_core__DOT___050626_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049560_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049553_))));
    vlSelf->wasmetal_core__DOT___049516_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049198_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049203_))));
    vlSelf->wasmetal_core__DOT___050608_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050506_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048989_))));
    vlSelf->wasmetal_core__DOT___049470_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049303_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049306_))));
    vlSelf->wasmetal_core__DOT___049562_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049561_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049560_))));
    vlSelf->__VdfgTmp_h10a4b2d7__0 = (((IData)(vlSelf->wasmetal_core__DOT___049199_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049198_));
    vlSelf->wasmetal_core__DOT___050508_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050507_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050506_))));
    vlSelf->wasmetal_core__DOT___049308_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049304_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049303_))));
    vlSelf->wasmetal_core__DOT___050627_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049558_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049561_))));
    vlSelf->wasmetal_core__DOT___049517_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049188_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049199_))));
    vlSelf->wasmetal_core__DOT___050619_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050504_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050507_))));
    vlSelf->wasmetal_core__DOT___049471_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049297_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049304_))));
    vlSelf->wasmetal_core__DOT___049563_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049559_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049558_))));
    vlSelf->__VdfgTmp_hcb165b79__0 = (((IData)(vlSelf->wasmetal_core__DOT___049189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049188_));
    vlSelf->wasmetal_core__DOT___050509_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050504_))));
    vlSelf->__VdfgTmp_hf18161ea__0 = (((IData)(vlSelf->wasmetal_core__DOT___049298_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049297_));
    vlSelf->wasmetal_core__DOT___050624_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049559_))));
    vlSelf->wasmetal_core__DOT___049518_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049180_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049189_))));
    vlSelf->wasmetal_core__DOT___050620_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050505_))));
    vlSelf->wasmetal_core__DOT___049472_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049293_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049298_))));
    vlSelf->wasmetal_core__DOT___063851_ = (1U & (IData)(
                                                         (0x7f7f7f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063849_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___042378_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048358_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___042427_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000354_)))))))));
    vlSelf->wasmetal_core__DOT___049575_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049571_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049570_))));
    vlSelf->__VdfgTmp_h2121b61a__0 = (((IData)(vlSelf->wasmetal_core__DOT___049181_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049180_));
    vlSelf->wasmetal_core__DOT___050515_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050513_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050512_))));
    vlSelf->wasmetal_core__DOT___049300_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049294_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049293_))));
    vlSelf->wasmetal_core__DOT___060487_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058931_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xffffff007f7f0000ULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0)) 
                                                                      << 5U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | ((4U 
                                                                            & ((0x80U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050141_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hb70db301__0)))))) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_ha9e2ef67__0)))))))))));
    vlSelf->wasmetal_core__DOT___058550_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))));
    vlSelf->wasmetal_core__DOT___051510_ = (1U & (IData)(
                                                         (0x8f8f00ff00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hf36d9f62__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051509_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051508_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9e4ff193__0))))))));
    vlSelf->wasmetal_core__DOT___049574_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049572_))));
    vlSelf->wasmetal_core__DOT___050625_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049573_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049571_))));
    vlSelf->__VdfgTmp_ha51ab883__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049181_));
    vlSelf->__VdfgTmp_hef58fdbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___049169_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___049168_));
    vlSelf->wasmetal_core__DOT___050514_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050510_))));
    vlSelf->wasmetal_core__DOT___050633_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050513_))));
    vlSelf->wasmetal_core__DOT___049466_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049294_))));
    vlSelf->wasmetal_core__DOT___049319_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049317_))));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028113_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__1__KET__)
                  : (vlSelf->insn_x >> 2U)));
    vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026481_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b5__05d));
    vlSelf->wasmetal_core__DOT___053505_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xffff44f400000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053498_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                                        << 3U) 
                                                                       | ((4U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                              << 2U)) 
                                                                          | ((2U 
                                                                              & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___044368_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___052845_))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___052847_)))))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053499_))));
    vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128477___O) 
            >> 2U) & (IData)(vlSelf->wasmetal_core__DOT___128142___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031047_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128325___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b14__05d));
    vlSelf->wasmetal_core__DOT___053895_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053646_))));
    vlSelf->wasmetal_core__DOT___050600_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050585_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049023_))))));
    vlSelf->wasmetal_core__DOT___049775_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049447_))))));
    vlSelf->wasmetal_core__DOT___050060_ = (1U & (0xf0f0ccaaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050053_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xacU 
                                                           >> (IData)(vlSelf->__VdfgTmp_hdfb5cdf6__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xacU 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9726a7a2__0)))))));
    vlSelf->__VdfgTmp_h23ac912c__0 = ((2U & ((0x53U 
                                              >> (IData)(vlSelf->__VdfgTmp_hee8b18a4__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056433_));
    vlSelf->wasmetal_core__DOT___057264_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012990_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012992_)))));
    vlSelf->wasmetal_core__DOT___056725_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012742_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012125_)))))))));
    vlSelf->wasmetal_core__DOT___011923_ = (1U & (IData)(
                                                         (0x33330f0f00ff5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012125_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010574_)))))))));
    vlSelf->__VdfgTmp_hcef50cee__0 = (((IData)(vlSelf->wasmetal_core__DOT___012131_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013095_));
    vlSelf->wasmetal_core__DOT___011701_ = (1U & (0x32U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        & (IData)(vlSelf->wasmetal_core__DOT___010166_)) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010197_)))));
    vlSelf->__VdfgTmp_h3784db21__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050526_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050521_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050528_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049013_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___051403_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051402_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051401_))));
    vlSelf->wasmetal_core__DOT___049731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049285_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049252_))));
    vlSelf->wasmetal_core__DOT___049869_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049657_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___049249_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___049659_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049658_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049657_))));
    vlSelf->wasmetal_core__DOT___049625_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049624_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049623_))));
    vlSelf->__VdfgTmp_h43b12a4e__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011528_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011381_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___012797_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14d4af94__0)))));
    vlSelf->wasmetal_core__DOT___011887_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h14d4af94__0))));
    vlSelf->wasmetal_core__DOT___011191_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011181_))));
    vlSelf->__VdfgTmp_hdd9e6a33__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056378_))))));
    vlSelf->wasmetal_core__DOT___056346_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056173_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056172_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)))))))));
    vlSelf->wasmetal_core__DOT___010402_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010392_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010391_))));
    vlSelf->__VdfgTmp_hc88b842e__0 = (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010182_));
    vlSelf->__VdfgTmp_h84e2ca83__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056380_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056377_))))));
    vlSelf->__VdfgTmp_h584e6b29__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056379_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056378_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___056376_))))));
    vlSelf->__VdfgTmp_h29c29c56__0 = (((IData)(vlSelf->wasmetal_core__DOT___056377_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h375c9c07__0));
    vlSelf->__VdfgTmp_h766276ef__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)));
    vlSelf->wasmetal_core__DOT___056206_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___009842_)) 
                                                  & ((~ 
                                                      (0xfef0U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010756_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_hf1d7bcdf__0)))))) 
                                                     & (IData)(
                                                               (1ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___009840_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)))))))))));
    vlSelf->__VdfgTmp_hf19e2482__0 = (((IData)(vlSelf->wasmetal_core__DOT___056721_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056720_));
    vlSelf->wasmetal_core__DOT___056774_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011922_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4284cb76__0))))));
    vlSelf->__VdfgTmp_h36a8bb37__0 = (((IData)(vlSelf->wasmetal_core__DOT___011921_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011922_));
    vlSelf->__VdfgTmp_h0e06d26a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0)));
    vlSelf->wasmetal_core__DOT___013143_ = (1U & (IData)(
                                                         (0xf0faacc00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3fe4e0c8__0))))));
    vlSelf->wasmetal_core__DOT___056801_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010196_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->wasmetal_core__DOT___056643_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012293_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4a9b748c__0)))))));
    vlSelf->wasmetal_core__DOT___056277_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012294_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012293_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d 
        = (1U & (IData)((0xeefe00f0ULL >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02elower_bound__05b31__05d) 
                                            << 5U) 
                                           | (IData)(vlSelf->__VdfgTmp_h16c112d2__0)))));
    vlSelf->wasmetal_core__DOT___010390_ = (1U & (IData)(
                                                         (0xfff00000eeeeULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056284_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010805_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h0931b472__0)))))))))));
    vlSelf->__VdfgTmp_h3a025ab3__0 = (((IData)(vlSelf->wasmetal_core__DOT___056288_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011995_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0931b472__0)));
    vlSelf->wasmetal_core__DOT____Vcellout___128541___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___033390_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___010045_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_hfa355bbf__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___033452_ = ((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128541___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hc33f85b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___033411_)))) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x69U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h6af19a3e__0)))));
    vlSelf->__VdfgTmp_haddc65cd__0 = ((((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                        & (IData)(vlSelf->wasmetal_core__DOT___011906_)) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xfaf3f0f0ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                            ? 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (2U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011522_)))
                                                                            : 
                                                                           ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                            & (IData)(vlSelf->wasmetal_core__DOT___010336_))) 
                                                                          << 2U)) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___011518_))))))))));
    vlSelf->__VdfgTmp_h30784950__0 = ((2U & ((0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___011539_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011906_));
    vlSelf->__VdfgTmp_h06746976__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0));
    vlSelf->__VdfgTmp_hf037ddb3__0 = ((2U & ((IData)(
                                                     (0xf0faacc00000000ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                           << 4U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011540_) 
                                                                 << 2U) 
                                                                | (IData)(vlSelf->__VdfgTmp_hf6c0bd72__0))))))) 
                                             << 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (0xc0aU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h470ae9e3__0))))
                                                : (0xa03U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010044_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___010298_))))))));
    vlSelf->wasmetal_core__DOT___011772_ = (1U & (IData)(
                                                         (0xfff4f400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010259_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h493dc6bd__0)))))));
    vlSelf->wasmetal_core__DOT___011961_ = (1U & (IData)(
                                                         (0xf4f400ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))));
    vlSelf->__VdfgTmp_hc77b1aaa__0 = ((2U & ((IData)(
                                                     (0xf4f4000000ffULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 5U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                           << 4U) 
                                                          | (IData)(vlSelf->__VdfgTmp_he09ec1d2__0))))) 
                                             << 1U)) 
                                      | ((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                         & (IData)(
                                                   (0xff00ffaaf0f0fcfcULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010189_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010188_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d))))))))));
    vlSelf->wasmetal_core__DOT___072147_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee315f88__0))));
    vlSelf->wasmetal_core__DOT___056964_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010722_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                      ? 
                                                     (0xfff4U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x5c00U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___033416_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___011522_))))) 
                                                              << 2U)) 
                                                          | (IData)(vlSelf->__VdfgTmp_h2790f0bb__0))))
                                                      : 
                                                     (0xf1U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0xa300U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_he7cac7a8__0)))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (0xa03U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___033390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011513_))))))))))));
    vlSelf->wasmetal_core__DOT___012179_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                   | (0xeU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012123_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                    ? 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))
                                                    : 
                                                   (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011413_)))))));
    vlSelf->__VdfgTmp_h6bff4562__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010575_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha5884336__0)))));
    vlSelf->wasmetal_core__DOT___010842_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011413_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)))))));
    vlSelf->__VdfgTmp_h8127a3d2__0 = (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h99697672__0)));
    vlSelf->__VdfgTmp_h0a5eca32__0 = (((IData)(vlSelf->wasmetal_core__DOT___011538_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011530_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011529_)));
    vlSelf->__VdfgTmp_h2aa20ca5__0 = (((IData)(vlSelf->wasmetal_core__DOT___010198_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010197_)));
    vlSelf->wasmetal_core__DOT___056922_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011697_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h42ead4cc__0)))))));
    vlSelf->wasmetal_core__DOT___072145_ = (1U & (IData)(
                                                         (0xe8e8e800e8000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0xfef0U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))));
    vlSelf->wasmetal_core__DOT___072146_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072160_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___009833_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___072177_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h25f5437e__0)))))))));
    vlSelf->wasmetal_core__DOT___010719_ = (1U & (IData)(
                                                         (0xff000f33335555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056369_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1055e951__0)))))));
    vlSelf->wasmetal_core__DOT___012045_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___010124_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    vlSelf->wasmetal_core__DOT___012295_ = ((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___010125_));
    vlSelf->wasmetal_core__DOT___011831_ = ((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                ? (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___010767_))
                                                : (IData)(vlSelf->wasmetal_core__DOT___011478_)));
    vlSelf->wasmetal_core__DOT___011962_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010220_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010219_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010261_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010260_)))))))));
    vlSelf->__VdfgTmp_h744d21e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___010260_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010259_));
    vlSelf->__VdfgTmp_h028857f6__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_hb211d2c2__0));
    vlSelf->wasmetal_core__DOT___072002_ = (1U & (IData)(
                                                         (0x55553333000f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056596_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011388_)))))))));
    vlSelf->__VdfgTmp_hcd2c6110__0 = (((IData)(vlSelf->wasmetal_core__DOT___011472_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011470_)));
    vlSelf->__VdfgTmp_h9484b551__0 = (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011390_));
    vlSelf->__VdfgTmp_h58c9f225__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_ha4e3e772__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hda718c9e__0)))));
    vlSelf->wasmetal_core__DOT___011110_ = (1U & (IData)(
                                                         (0x5050f0f00ff0033ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056499_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                          ? 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___010969_)))
                                                                          : 
                                                                         ((~ (IData)(vlSelf->wasmetal_core__DOT___010530_)) 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT___011115_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011604_)))))))));
    vlSelf->wasmetal_core__DOT___011359_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056594_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056593_)))));
    vlSelf->wasmetal_core__DOT___050678_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050675_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050674_))));
    vlSelf->wasmetal_core__DOT___049495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049493_))));
    vlSelf->wasmetal_core__DOT___049800_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049494_))));
    vlSelf->wasmetal_core__DOT___050696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049703_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049706_))));
    vlSelf->wasmetal_core__DOT___049889_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049621_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049624_))));
    vlSelf->wasmetal_core__DOT___049113_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049086_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049085_))));
    vlSelf->wasmetal_core__DOT___051474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049044_))));
    vlSelf->__VdfgTmp_h2966b870__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___050598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___050585_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___049023_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050601_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050598_))));
    vlSelf->wasmetal_core__DOT___050529_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050526_))));
    vlSelf->wasmetal_core__DOT___051412_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051410_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051402_))));
    vlSelf->wasmetal_core__DOT___050712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049588_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049689_))));
    vlSelf->wasmetal_core__DOT___049776_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049460_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049455_))));
    vlSelf->wasmetal_core__DOT___049462_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049455_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049454_))));
    vlSelf->wasmetal_core__DOT___049287_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049286_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049285_))));
    vlSelf->wasmetal_core__DOT___049870_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049655_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049658_))));
    vlSelf->wasmetal_core__DOT___056289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011998_))));
    vlSelf->wasmetal_core__DOT___013139_ = (1U & (IData)(
                                                         (0x111111110000ff0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011602_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011603_)))))))));
    vlSelf->__VdfgTmp_h5e559da9__0 = ((2U & ((0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___056437_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010530_)))) 
                                             << 1U)) 
                                      | (1U & (0xdU 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010530_))))));
    vlSelf->__VdfgTmp_h5fdab2da__0 = (((IData)(vlSelf->wasmetal_core__DOT___011859_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011604_));
    vlSelf->wasmetal_core__DOT___011109_ = (1U & (IData)(
                                                         (0xff005533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056500_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___010948_ = (1U & (IData)(
                                                         (0xff00ff5533330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056440_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4cd16820__0)))))));
    vlSelf->wasmetal_core__DOT___057068_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057067_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057066_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057065_)))))));
    vlSelf->wasmetal_core__DOT___071999_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011605_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf996b543__0))))));
    vlSelf->__VdfgTmp_hefe0e1be__0 = (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___011604_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h146131dd__0)));
    vlSelf->wasmetal_core__DOT___010850_ = (1U & (IData)(
                                                         (0xf0f000005533ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011858_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h146131dd__0))))))));
    vlSelf->wasmetal_core__DOT___056578_ = (1U & (IData)(
                                                         (0x4000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))))));
    vlSelf->wasmetal_core__DOT___011253_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011205_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010085_))))));
    vlSelf->__VdfgTmp_h55e24ebb__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011205_));
    vlSelf->__VdfgTmp_hef0b5c34__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                      << 1U) 
                                                     | (1U 
                                                        & (0x53U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)))))));
    vlSelf->wasmetal_core__DOT___056894_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x5300U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013099_))));
    vlSelf->wasmetal_core__DOT___063401_ = (1U & (0xeeeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053368_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053087_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053096_))))));
    vlSelf->wasmetal_core__DOT___063424_ = (1U & (IData)(
                                                         (0xff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063421_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x4f00000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->insn_valid) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050443_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___047994_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___048392_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x22330a0f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063414_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053010_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052906_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063418_)))))))));
    vlSelf->wasmetal_core__DOT___049045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049044_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049043_))));
    vlSelf->wasmetal_core__DOT___051543_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049688_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O)))));
    vlSelf->wasmetal_core__DOT___049690_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049688_))));
    vlSelf->wasmetal_core__DOT___052604_ = (1U & (IData)(
                                                         (0xaaccf000000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052600_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h84446dc0__0)))))));
    vlSelf->wasmetal_core__DOT___067179_ = (1U & (IData)(
                                                         (0xf0f00003355ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((4U 
                                                               & ((0xcaU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050046_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050058_))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050053_)))))));
    vlSelf->wasmetal_core__DOT___050061_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050059_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050058_))));
    vlSelf->wasmetal_core__DOT___051466_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049857_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049363_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___049370_)))))));
    vlSelf->wasmetal_core__DOT___049372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049363_))));
    vlSelf->wasmetal_core__DOT___051432_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051429_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051426_)))))));
    vlSelf->wasmetal_core__DOT___051461_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051428_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051427_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051426_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051433_)))))));
    vlSelf->wasmetal_core__DOT___053388_ = (1U & (IData)(
                                                         (0xf0f0aaaaccccff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050827_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___052592_ = (1U & (IData)(
                                                         (0xccccaaaaff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052591_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052590_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h36cbed8c__0))))));
    vlSelf->wasmetal_core__DOT___053111_ = (1U & (0xacU 
                                                  >> 
                                                  ((2U 
                                                    & ((0xacU 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___051918_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051904_))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (0xcaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___051906_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___051905_)))))));
    vlSelf->wasmetal_core__DOT___050899_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049057_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___050544_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050542_) 
                                                            << 3U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h10726817__0)))));
    vlSelf->wasmetal_core__DOT___049799_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049493_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049505_))));
    vlSelf->wasmetal_core__DOT___049507_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049505_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049504_))));
    vlSelf->wasmetal_core__DOT___049707_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049706_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049705_))));
    vlSelf->wasmetal_core__DOT___050695_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049705_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049700_))));
    vlSelf->wasmetal_core__DOT___049147_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049144_))));
    vlSelf->wasmetal_core__DOT___049751_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049145_))));
    vlSelf->wasmetal_core__DOT___049888_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049623_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049618_))));
    vlSelf->wasmetal_core__DOT___049620_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049618_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049617_))));
    vlSelf->__VdfgTmp_h2d927cdc__0 = (((IData)(vlSelf->wasmetal_core__DOT___011206_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011207_));
    vlSelf->__VdfgTmp_h9b5fb542__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 3U) | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0));
    vlSelf->__VdfgTmp_h890ba8da__0 = (((IData)(vlSelf->wasmetal_core__DOT___010412_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hb44ad26b__0)));
    vlSelf->__VdfgTmp_ha28d971c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010301_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)));
    vlSelf->wasmetal_core__DOT___011029_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010262_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011030_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010291_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011031_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010282_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011038_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010273_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011039_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010254_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT___011040_ = (1U & (IData)(
                                                         (0xffff0000ffffff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010243_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h450c5ec1__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b9__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b14__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b13__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b11__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b11__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b10__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b10__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b8__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055108_))));
    vlSelf->wasmetal_core__DOT___053581_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051779_))));
    vlSelf->__VdfgTmp_h86de1fc0__0 = (((IData)(vlSelf->wasmetal_core__DOT___012286_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h8b4e795d__0));
    vlSelf->wasmetal_core__DOT___072175_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x96U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))))));
    vlSelf->__VdfgTmp_hab99f676__0 = ((2U & ((IData)(
                                                     (0x55f366c366cfaa0ULL 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                                        << 5U) 
                                                       | ((0x10U 
                                                           & ((0xfef0U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                                              << 4U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                                                              << 3U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d)))))))) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0))));
    vlSelf->wasmetal_core__DOT___055309_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d))));
    vlSelf->wasmetal_core__DOT___013103_ = (1U & (0x1111000fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056896_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056895_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012177_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012178_)))))));
    vlSelf->__VdfgTmp_hc338337f__0 = (((IData)(vlSelf->wasmetal_core__DOT___012182_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012183_));
    vlSelf->__VdfgTmp_hc49b4927__0 = (((IData)(vlSelf->wasmetal_core__DOT___012183_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012182_));
    vlSelf->wasmetal_core__DOT___012402_ = (1U & (IData)(
                                                         (0xaaaaccccf0f0ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0))))))));
    vlSelf->wasmetal_core__DOT___056717_ = (1U & (0x503U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hede7bfa8__0)))));
    vlSelf->wasmetal_core__DOT___010720_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011471_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011390_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0))))))));
    vlSelf->wasmetal_core__DOT___011937_ = (1U & (0xc0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7bcb9cab__0)))));
    vlSelf->__VdfgTmp_he9aaeb48__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hb1f92188__0)))));
    vlSelf->wasmetal_core__DOT___011960_ = (1U & (IData)(
                                                         (0xff0000f4f4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010221_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he9d803b7__0)))))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b24__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b62__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b61__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b60__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b59__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b58__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b57__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b56__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b55__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b54__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b53__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b51__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b50__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b49__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b48__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b47__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b46__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b45__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b44__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b43__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___011478_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b42__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b40__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b39__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b38__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b37__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b36__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b35__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b34__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b33__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b32__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT___010413_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_)))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b31__05d 
        = (1U & (0xeU >> ((2U & ((0xfef0U >> (IData)(vlSelf->__VdfgTmp_h2133c371__0)) 
                                 << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b30__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___010972_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b29__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b28__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___011020_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b25__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b23__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b21__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b20__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b19__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b19__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b18__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b18__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b17__05d) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055194_))));
    vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d 
        = (1U & (0xf4U >> (((IData)(vlSelf->wasmetal_core__DOT___055194_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b15__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008974_)))));
    vlSelf->wasmetal_core__DOT___039366_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019277_)))));
    vlSelf->wasmetal_core__DOT___053887_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053634_))));
    vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006151_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127557___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013738_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127574___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h454dd727__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049531_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049530_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         (2U 
                                                          & ((0xacU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h3f02e9b4__0)) 
                                                             << 1U))) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___050869_ = (1U & (0xffaaccf0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050791_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h54bf9a7e__0)))));
    vlSelf->wasmetal_core__DOT___050895_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050791_))));
    vlSelf->wasmetal_core__DOT___051467_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049927_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049926_)))));
    vlSelf->wasmetal_core__DOT___049860_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049371_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049384_))));
    vlSelf->__VdfgTmp_h444aee6e__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___049384_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___049383_))) 
                                             << 1U)) 
                                      | (1U & (1U >> 
                                               (1U 
                                                & (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6a1d65be__0))))));
    vlSelf->wasmetal_core__DOT___050857_ = (1U & (0x5cU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050855_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x503U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h79a3c79a__0)))))));
    vlSelf->wasmetal_core__DOT___049649_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_he62a830e__0))));
    vlSelf->wasmetal_core__DOT___050830_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050829_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050828_)))));
    vlSelf->wasmetal_core__DOT___052620_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_had82d15e__0))));
    vlSelf->wasmetal_core__DOT___050546_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050543_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049898_)))));
    vlSelf->wasmetal_core__DOT___049243_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049241_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (4U 
                                                            >> 
                                                            (2U 
                                                             & ((4U 
                                                                 >> 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___049238_) 
                                                                  << 1U)) 
                                                                << 1U))))))));
    vlSelf->wasmetal_core__DOT___051922_ = (1U & (0xcaU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049765_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051907_)))));
    vlSelf->wasmetal_core__DOT___051583_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051582_))));
    vlSelf->wasmetal_core__DOT___051058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049146_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051057_))));
    vlSelf->wasmetal_core__DOT___051348_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049749_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051347_))));
    vlSelf->wasmetal_core__DOT___049753_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049750_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049749_))));
}
