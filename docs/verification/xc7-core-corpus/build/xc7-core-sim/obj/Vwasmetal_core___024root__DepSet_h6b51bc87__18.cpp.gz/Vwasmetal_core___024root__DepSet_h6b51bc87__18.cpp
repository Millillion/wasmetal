#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__16(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__16\n"); );
    // Init
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___128059___O;
    wasmetal_core__DOT____Vcellout___128059___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__ = 0;
    // Body
    vlSelf->wasmetal_core__DOT___049660_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049655_))));
    vlSelf->wasmetal_core__DOT___049496_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049487_))));
    vlSelf->wasmetal_core__DOT___051995_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050609_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050599_))));
    vlSelf->wasmetal_core__DOT___049463_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049460_))));
    vlSelf->wasmetal_core__DOT___049114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049112_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049111_))));
    vlSelf->wasmetal_core__DOT___051417_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051414_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051413_))));
    vlSelf->wasmetal_core__DOT___049288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049269_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049268_))));
    vlSelf->wasmetal_core__DOT___050700_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049704_))));
    vlSelf->wasmetal_core__DOT___051486_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051483_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049845_))));
    vlSelf->wasmetal_core__DOT___050715_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049600_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049589_))));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036898_)
            ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036635_));
    vlSelf->wasmetal_core__DOT___049892_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049622_))));
    vlSelf->wasmetal_core__DOT___050530_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049001_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049000_))));
    vlSelf->wasmetal_core__DOT___049872_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049662_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049656_))));
    vlSelf->wasmetal_core__DOT___050731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050689_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050688_))));
    vlSelf->wasmetal_core__DOT___049804_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049488_))));
    vlSelf->wasmetal_core__DOT___050637_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050609_))));
    vlSelf->wasmetal_core__DOT___049779_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049473_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049461_))));
    vlSelf->wasmetal_core__DOT___051594_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051318_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051317_))));
    vlSelf->wasmetal_core__DOT___049756_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049206_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049112_))));
    vlSelf->wasmetal_core__DOT___051898_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051415_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051414_))));
    vlSelf->wasmetal_core__DOT___049735_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049309_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049269_))));
    vlSelf->wasmetal_core__DOT___053117_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050628_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050623_))));
    vlSelf->wasmetal_core__DOT___049715_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049712_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049711_))));
    vlSelf->wasmetal_core__DOT___053126_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051484_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051483_))));
    vlSelf->wasmetal_core__DOT___049603_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049601_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049600_))));
    vlSelf->wasmetal_core__DOT___050554_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050546_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049575_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049574_))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049578_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049577_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049576_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050544_))))))));
    vlSelf->wasmetal_core__DOT___049633_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049631_))));
    vlSelf->wasmetal_core__DOT___049664_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049663_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049662_))));
    vlSelf->wasmetal_core__DOT___051992_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051989_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050730_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050689_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050688_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050675_)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xff00aaaaccccf0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050788_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050674_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7f4141b2__0)))))))))))));
    vlSelf->wasmetal_core__DOT___049521_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049520_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049519_))));
    vlSelf->wasmetal_core__DOT___049475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049474_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049473_))));
    vlSelf->wasmetal_core__DOT___049208_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049207_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049206_))));
    vlSelf->wasmetal_core__DOT___049325_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049309_))));
    vlSelf->wasmetal_core__DOT___018498_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048132_))));
    vlSelf->wasmetal_core__DOT___060246_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058551_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017940_))));
    vlSelf->wasmetal_core__DOT___051468_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | ((4U 
                                                               & ((0xacU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___050623_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049858_))) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050629_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___050628_)))))));
    vlSelf->wasmetal_core__DOT___052603_ = (1U & (0x55ccf0f0U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 4U)) 
                                                   | ((4U 
                                                       & ((0x55ccf000U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___051647_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___051646_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___049712_)))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xf0faaccU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___049704_) 
                                                                << 2U) 
                                                               | ((2U 
                                                                   & ((0xacU 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h97f76463__0)) 
                                                                      << 1U)) 
                                                                  | (1U 
                                                                     & (0xacU 
                                                                        >> (IData)(vlSelf->__VdfgTmp_h337a7e76__0)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___050696_))))));
    vlSelf->wasmetal_core__DOT___049522_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (1U 
                                                         & (0x35U 
                                                            >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049513_))));
    vlSelf->wasmetal_core__DOT___049805_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049513_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049520_))));
    vlSelf->wasmetal_core__DOT___050701_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049713_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049712_))));
    vlSelf->wasmetal_core__DOT___049716_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049713_))));
    vlSelf->wasmetal_core__DOT___049209_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049173_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))));
    vlSelf->wasmetal_core__DOT___049757_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049173_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049207_))));
    vlSelf->wasmetal_core__DOT___049893_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049629_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049632_))));
    vlSelf->wasmetal_core__DOT___049634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049629_))));
    vlSelf->wasmetal_core__DOT___049685_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049684_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049683_))));
    vlSelf->wasmetal_core__DOT___050716_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049601_))));
    vlSelf->wasmetal_core__DOT___049780_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049467_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049474_))));
    vlSelf->wasmetal_core__DOT___049476_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049464_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049467_))));
    vlSelf->wasmetal_core__DOT___049873_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049661_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049663_))));
    vlSelf->wasmetal_core__DOT___049665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049545_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049661_))));
    vlSelf->wasmetal_core__DOT___049736_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049310_))));
    vlSelf->wasmetal_core__DOT___049326_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049324_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028117_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___028084_)
                  : (vlSelf->insn_x >> 4U)));
    vlSelf->wasmetal_core__DOT____Vcellout___127851___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026483_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026482_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026481_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026480_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026447_)))));
    vlSelf->wasmetal_core__DOT___026451_ = ((IData)(vlSelf->wasmetal_core__DOT___026483_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127851___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b7__05d));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___029130_));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031049_)
            ? (IData)(vlSelf->wasmetal_core__DOT___031016_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b16__05d));
    vlSelf->wasmetal_core__DOT___057169_ = (1U & (0xf0eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010948_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0)))));
    vlSelf->wasmetal_core__DOT___011596_ = (1U & (IData)(
                                                         (0xaa00ffccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013096_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1d16dec4__0)))))));
    vlSelf->wasmetal_core__DOT___011361_ = (1U & (IData)(
                                                         (0x5500ff33330f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056595_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h1d16dec4__0)))))));
    vlSelf->wasmetal_core__DOT___057255_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011184_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011183_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___012548_)))))));
    vlSelf->wasmetal_core__DOT___013169_ = (1U & (0x55fc0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056921_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057009_)))))));
    vlSelf->wasmetal_core__DOT___072009_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9d4acb63__0))));
    vlSelf->__VdfgTmp_h77847496__0 = (((IData)(vlSelf->wasmetal_core__DOT___011595_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xaaaaccccf0f0ff00ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011593_)));
    vlSelf->__VdfgTmp_ha438982a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011441_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x555533330f0f00ffULL 
                                                            >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0)))));
    vlSelf->wasmetal_core__DOT___012959_ = (1U & (IData)(
                                                         (0xaf0fbbffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___056914_ = (1U & (IData)(
                                                         (0xff00aaaaccccf0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013139_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056910_)))))))));
    vlSelf->__VdfgTmp_h758d714e__0 = ((2U & ((IData)(
                                                     (0xaaaaccccf0f0ff00ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___013100_));
    vlSelf->wasmetal_core__DOT___056210_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056179_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056178_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056177_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb211d2c2__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010298_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b9__05d)))))))));
    vlSelf->__VdfgTmp_h5ae30e42__0 = ((2U & ((0x17U 
                                              >> (IData)(vlSelf->__VdfgTmp_h5164472e__0)) 
                                             << 1U)) 
                                      | (1U & (0x17U 
                                               >> (IData)(vlSelf->__VdfgTmp_hb1f92188__0))));
    vlSelf->__VdfgTmp_hf6f4b63c__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h5164472e__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h766276ef__0)))));
    vlSelf->wasmetal_core__DOT___055287_ = (1U & (IData)(
                                                         (0xff00fff4ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b41__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053772_)))))))));
    vlSelf->__VdfgTmp_hd485d8e6__0 = (((IData)(vlSelf->wasmetal_core__DOT___057011_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057010_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057009_)));
    vlSelf->wasmetal_core__DOT___057547_ = (1U & (IData)(
                                                         (0xffaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057024_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057010_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057011_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___033411_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT___010396_) {
        if (vlSelf->wasmetal_core__DOT___010395_) {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011961_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011960_))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010402_));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011192_));
        } else {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011962_)));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_he0f8989d__0)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
        }
        vlSelf->wasmetal_core__DOT___011252_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011186_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011185_)))));
        vlSelf->wasmetal_core__DOT___012597_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011185_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010395_) {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> ((4U & ((IData)((0xfff00000eeeeULL 
                                              >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                     << 2U)) | (IData)(vlSelf->__VdfgTmp_h9edc9904__0))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010394_)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
        } else {
            vlSelf->wasmetal_core__DOT___056787_ = 
                (1U & (1U >> (1U & (IData)((0xfff00000eeeeULL 
                                            >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))))));
            vlSelf->wasmetal_core__DOT___010897_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010393_)));
            vlSelf->wasmetal_core__DOT___011174_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011185_)));
        }
        vlSelf->wasmetal_core__DOT___011252_ = (1U 
                                                & (0x10fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0xfff00000eeeeULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                           << 2U)) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)))));
        vlSelf->wasmetal_core__DOT___012597_ = (1U 
                                                & (0x31U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((IData)(
                                                                   (0xfff00000eeee0000ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_ha429fd09__0))) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___011205_)))));
    }
    vlSelf->wasmetal_core__DOT___013200_ = (1U & (0xa03U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013104_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013047_))))));
    vlSelf->__VdfgTmp_h0bb40096__0 = (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                       << 1U) | (1U 
                                                 & (0xf0fccaaU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056424_) 
                                                            << 2U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h30784950__0)))))));
    vlSelf->wasmetal_core__DOT___057220_ = (1U & (IData)(
                                                         (0x3355f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x33550f0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057096_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___012420_)
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? (IData)(vlSelf->wasmetal_core__DOT___012422_)
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___010720_)))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010719_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010849_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010850_)))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011110_))))))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057094_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057095_)))))))));
    vlSelf->__VdfgTmp_h7c3586c1__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___012420_)
                                               : ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___012422_)
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012402_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011102_));
    vlSelf->wasmetal_core__DOT___012474_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012393_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011102_))));
    vlSelf->wasmetal_core__DOT___011136_ = (1U & (0xc000aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h62b744ad__0))))));
    vlSelf->wasmetal_core__DOT___056864_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056863_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012978_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012979_))))));
    vlSelf->wasmetal_core__DOT___057468_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056827_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056863_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056277_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->__VdfgTmp_hbde6c7ef__0 = (((IData)(vlSelf->wasmetal_core__DOT___056281_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012362_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056280_)));
    vlSelf->wasmetal_core__DOT___056645_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056640_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056639_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056638_))))));
    vlSelf->__VdfgTmp_h86a3b3a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___056640_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___056643_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___056642_)));
    vlSelf->wasmetal_core__DOT___057025_ = (1U & (0xf0f000eeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057024_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057023_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc88b842e__0))))));
    vlSelf->wasmetal_core__DOT___057548_ = (1U & (0xeef0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057050_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057023_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057049_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    if (vlSelf->wasmetal_core__DOT___010721_) {
        vlSelf->wasmetal_core__DOT___012392_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012400_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h9c39d480__0)))));
        vlSelf->wasmetal_core__DOT___011098_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010720_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0x555533330f0f00ffULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))));
        if (vlSelf->wasmetal_core__DOT___010722_) {
            vlSelf->wasmetal_core__DOT___056607_ = 
                (1U & (1U >> (1U & (0xffaaccf0U >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)))));
            vlSelf->wasmetal_core__DOT___011352_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011359_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011358_))));
        } else {
            vlSelf->wasmetal_core__DOT___056607_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h39b11875__0)));
            vlSelf->wasmetal_core__DOT___011352_ = 
                (1U & (1U >> ((2U & ((IData)((0xf0f0553300000000ULL 
                                              >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                     << 1U)) | (1U 
                                                & (IData)(
                                                          (0xf0f000005533ULL 
                                                           >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0)))))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___012392_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012402_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))));
        vlSelf->wasmetal_core__DOT___011098_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010719_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h23c0a543__0)))));
        vlSelf->wasmetal_core__DOT___056607_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011407_));
        vlSelf->wasmetal_core__DOT___011352_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011361_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011360_))));
    }
    vlSelf->wasmetal_core__DOT___056900_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012185_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056896_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056895_))))));
    vlSelf->__VdfgTmp_h74563738__0 = (((IData)(vlSelf->wasmetal_core__DOT___013100_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012185_));
    if (vlSelf->wasmetal_core__DOT___010395_) {
        if (vlSelf->wasmetal_core__DOT___010396_) {
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012362_)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012548_)));
        } else {
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011185_)));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h8262dffe__0)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011191_));
        }
        vlSelf->wasmetal_core__DOT___012426_ = (1U 
                                                & (0x11f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010393_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he0f8989d__0)))));
    } else {
        if (vlSelf->wasmetal_core__DOT___010396_) {
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___010402_));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___011192_));
        } else {
            vlSelf->wasmetal_core__DOT___012685_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2d927cdc__0)));
            vlSelf->wasmetal_core__DOT___012442_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___010394_)));
            vlSelf->wasmetal_core__DOT___012598_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___011186_)));
        }
        vlSelf->wasmetal_core__DOT___012426_ = (1U 
                                                & (0xcaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010394_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012377_)))));
    }
    vlSelf->wasmetal_core__DOT___012240_ = (1U & (IData)(
                                                         (0xf000ffccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056929_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056928_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___011666_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056552_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h98e4ab16__0)))))))))));
    vlSelf->wasmetal_core__DOT___013166_ = (1U & (0xf0f000ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056929_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056924_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056928_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010182_)))))));
    vlSelf->wasmetal_core__DOT___072159_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x17U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0))))));
    vlSelf->__VdfgTmp_ha1c57cb3__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                       << 2U) | ((2U 
                                                  & ((0x96U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (0x96U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0)))));
    vlSelf->wasmetal_core__DOT___057441_ = ((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                            & (IData)(
                                                      (0x55553333ff00ff0fULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1632b282__0))));
    vlSelf->wasmetal_core__DOT___012794_ = ((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                            & (IData)(
                                                      (0xaaaacccc00ff00f0ULL 
                                                       >> (IData)(vlSelf->__VdfgTmp_h1632b282__0))));
    vlSelf->__VdfgTmp_h4aad360c__0 = (((IData)(vlSelf->wasmetal_core__DOT___056728_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x1fU 
                                                            >> 
                                                            ((8U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                   ? 
                                                                  (0x53U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_ha12381c3__0))
                                                                   : 
                                                                  (0xcdU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h53b21008__0))) 
                                                                 << 3U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056718_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___056717_))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0x1111000fU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056723_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056722_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf19e2482__0))))))))));
    vlSelf->wasmetal_core__DOT___011940_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                   ? 
                                                  (0xacU 
                                                   >> (IData)(vlSelf->__VdfgTmp_ha12381c3__0))
                                                   : 
                                                  (0x32U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h53b21008__0))));
    vlSelf->wasmetal_core__DOT___066798_ = (1U & (IData)(
                                                         (0x45cf454545454545ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051051_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051418_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b21__05d) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (0xf7f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049005_) 
                                                                                << 5U) 
                                                                                | ((IData)(vlSelf->wasmetal_core__DOT___049048_) 
                                                                                << 4U))))))))))))))));
    vlSelf->wasmetal_core__DOT___050719_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050713_))));
    vlSelf->wasmetal_core__DOT___051729_ = (1U & (0xf0faaccU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049871_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0xcaU 
                                                              >> 
                                                              ((2U 
                                                                & ((0xf0faaccU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___049308_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf18161ea__0))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (IData)(
                                                                            (0xccccf0f0ff00aaaaULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___049318_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049294_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___049293_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049317_))))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (0xa3U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___049662_) 
                                                                 << 1U) 
                                                                | (1U 
                                                                   & (0xaacc0f0fU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___049258_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h32efca0f__0))))))))))));
    vlSelf->__VdfgTmp_hbb125bb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___012868_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012866_)));
    vlSelf->wasmetal_core__DOT___010083_ = (1U & (IData)(
                                                         (0xff00aaaaf0f0ccccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010394_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012377_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___010393_)))))))));
    vlSelf->wasmetal_core__DOT___011853_ = (1U & (0xa3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012793_)))));
    if (vlSelf->wasmetal_core__DOT___010722_) {
        if (vlSelf->wasmetal_core__DOT___010721_) {
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___011403_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011404_))));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___012178_) 
                                 << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012177_))));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h4284cb76__0)));
        } else {
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hc49b4927__0)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf1343531__0)));
        }
        vlSelf->wasmetal_core__DOT___012261_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012179_)));
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011595_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))))))));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h74563738__0))));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (0x10fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h52908d38__0)))));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011853_)));
    } else {
        if (vlSelf->wasmetal_core__DOT___010721_) {
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___011586_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011445_))));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012185_)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___012794_)));
        } else {
            vlSelf->wasmetal_core__DOT___011574_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___011586_)));
            vlSelf->wasmetal_core__DOT___013038_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___012184_)));
            vlSelf->wasmetal_core__DOT___012826_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011939_))));
        }
        vlSelf->wasmetal_core__DOT___012261_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___012180_));
        vlSelf->wasmetal_core__DOT___012642_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((IData)(
                                                                      (0xf0f0000aaccULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xf0faacc00000000ULL 
                                                                        >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))));
        vlSelf->wasmetal_core__DOT___057632_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 3U) 
                                                    | ((4U 
                                                        & ((IData)(
                                                                   (0xaaaaccccf0f0ff00ULL 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                           << 2U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013099_) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (0x5300U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0))))))));
        vlSelf->wasmetal_core__DOT___011954_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___011854_));
        vlSelf->wasmetal_core__DOT___011956_ = (1U 
                                                & (0xf0f033aaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011889_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                    << 2U) 
                                                                   | (IData)(vlSelf->__VdfgTmp_h23ac912c__0))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___011887_)))))));
    }
    vlSelf->wasmetal_core__DOT___072012_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072001_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x3030303000055ffULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___056595_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013095_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056593_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056594_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010530_)))))))))))));
    vlSelf->__VdfgTmp_h45f38dff__0 = (((IData)(vlSelf->wasmetal_core__DOT___011358_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011359_));
    vlSelf->wasmetal_core__DOT___056478_ = (1U & (IData)(
                                                         (0x5555f0f000ff00ccULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010950_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056475_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010948_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))))))))))));
    vlSelf->wasmetal_core__DOT___057168_ = (1U & (0xf0f05533U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056475_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h5e559da9__0))))));
    vlSelf->wasmetal_core__DOT___064004_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___010904_))));
    vlSelf->wasmetal_core__DOT___065289_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057399_)))));
    vlSelf->wasmetal_core__DOT___057401_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057399_)))))));
    vlSelf->wasmetal_core__DOT___056706_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___056703_))));
    vlSelf->wasmetal_core__DOT___012941_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012867_))));
    vlSelf->wasmetal_core__DOT___056755_ = (1U & (0x40000000U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0)) 
                                                       << 4U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010376_)))))));
    vlSelf->wasmetal_core__DOT___012879_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (0xfff00000eeee0000ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0))))));
    vlSelf->__VdfgTmp_h3816fa33__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (1U 
                                                 & (4U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h3b3aaa80__0))));
    vlSelf->wasmetal_core__DOT___057014_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056970_)))));
    vlSelf->wasmetal_core__DOT___056972_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056970_)))))))));
    vlSelf->wasmetal_core__DOT___057617_ = (1U & (IData)(
                                                         (0xf100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056970_)))))))));
    vlSelf->wasmetal_core__DOT___056948_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0))))));
    vlSelf->wasmetal_core__DOT___012241_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0)))));
    vlSelf->__VdfgTmp_h3478584b__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057551_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0b76dd71__0)));
    vlSelf->wasmetal_core__DOT___053633_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051321_))));
    vlSelf->wasmetal_core__DOT___050657_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049387_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h444aee6e__0)))))));
    vlSelf->wasmetal_core__DOT___049808_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049802_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049801_)))));
    vlSelf->wasmetal_core__DOT___051369_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050861_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051368_)))));
    vlSelf->wasmetal_core__DOT___051117_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051116_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051115_)))));
    vlSelf->wasmetal_core__DOT___051616_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051615_)))));
    vlSelf->wasmetal_core__DOT___051330_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051329_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051328_)))));
    vlSelf->wasmetal_core__DOT___051552_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050870_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051551_)))));
    vlSelf->wasmetal_core__DOT___050704_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050698_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___050697_)))));
    vlSelf->wasmetal_core__DOT___051062_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___051059_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051058_)))));
    vlSelf->wasmetal_core__DOT___051349_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050801_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051348_)))));
    vlSelf->__VdfgTmp_h6780f3af__0 = (((IData)(vlSelf->wasmetal_core__DOT___050820_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051522_));
    vlSelf->wasmetal_core__DOT___049895_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___049890_)))));
    vlSelf->wasmetal_core__DOT___051291_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050997_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051290_)))));
    vlSelf->wasmetal_core__DOT___051633_ = (1U & (0xacU 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___049627_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051632_)))));
    vlSelf->wasmetal_core__DOT___011798_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010790_)))));
    vlSelf->__VdfgTmp_h033744d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011564_));
    vlSelf->wasmetal_core__DOT___012218_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056450_)))))))));
    vlSelf->wasmetal_core__DOT___011047_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056449_)))))))));
    vlSelf->wasmetal_core__DOT___011300_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056451_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056455_)))))))));
    vlSelf->wasmetal_core__DOT___011786_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056450_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056454_)))))))));
    vlSelf->wasmetal_core__DOT___012220_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056449_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056453_)))))))));
    vlSelf->wasmetal_core__DOT___011046_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056452_)))))))));
    vlSelf->wasmetal_core__DOT___011299_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056454_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056459_)))))))));
    vlSelf->wasmetal_core__DOT___011785_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056453_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056458_)))))))));
    vlSelf->wasmetal_core__DOT___012219_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056452_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056457_)))))))));
    vlSelf->wasmetal_core__DOT___011045_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056459_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056456_)))))))));
    vlSelf->wasmetal_core__DOT___011302_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056458_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056460_)))))))));
    vlSelf->wasmetal_core__DOT___011793_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056457_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011306_)))))))));
    vlSelf->wasmetal_core__DOT___011044_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011306_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011305_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011304_)))))))));
    vlSelf->wasmetal_core__DOT___012073_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056456_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056460_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011306_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___011305_)))))))));
    vlSelf->wasmetal_core__DOT___010791_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010173_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010789_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010805_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010788_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010810_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b35__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010818_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010152_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010817_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010142_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b37__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010816_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010831_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b38__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010815_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010836_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b39__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010667_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010672_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010666_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010103_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b41__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010665_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010091_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b42__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010664_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010123_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011478_)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010692_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010113_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b44__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010691_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010132_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b45__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010690_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010705_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b46__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010689_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010710_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b47__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010422_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010429_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010421_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010434_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b49__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010420_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010439_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b50__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010419_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010444_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010452_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010457_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b52__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010451_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010462_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b53__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010450_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010467_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b54__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010449_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010472_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b55__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010480_ = (1U & ((~ 
                                                   (8U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___010092_)))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010479_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010490_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010478_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010495_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010477_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010500_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010507_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010513_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010506_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010518_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010505_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010523_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b62__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___010508_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010414_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b63__05d)
                                                      ? 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___010092_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___010417_))));
    vlSelf->wasmetal_core__DOT___056625_ = (1U & (IData)(
                                                         (0xff00f1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056624_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012632_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012631_)))))))));
    vlSelf->wasmetal_core__DOT___012456_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___011914_))));
    vlSelf->wasmetal_core__DOT___056744_ = ((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                            & (IData)(
                                                      (0xff55fffcULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011915_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___011912_)))))))));
    vlSelf->__VdfgTmp_h52f234fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___012630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012629_));
    vlSelf->wasmetal_core__DOT___011085_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011913_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056444_)))))))));
    vlSelf->__VdfgTmp_h796615cc__0 = (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012627_));
    vlSelf->__VdfgTmp_h519cda3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___011034_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011035_));
    vlSelf->__VdfgTmp_hfe0435c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___011035_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011034_));
    vlSelf->wasmetal_core__DOT___011787_ = (1U & (IData)(
                                                         (0xff00f0ccccaaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011033_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011032_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011564_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056451_)))))))));
    vlSelf->__VdfgTmp_h8f2fdb1c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011033_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___011032_)));
    vlSelf->__VdfgTmp_hc511e40f__0 = (((IData)(vlSelf->wasmetal_core__DOT___011566_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011565_));
    vlSelf->wasmetal_core__DOT____Vcellinp___134222___A 
        = ((0x10000U & ((0xffe0ffffU >> (((IData)(vlSelf->wasmetal_core__DOT___055203_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                            << 2U) 
                                           | ((2U & 
                                               ((IData)(
                                                        (0xff00ff00ff00e0ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055200_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055199_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d)))))))) 
                                                << 1U)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___055112_)))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffff010ffffffffULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___055198_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((0xbbbU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___055196_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b15__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009651_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009652_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009649_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009650_)))))))))))) 
                                                                            << 1U)) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffffffffff444ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055188_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b14__05d) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0xdU)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffff010ffffffffULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055179_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xbbb00000bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055177_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b13__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010253_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010252_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd7e7c41d__0))))))))))))) 
                                                                          << 1U)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffff010ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___055157_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xbbb00000bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055155_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b12__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x1111000fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010272_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010271_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8e4b209e__0))))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffffffffff444ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___055149_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b11__05d) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & (vlSelf->insn_x 
                                                                                >> 0xaU)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffffffffff444ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055134_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b10__05d) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 9U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffffffffff444ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___055126_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b9__05d) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 8U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffff010ffffffffULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055113_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055106_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055105_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055104_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009643_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((1U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x33330f0f00ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054723_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054720_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hffdded68__0))))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009642_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054686_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054696_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054721_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054714_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054713_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xc0aU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054676_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054685_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hfd347d5f__0))))))))))))))))))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b8__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffffffffff444ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___055063_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b7__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 6U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffffffffff888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055016_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055015_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027490_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((0xbU 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027489_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 4U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xf0fcc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054973_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054972_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___033411_))))))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((0xbU 
                                                                            >> 
                                                                            ((2U 
                                                                              & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027488_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b4__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 3U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xf0fccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054931_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054930_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054929_))))))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054892_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054891_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027487_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b3__05d)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffffffffff888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054846_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054845_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027486_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b2__05d)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((0xbU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027485_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b1__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & vlSelf->insn_x) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0fcc5500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054799_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054798_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010338_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (0xbU 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0xbbb0bbb0bbbULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___027478_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b0__05d) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0ccaa00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054748_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054747_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011042_))))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056832_ = (1U & (0xfef0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___056829_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___056828_)))))));
    vlSelf->__VdfgTmp_h2ec4fb80__0 = (((IData)(vlSelf->wasmetal_core__DOT___056828_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056829_));
    vlSelf->wasmetal_core__DOT___012596_ = (1U & (IData)(
                                                         (0xff0f11111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056644_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056641_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hca116eb2__0))))))));
    vlSelf->__VdfgTmp_hc8ed07a2__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_hca116eb2__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___012548_));
    vlSelf->wasmetal_core__DOT___072148_ = (1U & (0xaf8e8e0aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072146_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___072145_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((0x17U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___072143_)))))));
    vlSelf->wasmetal_core__DOT___039092_ = (1U & (IData)(
                                                         (0xffffffffff000e00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0xf4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___053771_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055277_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053772_))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055201_)))))))));
    vlSelf->wasmetal_core__DOT___056372_ = (1U & (IData)(
                                                         (0xcc00aaf0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011135_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h62b744ad__0))))))));
    vlSelf->wasmetal_core__DOT___012931_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011920_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011919_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h52908d38__0))))));
    vlSelf->wasmetal_core__DOT___072203_ = (1U & (0x17717117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x96U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d)))))));
    vlSelf->__VdfgTmp_h24dd6e03__0 = ((2U & ((0x96U 
                                              >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)) 
                                             << 1U)) 
                                      | (1U & (0x96U 
                                               >> (IData)(vlSelf->__VdfgTmp_h74dc1f9c__0))));
    vlSelf->wasmetal_core__DOT___011855_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1d24e3fc__0)))));
    vlSelf->__VdfgTmp_hc3a80e12__0 = (((IData)(vlSelf->wasmetal_core__DOT___013145_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013144_));
    vlSelf->wasmetal_core__DOT___012023_ = (1U & (0x11f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0x11fff0fff0ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                     << 5U) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfff00000eeeeULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h6f308c91__0))) 
                                                                           << 4U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011770_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9edc9904__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056803_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xfff00000eeee0000ULL 
                                                                       >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0)))))))));
    vlSelf->__VdfgTmp_h18f44539__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012878_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(
                                                              (0xeeee0000fff00000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))))));
    vlSelf->__VdfgTmp_h5c1422ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | ((2U 
                                                  & ((IData)(
                                                             (0xeeee0000fff00000ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012878_)));
    vlSelf->wasmetal_core__DOT___012969_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010085_)
                                                   ? 
                                                  (0xfefU 
                                                   >> 
                                                   ((0x10U 
                                                     & ((IData)(
                                                                (0xeeee0000fff0ULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h703b59c3__0))) 
                                                        << 4U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012868_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___012866_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010395_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___012867_))));
    vlSelf->wasmetal_core__DOT___057114_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012506_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012425_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___010896_ = (1U & (0xccaaf0f0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056293_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___012377_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (1U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_hc77b1aaa__0)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134225___A 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055279_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___134183___DOT____VdfgTmp_h9d2c3928__0) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055278_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b32__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffffffffff444ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___055273_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                               << 2U) 
                                                              | ((2U 
                                                                  & (vlSelf->insn_x 
                                                                     >> 0x1eU)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffffffffff444ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___055270_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b30__05d) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & (vlSelf->insn_x 
                                                                          >> 0x1dU)) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffff010ffffffffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___055268_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xbbbU 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b29__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x11f0U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010164_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009814_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009815_))))))))))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffff010ffffffffULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___055265_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf222e899__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b28__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffff010ffffffffULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___055262_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 2U) 
                                                                            | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff1fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009796_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009795_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009794_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b27__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffff010ffffffffULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___055259_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                               | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xff00e000ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009793_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h910334c5__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b26__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffff010ffffffffULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___055256_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0xee000f00ff00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h15c467ca__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b25__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((0xffe0ffffU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___055253_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (0xff00ff00ff00e0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055251_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053773_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055109_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055199_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d)))))))) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___055112_)))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffff010ffffffffULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___055250_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054855_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054853_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054854_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b23__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055247_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h034bd5a0__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b22__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055244_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054852_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054850_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054851_)))))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b21__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055241_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x13U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055221_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b19__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x12U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffffffffff444ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055219_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b18__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054752_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (vlSelf->insn_x 
                                                                                >> 0x11U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054745_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffff010ffffffffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055217_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x70U 
                                                                                >> 
                                                                                ((4U 
                                                                                & ((IData)(
                                                                                (0x11fff0ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___055201_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053774_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd610ba85__0)))))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b17__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___055109_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053773_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___050097_ = (1U & (IData)(
                                                         (0xb0bb0000b0bbb0bbULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127557___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006226_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127552___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005816_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76242b02__0))))))));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006058_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023497_));
    vlSelf->wasmetal_core__DOT___013783_ = (1U & (IData)(
                                                         (0xff00fff400000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048900_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048899_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b229ae__0))))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013737_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023618_));
    vlSelf->wasmetal_core__DOT___053836_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051834_))));
    vlSelf->wasmetal_core__DOT___053832_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051817_))));
    vlSelf->wasmetal_core__DOT___053848_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051866_))));
    vlSelf->wasmetal_core__DOT___053822_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051795_))));
    vlSelf->wasmetal_core__DOT___053840_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051849_))));
    vlSelf->wasmetal_core__DOT___053800_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051742_))));
    wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028638_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___003484_));
    vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029081_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001443_));
    wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028950_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b10__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___128436___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128436___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032287_)))));
    vlSelf->wasmetal_core__DOT___032260_ = ((IData)(vlSelf->wasmetal_core__DOT___001425_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___001425_)
                                             : (IData)(vlSelf->wasmetal_core__DOT___128436___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028772_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026726_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___070682_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070687_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027196_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b9__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127867___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026591_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026590_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026589_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026588_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026529_)))));
    vlSelf->wasmetal_core__DOT___026559_ = ((IData)(vlSelf->wasmetal_core__DOT___026591_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127867___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001488_));
    vlSelf->wasmetal_core__DOT___070785_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070790_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026996_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h5011624a__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->wasmetal_core__DOT____Vcellout___128664___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128436___S) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034569_)))));
    vlSelf->wasmetal_core__DOT___034510_ = ((~ (IData)(vlSelf->wasmetal_core__DOT___001425_)) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128664___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030120_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030276_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b5__05d));
    wasmetal_core__DOT____Vcellout___128059___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___028314_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___028313_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___028312_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028311_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___028278_)))));
    vlSelf->wasmetal_core__DOT___028282_ = ((IData)(vlSelf->wasmetal_core__DOT___028314_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128059___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___028249_));
    wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027471_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b2__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127952___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027394_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027393_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027388_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027377_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027301_)))));
    vlSelf->wasmetal_core__DOT___027330_ = ((IData)(vlSelf->wasmetal_core__DOT___027394_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127952___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b7__05d));
    vlSelf->wasmetal_core__DOT___023234_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfaf781e7__0))));
    vlSelf->wasmetal_core__DOT___023233_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005921_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h38639508__0)))));
    vlSelf->wasmetal_core__DOT___023232_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc23424b0__0))));
    vlSelf->wasmetal_core__DOT___023231_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005875_)
                                                   ? (IData)(
                                                             (0xfffffd55fffffdfdULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))
                                                   : (IData)(
                                                             (0x15500000101ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2a096466__0)))));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006015_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_h9b9779ca__0 = (((IData)(vlSelf->wasmetal_core__DOT___013719_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013658_));
    vlSelf->__VdfgTmp_hfe0efeb9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013701_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013719_));
    vlSelf->wasmetal_core__DOT___014422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013719_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127462___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___013687_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___002473_)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___002473_) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___022737_ = ((IData)(vlSelf->wasmetal_core__DOT___013687_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127462___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___072025_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057658_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x550fff33U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                    << 3U) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xf0f0aaaaccccff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072001_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___072002_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9d4acb63__0))))))) 
                                                                          << 2U)) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h56d07f21__0)))))))))));
    vlSelf->__VdfgTmp_hcdbca8e0__0 = ((2U & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___011407_)
                                               : ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                   ? 
                                                  (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h39b11875__0))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___011445_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___011102_));
    vlSelf->wasmetal_core__DOT___012644_ = (1U & (IData)(
                                                         (0xf0f000ff1111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((0xffaaccf0U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8127a3d2__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011405_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h39b11875__0))))))));
    vlSelf->wasmetal_core__DOT___058846_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058842_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058841_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___006022_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___058856_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058854_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058853_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc26f8061__0))))))));
    vlSelf->wasmetal_core__DOT___058839_ = (1U & (IData)(
                                                         (0xf351ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058828_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006044_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02eunit_bit__05b0__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___058852_ = (1U & (IData)(
                                                         (0x5f13ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058848_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___058840_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058834_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058833_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058832_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___005788_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b37__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___005809_))))))))))));
    vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127618___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127602___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___050145_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127454___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003807_))));
    vlSelf->wasmetal_core__DOT___127455___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006204_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022671_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d 
        = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057949_))));
    vlSelf->wasmetal_core__DOT___058683_ = (1U & (9U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057949_))));
    vlSelf->wasmetal_core__DOT___057805_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013635_))));
    vlSelf->wasmetal_core__DOT___017909_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xeU 
                                                         >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))))));
    vlSelf->wasmetal_core__DOT___017872_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013692_))));
    vlSelf->wasmetal_core__DOT___057857_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013712_))));
    vlSelf->wasmetal_core__DOT___017885_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013690_))));
    vlSelf->wasmetal_core__DOT___017886_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013654_))));
    vlSelf->wasmetal_core__DOT___057874_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013648_))));
    vlSelf->wasmetal_core__DOT___014289_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013719_))));
    vlSelf->wasmetal_core__DOT___014300_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013701_))));
    vlSelf->wasmetal_core__DOT___014350_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013722_))));
    vlSelf->wasmetal_core__DOT___014338_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013694_))));
    vlSelf->wasmetal_core__DOT___017903_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013668_))));
    vlSelf->wasmetal_core__DOT___057883_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013670_))));
    vlSelf->wasmetal_core__DOT___057923_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013672_))));
    vlSelf->wasmetal_core__DOT___022713_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002635_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022700_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->wasmetal_core__DOT___022699_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn))));
    vlSelf->__VdfgTmp_h15b2e0c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___000134_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___000139_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000138_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000137_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___000136_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___000135_))))));
    vlSelf->wasmetal_core__DOT___000140_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000139_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000138_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000137_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000136_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000135_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___000134_)))))))));
    vlSelf->__VdfgTmp_h0db23397__0 = (((IData)(vlSelf->wasmetal_core__DOT___013705_) 
                                       << 1U) | (1U 
                                                 & (0xeU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h1e702231__0))));
    vlSelf->__VdfgTmp_h3f696fc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___013692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013705_));
    vlSelf->wasmetal_core__DOT___017871_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___057987_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___013705_))));
    vlSelf->wasmetal_core__DOT___057189_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012440_)))));
    vlSelf->__VdfgTmp_heaf10b4b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012441_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012440_));
    vlSelf->wasmetal_core__DOT___010082_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056293_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056292_)))));
    vlSelf->__VdfgTmp_h2c387a2e__0 = ((4U & ((0x10000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & ((0x53U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h95d3d0ab__0)) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___056292_)));
    vlSelf->wasmetal_core__DOT___065207_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057306_))));
    vlSelf->wasmetal_core__DOT___059111_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059107_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059106_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b17__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h83434591__0))))))));
    vlSelf->wasmetal_core__DOT___059158_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059154_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059153_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059152_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005716_))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___006144_))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___006015_))))))))))));
    vlSelf->wasmetal_core__DOT___059157_ = (1U & (IData)(
                                                         (0x8acfULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059148_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059147_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b27__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006171_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___005928_)))))))));
    vlSelf->wasmetal_core__DOT___059135_ = (1U & (IData)(
                                                         (0xd00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___059117_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___059116_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___059115_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b10__05d) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___005982_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b2__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127487___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02eintegral_round__02ehalf_bit__05b1__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127479___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001537_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128649___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028874_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128113___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT____Vcellout___128078___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028463_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028462_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028492_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028491_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028458_)))));
    vlSelf->wasmetal_core__DOT___028430_ = ((IData)(vlSelf->wasmetal_core__DOT___028463_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128078___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003558_));
    vlSelf->wasmetal_core__DOT___055415_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___049768_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051920_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051907_))))))));
    vlSelf->wasmetal_core__DOT___053114_ = (1U & (IData)(
                                                         (0x5555ccccff00f0f0ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053108_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xaaccf0f0U 
                                                                      >> 
                                                                      ((4U 
                                                                        & ((8U 
                                                                            >> 
                                                                            (1U 
                                                                             & (8U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049152_)))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hebb238d0__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (0xcaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hef58fdbd__0)))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((IData)(
                                                                                (0x5555ccccf0f0ff00ULL 
                                                                                >> 
                                                                                ((8U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2121b61a__0)) 
                                                                                << 3U)) 
                                                                                | ((4U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcb165b79__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h10a4b2d7__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049204_)))))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049113_))))))));
    vlSelf->wasmetal_core__DOT___049754_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049752_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049751_))));
    vlSelf->wasmetal_core__DOT___051593_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051591_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051403_))));
    vlSelf->wasmetal_core__DOT___049733_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049732_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049731_))));
    vlSelf->wasmetal_core__DOT___049861_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049859_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049372_))));
    vlSelf->wasmetal_core__DOT___049710_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049708_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049707_))));
    vlSelf->wasmetal_core__DOT___049847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049045_))));
    vlSelf->wasmetal_core__DOT___049691_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049602_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049690_))));
    vlSelf->wasmetal_core__DOT___053220_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053216_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053215_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051833_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))))));
    vlSelf->wasmetal_core__DOT___049628_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049626_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049625_))));
    vlSelf->wasmetal_core__DOT___052629_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h3784db21__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049001_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___052624_))))))));
    vlSelf->wasmetal_core__DOT___049667_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049660_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049659_))));
    vlSelf->wasmetal_core__DOT___049509_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049496_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049495_))));
    vlSelf->wasmetal_core__DOT___052000_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((0x5cU 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2966b870__0)) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050610_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051995_))))))));
    vlSelf->wasmetal_core__DOT___049478_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049463_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049462_))));
    vlSelf->wasmetal_core__DOT___049149_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049114_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049113_))));
    vlSelf->wasmetal_core__DOT___066105_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___051401_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051412_))))))));
    vlSelf->wasmetal_core__DOT___051419_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051417_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051416_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051415_)))))));
    vlSelf->wasmetal_core__DOT___049290_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049287_))));
    vlSelf->wasmetal_core__DOT___050871_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050700_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050696_))));
    vlSelf->wasmetal_core__DOT___053374_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((4U 
                                                                      >> 
                                                                      (2U 
                                                                       & ((1U 
                                                                           >> (IData)(vlSelf->wasmetal_core__DOT___049043_)) 
                                                                          << 1U))) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051474_))))))));
    vlSelf->wasmetal_core__DOT___065164_ = (1U & (IData)(
                                                         (0xf0f00005533ULL 
                                                          >> 
                                                          ((0x10U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051486_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051485_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___051484_)))))));
    vlSelf->wasmetal_core__DOT___050876_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050712_))));
    vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036899_)
            ? (IData)(vlSelf->wasmetal_core__DOT___134172___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___036636_));
    vlSelf->wasmetal_core__DOT___050821_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049892_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049889_))));
    vlSelf->wasmetal_core__DOT___053219_ = (1U & (IData)(
                                                         (0xf0f0553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->wasmetal_core__DOT___050528_)) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050530_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050529_))))))));
    vlSelf->wasmetal_core__DOT___050834_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049872_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049870_))));
    vlSelf->wasmetal_core__DOT___065828_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050869_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050731_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050678_))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xcaU 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___050792_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7f4141b2__0)))))))))))));
    vlSelf->wasmetal_core__DOT___050862_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049804_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049800_))));
    vlSelf->wasmetal_core__DOT___051012_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050639_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___050634_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___050633_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___050632_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___050637_))))))));
    vlSelf->wasmetal_core__DOT___050814_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049779_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049776_))));
    vlSelf->wasmetal_core__DOT___051927_ = (1U & (IData)(
                                                         (0xf0f0aacc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051922_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0f0077U 
                                                                         >> 
                                                                         ((8U 
                                                                           & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049574_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050476_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050475_))))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                              << 2U) 
                                                                             | ((IData)(vlSelf->wasmetal_core__DOT___051425_) 
                                                                                << 1U)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051920_))))))));
    vlSelf->wasmetal_core__DOT___065729_ = (1U & (IData)(
                                                         (0xf0f55cc00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050857_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0x55330f0fU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051594_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___051424_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___051429_)))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___051461_))))))));
    vlSelf->wasmetal_core__DOT___050802_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049756_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049752_))));
    vlSelf->wasmetal_core__DOT___050807_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049735_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049732_))));
    vlSelf->wasmetal_core__DOT___053121_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((1U 
                                                                >> 
                                                                (3U 
                                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                    >> 2U))) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053119_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xacU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___053117_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___049859_))) 
                                                                        << 1U)) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___049387_))))))));
    vlSelf->wasmetal_core__DOT___050635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049715_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049708_))));
    vlSelf->wasmetal_core__DOT___049686_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049603_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049602_))));
    vlSelf->wasmetal_core__DOT___065049_ = (1U & (IData)(
                                                         (0xbbbb0000ff0f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___009501_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009510_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050554_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3fff2a003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050501_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                                                >> 2U))) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050500_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___049595_))))))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x3fff20003fff3fffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_accum__05b3__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050550_) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___009506_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___049545_))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050548_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xf0f553300000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___049006_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050532_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050516_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050515_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050514_)))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050530_))))))))))))))));
    vlSelf->wasmetal_core__DOT___050979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049626_))));
    vlSelf->wasmetal_core__DOT___050784_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049664_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049660_))));
    vlSelf->wasmetal_core__DOT___051865_ = (1U & (0x3aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xccaaf000U 
                                                         >> 
                                                         ((4U 
                                                           & ((0xcaU 
                                                               >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((0xacU 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha51ab883__0)) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xacU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc497fe80__0))))))))));
    vlSelf->wasmetal_core__DOT___050065_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049521_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049496_))));
    vlSelf->wasmetal_core__DOT___051101_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049475_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049463_))));
    vlSelf->wasmetal_core__DOT___051060_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049208_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049114_))));
    vlSelf->wasmetal_core__DOT___051045_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049288_))));
    vlSelf->wasmetal_core__DOT___052612_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052605_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052604_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052603_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hf35ae7d9__0))))));
    vlSelf->wasmetal_core__DOT___051766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049522_))))));
    vlSelf->wasmetal_core__DOT___049523_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049522_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049521_))));
    vlSelf->wasmetal_core__DOT___049806_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049804_))));
    vlSelf->wasmetal_core__DOT___050863_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> 
                                                            (1U 
                                                             & (0x35U 
                                                                >> (IData)(vlSelf->__VdfgTmp_habccd4be__0)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049805_))));
    vlSelf->wasmetal_core__DOT___050872_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049714_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050701_))));
    vlSelf->wasmetal_core__DOT___050702_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050701_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050700_))));
    vlSelf->wasmetal_core__DOT___051797_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049716_))))));
    vlSelf->wasmetal_core__DOT___049717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049715_))));
    vlSelf->wasmetal_core__DOT___051422_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049209_))))));
    vlSelf->wasmetal_core__DOT___049210_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049209_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049208_))));
    vlSelf->wasmetal_core__DOT___049759_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049756_))));
    vlSelf->wasmetal_core__DOT___050803_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049757_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049152_))))))))));
    vlSelf->wasmetal_core__DOT___050822_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049630_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049893_))));
    vlSelf->wasmetal_core__DOT___049894_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049893_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049892_))));
    vlSelf->wasmetal_core__DOT___051782_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128508___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049634_))))));
    vlSelf->wasmetal_core__DOT___049635_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049633_))));
    vlSelf->wasmetal_core__DOT___049692_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049685_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049603_))));
    vlSelf->wasmetal_core__DOT___050717_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050715_))));
    vlSelf->wasmetal_core__DOT___050877_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049684_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050716_))));
    vlSelf->wasmetal_core__DOT___049781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049779_))));
    vlSelf->wasmetal_core__DOT___050815_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___049464_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049780_))));
    vlSelf->wasmetal_core__DOT___051771_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049476_))))));
    vlSelf->wasmetal_core__DOT___049479_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049476_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049475_))));
    vlSelf->wasmetal_core__DOT___049874_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049873_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049872_))));
    vlSelf->wasmetal_core__DOT___050835_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___049545_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049873_))));
    vlSelf->wasmetal_core__DOT___049668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049665_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049664_))));
    vlSelf->wasmetal_core__DOT___049738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049735_))));
    vlSelf->wasmetal_core__DOT___050808_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049736_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (8U 
                                                             >> 
                                                             (1U 
                                                              & (8U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___049321_))))))))));
    vlSelf->wasmetal_core__DOT___051408_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___049326_))))));
    vlSelf->wasmetal_core__DOT___049327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___049326_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___049325_))));
    vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___028118_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___128043___DOT__CO__BRA__0__KET__)
                  : (vlSelf->insn_x >> 5U)));
    vlSelf->wasmetal_core__DOT___127852___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026484_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026451_)
            : (IData)(vlSelf->wasmetal_core__DOT__heap_next__05b8__05d));
    vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128478___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___128143___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___031050_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128326___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b17__05d));
    vlSelf->wasmetal_core__DOT___057560_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013169_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    if (vlSelf->wasmetal_core__DOT___011101_) {
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35U 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011748_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___011749_)))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (2U 
                                                   >> 
                                                   (1U 
                                                    & (0x35ffffffU 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h5fb0de62__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___012708_ = (1U 
                                                & (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___012714_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012721_))
                                                                    : 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012718_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012717_))))
                                                                   : 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (1U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___012720_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___012719_)))
                                                                    : 
                                                                   (2U 
                                                                    >> (IData)(vlSelf->wasmetal_core__DOT___012722_)))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00aaccccf0f0ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012761_) 
                                                                                << 3U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h77847496__0)))))))))))));
        vlSelf->wasmetal_core__DOT___011549_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                    ? 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          & (IData)(
                                                                    (0xaaaaccccf0f0ff00ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___011596_) 
                                                                             << 3U) 
                                                                            | (IData)(vlSelf->__VdfgTmp_h77847496__0))))))) 
                                                         << 1U) 
                                                        | (1U 
                                                           & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                               ? 
                                                              (0xee0fU 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011631_) 
                                                                    << 2U) 
                                                                   | ((2U 
                                                                       & ((IData)(
                                                                                (0xf0faacc00000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0))) 
                                                                          << 1U)) 
                                                                      | (1U 
                                                                         & (IData)(
                                                                                (0xf0f0000aaccULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))))))))
                                                               : 
                                                              (0x35U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011633_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___011632_)))))))))
                                                    : 
                                                   (0xcdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011576_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___011574_))))));
        vlSelf->wasmetal_core__DOT___057665_ = (1U 
                                                & (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((0xf0f0aaccU 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013103_) 
                                                                          << 2U) 
                                                                         | (IData)(vlSelf->__VdfgTmp_h74563738__0))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & (0xaaccf0f0U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___057630_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                              << 1U) 
                                                                             | (1U 
                                                                                & (IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))))))))))))))));
    }
    vlSelf->wasmetal_core__DOT___056903_ = (1U & (IData)(
                                                         (0xaaaaccccff00f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056894_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013139_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h758d714e__0))))))));
    vlSelf->__VdfgTmp_h10754ee4__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                             << 1U)) 
                                      | (1U & (0xb2U 
                                               >> (
                                                   (4U 
                                                    & ((0x17U 
                                                        >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                       << 2U)) 
                                                   | ((2U 
                                                       & ((6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x17U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0))))))));
    vlSelf->__VdfgTmp_h9816e297__0 = ((0x10U & ((0x17U 
                                                 >> (IData)(vlSelf->__VdfgTmp_he9aaeb48__0)) 
                                                << 4U)) 
                                      | ((8U & ((6U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h5ae30e42__0)) 
                                                << 3U)) 
                                         | ((4U & (
                                                   (0x17U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                   << 2U)) 
                                            | ((2U 
                                                & ((0x69U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he9efeda2__0)) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (0x17U 
                                                     >> (IData)(vlSelf->__VdfgTmp_h4e50e0f7__0)))))));
    vlSelf->wasmetal_core__DOT___072181_ = (1U & (0x6996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b24__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b22__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((0x96U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___072175_))))));
    vlSelf->wasmetal_core__DOT___072193_ = (1U & (0x17U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b34__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x96U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hf6f4b63c__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0x96U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h08c644ac__0)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134228___A 
        = ((0x10000U & ((IData)((0xfffffff8ffff8888ULL 
                                 >> (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                      << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                 << 4U) 
                                                | (((IData)(vlSelf->wasmetal_core__DOT___055296_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b50__05d) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                        << 0x10U)) | ((0x8000U & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055295_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b49__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xfU)) 
                                      | ((0x4000U & 
                                          ((IData)(
                                                   (0xfffffff8ffff8888ULL 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                      << 5U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                         << 4U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055294_) 
                                                            << 3U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b48__05d) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                           << 0xeU)) 
                                         | ((0x2000U 
                                             & ((IData)(
                                                        (0xfffffff8ffff8888ULL 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                           << 5U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055293_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b47__05d) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                << 0xdU)) 
                                            | ((0x1000U 
                                                & ((IData)(
                                                           (0xfffffff8ffff8888ULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055292_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b46__05d) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                   << 0xcU)) 
                                               | ((0x800U 
                                                   & ((IData)(
                                                              (0xfffffff8ffff8888ULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055291_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b45__05d) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                      << 0xbU)) 
                                                  | ((0x400U 
                                                      & ((IData)(
                                                                 (0xfffffff8ffff8888ULL 
                                                                  >> 
                                                                  (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                    << 5U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                       << 4U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055290_) 
                                                                          << 3U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                             << 2U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b44__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                         << 0xaU)) 
                                                     | ((0x200U 
                                                         & ((IData)(
                                                                    (0xfffffff8ffff8888ULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055289_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                            << 9U)) 
                                                        | ((0x100U 
                                                            & ((IData)(
                                                                       (0xfffffff8ffff8888ULL 
                                                                        >> 
                                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                          << 5U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055288_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b42__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                               << 8U)) 
                                                           | ((0x80U 
                                                               & ((IData)(
                                                                          (0xfffffff8ffff8888ULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055287_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b41__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                  << 7U)) 
                                                              | ((0x40U 
                                                                  & ((IData)(
                                                                             (0xfffffff8ffff8888ULL 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b40__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                     << 6U)) 
                                                                 | ((0x20U 
                                                                     & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055285_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b39__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                        << 5U)) 
                                                                    | ((0x10U 
                                                                        & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055284_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b38__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                           << 4U)) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055283_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b37__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                              << 3U)) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055282_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b36__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 2U)) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055281_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055280_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___057012_ = (1U & (0xfc550000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->wasmetal_core__DOT___057026_ = (1U & (0xfc0055U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hd485d8e6__0)))));
    vlSelf->__VdfgTmp_h3af565ab__0 = (((IData)(vlSelf->wasmetal_core__DOT___057547_) 
                                       << 1U) | (1U 
                                                 & (0xf011U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___057009_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056922_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056921_)))))));
    vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___033416_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128548___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___057538_ = (1U & (IData)(
                                                         (0xaf0fbbffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013200_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057536_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___056461_ = (1U & (IData)(
                                                         (0xf0fff4400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056443_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                          ? 
                                                                         (0x32U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010950_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010948_))))
                                                                          : 
                                                                         (0xeef0U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010949_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___057172_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012413_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7c3586c1__0))))));
    vlSelf->wasmetal_core__DOT___057100_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___056504_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xaf0fbbffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012474_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d))))))))))));
    vlSelf->wasmetal_core__DOT___011129_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056335_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056336_))))))) 
                                                  & (IData)(
                                                            (0xff33ff55ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011136_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011135_) 
                                                                           << 1U) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hf6de1ad3__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h23c0a543__0))))
                                                                                 : 
                                                                                (0xcaU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011109_)))))))))))))));
    vlSelf->wasmetal_core__DOT___012053_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))));
    vlSelf->__VdfgTmp_hb67239de__0 = (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057468_));
    vlSelf->wasmetal_core__DOT___012599_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h86a3b3a9__0)))));
    vlSelf->__VdfgTmp_hdb922d45__0 = (((IData)(vlSelf->wasmetal_core__DOT___057025_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0x30303030000ffaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057050_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057049_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057048_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057047_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___010182_))))))))));
    vlSelf->__VdfgTmp_h3514b323__0 = (((IData)(vlSelf->wasmetal_core__DOT___057548_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057547_));
    vlSelf->__VdfgTmp_h224cdee6__0 = (((IData)(vlSelf->wasmetal_core__DOT___012393_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012392_));
    vlSelf->__VdfgTmp_he499e9e8__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                   << 2U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___056900_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___056899_)))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___056901_));
    vlSelf->wasmetal_core__DOT___013108_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057571_))))))) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? 
                                                     (0xf3f5U 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & (((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                   ? 
                                                                  (0xf11U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((0xac00U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h7e112ed5__0)) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0x55330000f0f0ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hefe0e1be__0))))))))))
                                                                   : 
                                                                  (0x32U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                         & (IData)(vlSelf->wasmetal_core__DOT___013139_)) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT___010531_)
                                                                              ? 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___012131_))
                                                                               : 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011868_)))
                                                                              : 
                                                                             ((IData)(vlSelf->wasmetal_core__DOT___010530_)
                                                                               ? 
                                                                              (1U 
                                                                               >> (IData)(vlSelf->wasmetal_core__DOT___011869_))
                                                                               : 
                                                                              (0xacU 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h6cc2c965__0))))))))) 
                                                                 << 1U)) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hb331ded8__0))
                                                                     : 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013144_)))
                                                                    : 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                     ? 
                                                                    (1U 
                                                                     >> (IData)(vlSelf->wasmetal_core__DOT___013145_))
                                                                     : 
                                                                    (0xeU 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hf037ddb3__0)))))))))
                                                      : 
                                                     (0xfcfdU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013041_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013038_))))))));
    vlSelf->wasmetal_core__DOT___011731_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011253_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011252_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057256_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012687_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012685_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->wasmetal_core__DOT___057343_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012597_))));
    vlSelf->__VdfgTmp_hca77b771__0 = (((IData)(vlSelf->wasmetal_core__DOT___056932_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012240_));
    vlSelf->__VdfgTmp_h638ad0d9__0 = (((IData)(vlSelf->wasmetal_core__DOT___013167_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013166_));
    vlSelf->__VdfgTmp_h839fe08c__0 = ((4U & ((0x177eU 
                                              >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                             << 2U)) 
                                      | ((2U & ((0xe81717e8U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___072145_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___072143_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___072147_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___072146_) 
                                                            << 1U) 
                                                           | (1U 
                                                              & (0x17U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)))))))) 
                                                << 1U)) 
                                         | (1U & (IData)(
                                                         (0x115577f577f0115ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x96U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hf95d62e9__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((0x96U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc33f85b3__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0x6996U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)))))))))))));
    vlSelf->wasmetal_core__DOT___072182_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b16__05d) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x96U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))))));
    vlSelf->wasmetal_core__DOT___072195_ = (1U & (0x7117U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b36__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___072179_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b26__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (0x96U 
                                                               >> (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0))))))));
    vlSelf->wasmetal_core__DOT___072196_ = (1U & (IData)(
                                                         (0xe81717e817e8e817ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___072160_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x6996U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h64d6559e__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___072159_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_ha1c57cb3__0)))))));
    vlSelf->wasmetal_core__DOT___057455_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057450_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___057449_))))))) 
                                                  & (IData)(
                                                            (0xffccffaaff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___012915_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((0xf0f000eeU 
                                                                               >> 
                                                                               (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012805_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057438_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010721_)))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (IData)(
                                                                                (0xccccf0f0ff00aaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012800_))))))))))))))))));
    if (vlSelf->wasmetal_core__DOT___011103_) {
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xf0accccU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012806_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00aaccccf0f0ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057441_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057440_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057438_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___012805_)))))));
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0xf030f05U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011098_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                    ? 
                                                                   (0xf011U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011110_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x5533f0f000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011870_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h51371d7f__0))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT___010092_)
                                                                                 ? 
                                                                                (0x305U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hadb47ff7__0))))
                                                                                 : 
                                                                                (0x503U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f935f8__0))))))))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011109_) 
                                                                         << 1U) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0)))))))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___057444_ = (1U 
                                                & (0xfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___012804_)))));
        vlSelf->wasmetal_core__DOT___011092_ = (1U 
                                                & (0x3331U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011100_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___011099_))))));
    }
    vlSelf->wasmetal_core__DOT___057386_ = (1U & (0xf100U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | ((((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                        & (IData)(
                                                                  (0xff00ff0f33335555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___012794_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011939_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h84e2ca83__0))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012793_))))))))) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                ? 
                                                               (0xfeeU 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012801_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h03a652de__0))))
                                                                : 
                                                               (0x35U 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___012799_)))))))))));
    vlSelf->wasmetal_core__DOT___053533_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128615___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050719_))));
    vlSelf->__VdfgTmp_hef87eb38__0 = (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___012425_));
    vlSelf->wasmetal_core__DOT___068285_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012442_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012441_))))));
    vlSelf->wasmetal_core__DOT___056780_ = (1U & (0x30aU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff33330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056774_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((0x1fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___011940_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf1343531__0)))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011853_)))))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___056775_))))));
    vlSelf->wasmetal_core__DOT___011427_ = (1U & ((~ 
                                                   (0xca000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056600_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___056599_))))))) 
                                                  & (IData)(
                                                            (0xff55ff33ff0fff0fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011437_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & (((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                ? 
                                                                               (0xf011U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011441_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h45f38dff__0))))
                                                                                : 
                                                                               (0xacU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0)))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                                                 ? 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h39b11875__0))
                                                                                 : 
                                                                                (1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2994a26e__0)))
                                                                                 : 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                                                 ? 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011445_))
                                                                                 : 
                                                                                (2U 
                                                                                >> (IData)(vlSelf->wasmetal_core__DOT___011444_))))))))))))));
    vlSelf->wasmetal_core__DOT___057320_ = ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ff55ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012616_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((0xcaU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011444_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___011441_)))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf011U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                           << 3U) 
                                                                          | ((4U 
                                                                              & ((IData)(
                                                                                (0x555533330f0f00ffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd9e6a33__0))) 
                                                                                << 2U)) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h45f38dff__0)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011361_) 
                                                                               << 2U) 
                                                                              | ((2U 
                                                                                & ((IData)(
                                                                                (0xf0f000005533ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h0e06d26a__0))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xf0f0553300000000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc9438d71__0)))))))))))))))));
    vlSelf->__VdfgTmp_hedaab00c__0 = (((IData)(vlSelf->wasmetal_core__DOT___011099_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011098_));
    vlSelf->wasmetal_core__DOT___056479_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056478_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x11f00000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                              << 3U) 
                                                                             | ((4U 
                                                                                & ((IData)(
                                                                                (0xaaaaccccf0f0ff00ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h43b12a4e__0))) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1d3dc22c__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0bb40096__0))))))));
    vlSelf->wasmetal_core__DOT___012459_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057168_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057169_)))));
    vlSelf->wasmetal_core__DOT___065290_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065289_))));
    vlSelf->wasmetal_core__DOT___066145_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___012941_))));
    vlSelf->wasmetal_core__DOT___012001_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3816fa33__0))));
    vlSelf->__VdfgTmp_he1977acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___056787_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3816fa33__0));
    vlSelf->wasmetal_core__DOT___057028_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012241_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___012240_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010396_)))));
    vlSelf->wasmetal_core__DOT___013184_ = (1U & (IData)(
                                                         (0xf0fe00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h3478584b__0))))));
    vlSelf->wasmetal_core__DOT___013168_ = (1U & (0xf0feU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3478584b__0))));
    vlSelf->wasmetal_core__DOT___012610_ = ((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                            & (IData)(
                                                      (0xfff0fff033335555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011566_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011565_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h033744d0__0))))))));
    vlSelf->__VdfgTmp_hdcc00e41__0 = (((IData)(vlSelf->wasmetal_core__DOT___011300_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011299_));
    vlSelf->__VdfgTmp_ha9c6ec44__0 = (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011785_));
    vlSelf->__VdfgTmp_h358fed79__0 = (((IData)(vlSelf->wasmetal_core__DOT___012220_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012219_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012218_)));
    vlSelf->wasmetal_core__DOT___057161_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011046_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011045_)))));
    vlSelf->__VdfgTmp_h417b846d__0 = (((IData)(vlSelf->wasmetal_core__DOT___011785_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011793_));
    vlSelf->__VdfgTmp_hde352602__0 = (((IData)(vlSelf->wasmetal_core__DOT___011045_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011044_));
    vlSelf->wasmetal_core__DOT___011301_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___010124_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011306_))
                                                    : 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011304_)))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___011305_))
                                                    : 
                                                   (0xeU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010791_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___010423_)))))));
    vlSelf->wasmetal_core__DOT___011799_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010791_)))));
    vlSelf->wasmetal_core__DOT___010794_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010790_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010788_))))));
    vlSelf->wasmetal_core__DOT___011315_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010789_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010818_))))));
    vlSelf->wasmetal_core__DOT___011804_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010788_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010817_))))));
    vlSelf->wasmetal_core__DOT___010822_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010818_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010816_))))));
    vlSelf->wasmetal_core__DOT___010821_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010817_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010815_))))));
    vlSelf->wasmetal_core__DOT___011790_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010816_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010815_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010666_))))))));
    vlSelf->wasmetal_core__DOT___010671_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010667_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010665_))))));
    vlSelf->wasmetal_core__DOT___010670_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010666_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010664_))))));
    vlSelf->wasmetal_core__DOT___011323_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010665_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010692_))))));
    vlSelf->wasmetal_core__DOT___011812_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010664_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010691_))))));
    vlSelf->wasmetal_core__DOT___010696_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010692_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010690_))))));
    vlSelf->wasmetal_core__DOT___010695_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010691_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010689_))))));
    vlSelf->wasmetal_core__DOT___012781_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010424_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___010182_)
                                                      ? 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010690_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010689_)))))
                                                      : 
                                                     (0xfcfaU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___010421_))))))));
    vlSelf->wasmetal_core__DOT___010428_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010422_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010420_))))));
    vlSelf->wasmetal_core__DOT___010427_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010421_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010419_))))));
    vlSelf->wasmetal_core__DOT___011339_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010420_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010452_))))));
    vlSelf->wasmetal_core__DOT___011820_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010419_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010451_))))));
    vlSelf->wasmetal_core__DOT___010456_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010452_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010450_))))));
    vlSelf->wasmetal_core__DOT___010455_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010451_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010449_))))));
    vlSelf->wasmetal_core__DOT___011343_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010450_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010480_))))));
    vlSelf->wasmetal_core__DOT___011824_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010449_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010479_))))));
    vlSelf->wasmetal_core__DOT___010484_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010480_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010478_))))));
    vlSelf->wasmetal_core__DOT___010483_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010479_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010477_))))));
    vlSelf->wasmetal_core__DOT___011347_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010478_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010507_))))));
    vlSelf->wasmetal_core__DOT___011828_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010477_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010506_))))));
    vlSelf->__VdfgTmp_hb5646ca1__0 = (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->__VdfgTmp_h025488dc__0 = (((IData)(vlSelf->wasmetal_core__DOT___010506_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010505_));
    vlSelf->wasmetal_core__DOT___010512_ = (1U & (0xfcfaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___010507_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___010505_))))));
    vlSelf->wasmetal_core__DOT___056716_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___010395_)) 
                                                  & (IData)(
                                                            (0xccccccccddcfcfcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___010505_))))))))));
    vlSelf->wasmetal_core__DOT___012559_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010508_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b31__05d)))));
    vlSelf->__VdfgTmp_hb8dc7649__0 = (((IData)(vlSelf->wasmetal_core__DOT___010424_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___010423_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___010508_)));
    vlSelf->wasmetal_core__DOT___057174_ = ((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                            & (IData)(
                                                      (0x3333555500ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012456_) 
                                                               << 3U) 
                                                              | ((4U 
                                                                  & ((1U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056445_))) 
                                                                     << 2U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h619b0a2b__0))))))));
    vlSelf->wasmetal_core__DOT___056962_ = (1U & (IData)(
                                                         (0xf5f300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056961_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h52f234fa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___012631_)))))))));
    vlSelf->wasmetal_core__DOT___011558_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012630_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012629_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h796615cc__0))))))));
    vlSelf->wasmetal_core__DOT___011788_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))))))));
    vlSelf->wasmetal_core__DOT___012809_ = ((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                            & (IData)(
                                                      (0x1111111100ff0f0fULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011787_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011786_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((0xf0110000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___011912_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011914_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011913_)))))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (IData)(
                                                                                (0xf00001111ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056444_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056445_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h519cda3a__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___057162_ = (1U & (IData)(
                                                         (0xfff1f100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((1U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h519cda3a__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0)))))));
    if (vlSelf->wasmetal_core__DOT___010182_) {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hfe0435c8__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))));
    } else {
        vlSelf->wasmetal_core__DOT___011084_ = (1U 
                                                & (0xf1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h8f2fdb1c__0))));
        vlSelf->wasmetal_core__DOT___011557_ = (1U 
                                                & (0x35U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010124_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h033744d0__0)))));
    }
    vlSelf->wasmetal_core__DOT___012221_ = (1U & (IData)(
                                                         (0xfff00000eeee0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010182_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012627_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012628_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc511e40f__0))))))));
    vlSelf->wasmetal_core__DOT___056835_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xdddd000f000fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(
                                                                                (0xfff00000eeee0000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                              << 3U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056803_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010396_)))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056703_)))));
    vlSelf->wasmetal_core__DOT___012002_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xfdfU 
                                                           >> 
                                                           ((0x10U 
                                                             & ((IData)(
                                                                        (0xfff00000eeeeULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                   << 2U) 
                                                                  | ((2U 
                                                                      & ((1U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)) 
                                                                         << 1U)) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___010395_)))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056787_)))));
    vlSelf->wasmetal_core__DOT___012052_ = (1U & (IData)(
                                                         (0xfff4ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(
                                                                             (0xfff00000eeeeULL 
                                                                              >> (IData)(vlSelf->__VdfgTmp_hcec95e31__0))) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056830_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))))))))));
    vlSelf->__VdfgTmp_hf2cfe231__0 = (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056825_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056826_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h2ec4fb80__0)))));
    vlSelf->__VdfgTmp_h7487032b__0 = (((IData)(vlSelf->wasmetal_core__DOT___012596_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010396_));
    vlSelf->wasmetal_core__DOT___011764_ = (1U & (0x3500U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT___056648_ = (1U & (0x305U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8ed07a2__0)))));
    vlSelf->wasmetal_core__DOT____Vcellinp___134220___A 
        = ((0x3fffe000U & ((- (IData)((IData)(vlSelf->wasmetal_core__DOT___039092_))) 
                           << 0xdU)) | ((0x1000U & 
                                         ((0xf8U >> 
                                           (((IData)(vlSelf->wasmetal_core__DOT___039092_) 
                                             << 2U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___054752_)))) 
                                          << 0xcU)) 
                                        | ((0x800U 
                                            & ((IData)(
                                                       (0xfffffff8ffff8888ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                          << 5U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                             << 4U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055308_) 
                                                                << 3U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                               << 0xbU)) 
                                           | ((0x400U 
                                               & ((IData)(
                                                          (0xfffffff8ffff8888ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055307_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                  << 0xaU)) 
                                              | ((0x200U 
                                                  & ((IData)(
                                                             (0xfffffff8ffff8888ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055306_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                     << 9U)) 
                                                 | ((0x100U 
                                                     & ((IData)(
                                                                (0xfffffff8ffff8888ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055305_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                        << 8U)) 
                                                    | ((0x80U 
                                                        & ((IData)(
                                                                   (0xfffffff8ffff8888ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055304_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                           << 7U)) 
                                                       | ((0x40U 
                                                           & ((IData)(
                                                                      (0xfffffff8ffff8888ULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055303_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                              << 6U)) 
                                                          | ((0x20U 
                                                              & ((IData)(
                                                                         (0xfffffff8ffff8888ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055302_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                 << 5U)) 
                                                             | ((0x10U 
                                                                 & ((IData)(
                                                                            (0xfffffff8ffff8888ULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055301_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                    << 4U)) 
                                                                | ((8U 
                                                                    & ((IData)(
                                                                               (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055300_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b54__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                       << 3U)) 
                                                                   | ((4U 
                                                                       & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055299_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b53__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                          << 2U)) 
                                                                      | ((2U 
                                                                          & ((IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055298_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b52__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_)))))))) 
                                                                             << 1U)) 
                                                                         | (1U 
                                                                            & (IData)(
                                                                                (0xfffffff8ffff8888ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___054749_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055062_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055297_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___055112_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b51__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054752_))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___056388_ = (1U & (IData)(
                                                         (0xff00fff8ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010376_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056374_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x40U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___056371_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_hedbbe05b__0))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056372_)))))))));
    vlSelf->wasmetal_core__DOT___056480_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056372_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___011103_)))));
    vlSelf->wasmetal_core__DOT___012928_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___011101_)) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___011103_)
                                                      ? (IData)(
                                                                (0xf0f0fcfcf0fff0faULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___012934_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___012933_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012804_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___012931_))))))))
                                                      : 
                                                     (2U 
                                                      >> (IData)(vlSelf->wasmetal_core__DOT___012933_)))));
    vlSelf->wasmetal_core__DOT___072180_ = (1U & (0x96696996U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b20__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b14__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b12__05d) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h24dd6e03__0))))));
    vlSelf->__VdfgTmp_he54a047f__0 = ((4U & ((0xca000000U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___056730_)))))) 
                                             << 2U)) 
                                      | ((2U & ((1U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                                   << 1U) 
                                                  | (1U 
                                                     & (IData)(
                                                               (0xfafcULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                                  << 5U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h4aad360c__0))))))) 
                                                << 1U)) 
                                         | ((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                            & (IData)(
                                                      (0xf0f3333ffaaff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___011855_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011854_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011853_) 
                                                                     << 1U) 
                                                                    | (1U 
                                                                       & (0xf011U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___012800_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___012797_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___012798_))))))))))))))));
    vlSelf->wasmetal_core__DOT___067171_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048330_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___012023_)))));
    vlSelf->__VdfgTmp_h4364218e__0 = (((IData)(vlSelf->wasmetal_core__DOT___012023_) 
                                       << 1U) | (1U 
                                                 & (IData)(
                                                           (0xccccaaaa00f000ffULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056832_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___056831_) 
                                                                       << 2U) 
                                                                      | ((2U 
                                                                          & ((0xf011U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___012983_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h336e35bc__0)))) 
                                                                             << 1U)) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___056864_))))))))));
    vlSelf->wasmetal_core__DOT___057504_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___012879_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5c1422ca__0))));
    vlSelf->wasmetal_core__DOT___057118_ = (1U & (IData)(
                                                         (0x1111f0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___010084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057114_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___012426_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xeeee0000fff00000ULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h31fa1bee__0))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (0xf00eeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___010395_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___010396_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___012362_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010391_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010392_)))))))))))))));
    vlSelf->__VdfgTmp_hd6fa80fa__0 = (((IData)(vlSelf->wasmetal_core__DOT___010897_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010896_));
    vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006044_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127558___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___013775_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___013783_)) 
                                                  & (IData)(
                                                            (0xb0bbb0bb0000b0bbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                                     << 2U)) 
                                                                 | ((8U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127569___O) 
                                                                              >> 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___013778_))))))))));
    vlSelf->wasmetal_core__DOT___057757_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013783_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127574___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013740_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127575___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128096___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028639_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028638_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028668_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028667_)))) 
           ^ (((IData)(wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128096___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028634_)))));
    vlSelf->wasmetal_core__DOT___028606_ = ((IData)(vlSelf->wasmetal_core__DOT___028639_)
                                             ? (IData)(wasmetal_core__DOT___128096___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___003558_));
    vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___029082_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128131___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001475_));
    vlSelf->wasmetal_core__DOT____Vcellout___128123___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___028951_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___028950_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___028980_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028979_)))) 
           ^ (((IData)(wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128123___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___028946_)))));
    vlSelf->wasmetal_core__DOT___028918_ = ((IData)(vlSelf->wasmetal_core__DOT___028951_)
                                             ? (IData)(wasmetal_core__DOT___128123___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fifth__05b11__05d));
    vlSelf->wasmetal_core__DOT___128437___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___001524_)
            ? (IData)(vlSelf->wasmetal_core__DOT___001524_)
            : (IData)(vlSelf->wasmetal_core__DOT___032260_));
    vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028742_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128105___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026664_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128087___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___070684_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070683_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070682_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070689_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070688_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070687_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054333_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027134_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127936___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b10__05d));
    vlSelf->wasmetal_core__DOT___045492_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071347_))))))));
    vlSelf->wasmetal_core__DOT___045516_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071349_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071348_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071347_)))))))));
    vlSelf->wasmetal_core__DOT___045489_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045513_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071346_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071345_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071344_)))))))));
    vlSelf->wasmetal_core__DOT___045288_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((0xcU 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071410_))))))));
    vlSelf->wasmetal_core__DOT___045312_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071412_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071411_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071410_)))))))));
    vlSelf->wasmetal_core__DOT___045285_ = (1U & (IData)(
                                                         (0xfea8ea80ea80ea80ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___045309_ = (1U & (IData)(
                                                         (0x66006600000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071409_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127859___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071408_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127867___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071407_)))))))));
    vlSelf->wasmetal_core__DOT___127868___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026592_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026559_)
            : (IData)(vlSelf->wasmetal_core__DOT___001370_));
    vlSelf->wasmetal_core__DOT___070787_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)))))))))));
    vlSelf->wasmetal_core__DOT___070786_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070785_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054326_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 3U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___070792_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)))))))))));
    vlSelf->wasmetal_core__DOT___070791_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070790_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054332_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 6U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026934_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127919___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__2__KET__ 
        = ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_h32ee57a6__0)))
            ? (IData)(vlSelf->wasmetal_core__DOT___128069___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->__VdfgTmp_h3b36f4b3__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001425_));
    vlSelf->__VdfgTmp_hf4f36877__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001413_));
    vlSelf->__VdfgTmp_h0642a572__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001381_));
    vlSelf->__VdfgTmp_h25bc616c__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___001369_));
    vlSelf->wasmetal_core__DOT___040007_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___040008_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___040014_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001413_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___040024_ = (1U & (IData)(
                                                         (0xaeaea2a2aea2aea2ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054541_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128664___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001425_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052804_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052805_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__divider__02edivisor__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___128665___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001524_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___034510_));
    vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030121_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128232___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030281_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128246___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea32__05b6__05d));
    vlSelf->wasmetal_core__DOT___063120_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063126_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063132_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(wasmetal_core__DOT____Vcellout___128059___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___063138_ = (1U & (IData)(
                                                         (0x707770777077ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127901___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(wasmetal_core__DOT____Vcellout___128059___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___063094_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128077___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052837_)))))))));
    vlSelf->wasmetal_core__DOT___128060___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___028315_)
            ? (IData)(vlSelf->wasmetal_core__DOT___028282_)
            : (IData)(vlSelf->wasmetal_core__DOT___028250_));
    vlSelf->wasmetal_core__DOT____Vcellout___127961___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027472_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027471_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027470_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027469_)))) 
           ^ (((IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127961___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027436_ = ((IData)(vlSelf->wasmetal_core__DOT___027472_)
                                             ? (IData)(wasmetal_core__DOT___127961___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_size__05b3__05d));
    vlSelf->wasmetal_core__DOT___027473_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127952___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__access_size__05b4__05d))));
    vlSelf->wasmetal_core__DOT___127953___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027395_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027330_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b8__05d));
    vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___006085_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127435___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127463___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___013656_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022737_));
    vlSelf->__VdfgTmp_hd6365363__0 = (((IData)(vlSelf->wasmetal_core__DOT___012261_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010721_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___012184_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc49b4927__0))))
                                                     : 
                                                    (0x53U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xaaaaccccf0f0ff00ULL 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h584e6b29__0))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___012185_)))))));
    vlSelf->__VdfgTmp_h2163f181__0 = (((IData)(vlSelf->wasmetal_core__DOT___011101_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___012582_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___011103_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hcdbca8e0__0))));
    vlSelf->__VdfgTmp_ha0e20209__0 = (((IData)(vlSelf->wasmetal_core__DOT___012644_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT___010722_)
                                                     ? 
                                                    (0x11f0U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h2994a26e__0))))
                                                     : 
                                                    (0x32U 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                       << 2U) 
                                                      | ((((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                           & (IData)(
                                                                     (0xcc00fff0f0aaaaULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___010531_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___010530_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011473_) 
                                                                              << 3U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hcd2c6110__0))))))) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___011441_)))))));
    vlSelf->wasmetal_core__DOT___011461_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011102_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf000ffccccaaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___010722_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010721_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___011586_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___011445_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_ha438982a__0))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___056607_)))));
    vlSelf->wasmetal_core__DOT___011683_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___011176_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___011174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010085_)))));
    vlSelf->__VdfgTmp_h6b93e166__0 = (((IData)(vlSelf->wasmetal_core__DOT___010085_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___012598_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___012597_)));
    vlSelf->wasmetal_core__DOT___017453_ = (1U & (IData)(
                                                         (0xf351000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058856_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058855_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b17__05d)))))))));
}
