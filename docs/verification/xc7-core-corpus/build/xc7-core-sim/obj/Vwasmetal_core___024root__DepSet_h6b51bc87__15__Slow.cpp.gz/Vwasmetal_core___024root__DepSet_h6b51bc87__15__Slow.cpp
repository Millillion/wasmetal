#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_ATTR_COLD void Vwasmetal_core___024root___stl_sequent__TOP__40(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___stl_sequent__TOP__40\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___013498_;
    wasmetal_core__DOT___013498_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013543_;
    wasmetal_core__DOT___013543_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013544_;
    wasmetal_core__DOT___013544_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013554_;
    wasmetal_core__DOT___013554_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013555_;
    wasmetal_core__DOT___013555_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013556_;
    wasmetal_core__DOT___013556_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___013557_;
    wasmetal_core__DOT___013557_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___014102_;
    wasmetal_core__DOT___014102_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015691_;
    wasmetal_core__DOT___015691_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015693_;
    wasmetal_core__DOT___015693_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015703_;
    wasmetal_core__DOT___015703_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015705_;
    wasmetal_core__DOT___015705_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015715_;
    wasmetal_core__DOT___015715_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015779_;
    wasmetal_core__DOT___015779_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017212_;
    wasmetal_core__DOT___017212_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017225_;
    wasmetal_core__DOT___017225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017266_;
    wasmetal_core__DOT___017266_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017267_;
    wasmetal_core__DOT___017267_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017272_;
    wasmetal_core__DOT___017272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017293_;
    wasmetal_core__DOT___017293_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017294_;
    wasmetal_core__DOT___017294_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017317_;
    wasmetal_core__DOT___017317_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017346_;
    wasmetal_core__DOT___017346_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017347_;
    wasmetal_core__DOT___017347_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017368_;
    wasmetal_core__DOT___017368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017380_;
    wasmetal_core__DOT___017380_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017382_;
    wasmetal_core__DOT___017382_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017422_;
    wasmetal_core__DOT___017422_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017428_;
    wasmetal_core__DOT___017428_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057775_;
    wasmetal_core__DOT___057775_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057780_;
    wasmetal_core__DOT___057780_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057783_;
    wasmetal_core__DOT___057783_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057813_;
    wasmetal_core__DOT___057813_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057818_;
    wasmetal_core__DOT___057818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057870_;
    wasmetal_core__DOT___057870_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057898_;
    wasmetal_core__DOT___057898_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057917_;
    wasmetal_core__DOT___057917_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057937_;
    wasmetal_core__DOT___057937_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___057951_;
    wasmetal_core__DOT___057951_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058015_;
    wasmetal_core__DOT___058015_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058016_;
    wasmetal_core__DOT___058016_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058017_;
    wasmetal_core__DOT___058017_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058673_;
    wasmetal_core__DOT___058673_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058674_;
    wasmetal_core__DOT___058674_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058676_;
    wasmetal_core__DOT___058676_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058679_;
    wasmetal_core__DOT___058679_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058682_;
    wasmetal_core__DOT___058682_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058809_;
    wasmetal_core__DOT___058809_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058918_;
    wasmetal_core__DOT___058918_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070665_;
    wasmetal_core__DOT___070665_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070666_;
    wasmetal_core__DOT___070666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___070667_;
    wasmetal_core__DOT___070667_ = 0;
    CData/*3:0*/ wasmetal_core__DOT____Vcellout___127432___O;
    wasmetal_core__DOT____Vcellout___127432___O = 0;
    CData/*0:0*/ wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127882___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127882___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127882___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127882___DOT__CO__BRA__0__KET__ = 0;
    CData/*2:0*/ wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*2:0*/ wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0;
    wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127933___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127933___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127933___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127933___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127949___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127949___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127949___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127949___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127965___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127965___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127965___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127965___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127965___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127965___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128546___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128546___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128546___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128546___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128546___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___128546___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___135433___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___135433___DOT__CO__BRA__1__KET__ = 0;
    CData/*2:0*/ __VdfgTmp_hf266d7f5__0;
    __VdfgTmp_hf266d7f5__0 = 0;
    CData/*1:0*/ __VdfgTmp_h08ed86fa__0;
    __VdfgTmp_h08ed86fa__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf9227657__0;
    __VdfgTmp_hf9227657__0 = 0;
    CData/*2:0*/ __VdfgTmp_h679b257d__0;
    __VdfgTmp_h679b257d__0 = 0;
    CData/*2:0*/ __VdfgTmp_hf9acc022__0;
    __VdfgTmp_hf9acc022__0 = 0;
    CData/*2:0*/ __VdfgTmp_hdaec8d52__0;
    __VdfgTmp_hdaec8d52__0 = 0;
    CData/*2:0*/ __VdfgTmp_h20a7a16d__0;
    __VdfgTmp_h20a7a16d__0 = 0;
    CData/*5:0*/ __VdfgTmp_h6bdbc3d0__0;
    __VdfgTmp_h6bdbc3d0__0 = 0;
    CData/*5:0*/ __VdfgTmp_ha1eca74f__0;
    __VdfgTmp_ha1eca74f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h6a06b08d__0;
    __VdfgTmp_h6a06b08d__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd3a62ed9__0;
    __VdfgTmp_hd3a62ed9__0 = 0;
    CData/*1:0*/ __VdfgTmp_hd4b8326f__0;
    __VdfgTmp_hd4b8326f__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5db557ff__0;
    __VdfgTmp_h5db557ff__0 = 0;
    CData/*2:0*/ __VdfgTmp_h1b18da23__0;
    __VdfgTmp_h1b18da23__0 = 0;
    CData/*1:0*/ __VdfgTmp_h3814f5f0__0;
    __VdfgTmp_h3814f5f0__0 = 0;
    CData/*1:0*/ __VdfgTmp_h37ce14e0__0;
    __VdfgTmp_h37ce14e0__0 = 0;
    CData/*5:0*/ __VdfgTmp_h74f5df1f__0;
    __VdfgTmp_h74f5df1f__0 = 0;
    CData/*5:0*/ __VdfgTmp_h8b0eda81__0;
    __VdfgTmp_h8b0eda81__0 = 0;
    CData/*5:0*/ __VdfgTmp_h61aaf3ff__0;
    __VdfgTmp_h61aaf3ff__0 = 0;
    CData/*1:0*/ __VdfgTmp_h6843336c__0;
    __VdfgTmp_h6843336c__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___043095_ = (1U & (0x7150U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057949_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015654_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015651_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057942_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057942_))));
    vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023567_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023544_));
    vlSelf->wasmetal_core__DOT____Vcellout___127881___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026717_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026716_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026715_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026714_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026648_)))));
    vlSelf->wasmetal_core__DOT___026652_ = ((IData)(vlSelf->wasmetal_core__DOT___026717_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127881___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001102_));
    vlSelf->wasmetal_core__DOT___045238_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070763_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054426_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___045214_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070764_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054430_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054426_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070763_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU))))))))))))));
    vlSelf->wasmetal_core__DOT___045239_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070768_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054432_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___045215_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070769_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054436_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x31U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054432_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070768_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 5U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127932___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027187_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027186_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027185_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027184_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027118_)))));
    vlSelf->wasmetal_core__DOT___027122_ = ((IData)(vlSelf->wasmetal_core__DOT___027187_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127932___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d));
    vlSelf->wasmetal_core__DOT___044966_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070866_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054425_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___044942_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070867_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054429_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2fU)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054425_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070866_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b50__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x2dU))))))))))))));
    vlSelf->wasmetal_core__DOT___044967_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070871_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054431_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                        >> 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d)))))))));
    vlSelf->wasmetal_core__DOT___044943_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070872_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054435_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x31U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054431_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070871_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b53__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__parity) 
                                                                                >> 5U)))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127915___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026987_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026986_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026985_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026984_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026918_)))));
    vlSelf->wasmetal_core__DOT___026922_ = ((IData)(vlSelf->wasmetal_core__DOT___026987_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127915___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001102_));
    vlSelf->wasmetal_core__DOT____Vcellout___127898___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026852_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026851_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026850_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026849_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026783_)))));
    vlSelf->wasmetal_core__DOT___026787_ = ((IData)(vlSelf->wasmetal_core__DOT___026852_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127898___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___001102_));
    wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___034505_) 
           & (IData)(vlSelf->wasmetal_core__DOT___128662___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___135433___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT___001146_)) 
           & (IData)(vlSelf->wasmetal_core__DOT___135433___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___128243___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030271_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030270_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030269_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030268_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030203_)))));
    vlSelf->wasmetal_core__DOT___030207_ = ((IData)(vlSelf->wasmetal_core__DOT___030271_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128243___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b55__05d));
    __VdfgTmp_h6843336c__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127964___O) 
                                     << 1U)) | (1U 
                                                & (8U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b32__05d)))));
    vlSelf->__VdfgTmp_ha6d1ccdb__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127964___O) 
                                             >> 2U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b35__05d)))));
    wasmetal_core__DOT___127965___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127948___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027449_));
    wasmetal_core__DOT___127949___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027385_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127949___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b57__05d));
    wasmetal_core__DOT____Vcellout___127432___O = (
                                                   (((IData)(vlSelf->wasmetal_core__DOT___022499_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___022498_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___022497_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022496_)))) 
                                                   ^ 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__2__KET__) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__1__KET__) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__0__KET__) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___022554_)))));
    vlSelf->wasmetal_core__DOT___022558_ = ((IData)(vlSelf->wasmetal_core__DOT___022499_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___127432___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___128546___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033469_));
    vlSelf->wasmetal_core__DOT____Vcellout___127587___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023782_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023781_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023780_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023779_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127587___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127587___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127587___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023715_)))));
    vlSelf->wasmetal_core__DOT___023719_ = ((IData)(vlSelf->wasmetal_core__DOT___023782_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127587___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d));
    vlSelf->wasmetal_core__DOT___023787_ = (1U & (6U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060464_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d))));
    vlSelf->wasmetal_core__DOT___058808_ = (1U & (0x777U 
                                                  >> 
                                                  ((8U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058803_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((4U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h6202353f__0)) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___023786_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcf1816fa__0))));
    vlSelf->wasmetal_core__DOT___058919_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h0afc15e4__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h6202353f__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058803_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0)))))))))));
    vlSelf->wasmetal_core__DOT___023784_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h324d1ed5__0))));
    vlSelf->wasmetal_core__DOT___058782_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0))))));
    vlSelf->wasmetal_core__DOT___023783_ = (1U & (0xe1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h40a0ef26__0))));
    vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d) {
        vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d;
        wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___128865___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b15__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b14__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b13__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b12__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128865___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128865___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128865___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036403_)))));
    vlSelf->wasmetal_core__DOT___036407_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b15__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128865___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___015779_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013216_));
    wasmetal_core__DOT___015693_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___006979_));
    wasmetal_core__DOT___015691_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013317_));
    wasmetal_core__DOT___015703_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013387_));
    wasmetal_core__DOT___015705_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013429_));
    wasmetal_core__DOT___015715_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013392_));
    vlSelf->__VdfgTmp_hbb788d21__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d));
    wasmetal_core__DOT___013554_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013423_));
    wasmetal_core__DOT___013556_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013491_));
    wasmetal_core__DOT___013543_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)(vlSelf->wasmetal_core__DOT___013359_));
    vlSelf->wasmetal_core__DOT___013545_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013460_));
    vlSelf->wasmetal_core__DOT___015610_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___013323_));
    wasmetal_core__DOT___017347_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015747_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013549_)))));
    wasmetal_core__DOT___013557_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))));
    __VdfgTmp_h679b257d__0 = (((IData)(vlSelf->wasmetal_core__DOT___006658_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0));
    vlSelf->__VdfgTmp_h8523194f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013466_));
    wasmetal_core__DOT___017346_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015750_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013466_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___013549_)))));
    wasmetal_core__DOT___013544_ = (1U & (0xcf5fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))));
    __VdfgTmp_h20a7a16d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013243_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h003a3400__0));
    vlSelf->__VdfgTmp_h514789fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___013440_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013414_));
    vlSelf->__VdfgTmp_h12c4c12e__0 = (((IData)(vlSelf->wasmetal_core__DOT___013440_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013414_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___006652_))));
    vlSelf->wasmetal_core__DOT___013546_ = (1U & (0xcf5fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))));
    __VdfgTmp_hdaec8d52__0 = (((IData)(vlSelf->wasmetal_core__DOT___007006_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0));
    vlSelf->wasmetal_core__DOT___015611_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h06545140__0)))));
    vlSelf->wasmetal_core__DOT___015812_ = (1U & (IData)(
                                                         (0xbfffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___057729_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h06545140__0))))))));
    wasmetal_core__DOT___013555_ = (1U & (0xcfafU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))));
    __VdfgTmp_hf9acc022__0 = (((IData)(vlSelf->wasmetal_core__DOT___013563_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0));
    if (vlSelf->wasmetal_core__DOT___006652_) {
        vlSelf->wasmetal_core__DOT___015645_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013605_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))))));
        vlSelf->wasmetal_core__DOT___015647_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013599_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))))));
        vlSelf->wasmetal_core__DOT___015813_ = (1U 
                                                & (IData)(
                                                          (0xc050f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013596_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))))));
        vlSelf->wasmetal_core__DOT___015646_ = (1U 
                                                & (IData)(
                                                          (0xc0a0f0f0f0f0f0fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___013602_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))))));
        if (vlSelf->wasmetal_core__DOT___013549_) {
            vlSelf->wasmetal_core__DOT___015637_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013565_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h679b257d__0)))))));
            vlSelf->wasmetal_core__DOT___015636_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013572_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_h20a7a16d__0)))))));
            vlSelf->wasmetal_core__DOT___015648_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013581_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hdaec8d52__0)))))));
            vlSelf->wasmetal_core__DOT___015635_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___013589_) 
                                                  << 3U) 
                                                 | (IData)(__VdfgTmp_hf9acc022__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___015637_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013565_)));
            vlSelf->wasmetal_core__DOT___015636_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013572_)));
            vlSelf->wasmetal_core__DOT___015648_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013581_)));
            vlSelf->wasmetal_core__DOT___015635_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___013589_)));
        }
    } else {
        vlSelf->wasmetal_core__DOT___015645_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013605_)));
        vlSelf->wasmetal_core__DOT___015647_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013599_)));
        vlSelf->wasmetal_core__DOT___015813_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013596_)));
        vlSelf->wasmetal_core__DOT___015646_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013602_)));
        vlSelf->wasmetal_core__DOT___015637_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013565_)));
        vlSelf->wasmetal_core__DOT___015636_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013572_)));
        vlSelf->wasmetal_core__DOT___015648_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013581_)));
        vlSelf->wasmetal_core__DOT___015635_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013589_)));
    }
    wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023424_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023424_));
    vlSelf->__VdfgTmp_hca71c93a__0 = ((0x20U & ((0x8000U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                << 5U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017324_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017323_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017322_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017321_))))));
    vlSelf->wasmetal_core__DOT___057798_ = (1U & (IData)(
                                                         (0xeeeef0f000ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017321_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017322_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017323_)))))))));
    vlSelf->wasmetal_core__DOT___017250_ = ((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                            & (IData)(
                                                      (0xff33330f0f5555ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014065_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2687b8ff__0)))))));
    vlSelf->wasmetal_core__DOT___057920_ = ((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                            & (IData)(
                                                      (0xf0f0aaaaccccff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___014001_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h2687b8ff__0)))))));
    vlSelf->__VdfgTmp_h45f4eeab__0 = ((0x20U & ((0x8000U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                << 5U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017241_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017240_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017239_) 
                                               << 1U) 
                                              | (1U 
                                                 & (0xf4000000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                         << 3U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h57745526__0))))))))));
    vlSelf->wasmetal_core__DOT___057834_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017241_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                           << 1U) 
                                                          | (1U 
                                                             & (IData)(
                                                                       (0xff7f7f7f7fULL 
                                                                        >> 
                                                                        ((0x20U 
                                                                          & ((0x8000U 
                                                                              >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                             << 5U)) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017239_) 
                                                                             << 4U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017240_) 
                                                                                << 3U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xff4040U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013998_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057830_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013672_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___057891_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057889_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057888_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___057887_))))));
    vlSelf->wasmetal_core__DOT___057894_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017355_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017352_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017353_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058014_))));
    vlSelf->wasmetal_core__DOT___057847_ = (1U & (IData)(
                                                         (0x1f1fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017246_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x8000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017244_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017245_)))))))));
    vlSelf->__VdfgTmp_h4f3902df__0 = (((IData)(vlSelf->wasmetal_core__DOT___017355_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017354_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017353_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017352_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017351_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017350_))))));
    vlSelf->wasmetal_core__DOT___057885_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017350_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017351_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017832_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xeeeef0f0ff00ff00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_he745277b__0))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057994_))));
    vlSelf->wasmetal_core__DOT___057875_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017363_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017364_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017365_)))))))));
    vlSelf->wasmetal_core__DOT___057999_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017283_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017279_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017280_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057958_))));
    vlSelf->wasmetal_core__DOT___017219_ = (1U & (IData)(
                                                         (0xfaa330000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h36931491__0)))))));
    if (vlSelf->wasmetal_core__DOT___013735_) {
        if (vlSelf->wasmetal_core__DOT___014330_) {
            vlSelf->wasmetal_core__DOT___057952_ = 
                (1U & (IData)((0xf0005500cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014401_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h36931491__0)))))));
            vlSelf->wasmetal_core__DOT___017436_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014415_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
            wasmetal_core__DOT___057951_ = (1U & (IData)(
                                                         (0xcc00aa000f000fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014394_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
            vlSelf->wasmetal_core__DOT___017435_ = 
                (1U & (IData)((0xf000aa00cc00ffULL 
                               >> (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                    << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___014408_) 
                                                  << 3U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
        } else {
            vlSelf->wasmetal_core__DOT___057952_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014401_)));
            vlSelf->wasmetal_core__DOT___017436_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014415_)));
            wasmetal_core__DOT___057951_ = (1U & (1U 
                                                  >> (IData)(vlSelf->wasmetal_core__DOT___014394_)));
            vlSelf->wasmetal_core__DOT___017435_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014408_)));
        }
        vlSelf->wasmetal_core__DOT___017304_ = (1U 
                                                & (IData)(
                                                          (0xff33330f0faaaaULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013875_) 
                                                                   << 3U) 
                                                                  | (IData)(vlSelf->__VdfgTmp_h36931491__0)))))));
    } else {
        vlSelf->wasmetal_core__DOT___057952_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014401_)));
        vlSelf->wasmetal_core__DOT___017436_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014415_)));
        wasmetal_core__DOT___057951_ = (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___014394_)));
        vlSelf->wasmetal_core__DOT___017435_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___014408_)));
        vlSelf->wasmetal_core__DOT___017304_ = 0U;
    }
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017230_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057852_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d 
        = (1U & (0xff100000U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                  << 4U) | (IData)(vlSelf->__VdfgTmp_h3e2b175e__0))));
    vlSelf->wasmetal_core__DOT___057864_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017254_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017255_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017256_)))))))));
    wasmetal_core__DOT___058016_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017426_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017423_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017424_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057964_))));
    wasmetal_core__DOT___017317_ = (1U & (IData)((0xf55330000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
    wasmetal_core__DOT___017380_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
    wasmetal_core__DOT___014102_ = ((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014165_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9832e630__0)))))));
    __VdfgTmp_h74f5df1f__0 = (((IData)(vlSelf->wasmetal_core__DOT___017284_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017283_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017282_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017281_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___017280_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017279_))))));
    vlSelf->wasmetal_core__DOT___058002_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017284_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017281_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017282_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057960_))));
    wasmetal_core__DOT___057780_ = (1U & (IData)((0xeeeef0f0ff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017259_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017260_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017261_)))))))));
    vlSelf->wasmetal_core__DOT___017338_ = (1U & (0xdU 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013652_))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017259_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d 
        = (1U & (0xeU >> ((2U & ((IData)((0x33aa0f0f00000000ULL 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                               << 5U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                  << 4U) 
                                                 | ((8U 
                                                     & ((0x8000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                        << 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((1U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___017309_) 
                                                                 << 1U) 
                                                                | (IData)(vlSelf->wasmetal_core__DOT___017310_))) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017311_)))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057806_)))))));
    vlSelf->wasmetal_core__DOT___057986_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017437_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    wasmetal_core__DOT___017225_ = (1U & (IData)((0x3355f0f000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
    wasmetal_core__DOT___017422_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff33ff55fff0fff0ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_he08c3f48__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017229_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057843_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058001_))));
    wasmetal_core__DOT___057870_ = (1U & (IData)((0x1f1fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057869_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 2U)) 
                                                            | ((((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                                 & (IData)(
                                                                           (0xff33330f0f5555ULL 
                                                                            >> 
                                                                            (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                              << 5U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013914_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013913_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013946_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013945_))))))))) 
                                                                << 1U) 
                                                               | ((IData)(vlSelf->wasmetal_core__DOT___013734_)
                                                                   ? (IData)(vlSelf->wasmetal_core__DOT___014266_)
                                                                   : (IData)(vlSelf->wasmetal_core__DOT___014288_))))))))));
    wasmetal_core__DOT___058017_ = (1U & (0xefU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017409_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                               << 2U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___017407_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017408_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057967_))));
    wasmetal_core__DOT___017212_ = (1U & (IData)((0xf55330000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___017382_ = ((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                    & (IData)((0xff0fff55ff33ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___017272_ = ((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                    & (IData)((0xff33330f0f5555ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013976_) 
                                                          << 3U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hc2f9fea7__0)))))));
    wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023545_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023545_));
    vlSelf->wasmetal_core__DOT___071333_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071332_))));
    vlSelf->wasmetal_core__DOT___071328_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071327_))));
    wasmetal_core__DOT___127882___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026719_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026652_)
            : (IData)(vlSelf->wasmetal_core__DOT___001124_));
    vlSelf->wasmetal_core__DOT___054438_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054444_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054440_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054442_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127932___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    wasmetal_core__DOT___127933___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027189_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027122_)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d));
    vlSelf->wasmetal_core__DOT___054437_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054443_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054439_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054441_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127915___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026989_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026922_)
            : (IData)(vlSelf->wasmetal_core__DOT___001124_));
    vlSelf->wasmetal_core__DOT___045080_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                               << 4U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071229_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071228_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___071227_))))))));
    vlSelf->wasmetal_core__DOT___045104_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071229_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071228_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071227_)))))))));
    vlSelf->wasmetal_core__DOT___045079_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071214_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___071213_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071212_)))))))));
    vlSelf->wasmetal_core__DOT___045103_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071214_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127897___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___071213_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___071212_)))))))));
    vlSelf->wasmetal_core__DOT___045870_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                  << 2U)) 
                                                              | (IData)(vlSelf->__VdfgTmp_hfe9e3bd4__0))))));
    vlSelf->wasmetal_core__DOT___045894_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005380_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005108_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127898___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___004972_)))))))));
    vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026854_)
            ? (IData)(vlSelf->wasmetal_core__DOT___026787_)
            : (IData)(vlSelf->wasmetal_core__DOT___001124_));
    vlSelf->wasmetal_core__DOT____Vcellout___128662___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___034507_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_ha80d5d1f__0))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___034506_) 
                & (IData)(wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___128662___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128662___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___034562_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___135433___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT___001168_)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT___001146_)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT___001124_)))))) 
           ^ ((((~ (IData)(vlSelf->wasmetal_core__DOT___001168_)) 
                & (IData)(wasmetal_core__DOT___135433___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___135433___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___135433___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___046658_)))));
    vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030272_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030207_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b56__05d));
    vlSelf->wasmetal_core__DOT___044853_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127964___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127964___O)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(__VdfgTmp_h6843336c__0)))))))))));
    vlSelf->wasmetal_core__DOT___044877_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(__VdfgTmp_h6843336c__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127964___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d))))))));
    wasmetal_core__DOT___127965___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127948___O) 
            >> 1U) & (IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___127949___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027386_)
            ? (IData)(wasmetal_core__DOT___127949___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b58__05d));
    vlSelf->__VdfgTmp_h9fcc5824__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                    >> 3U)));
    vlSelf->__VdfgTmp_h5ab387cb__0 = (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                       >> 1U))));
    vlSelf->__VdfgTmp_h9fc18e31__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_h5b8459c4__0 = (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(wasmetal_core__DOT____Vcellout___127432___O))));
    vlSelf->wasmetal_core__DOT___023241_ = (1U & (0xf0f0077U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_he648fa65__0))))));
    vlSelf->__VdfgTmp_h58a856e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022497_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                       >> 1U))));
    vlSelf->wasmetal_core__DOT___023235_ = (1U & (0xf0f00ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(wasmetal_core__DOT____Vcellout___127432___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_ha93fec6f__0))))));
    vlSelf->__VdfgTmp_h1d759fa4__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022499_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(wasmetal_core__DOT____Vcellout___127432___O) 
                                                       >> 3U))));
    vlSelf->wasmetal_core__DOT___127433___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022500_) 
           & (IData)(vlSelf->wasmetal_core__DOT___022558_));
    wasmetal_core__DOT___128546___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)) 
           & (IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__0__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) {
        wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d;
        vlSelf->wasmetal_core__DOT___023921_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d;
    } else {
        wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__;
        vlSelf->wasmetal_core__DOT___023921_ = wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__;
    }
    vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023783_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023719_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b47__05d));
    vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036407_));
    vlSelf->wasmetal_core__DOT___015678_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xafcfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013420_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006660_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006659_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006658_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006657_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006649_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005955_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057844_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015678_)))));
    vlSelf->wasmetal_core__DOT___015676_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xafcfU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013488_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013212_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013244_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013242_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013464_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005788_))));
    vlSelf->__VdfgTmp_h3f94b345__0 = (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057848_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_)))));
    vlSelf->__VdfgTmp_hfacd537a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015780_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___015779_));
    vlSelf->__VdfgTmp_h83a6d262__0 = (((IData)(vlSelf->wasmetal_core__DOT___015781_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                  << 2U) 
                                                 | (((IData)(wasmetal_core__DOT___015779_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___015780_))));
    vlSelf->wasmetal_core__DOT___013206_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015696_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015693_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015694_))))));
    vlSelf->wasmetal_core__DOT___013205_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015695_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015691_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015692_))))));
    vlSelf->wasmetal_core__DOT___017385_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015707_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015703_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015704_))))));
    vlSelf->wasmetal_core__DOT___057727_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015708_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015705_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015706_))))));
    vlSelf->wasmetal_core__DOT___017427_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015717_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___015715_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___015716_))))));
    vlSelf->wasmetal_core__DOT___015828_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0x33aaf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006651_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff0033330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050259_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050258_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050256_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___006649_))))))
                                                   : 
                                                  (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d 
        = (1U & (0x53U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___051320_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015828_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017347_))));
    vlSelf->wasmetal_core__DOT___015671_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35000000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h9cdfec6f__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050170_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050169_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013533_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013491_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005948_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057872_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_)))));
    vlSelf->wasmetal_core__DOT___017410_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___013556_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___013557_))))));
    wasmetal_core__DOT___058679_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015645_)
                                           ? ((~ (IData)(vlSelf->wasmetal_core__DOT___017396_)) 
                                              & (IData)(
                                                        (0xafffffffcfffffffULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h03d841f5__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___017396_) 
                                              | (IData)(
                                                        (0x5000000030000000ULL 
                                                         >> (IData)(vlSelf->__VdfgTmp_h03d841f5__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015645_))));
    vlSelf->wasmetal_core__DOT___013319_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___006659_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h679b257d__0)))))));
    vlSelf->wasmetal_core__DOT___015763_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0x33aaf0f0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013466_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff0033330f0f5555ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057724_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057723_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057709_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013464_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005816_))));
    vlSelf->wasmetal_core__DOT___017297_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015763_)) 
                                                  & (IData)(
                                                            (0xeefff0ffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017333_) 
                                                               << 5U) 
                                                              | ((0x10U 
                                                                  & ((0x8000U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                     << 4U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he745277b__0))))))));
    vlSelf->wasmetal_core__DOT___017298_ = ((IData)(vlSelf->wasmetal_core__DOT___015763_) 
                                            & (IData)(
                                                      (0xff11ff0fff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0x8000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017333_) 
                                                               << 3U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he745277b__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057797_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015763_)))));
    wasmetal_core__DOT___070665_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___017346_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___057994_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017346_))));
    vlSelf->wasmetal_core__DOT___015674_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057708_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013215_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013214_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013359_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x3a00U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h003a3400__0))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005809_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017113_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015674_)))));
    vlSelf->__VdfgTmp_h9b65f112__0 = (((IData)(wasmetal_core__DOT___013544_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___013543_));
    vlSelf->wasmetal_core__DOT___017285_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(wasmetal_core__DOT___013543_) 
                                                          << 1U) 
                                                         | (IData)(wasmetal_core__DOT___013544_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015647_))));
    vlSelf->wasmetal_core__DOT___013503_ = (1U & (IData)(
                                                         (0xff00ccccf0f05555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013244_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h20a7a16d__0)))))));
    vlSelf->wasmetal_core__DOT___015681_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013416_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013415_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013414_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005889_))));
    vlSelf->__VdfgTmp_h20099147__0 = (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015676_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057882_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015681_)))));
    vlSelf->wasmetal_core__DOT___017339_ = (1U & (0xfdfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015621_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h12c4c12e__0))));
    vlSelf->wasmetal_core__DOT___015677_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057714_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006978_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006977_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013460_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x3a00U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h3a7f2dd6__0))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005882_))));
    vlSelf->__VdfgTmp_hdeec5a49__0 = (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_));
    vlSelf->__VdfgTmp_h46ff4218__0 = (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057839_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015677_)))));
    vlSelf->wasmetal_core__DOT___017286_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013545_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013546_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015813_))));
    __VdfgTmp_h6bdbc3d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___007007_) 
                                           << 3U) | (IData)(__VdfgTmp_hdaec8d52__0))));
    vlSelf->wasmetal_core__DOT___013520_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xcfafU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013325_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                           << 2U) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057704_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013316_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013315_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013323_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005802_))));
    vlSelf->__VdfgTmp_h5fa4cdd4__0 = (((IData)(vlSelf->wasmetal_core__DOT___017230_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017229_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057854_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013520_)))));
    vlSelf->__VdfgTmp_hc4d25f20__0 = (((IData)(vlSelf->wasmetal_core__DOT___015610_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015611_));
    vlSelf->wasmetal_core__DOT___043104_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057945_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xbfffffffULL 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h479b81d6__0))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057943_)))))))));
    wasmetal_core__DOT___058682_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015812_)
                                           ? (IData)(
                                                     (0xbfffffffULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1d909866__0)))
                                           : (IData)(
                                                     (0xffffffff40000000ULL 
                                                      >> (IData)(vlSelf->__VdfgTmp_h1d909866__0)))));
    vlSelf->__VdfgTmp_h31f6f19a__0 = (((IData)(vlSelf->wasmetal_core__DOT___015812_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015878_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015812_))));
    vlSelf->wasmetal_core__DOT___015672_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xccaa0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x35000000U 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 2U) 
                                                                      | (IData)(vlSelf->__VdfgTmp_h08c7d12f__0))))) 
                                                              << 2U)) 
                                                          | ((2U 
                                                              & ((IData)(
                                                                         (0xff00ccccf0f0aaaaULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057704_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013316_)))))))) 
                                                                 << 1U)) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___013423_))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006051_))));
    vlSelf->__VdfgTmp_hb73d1e0b__0 = (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015671_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057866_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015672_)))));
    __VdfgTmp_hd3a62ed9__0 = (((IData)(wasmetal_core__DOT___013555_) 
                               << 1U) | (IData)(wasmetal_core__DOT___013554_));
    if (vlSelf->wasmetal_core__DOT___013549_) {
        vlSelf->wasmetal_core__DOT___015697_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015696_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015694_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015693_)))));
        vlSelf->wasmetal_core__DOT___015698_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015695_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015692_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015691_)))));
        vlSelf->wasmetal_core__DOT___015709_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015707_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015704_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015703_)))));
        vlSelf->wasmetal_core__DOT___015710_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015708_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015706_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015705_)))));
        vlSelf->wasmetal_core__DOT___015718_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015717_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015716_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___015715_)))));
        vlSelf->wasmetal_core__DOT___015724_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___013557_) 
                                                        << 1U) 
                                                       | (IData)(wasmetal_core__DOT___013556_)))));
        vlSelf->wasmetal_core__DOT___015614_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013548_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___013546_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___013545_)))));
        vlSelf->wasmetal_core__DOT___015725_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013547_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9b65f112__0))));
        vlSelf->wasmetal_core__DOT___015719_ = (1U 
                                                & (0xeU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hd3a62ed9__0))));
        vlSelf->wasmetal_core__DOT___013538_ = (1U 
                                                & (IData)(
                                                          (0xeee0ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                                                << 4U) 
                                                               | (((IData)(wasmetal_core__DOT___013557_) 
                                                                   << 3U) 
                                                                  | (((IData)(wasmetal_core__DOT___013556_) 
                                                                      << 2U) 
                                                                     | (IData)(__VdfgTmp_hd3a62ed9__0))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015697_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015696_)));
        vlSelf->wasmetal_core__DOT___015698_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015695_)));
        vlSelf->wasmetal_core__DOT___015709_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015707_)));
        vlSelf->wasmetal_core__DOT___015710_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015708_)));
        vlSelf->wasmetal_core__DOT___015718_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015717_)));
        vlSelf->wasmetal_core__DOT___015724_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013559_)));
        vlSelf->wasmetal_core__DOT___015614_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013548_)));
        vlSelf->wasmetal_core__DOT___015725_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013547_)));
        vlSelf->wasmetal_core__DOT___015719_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013558_)));
        vlSelf->wasmetal_core__DOT___013538_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___013559_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013558_))));
    }
    wasmetal_core__DOT___017428_ = (1U & (0xefU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013558_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                               << 2U) 
                                              | (((IData)(wasmetal_core__DOT___013554_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___013555_))))));
    vlSelf->__VdfgTmp_h63c4ff94__0 = (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015645_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015646_))));
    vlSelf->__VdfgTmp_he88fe03e__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___013317_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0xf0aaccffU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 3U) 
                                                                | (IData)(__VdfgTmp_hf9acc022__0)))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (IData)(
                                                                    (0xff00ccccf0f0aaaaULL 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                       << 5U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                          << 4U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___013343_) 
                                                                             << 3U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                                << 2U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___013341_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057704_)))))))))))));
    vlSelf->wasmetal_core__DOT___013335_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013313_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_hf9acc022__0)))))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___015668_ = (1U 
                                                & (0xf0aaccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050170_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050169_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013387_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xf0aaccffU 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h679b257d__0)))))))))));
        vlSelf->wasmetal_core__DOT___015667_ = (1U 
                                                & (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057708_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013215_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013429_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfaa3300U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_h20a7a16d__0)))))))))));
        vlSelf->wasmetal_core__DOT___015656_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___006653_)
                                                    ? 
                                                   (0x5cU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013415_) 
                                                         << 1U) 
                                                        | (1U 
                                                           & (IData)(
                                                                     (0xff0033330f0f5555ULL 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                        << 5U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057721_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___057720_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057715_))))))))))))
                                                    : 
                                                   (0x23U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h514789fb__0)))));
        vlSelf->wasmetal_core__DOT___015673_ = (1U 
                                                & (0xf055ccffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((IData)(
                                                                      (0xff00ccccf0f0aaaaULL 
                                                                       >> 
                                                                       (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                         << 5U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                            << 4U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                               << 3U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057714_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006978_)))))))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013392_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0xfaa3300U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                        << 3U) 
                                                                       | (IData)(__VdfgTmp_hdaec8d52__0)))))))))));
        vlSelf->wasmetal_core__DOT___015658_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013320_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013319_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___050258_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050257_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050256_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050170_)))))))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___015668_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006058_)));
        vlSelf->wasmetal_core__DOT___015667_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006044_)));
        vlSelf->wasmetal_core__DOT___015656_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005903_)));
        vlSelf->wasmetal_core__DOT___015673_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006029_)));
        vlSelf->wasmetal_core__DOT___015658_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006274_)));
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127549___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023425_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023424_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023446_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023444_)))) 
           ^ (((IData)(wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127549___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023437_ = ((IData)(vlSelf->wasmetal_core__DOT___023425_)
                                             ? (IData)(wasmetal_core__DOT___127549___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023425_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d 
        = (1U & (0x153f3fU >> (((IData)(vlSelf->wasmetal_core__DOT___014610_) 
                                << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___057799_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___057798_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___057769_)))))));
    wasmetal_core__DOT___057898_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hfb436b73__0)) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017250_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017251_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d 
        = (1U & (IData)((0xfff4f4f4ff000000ULL >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057923_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___057919_))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___057920_)))))))));
    vlSelf->wasmetal_core__DOT___017233_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015677_)
                                                   ? (IData)(
                                                             (0x3ff000055ffULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h45f4eeab__0)))
                                                   : (IData)(
                                                             (0xfffffc00ffffaa00ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h45f4eeab__0)))));
    vlSelf->wasmetal_core__DOT___043098_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015678_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015677_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017229_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017230_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057834_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057835_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057834_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057891_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057890_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057894_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057893_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057847_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057846_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057885_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057884_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057876_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057875_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057999_))));
    __VdfgTmp_h5db557ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___017219_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017218_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017217_)));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057952_))));
    vlSelf->wasmetal_core__DOT___057770_ = (1U & (IData)(
                                                         (0x11110f0fff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((0x8000U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017304_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017305_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017306_)))))))));
    vlSelf->__VdfgTmp_hdf4f813b__0 = (((IData)(vlSelf->wasmetal_core__DOT___017304_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___014330_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057865_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057864_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058016_))));
    vlSelf->__VdfgTmp_h8c37f2ea__0 = (((IData)(wasmetal_core__DOT___017317_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017316_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___017315_)));
    wasmetal_core__DOT___057917_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017383_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017379_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017380_)))));
    vlSelf->wasmetal_core__DOT___057992_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___014102_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017436_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058002_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057781_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057780_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017338_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057986_))));
    __VdfgTmp_h1b18da23__0 = (((IData)(wasmetal_core__DOT___017225_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017224_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017223_)));
    __VdfgTmp_h61aaf3ff__0 = (((IData)(vlSelf->wasmetal_core__DOT___017426_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017425_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___017424_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017423_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___017422_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017421_))))));
    wasmetal_core__DOT___058015_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017425_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017421_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017422_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057951_))));
    __VdfgTmp_h37ce14e0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015671_) 
                               << 1U) | (IData)(wasmetal_core__DOT___057870_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057871_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057870_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058017_))));
    wasmetal_core__DOT___057813_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017212_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017213_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017214_)))))))));
    __VdfgTmp_h8b0eda81__0 = (((IData)(vlSelf->wasmetal_core__DOT___017384_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017383_) 
                                          << 4U) | 
                                         (((IData)(wasmetal_core__DOT___017382_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___017381_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___017380_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___017379_))))));
    wasmetal_core__DOT___057937_ = (1U & (0xdU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017384_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017381_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017382_)))));
    wasmetal_core__DOT___057775_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___017272_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017392_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017393_)))))))));
    vlSelf->wasmetal_core__DOT___057993_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017273_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017272_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___014330_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017435_))));
    vlSelf->wasmetal_core__DOT____Vcellout___127566___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023546_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023545_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023567_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023565_)))) 
           ^ (((IData)(wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127566___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___023558_ = ((IData)(vlSelf->wasmetal_core__DOT___023546_)
                                             ? (IData)(wasmetal_core__DOT___127566___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023546_));
    vlSelf->wasmetal_core__DOT___071334_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071333_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054237_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___071329_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071328_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 1U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054231_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d)))))))));
    wasmetal_core__DOT___127882___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026720_)
            ? (IData)(wasmetal_core__DOT___127882___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001146_));
    vlSelf->wasmetal_core__DOT___070772_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054442_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d)))))));
    wasmetal_core__DOT___127933___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027190_)
            ? (IData)(wasmetal_core__DOT___127933___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d));
    vlSelf->wasmetal_core__DOT___070875_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054441_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026990_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001146_));
    vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026855_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001146_));
    vlSelf->wasmetal_core__DOT___030280_ = (1U & (0xa5c3U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b63__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135433___O) 
                                                             >> 2U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))))));
    vlSelf->wasmetal_core__DOT___030279_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b62__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135433___O) 
                                                             >> 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001168_))))));
    vlSelf->wasmetal_core__DOT___030278_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b61__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___135433___O)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001146_))))));
    vlSelf->wasmetal_core__DOT___030277_ = (1U & (0xac53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071777_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___135433___O) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___001124_))))));
    vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030273_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b57__05d));
    wasmetal_core__DOT___127965___DOT__CO__BRA__2__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127948___O) 
            >> 2U) & (IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127949___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027387_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027386_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027385_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027384_)))) 
           ^ (((IData)(wasmetal_core__DOT___127949___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127949___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127949___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027318_)))));
    vlSelf->wasmetal_core__DOT___027322_ = ((IData)(vlSelf->wasmetal_core__DOT___027387_)
                                             ? (IData)(wasmetal_core__DOT___127949___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b59__05d));
    vlSelf->wasmetal_core__DOT___006602_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023241_))));
    vlSelf->wasmetal_core__DOT___006601_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h58a856e0__0))));
    vlSelf->wasmetal_core__DOT___006604_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023235_))));
    vlSelf->wasmetal_core__DOT___006603_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1d759fa4__0))));
    wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___022501_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127433___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128546___DOT__CO__BRA__2__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)) 
           & (IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT____Vcellout___127622___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127622___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___024044_)))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d) {
        vlSelf->wasmetal_core__DOT___024048_ = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d;
    } else {
        vlSelf->wasmetal_core__DOT___024048_ = wasmetal_core__DOT___127622___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___023921_;
    }
    vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023784_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127606___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___127606___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127606___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023917_)))));
    vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__));
    vlSelf->__VdfgTmp_hccfff196__0 = (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h3f94b345__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057886_) 
                                       << 1U) | (1U 
                                                 & (0xefU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))))));
    vlSelf->wasmetal_core__DOT___017337_ = (1U & (0xff100000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057920_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057919_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013206_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013205_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017385_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057727_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017427_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017410_))));
    vlSelf->wasmetal_core__DOT___043105_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058679_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057958_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___057960_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015645_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057967_)))))))));
    vlSelf->wasmetal_core__DOT___017371_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058679_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057960_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015813_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057958_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057816_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015668_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015637_))));
    vlSelf->__VdfgTmp_h12d5b185__0 = (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013319_));
    __VdfgTmp_h3814f5f0__0 = (((IData)(vlSelf->wasmetal_core__DOT___013320_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013319_));
    vlSelf->wasmetal_core__DOT___017275_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015630_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013319_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017285_))));
    vlSelf->__VdfgTmp_h2c2f1e15__0 = (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057821_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015667_)))));
    vlSelf->wasmetal_core__DOT___015634_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013503_))))));
    __VdfgTmp_ha1eca74f__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                               << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                          << 4U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___013505_) 
                                           << 3U) | 
                                          (((IData)(vlSelf->wasmetal_core__DOT___013216_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___013503_) 
                                               << 1U) 
                                              | (1U 
                                                 & (IData)(
                                                           (0xff00ccccf0f0aaaaULL 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                              << 5U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                 << 4U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057723_) 
                                                                    << 3U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057718_) 
                                                                       << 2U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057709_) 
                                                                          << 1U) 
                                                                         | (IData)(vlSelf->wasmetal_core__DOT___057708_))))))))))))));
    vlSelf->wasmetal_core__DOT___057988_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015629_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013503_))))));
    vlSelf->wasmetal_core__DOT___013539_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015637_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015636_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017141_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_)))));
    vlSelf->wasmetal_core__DOT___017340_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014330_)
                                                   ? (IData)(
                                                             (0x800c40a02f531ULL 
                                                              >> 
                                                              (((IData)(wasmetal_core__DOT___017347_) 
                                                                << 5U) 
                                                               | (((IData)(wasmetal_core__DOT___017346_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017345_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017344_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017321_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___017332_))))))))
                                                   : 
                                                  (0x1248U 
                                                   >> 
                                                   (((IData)(wasmetal_core__DOT___017347_) 
                                                     << 3U) 
                                                    | (((IData)(wasmetal_core__DOT___017346_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017345_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017344_)))))));
    vlSelf->wasmetal_core__DOT___043123_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___017338_)))));
    vlSelf->wasmetal_core__DOT___043109_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___017347_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058001_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070665_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017338_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017339_))));
    vlSelf->wasmetal_core__DOT___017268_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017286_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017285_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017285_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(__VdfgTmp_h74f5df1f__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017286_))));
    wasmetal_core__DOT___058673_ = ((IData)(vlSelf->wasmetal_core__DOT___015673_) 
                                    & (IData)((0xfffcffaaff00ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017226_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017224_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017223_) 
                                                                << 1U) 
                                                               | (IData)(wasmetal_core__DOT___017225_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057863_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015673_)))));
    vlSelf->wasmetal_core__DOT___015762_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff00ccccf0f05555ULL 
                                                                       >> (IData)(__VdfgTmp_h6bdbc3d0__0)))))))));
    wasmetal_core__DOT___013498_ = ((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                    & (IData)((0xff33330f0faaaaULL 
                                               >> (IData)(__VdfgTmp_h6bdbc3d0__0))));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___015665_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> (IData)(vlSelf->__VdfgTmp_he88fe03e__0)));
        vlSelf->wasmetal_core__DOT___015657_ = (1U 
                                                & (0xaaccf0ffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___013336_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___013335_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT___006662_)
                                                                    ? 
                                                                   (0xeef0U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013342_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((IData)(
                                                                                (0x2a2a3f003f003f00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006151_)))))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (IData)(
                                                                                (0xaccc000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___006692_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006693_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006695_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___006694_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8744bfbd__0))))))))))))
                                                                    : 
                                                                   (0xcaU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013343_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___013341_))))))))))));
        vlSelf->wasmetal_core__DOT___013508_ = (1U 
                                                & (IData)(
                                                          (0xff55ff33ff0fff00ULL 
                                                           >> (IData)(__VdfgTmp_ha1eca74f__0))));
        vlSelf->wasmetal_core__DOT___015765_ = (1U 
                                                & (IData)(
                                                          (0xaa00cc00f000ffULL 
                                                           >> (IData)(__VdfgTmp_ha1eca74f__0))));
    } else {
        vlSelf->wasmetal_core__DOT___015665_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006178_)));
        vlSelf->wasmetal_core__DOT___015657_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___005823_)));
        vlSelf->wasmetal_core__DOT___013508_ = (1U 
                                                & (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013505_)));
        vlSelf->wasmetal_core__DOT___015765_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___013505_)));
    }
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) {
        vlSelf->wasmetal_core__DOT___017234_ = (1U 
                                                & (0x1fffe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017246_) 
                                                        << 3U) 
                                                       | ((4U 
                                                           & ((0x8000U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017245_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017244_)))))));
        vlSelf->wasmetal_core__DOT___017341_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017365_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017364_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017363_)))))));
        vlSelf->wasmetal_core__DOT___017231_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017251_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017250_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hfb436b73__0)))))))));
        wasmetal_core__DOT___057783_ = (1U & (0xdd0f0fU 
                                              >> ((0x10U 
                                                   & ((0x8000U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                      << 4U)) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014103_) 
                                                      << 3U) 
                                                     | (((IData)(wasmetal_core__DOT___014102_) 
                                                         << 2U) 
                                                        | ((2U 
                                                            & (((IData)(vlSelf->wasmetal_core__DOT___013734_)
                                                                 ? 
                                                                (0xeef0U 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014110_) 
                                                                      << 2U) 
                                                                     | ((2U 
                                                                         & ((IData)(
                                                                                (0xbfff8000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013738_)))))))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (IData)(
                                                                                (0xbfff800000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___013744_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013743_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013742_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___014037_)))))))))))))
                                                                 : 
                                                                (0xcaU 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                   << 2U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___014111_) 
                                                                      << 1U) 
                                                                     | (IData)(vlSelf->wasmetal_core__DOT___014109_))))) 
                                                               << 1U)) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___013735_)))))));
        wasmetal_core__DOT___058674_ = (1U & (0x355fcaaU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((0x8000U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017214_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017213_) 
                                                            << 1U) 
                                                           | (IData)(wasmetal_core__DOT___017212_)))))));
        wasmetal_core__DOT___058676_ = (1U & (0xfcaa0355U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                   << 4U) 
                                                  | ((8U 
                                                      & ((0x8000U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                         << 3U)) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017261_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017260_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___017259_)))))));
        vlSelf->wasmetal_core__DOT___017370_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017393_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017392_) 
                                                              << 1U) 
                                                             | (IData)(wasmetal_core__DOT___017272_)))))));
        vlSelf->wasmetal_core__DOT___017299_ = (1U 
                                                & (0x355fcaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 4U) 
                                                    | ((8U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                           << 3U)) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017306_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___017305_) 
                                                              << 1U) 
                                                             | (IData)(vlSelf->wasmetal_core__DOT___017304_)))))));
    } else {
        vlSelf->wasmetal_core__DOT___017234_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013798_))));
        vlSelf->wasmetal_core__DOT___017341_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013788_))));
        vlSelf->wasmetal_core__DOT___017231_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013771_))));
        wasmetal_core__DOT___057783_ = (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___013780_)));
        wasmetal_core__DOT___058674_ = (1U & (9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___013737_))));
        wasmetal_core__DOT___058676_ = (1U & (9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___013778_))));
        vlSelf->wasmetal_core__DOT___017370_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014037_))));
        vlSelf->wasmetal_core__DOT___017299_ = (1U 
                                                & (9U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___013918_))));
    }
    vlSelf->wasmetal_core__DOT___015666_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_a__02eisZeroExpIn)
                                                   ? 
                                                  (0xaacc0f0fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___006653_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                        << 3U) 
                                                       | (((IData)(wasmetal_core__DOT___013498_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___006979_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (0xff00ccccf0f0aaaaULL 
                                                                           >> 
                                                                           (((IData)(vlSelf->wasmetal_core__DOT___006662_) 
                                                                             << 5U) 
                                                                            | (((IData)(vlSelf->wasmetal_core__DOT___006661_) 
                                                                                << 4U) 
                                                                               | (((IData)(vlSelf->wasmetal_core__DOT___057720_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057716_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057715_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057714_))))))))))))))
                                                   : 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___006151_))));
    vlSelf->wasmetal_core__DOT___043106_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057952_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057951_)))))))));
    vlSelf->wasmetal_core__DOT___017269_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057952_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015646_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057964_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057951_)))))))));
    vlSelf->__VdfgTmp_h9a784e39__0 = (((IData)(vlSelf->wasmetal_core__DOT___015648_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015646_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015648_))));
    __VdfgTmp_h6a06b08d__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hc4d25f20__0));
    vlSelf->wasmetal_core__DOT___017372_ = (1U & (0x10010000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058682_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015879_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___057945_) 
                                                          << 2U) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___015878_) 
                                                              & (IData)(
                                                                        (0xffffffff40000000ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h479b81d6__0)))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___015878_)) 
                                                                  & (IData)(
                                                                            (0xbfffffffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017404_) 
                                                                               << 5U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013734_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013733_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___013735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___013973_))))))))))))))));
    wasmetal_core__DOT___070666_ = (1U & (4U >> (((IData)(wasmetal_core__DOT___017428_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___058016_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___017428_))));
    vlSelf->__VdfgTmp_hc84aef23__0 = (((IData)(vlSelf->wasmetal_core__DOT___015647_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h63c4ff94__0));
    vlSelf->__VdfgTmp_he68a43c0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017436_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___017435_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015635_))));
    vlSelf->__VdfgTmp_h7d202e30__0 = (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013335_)));
    __VdfgTmp_hd4b8326f__0 = (((IData)(vlSelf->wasmetal_core__DOT___013336_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013335_));
    vlSelf->wasmetal_core__DOT___017276_ = (1U & (0xbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015622_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013335_))))));
    vlSelf->wasmetal_core__DOT___017270_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___014330_)
                                                   ? (IData)(
                                                             (0x100320504fac8ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___017273_) 
                                                                         << 2U) 
                                                                        | (((IData)(wasmetal_core__DOT___014102_) 
                                                                            << 1U) 
                                                                           | (IData)(wasmetal_core__DOT___017272_))))))))
                                                   : 
                                                  (0x1248U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___017274_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___017273_)))))));
    vlSelf->wasmetal_core__DOT___057717_ = (1U & (0xe0U 
                                                  >> 
                                                  ((4U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 1U))))));
    vlSelf->wasmetal_core__DOT___057695_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)))));
    vlSelf->__VdfgTmp_h46c2cf96__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (3U 
                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127450___O))))));
    vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023426_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023437_)
            : (IData)(vlSelf->wasmetal_core__DOT___023426_));
    vlSelf->wasmetal_core__DOT___070668_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017231_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017234_))));
    vlSelf->wasmetal_core__DOT___070669_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015681_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057898_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (((IData)(wasmetal_core__DOT___057898_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057897_))))));
    vlSelf->wasmetal_core__DOT___043117_ = (1U & (0x90090000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017233_) 
                                                    << 4U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5fa4cdd4__0))));
    vlSelf->__VdfgTmp_hcc37b29f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d));
    wasmetal_core__DOT___057818_ = (1U & (IData)((0x11110f0fff00ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_h5db557ff__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___057771_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057770_))))));
    __VdfgTmp_hf266d7f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___057987_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_hdf4f813b__0));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | 
                                         (1U & (IData)(
                                                       (0x11110f0fff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 5U) 
                                                         | ((0x10U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                                << 3U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h8c37f2ea__0))))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057790_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057917_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017830_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057783_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057992_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | 
                                         (1U & (IData)(
                                                       (0x11110f0fff00ff00ULL 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                          << 5U) 
                                                         | ((0x10U 
                                                             & ((0x8000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                << 4U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                                << 3U) 
                                                               | (IData)(__VdfgTmp_h1b18da23__0))))))))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057858_)))))));
    vlSelf->wasmetal_core__DOT___017374_ = (1U & ((IData)(wasmetal_core__DOT___017428_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017427_)
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017427_)
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(__VdfgTmp_h61aaf3ff__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___058015_))));
    vlSelf->wasmetal_core__DOT___017203_ = (1U & (0x90U 
                                                  >> 
                                                  ((4U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn)
                                                         ? 
                                                        (0x355fcaaU 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                           << 4U) 
                                                          | ((8U 
                                                              & ((0x8000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                 << 3U)) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017256_) 
                                                                 << 2U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017255_) 
                                                                    << 1U) 
                                                                   | (IData)(vlSelf->wasmetal_core__DOT___017254_))))))
                                                         : 
                                                        (9U 
                                                         >> 
                                                         (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___013787_)))) 
                                                       << 2U)) 
                                                   | (IData)(__VdfgTmp_h37ce14e0__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | (IData)(wasmetal_core__DOT___057813_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057812_)))))));
    wasmetal_core__DOT___017368_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___017385_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___013205_)
                                               ? (IData)(
                                                         (0xb0bbULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0)))
                                               : (IData)(
                                                         (0xf0ff4044ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0))))
                                           : ((IData)(vlSelf->wasmetal_core__DOT___013205_)
                                               ? (IData)(
                                                         (0xbbbb00000b00ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0)))
                                               : (IData)(
                                                         (0xffff44440f000400ULL 
                                                          >> (IData)(__VdfgTmp_h8b0eda81__0))))));
    wasmetal_core__DOT___070667_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___017385_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___057937_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(wasmetal_core__DOT___057937_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d 
        = (1U & (0x4f44U >> (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017828_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___057775_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057993_))));
    vlSelf->__VdfgTmp_he29625ac__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d));
    vlSelf->wasmetal_core__DOT___043069_ = (1U & (IData)(
                                                         (0x7f13370177113300ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                  << 3U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        << 2U)) 
                                                                    | (3U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                          >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___043073_ = (1U & (IData)(
                                                         (0x9009000000009009ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                               << 3U)) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                  << 2U)) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                     << 2U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                        << 1U)) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             >> 2U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 3U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             >> 1U)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 2U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O)) 
                                      | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O) 
                                               >> 1U))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d 
        = (1U & (0xcaU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127566___O) 
                                             << 1U)) 
                                      | (1U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127459___O))))));
    vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023547_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023558_)
            : (IData)(vlSelf->wasmetal_core__DOT___023547_));
    vlSelf->wasmetal_core__DOT___045036_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071334_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054235_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___045012_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071334_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                        << 3U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b41__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054235_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                          >> 1U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                                   << 2U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b42__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054237_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071332_))))));
    vlSelf->wasmetal_core__DOT___045035_ = (1U & (IData)(
                                                         (0x30a0cf5f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___071329_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                  << 2U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054229_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___045011_ = (1U & (0xffe8U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xaf3f000000000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___071329_) 
                                                                  << 5U) 
                                                                 | ((0x10U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___054229_)))))))) 
                                                       << 3U)) 
                                                   | ((4U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127881___O) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0xaf3f0000U 
                                                              >> 
                                                              ((0x10U 
                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127880___O) 
                                                                   << 1U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b39__05d) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___054231_)))))) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___071327_))))));
    vlSelf->wasmetal_core__DOT___127882___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026721_)
            ? (IData)(wasmetal_core__DOT___127882___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001168_));
    vlSelf->wasmetal_core__DOT___070774_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054440_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)))))))))));
    vlSelf->wasmetal_core__DOT___070773_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070772_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054440_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___127933___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027191_)
            ? (IData)(wasmetal_core__DOT___127933___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d));
    vlSelf->wasmetal_core__DOT___070877_ = (1U & (IData)(
                                                         (0xf77000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___054439_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070875_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)))))))))));
    vlSelf->wasmetal_core__DOT___070876_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070875_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054439_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x33U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b57__05d)))))))));
    vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026991_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001168_));
    vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___026856_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___001168_));
    vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030274_)
            ? (IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b58__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127965___O 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127948___O) 
           ^ (((IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027449_)))));
    vlSelf->wasmetal_core__DOT___027453_ = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127948___O) 
                                             >> 3U) 
                                            & (IData)(wasmetal_core__DOT___127965___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___063340_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128359___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128447___O) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063342_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128359___O) 
                                                                     << 2U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128447___O)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063344_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                                               << 3U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128359___O) 
                                                                     << 1U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128447___O) 
                                                                           >> 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___063346_ = (1U & (IData)(
                                                         (0x77707770777ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
                                                               << 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___062961_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128359___O)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128447___O) 
                                                                           >> 2U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048482_)))))))));
    vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027389_)
            ? (IData)(vlSelf->wasmetal_core__DOT___027322_)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b60__05d));
    vlSelf->__VdfgTmp_hefac2d69__0 = (((IData)(vlSelf->wasmetal_core__DOT___050073_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___006602_));
    vlSelf->wasmetal_core__DOT____Vcellout___127433___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___022503_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___022502_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022501_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022500_)))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___022502_) 
                & (IData)(wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127433___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127433___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___022558_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128546___O 
        = (((8U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)) 
                   << 3U)) | ((4U & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b58__05d)) 
                                     << 2U)) | ((2U 
                                                 & ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b57__05d)) 
                                                    << 1U)) 
                                                | (1U 
                                                   & (~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)))))) 
           ^ (((IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___033469_)))));
    vlSelf->wasmetal_core__DOT___033473_ = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b59__05d)) 
                                            & (IData)(wasmetal_core__DOT___128546___DOT__CO__BRA__2__KET__));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__ 
            = vlSelf->wasmetal_core__DOT___024048_;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__0__KET__;
    }
    wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023786_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d));
    vlSelf->__VdfgTmp_h85d2f38f__0 = ((2U & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005896_));
    vlSelf->__VdfgTmp_h9333e746__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005830_));
    vlSelf->__VdfgTmp_hfab14cf6__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 2U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___005962_));
    vlSelf->__VdfgTmp_h5c347c33__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127606___O) 
                                             >> 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__));
    wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_h6cc9accb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017337_) 
                                       << 1U) | (1U 
                                                 & (0xfdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___057922_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___057920_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057919_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___014330_))))))));
    vlSelf->wasmetal_core__DOT___015633_ = (1U & (0xdcccU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h12d5b185__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057776_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015658_)))));
    vlSelf->__VdfgTmp_he3b69f57__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057702_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_h3814f5f0__0))));
    vlSelf->wasmetal_core__DOT___015777_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057702_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_h3814f5f0__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017275_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___057988_))));
    vlSelf->__VdfgTmp_h7c001b5f__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d));
    vlSelf->__VdfgTmp_ha1f1e621__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d));
    vlSelf->wasmetal_core__DOT___017201_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058674_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058673_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (((~ (IData)(vlSelf->wasmetal_core__DOT___015673_)) 
                                                              & (IData)(
                                                                        (0x11ff0fffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___017226_) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h1b18da23__0))))))) 
                                                             << 2U)) 
                                                         | ((((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                              & (IData)(
                                                                        (0xfffcffaaff00ff00ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                           << 5U) 
                                                                          | ((0x10U 
                                                                              & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017220_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017218_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017217_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___017219_))))))))) 
                                                             << 1U) 
                                                            | (1U 
                                                               & ((~ (IData)(vlSelf->wasmetal_core__DOT___015667_)) 
                                                                  & (IData)(
                                                                            (0x11ff0fffULL 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___017220_) 
                                                                               << 5U) 
                                                                              | ((0x10U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                                << 3U) 
                                                                                | (IData)(__VdfgTmp_h5db557ff__0))))))))))))));
    vlSelf->__VdfgTmp_hb584f1fd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___013498_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___013549_)));
    vlSelf->wasmetal_core__DOT___013540_ = (1U & (IData)(
                                                         (0xfefULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015638_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___013498_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h6a06b08d__0)))))));
    vlSelf->wasmetal_core__DOT___058006_ = (1U & (0xefU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015612_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_h6a06b08d__0))));
    vlSelf->wasmetal_core__DOT___017296_ = ((IData)(vlSelf->wasmetal_core__DOT___015665_) 
                                            & (IData)(
                                                      (0xfffcffaaff00ff00ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                         << 5U) 
                                                        | ((0x10U 
                                                            & ((0x8000U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                               << 4U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017318_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017316_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017315_) 
                                                                     << 1U) 
                                                                    | (IData)(wasmetal_core__DOT___017317_)))))))));
    vlSelf->__VdfgTmp_hb34385bd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057794_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_)))));
    vlSelf->__VdfgTmp_h7f30fde6__0 = (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                  << 4U) 
                                                 | (IData)(vlSelf->__VdfgTmp_he68a43c0__0)));
    vlSelf->wasmetal_core__DOT___043102_ = (1U & (IData)(
                                                         (0xf4ff44f444444444ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___057783_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015658_) 
                                                                           << 1U) 
                                                                          | (IData)(wasmetal_core__DOT___057775_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015656_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___057780_)))))))));
    vlSelf->wasmetal_core__DOT___017204_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058676_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___057783_)))));
    vlSelf->__VdfgTmp_hd1c7c886__0 = (((IData)(vlSelf->wasmetal_core__DOT___015657_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015656_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057784_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015657_)))));
    vlSelf->__VdfgTmp_h9cde2904__0 = (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057706_) 
                                                     << 2U) 
                                                    | (IData)(__VdfgTmp_hd4b8326f__0))));
    vlSelf->wasmetal_core__DOT___015776_ = (1U & (0xcfafU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057706_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006652_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013549_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_hd4b8326f__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017276_))));
    vlSelf->wasmetal_core__DOT___051336_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d))));
    vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023427_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023427_));
    vlSelf->__VdfgTmp_hc322cfc1__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d));
    vlSelf->wasmetal_core__DOT___043100_ = (1U & (0xf7755110U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015668_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015667_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058673_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___057818_) 
                                                             << 1U) 
                                                            | (IData)(wasmetal_core__DOT___057813_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d 
        = (1U & (0xeU >> ((2U & ((4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                                          << 1U) | (IData)(wasmetal_core__DOT___057818_))) 
                                 << 1U)) | (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057772_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057817_)))))));
    vlSelf->wasmetal_core__DOT___017264_ = (1U & (0xf800U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057988_) 
                                                    << 3U) 
                                                   | (IData)(__VdfgTmp_hf266d7f5__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d 
        = (1U & (0xf800U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                              << 3U) | (IData)(__VdfgTmp_hf266d7f5__0))));
    vlSelf->wasmetal_core__DOT___043125_ = (1U & (0x90U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058017_)))));
    vlSelf->wasmetal_core__DOT___043111_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017427_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058015_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070666_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___058017_)))))))));
    vlSelf->wasmetal_core__DOT___043118_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017341_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017203_))));
    vlSelf->wasmetal_core__DOT___043099_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015672_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057864_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(__VdfgTmp_h37ce14e0__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015674_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017203_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057875_)))))))));
    vlSelf->__VdfgTmp_hb820c59b__0 = ((2U & ((0xefff10U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058013_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                         << 2U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058011_) 
                                                            << 1U) 
                                                           | (IData)(vlSelf->wasmetal_core__DOT___058012_)))))) 
                                             << 1U)) 
                                      | (IData)(wasmetal_core__DOT___017368_));
    vlSelf->wasmetal_core__DOT___043112_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___013205_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___057917_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___070667_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057727_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___017368_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058014_)))))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135066___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b33__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b32__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b31__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b22__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d)))))))))))))))));
    vlSelf->__VdfgTmp_h7a977bbe__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b55__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b55__05d));
    vlSelf->__VdfgTmp_hfe3e676b__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b54__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b54__05d));
    vlSelf->__VdfgTmp_hb08bdf67__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d));
    vlSelf->__VdfgTmp_h45b9122a__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023548_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023548_));
    vlSelf->wasmetal_core__DOT___127882___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127882___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127882___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127882___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___045240_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070773_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054438_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___045216_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070774_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054442_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x34U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054438_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070773_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U))))))))))))));
    vlSelf->wasmetal_core__DOT___127933___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127933___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(wasmetal_core__DOT___127933___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(wasmetal_core__DOT___127933___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___044968_ = (1U & (IData)(
                                                         (0xaac0553f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070876_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___054437_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d)))))))));
    vlSelf->wasmetal_core__DOT___044944_ = (1U & (0xbU 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xf0ff88ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___070877_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___054441_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d) 
                                                                           << 2U) 
                                                                          | ((2U 
                                                                              & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x34U)) 
                                                                                << 1U)) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xf77000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___054437_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___070876_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b56__05d) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                                >> 0x32U))))))))))))));
    wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__0__KET__)));
    wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0 
        = (((IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__2__KET__) 
            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__1__KET__) 
                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128244___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___030275_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___030274_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___030273_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030272_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___030207_)))));
    vlSelf->wasmetal_core__DOT___030211_ = ((IData)(vlSelf->wasmetal_core__DOT___030275_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128244___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b59__05d));
    vlSelf->wasmetal_core__DOT___044854_ = (1U & (IData)(
                                                         (0xb230f3b2fffafffaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                        << 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_ha6d1ccdb__0)))))))))));
    vlSelf->wasmetal_core__DOT___044878_ = (1U & (IData)(
                                                         (0x8040201f00000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((9U 
                                                                >> (IData)(vlSelf->__VdfgTmp_ha6d1ccdb__0)) 
                                                               << 5U)) 
                                                           | ((0x18U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                                                  << 3U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b37__05d) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b36__05d))))))));
    vlSelf->__VdfgTmp_h0f43979c__0 = ((2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127965___O) 
                                             >> 1U)) 
                                      | (1U & (8U >> 
                                               (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                 << 1U) 
                                                | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b38__05d)))));
    vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
           & (IData)(vlSelf->wasmetal_core__DOT___027453_));
    vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027390_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b61__05d));
    vlSelf->__VdfgTmp_hf9e966c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                    >> 2U)));
    vlSelf->__VdfgTmp_hf92fc642__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 1U) | (1U 
                                                 & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)));
    vlSelf->__VdfgTmp_haf233eab__0 = (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___022500_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O))));
    __VdfgTmp_hf9227657__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                               >> 1U)));
    vlSelf->__VdfgTmp_hb47377e1__0 = (((IData)(vlSelf->wasmetal_core__DOT___022503_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O) 
                                                       >> 3U))));
    vlSelf->wasmetal_core__DOT___023191_ = (1U & (0xf0f00ddU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006248_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006247_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127433___O)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb3f3e4b7__0))))));
    vlSelf->wasmetal_core__DOT___012305_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f0ccccff00aaaaULL 
                                                                   >> 
                                                                   ((0x20U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                        << 5U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056497_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b51__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___009832_) 
                                                                              << 2U) 
                                                                             | ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                >> 3U))))))))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___010092_)))));
    vlSelf->wasmetal_core__DOT___056420_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009681_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((IData)(
                                                                     (0xff55550f0f3333ULL 
                                                                      >> 
                                                                      ((0x20U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                           << 5U)) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                           << 4U) 
                                                                          | ((8U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128546___O) 
                                                                                << 3U)) 
                                                                             | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128544___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b48__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b56__05d)))))))) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & (IData)(
                                                                      (0xff55550f0f3333ULL 
                                                                       >> 
                                                                       ((0x20U 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128623___O) 
                                                                            << 5U)) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02esx__05b63__05d) 
                                                                            << 4U) 
                                                                           | ((8U 
                                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128542___O) 
                                                                                << 3U)) 
                                                                              | ((4U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128555___O) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b32__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b40__05d))))))))))))));
    vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b60__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___033473_));
    if (vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d;
    } else {
        vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT___127607___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT____Vcellout___127588___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023787_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023786_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023784_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023783_)))) 
           ^ (((IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127588___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023719_)))));
    vlSelf->wasmetal_core__DOT___023724_ = ((IData)(vlSelf->wasmetal_core__DOT___023787_)
                                             ? (IData)(wasmetal_core__DOT___127588___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b50__05d));
    vlSelf->wasmetal_core__DOT___023789_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b52__05d))));
    vlSelf->wasmetal_core__DOT___058909_ = (1U & (IData)(
                                                         (1ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h5220a2be__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((4U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0)) 
                                                                  << 4U)) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hde857550__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)))))))))));
    vlSelf->wasmetal_core__DOT___058766_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9333e746__0))))));
    vlSelf->wasmetal_core__DOT___023788_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h9333e746__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d))));
    vlSelf->wasmetal_core__DOT___023791_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d))));
    vlSelf->wasmetal_core__DOT___058905_ = (1U & (IData)(
                                                         (0x700000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058899_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058898_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058897_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((4U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b48__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0)))))))))));
    wasmetal_core__DOT___058918_ = (1U & (1U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h40a0ef26__0))))));
    wasmetal_core__DOT___058809_ = (1U & (0x777U >> 
                                          ((8U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                  << 2U)) 
                                           | ((4U & 
                                               ((4U 
                                                 >> (IData)(vlSelf->__VdfgTmp_h85d2f38f__0)) 
                                                << 2U)) 
                                              | ((2U 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127622___O) 
                                                     >> 2U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hfab14cf6__0))))))));
    vlSelf->wasmetal_core__DOT___023790_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b53__05d))));
    vlSelf->wasmetal_core__DOT___058882_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058803_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b54__05d) 
                                                          << 1U) 
                                                         | (1U 
                                                            & (4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128866___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b18__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b17__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b16__05d)))) 
           ^ (((IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128866___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036407_)))));
    vlSelf->wasmetal_core__DOT___036411_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b19__05d) 
                                            & (IData)(wasmetal_core__DOT___128866___DOT__CO__BRA__2__KET__));
    vlSelf->wasmetal_core__DOT___017342_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015777_)
                                                   ? 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xb0bbULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xf0ff4044ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))
                                                   : 
                                                  ((1U 
                                                    & (0xefU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)))
                                                    ? (IData)(
                                                              (0xbbbb00000b00ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0)))
                                                    : (IData)(
                                                              (0xffff44440f000400ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h4f3902df__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057895_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015777_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___017017_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_)))));
    wasmetal_core__DOT___017293_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015666_)) 
                                          & (IData)(
                                                    (0x11ff0fffULL 
                                                     >> 
                                                     (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                       << 5U) 
                                                      | ((0x10U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                             << 4U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017311_) 
                                                                << 2U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                                   << 1U) 
                                                                  | (IData)(vlSelf->wasmetal_core__DOT___017309_))))))))));
    wasmetal_core__DOT___017294_ = ((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                    & (IData)((0xfffcffaaff00ff00ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                    << 5U) 
                                                   | ((0x10U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                          << 4U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017312_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___017310_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017309_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017311_)))))))));
    vlSelf->__VdfgTmp_h10a18780__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015665_));
    vlSelf->__VdfgTmp_hfcfb0a06__0 = (((IData)(vlSelf->wasmetal_core__DOT___015666_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015765_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057811_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015666_)))));
    vlSelf->wasmetal_core__DOT___043107_ = (1U & (IData)(
                                                         (0x7f57150177551100ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((7U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017435_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017436_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057986_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (1U & (7U >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0))))));
    wasmetal_core__DOT___017266_ = (1U & (0xfdU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___058005_) 
                                            << 4U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 3U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___058004_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058003_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___014330_)))))));
    wasmetal_core__DOT___017267_ = (1U & (0xff100000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___058006_) 
                                               << 4U) 
                                              | (IData)(vlSelf->__VdfgTmp_h3e2b175e__0))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d 
        = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058006_))));
    vlSelf->wasmetal_core__DOT___017375_ = (1U & ((1U 
                                                   & (7U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hb584f1fd__0)))
                                                   ? 
                                                  ((~ (IData)(vlSelf->wasmetal_core__DOT___017437_)) 
                                                   & (IData)(
                                                             (0x900990099009ULL 
                                                              >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___017437_)
                                                    ? 
                                                   (0x9009U 
                                                    >> (IData)(vlSelf->__VdfgTmp_he68a43c0__0))
                                                    : (IData)(
                                                              (0x9009000000000000ULL 
                                                               >> (IData)(vlSelf->__VdfgTmp_h7f30fde6__0))))));
    vlSelf->wasmetal_core__DOT___043120_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017204_))));
    vlSelf->wasmetal_core__DOT___043097_ = (1U & (IData)(
                                                         (0xff40ffff4040ff40ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015676_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___057847_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___070669_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070668_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057891_)))))))));
    vlSelf->wasmetal_core__DOT___017232_ = (1U & (0xefff10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015776_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___057887_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___057888_)))))));
    vlSelf->__VdfgTmp_h649aadfd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d 
        = (1U & (0x5cU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ewide) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___057892_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015776_)))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b50__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b49__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b44__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b43__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b42__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b41__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b40__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b39__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b38__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b37__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b36__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b35__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b30__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b29__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b28__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b27__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b26__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b25__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b24__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b23__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b21__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b19__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b18__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b17__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b16__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b14__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b12__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b11__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b10__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b9__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b8__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b7__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b6__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b5__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b4__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b3__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b2__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d)))))));
    vlSelf->__VdfgTmp_h9a302586__0 = (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___051336_));
    wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023428_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023428_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135067___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b48__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b47__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b46__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b45__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b34__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___043108_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017275_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017276_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057993_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057992_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017264_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017270_)))))))));
    __VdfgTmp_h08ed86fa__0 = ((2U & ((7U >> (((IData)(vlSelf->wasmetal_core__DOT___057987_) 
                                              << 3U) 
                                             | (((IData)(vlSelf->wasmetal_core__DOT___057988_) 
                                                 << 2U) 
                                                | (IData)(vlSelf->__VdfgTmp_hdf4f813b__0)))) 
                                     << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___017264_));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___B 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b1__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b0__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___036956_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))));
    vlSelf->wasmetal_core__DOT___036955_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__ 
        = ((6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d));
    vlSelf->wasmetal_core__DOT___036954_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h45b9122a__0))));
    vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b52__05d)));
    vlSelf->wasmetal_core__DOT____Vcellinp___128775___S 
        = ((8U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h7a977bbe__0))) 
                  << 3U)) | ((4U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_hfe3e676b__0))) 
                                    << 2U)) | ((2U 
                                                & ((~ 
                                                    (6U 
                                                     >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))) 
                                                   << 1U)) 
                                               | (1U 
                                                  & (~ 
                                                     (6U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0)))))));
    vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (6U >> (IData)(vlSelf->__VdfgTmp_h45b9122a__0))) 
                 | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b52__05d)));
    wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023549_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT___023549_));
    vlSelf->wasmetal_core__DOT____Vcellout___127882___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026722_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127882___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127882___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127882___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026722_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026721_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026720_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026719_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127882___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026652_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127933___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027192_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127933___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d)) 
            << 3U) | (IData)(vlSelf->wasmetal_core__DOT___127933___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127933___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027192_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027191_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027190_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027189_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127933___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027122_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127916___CO 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026992_)
              ? (IData)(vlSelf->wasmetal_core__DOT___127916___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127916___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026992_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026991_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026990_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026989_)))) 
           ^ (((IData)(wasmetal_core__DOT___127916___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026922_)));
    vlSelf->wasmetal_core__DOT____Vcellout___127899___CO 
        = ((((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)))
              ? (IData)(vlSelf->wasmetal_core__DOT___127899___DOT__CO__BRA__2__KET__)
              : (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d)) 
            << 3U) | (IData)(wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0));
    vlSelf->wasmetal_core__DOT____Vcellout___127899___O 
        = (((8U & ((6U >> (IData)(vlSelf->__VdfgTmp_hdb4c449f__0)) 
                   << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT___026856_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026855_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026854_)))) 
           ^ (((IData)(wasmetal_core__DOT___127899___DOT____VdfgTmp_h3cda4b7d__0) 
               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026787_)));
    vlSelf->wasmetal_core__DOT___128245___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___030277_)
            ? (IData)(vlSelf->wasmetal_core__DOT___030211_)
            : (IData)(vlSelf->wasmetal_core__DOT__alu__02ea__05b60__05d));
    vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__1__KET__ 
        = (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127949___O) 
            >> 1U) & (IData)(vlSelf->wasmetal_core__DOT___127966___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___027391_)
            ? (IData)(vlSelf->wasmetal_core__DOT___127950___DOT__CO__BRA__1__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__access_base__05b62__05d));
    vlSelf->wasmetal_core__DOT___006596_ = (1U & (0xa300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf233eab__0))));
    vlSelf->wasmetal_core__DOT___023202_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                   ? (IData)(
                                                             (0xf0c0f0d1f0c05555ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___006155_) 
                                                                         << 2U) 
                                                                        | (IData)(__VdfgTmp_hf9227657__0)))))))
                                                   : 
                                                  (0xfcfdU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_hf9227657__0))))));
    vlSelf->wasmetal_core__DOT___006597_ = (1U & (0xe00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb47377e1__0))));
    vlSelf->wasmetal_core__DOT___006598_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006127_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___023191_))));
    vlSelf->wasmetal_core__DOT___127519___DOT__CO__BRA__1__KET__ 
        = ((~ (0xeU >> (IData)(vlSelf->__VdfgTmp_hb47377e1__0))) 
           & (IData)(vlSelf->wasmetal_core__DOT___023191_));
    vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__1__KET__ 
        = ((~ (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02epop__02ebits_in__05b61__05d)) 
           & (IData)(vlSelf->wasmetal_core__DOT___128547___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)
            ? (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b58__05d)
            : (IData)(vlSelf->wasmetal_core__DOT___127623___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___127589___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023788_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023724_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d));
    vlSelf->wasmetal_core__DOT___058920_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058919_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058918_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((4U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h8e8edf3a__0)) 
                                                                     << 3U)) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hd093a298__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5c347c33__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_hd665514e__0)))))))))));
    vlSelf->wasmetal_core__DOT___058811_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___058809_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058808_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058807_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         ((2U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127633___O) 
                                                                              >> 2U)) 
                                                                          | (1U 
                                                                             & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7be661a5__0))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                             >> 1U))))))))));
    vlSelf->__VdfgTmp_ha7b11bb8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058457_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O)))));
    vlSelf->__VdfgTmp_hf552ae6e__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058467_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128866___O) 
                                                          >> 3U)))));
    vlSelf->wasmetal_core__DOT___128867___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b20__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036411_));
    vlSelf->wasmetal_core__DOT___043115_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0))));
    vlSelf->wasmetal_core__DOT___043096_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((0xefU 
                                                                >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057885_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057894_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017337_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017342_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b34__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b33__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b32__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b31__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b49__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b48__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b47__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b46__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d)))))));
    vlSelf->wasmetal_core__DOT___043101_ = (1U & (IData)(
                                                         (0xf4fff4f400ff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017299_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057770_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___017293_)))))))));
    vlSelf->__VdfgTmp_h182596d5__0 = (((IData)(vlSelf->wasmetal_core__DOT___017296_) 
                                       << 3U) | ((4U 
                                                  & (((~ (IData)(vlSelf->wasmetal_core__DOT___015665_)) 
                                                      & (IData)(
                                                                (0x11ff0fffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___017318_) 
                                                                   << 5U) 
                                                                  | ((0x10U 
                                                                      & ((0x8000U 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h895aa12b__0)) 
                                                                         << 4U)) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02edecode_b__02eisZeroExpIn) 
                                                                         << 3U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_h8c37f2ea__0))))))) 
                                                     << 2U)) 
                                                 | (((IData)(wasmetal_core__DOT___017294_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___017293_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b48__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b47__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b46__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b45__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b16__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b15__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b14__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b13__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135069___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b16__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b15__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b14__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b13__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b12__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b11__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b10__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b9__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b8__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b7__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b6__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b5__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b4__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b3__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b2__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb788d21__0))))))))))))))));
    vlSelf->wasmetal_core__DOT___043124_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___017267_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___017266_)))));
    vlSelf->wasmetal_core__DOT___043110_ = (1U & (IData)(
                                                         (0x8fff888f8f8f8888ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017286_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017285_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058002_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057999_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___017267_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017268_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b23__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b22__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b21__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b20__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d)))))));
    vlSelf->wasmetal_core__DOT___043116_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070668_))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b35__05d 
        = (1U & (0xaaccf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b34__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b33__05d 
        = (1U & (0xccaaf0f0U >> (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___051336_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b32__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d)))))));
    vlSelf->wasmetal_core__DOT____Vcellinp___135073___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b33__05d) 
            << 0x10U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b32__05d) 
                          << 0xfU) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b31__05d) 
                                       << 0xeU) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b30__05d) 
                                                    << 0xdU) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b29__05d) 
                                                       << 0xcU) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b28__05d) 
                                                          << 0xbU) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b27__05d) 
                                                             << 0xaU) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b26__05d) 
                                                                << 9U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b25__05d) 
                                                                   << 8U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b24__05d) 
                                                                      << 7U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b23__05d) 
                                                                         << 6U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b22__05d) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b21__05d) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b20__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b19__05d) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b18__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b17__05d)))))))))))))))));
    vlSelf->wasmetal_core__DOT___036005_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b51__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071838_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b50__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b50__05d)))))))));
    vlSelf->wasmetal_core__DOT___036004_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b50__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071837_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b49__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___035998_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b45__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071832_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b44__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b44__05d)))))))));
    vlSelf->wasmetal_core__DOT___035997_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b44__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071831_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b43__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b43__05d)))))))));
    vlSelf->wasmetal_core__DOT___035996_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b43__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071830_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b42__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b42__05d)))))))));
    vlSelf->wasmetal_core__DOT___035995_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b42__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071829_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b41__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b41__05d)))))))));
    vlSelf->wasmetal_core__DOT___035994_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b41__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071828_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b40__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b40__05d)))))))));
    vlSelf->wasmetal_core__DOT___035993_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b40__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071827_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b39__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b39__05d)))))))));
    vlSelf->wasmetal_core__DOT___035991_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b39__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071826_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b38__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b38__05d)))))))));
    vlSelf->wasmetal_core__DOT___035990_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b38__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff0077ffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b38__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b37__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b37__05d))))));
    vlSelf->wasmetal_core__DOT___035989_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b37__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071824_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b36__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b36__05d)))))))));
    vlSelf->wasmetal_core__DOT___035988_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b36__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071823_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b35__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b35__05d)))))))));
    vlSelf->wasmetal_core__DOT___035983_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b31__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071818_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b30__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b30__05d)))))))));
    vlSelf->wasmetal_core__DOT___035982_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b30__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071817_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b29__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b29__05d)))))))));
    vlSelf->wasmetal_core__DOT___035980_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b29__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071816_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b28__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b28__05d)))))))));
    vlSelf->wasmetal_core__DOT___035979_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071815_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b27__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b27__05d)))))))));
    vlSelf->wasmetal_core__DOT___035978_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b27__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071814_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b26__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b26__05d)))))))));
    vlSelf->wasmetal_core__DOT___035977_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b26__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071813_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b25__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b25__05d)))))))));
    vlSelf->wasmetal_core__DOT___035976_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b25__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071812_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b24__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b24__05d)))))))));
    vlSelf->wasmetal_core__DOT___035975_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b24__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071811_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b23__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b23__05d)))))))));
    vlSelf->wasmetal_core__DOT___035973_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b22__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071809_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b21__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b21__05d)))))))));
    vlSelf->wasmetal_core__DOT___035971_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b20__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071807_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b19__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b19__05d)))))))));
    vlSelf->wasmetal_core__DOT___035969_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b19__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071806_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b18__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b18__05d)))))))));
    vlSelf->wasmetal_core__DOT___035968_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b18__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071805_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b17__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b17__05d)))))))));
    vlSelf->wasmetal_core__DOT___035967_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b17__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071804_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b16__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b16__05d)))))))));
    vlSelf->wasmetal_core__DOT___035965_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b15__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071802_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b14__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b14__05d)))))))));
    vlSelf->wasmetal_core__DOT___035963_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b13__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071800_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b12__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b12__05d)))))))));
    vlSelf->wasmetal_core__DOT___035962_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b12__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071799_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b11__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b11__05d)))))))));
    vlSelf->wasmetal_core__DOT___035961_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b11__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071798_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b10__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b10__05d)))))))));
    vlSelf->wasmetal_core__DOT___035960_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b10__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071797_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b9__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b9__05d)))))))));
    vlSelf->wasmetal_core__DOT___036014_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b9__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071796_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b8__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b8__05d)))))))));
    vlSelf->wasmetal_core__DOT___036013_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b8__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071795_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b7__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b7__05d)))))))));
    vlSelf->wasmetal_core__DOT___036012_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b7__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071794_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b6__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b6__05d)))))))));
    vlSelf->wasmetal_core__DOT___036011_ = (1U & (0x8f70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b6__05d) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xffff00bbffff0f0fULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOpOut) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048948_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ediv_significand__05b6__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b5__05d) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h2c6daa45__0))))))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b5__05d))))));
    vlSelf->wasmetal_core__DOT___036010_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b5__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071792_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b4__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b4__05d)))))))));
    vlSelf->wasmetal_core__DOT___036003_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071791_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b3__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b3__05d)))))))));
    vlSelf->wasmetal_core__DOT___035992_ = (1U & (IData)(
                                                         (0xffffeac00000153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b3__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___071790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02efractB_Z__05b2__05d) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hb0c92cfa__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b2__05d)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b54__05d 
        = (1U & (0x4f44U >> ((8U & ((8U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b53__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT___036006_ = (1U & (0xf8ff0700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b52__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___071839_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___071787_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b51__05d)))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b2__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b1__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b1__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem__05b1__05d 
        = (1U & (0xf444U >> ((8U & ((4U >> (IData)(vlSelf->__VdfgTmp_h9a302586__0)) 
                                    << 3U)) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b0__05d) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02erem_Z__05b0__05d) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___048948_))))));
    vlSelf->wasmetal_core__DOT____Vcellout___127550___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023429_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023428_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023427_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023426_)))) 
           ^ (((IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127550___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023437_)))));
    vlSelf->wasmetal_core__DOT___023441_ = ((IData)(vlSelf->wasmetal_core__DOT___023429_)
                                             ? (IData)(wasmetal_core__DOT___127550___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023429_));
    vlSelf->wasmetal_core__DOT___043122_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h08ed86fa__0))));
    vlSelf->wasmetal_core__DOT___017205_ = ((IData)(vlSelf->wasmetal_core__DOT___017270_) 
                                            & (IData)(
                                                      (0x1000000000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___017269_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017268_) 
                                                            << 4U) 
                                                           | (((IData)(wasmetal_core__DOT___017267_) 
                                                               << 3U) 
                                                              | (((IData)(wasmetal_core__DOT___017266_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h08ed86fa__0))))))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0)))) {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02eb__05b53__05d;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b53__05d;
    } else {
        vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128789___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128779___DOT__CO__BRA__0__KET__;
        vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128775___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___134179___DOT__CO__BRA__1__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___036954_)) 
                 & (6U >> (IData)(vlSelf->__VdfgTmp_hb08bdf67__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___127567___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023550_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023549_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023548_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023547_)))) 
           ^ (((IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127567___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023558_)))));
    vlSelf->wasmetal_core__DOT___023562_ = ((IData)(vlSelf->wasmetal_core__DOT___023550_)
                                             ? (IData)(wasmetal_core__DOT___127567___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT___023550_));
    vlSelf->wasmetal_core__DOT___071908_ = (1U & (0x1000afbfU 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___CO) 
                                                       << 1U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__decoded_table)))))));
    vlSelf->wasmetal_core__DOT___045015_ = (1U & (IData)(
                                                         (0xfcfc4054fcfcfcfcULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b48__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___CO) 
                                                                        >> 1U)) 
                                                                    | ((2U 
                                                                        & ((0xaf3f0000U 
                                                                            >> 
                                                                            ((0x10U 
                                                                              & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                                                << 1U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__decoded_table) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___045759_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b47__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___054247_)))))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b49__05d)))))))));
    vlSelf->wasmetal_core__DOT___071338_ = (1U & (6U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127882___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___071337_))));
    vlSelf->wasmetal_core__DOT___054450_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___045219_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___045243_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070783_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070782_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___CO) 
                                                                          >> 3U)))))))));
    vlSelf->wasmetal_core__DOT___054446_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___054448_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127933___O)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045777_))));
    vlSelf->wasmetal_core__DOT___044947_ = (1U & (IData)(
                                                         (0xfeeaeaea00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                     << 1U)) 
                                                                 | ((4U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                             >> 3U))))))))));
    vlSelf->wasmetal_core__DOT___044971_ = (1U & (IData)(
                                                         (0x1ff100004004000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___070886_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___070885_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___045777_) 
                                                                  << 3U) 
                                                                 | ((6U 
                                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___O) 
                                                                        >> 1U)) 
                                                                    | (1U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127916___CO) 
                                                                          >> 3U)))))))));
}
