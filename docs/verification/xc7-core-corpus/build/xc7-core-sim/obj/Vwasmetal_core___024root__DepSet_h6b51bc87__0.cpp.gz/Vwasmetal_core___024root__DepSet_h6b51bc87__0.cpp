#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

#ifdef VL_DEBUG
VL_ATTR_COLD void Vwasmetal_core___024root___dump_triggers__ico(Vwasmetal_core___024root* vlSelf);
#endif  // VL_DEBUG

void Vwasmetal_core___024root___eval_triggers__ico(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___eval_triggers__ico\n"); );
    // Body
    vlSelf->__VicoTriggered.set(0U, (IData)(vlSelf->__VicoFirstIteration));
#ifdef VL_DEBUG
    if (VL_UNLIKELY(vlSymsp->_vm_contextp__->debug())) {
        Vwasmetal_core___024root___dump_triggers__ico(vlSelf);
    }
#endif
}

VL_INLINE_OPT void Vwasmetal_core___024root___ico_sequent__TOP__3(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___ico_sequent__TOP__3\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___000357_;
    wasmetal_core__DOT___000357_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___001235_;
    wasmetal_core__DOT___001235_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___019356_;
    wasmetal_core__DOT___019356_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043138_;
    wasmetal_core__DOT___043138_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043582_;
    wasmetal_core__DOT___043582_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044115_;
    wasmetal_core__DOT___044115_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044157_;
    wasmetal_core__DOT___044157_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044224_;
    wasmetal_core__DOT___044224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045666_;
    wasmetal_core__DOT___045666_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045709_;
    wasmetal_core__DOT___045709_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045726_;
    wasmetal_core__DOT___045726_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___045738_;
    wasmetal_core__DOT___045738_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048375_;
    wasmetal_core__DOT___048375_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051191_;
    wasmetal_core__DOT___051191_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___052838_;
    wasmetal_core__DOT___052838_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053756_;
    wasmetal_core__DOT___053756_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___053760_;
    wasmetal_core__DOT___053760_ = 0;
    CData/*2:0*/ __VdfgTmp_hcc483c10__0;
    __VdfgTmp_hcc483c10__0 = 0;
    CData/*1:0*/ __VdfgTmp_he81561f4__0;
    __VdfgTmp_he81561f4__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf2823744__0;
    __VdfgTmp_hf2823744__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9205a979__0;
    __VdfgTmp_h9205a979__0 = 0;
    // Body
    vlSelf->wasmetal_core__DOT___048377_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048333_ = (1U & (IData)(
                                                         (0x1ffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048327_)))))))));
    __VdfgTmp_hf2823744__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048328_));
    vlSelf->wasmetal_core__DOT___048402_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048403_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048412_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    vlSelf->wasmetal_core__DOT___048472_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048328_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048327_)))));
    vlSelf->wasmetal_core__DOT___048385_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048328_))));
    wasmetal_core__DOT___053760_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    vlSelf->wasmetal_core__DOT___048287_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048283_))))));
    vlSelf->wasmetal_core__DOT___048413_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    vlSelf->wasmetal_core__DOT___048405_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048284_))));
    __VdfgTmp_he81561f4__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048284_));
    vlSelf->wasmetal_core__DOT___047790_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h84a34a18__0)))));
    vlSelf->wasmetal_core__DOT___002964_ = (1U & (IData)(
                                                         (0xf78fffffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_h84a34a18__0)))));
    vlSelf->wasmetal_core__DOT___053780_ = (1U & (IData)(
                                                         (0xfff1f1f1f1ffffffULL 
                                                          >> 
                                                          ((0x3cU 
                                                            & (vlSelf->insn_op 
                                                               >> 2U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___010007_))))));
    vlSelf->wasmetal_core__DOT___053765_ = (1U & (0x1110fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010006_)))))));
    wasmetal_core__DOT___048375_ = (1U & (0xf8880000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))));
    vlSelf->wasmetal_core__DOT___048318_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    vlSelf->wasmetal_core__DOT___048437_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    __VdfgTmp_h9205a979__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048314_));
    vlSelf->wasmetal_core__DOT___048466_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048326_)))));
    vlSelf->wasmetal_core__DOT___048473_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___010007_)))))));
    vlSelf->wasmetal_core__DOT___048325_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048314_))));
    vlSelf->wasmetal_core__DOT___060712_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))));
    wasmetal_core__DOT___053756_ = (1U & (8U >> (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                  << 1U) 
                                                 | (1U 
                                                    & (8U 
                                                       >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    vlSelf->wasmetal_core__DOT___048341_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)))))));
    vlSelf->wasmetal_core__DOT___048347_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    vlSelf->wasmetal_core__DOT___048360_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0))))));
    __VdfgTmp_hcc483c10__0 = (((IData)(vlSelf->wasmetal_core__DOT___048320_) 
                               << 2U) | ((2U & ((8U 
                                                 >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                << 1U)) 
                                         | (1U & (8U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))));
    if (vlSelf->wasmetal_core__DOT___001233_) {
        vlSelf->wasmetal_core__DOT___002977_ = (1U 
                                                & (IData)(
                                                          (0xfffffff01111111ULL 
                                                           >> 
                                                           ((0x20U 
                                                             & ((0xfffeU 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                << 5U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 4U) 
                                                               | ((8U 
                                                                   & ((0x8000U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                      << 3U)) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hec761a3f__0))))))));
        vlSelf->wasmetal_core__DOT___003039_ = (1U 
                                                & ((1U 
                                                    & (0xfffeU 
                                                       >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___001246_)
                                                    : (IData)(
                                                              (0x1111111111111ULL 
                                                               >> 
                                                               ((0x20U 
                                                                 & ((0x8000U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                    << 5U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                          << 2U) 
                                                                         | ((2U 
                                                                             & ((0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                                << 1U)) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___001240_))))))))));
    } else {
        vlSelf->wasmetal_core__DOT___002977_ = (1U 
                                                & (0x7fU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & ((0x8000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                           << 1U)) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___000366_)))));
        vlSelf->wasmetal_core__DOT___003039_ = (1U 
                                                & (IData)(vlSelf->wasmetal_core__DOT___001246_));
    }
    vlSelf->wasmetal_core__DOT___002963_ = (1U & (0xf1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0xfffeU 
                                                           >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hec761a3f__0)))));
    wasmetal_core__DOT___045666_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070629_))));
    vlSelf->wasmetal_core__DOT___053778_ = (1U & (IData)(
                                                         (0x10101ffffffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___048361_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h755be032__0))));
    vlSelf->wasmetal_core__DOT___048382_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h755be032__0))))));
    vlSelf->wasmetal_core__DOT___048362_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h755be032__0))))));
    vlSelf->wasmetal_core__DOT___048269_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h755be032__0))));
    wasmetal_core__DOT___044224_ = (1U & (4U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h94b1bf18__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)))));
    wasmetal_core__DOT___045738_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h94b1bf18__0))))));
    vlSelf->wasmetal_core__DOT___047963_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000368_)) 
                                                  | ((1U 
                                                      & (8U 
                                                         >> 
                                                         (3U 
                                                          & (vlSelf->insn_op 
                                                             >> 6U))))
                                                      ? (IData)(
                                                                (0xafaf000fffff33ffULL 
                                                                 >> 
                                                                 ((0x20U 
                                                                   & ((8U 
                                                                       >> (IData)(vlSelf->__VdfgTmp_h3ca161df__0)) 
                                                                      << 5U)) 
                                                                  | ((0x10U 
                                                                      & (vlSelf->insn_op 
                                                                         << 2U)) 
                                                                     | ((8U 
                                                                         & ((4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                                            << 3U)) 
                                                                        | ((4U 
                                                                            & ((8U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                                               << 2U)) 
                                                                           | (IData)(vlSelf->__VdfgTmp_h94b1bf18__0)))))))
                                                      : 
                                                     (0xf7U 
                                                      >> 
                                                      ((4U 
                                                        & vlSelf->insn_op) 
                                                       | ((2U 
                                                           & ((4U 
                                                               >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)) 
                                                              << 1U)) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___001234_)))))));
    vlSelf->__VdfgTmp_h88a73cb4__0 = (((IData)(vlSelf->wasmetal_core__DOT___003009_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___002965_));
    vlSelf->wasmetal_core__DOT___053017_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053009_))));
    vlSelf->wasmetal_core__DOT___051565_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048005_)))));
    vlSelf->wasmetal_core__DOT___005571_ = (1U & (0x7fd5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_product__05b31__05d) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048005_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__simd_phase)))))));
    vlSelf->wasmetal_core__DOT___052889_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051568_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048275_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___047979_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          >> 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___047794_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___047793_)))))));
    vlSelf->wasmetal_core__DOT___048419_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000368_))));
    wasmetal_core__DOT___001235_ = (1U & (0x1fU >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___001231_)))));
    vlSelf->__VdfgTmp_h9fdaf630__0 = (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048424_));
    vlSelf->wasmetal_core__DOT___051564_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051563_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___054457_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051563_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048328_)))))));
    vlSelf->wasmetal_core__DOT___000125_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x1000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdd61004f__0)))));
    vlSelf->wasmetal_core__DOT___051253_ = (1U & (0x4000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hdd61004f__0)))));
    vlSelf->wasmetal_core__DOT___052643_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___052838_ = (1U & (0x40U >> 
                                          ((4U & ((0x1000U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048445_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048433_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___000357_ = (1U & (0x40U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                            << 2U) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___051191_ = (1U & (0x40U >> 
                                          ((4U & ((0x1000U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                  << 2U)) 
                                           | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___048425_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    vlSelf->wasmetal_core__DOT___052647_ = (1U & (0x40U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdd61004f__0))));
    wasmetal_core__DOT___044115_ = (1U & (8U >> ((2U 
                                                  & (vlSelf->insn_op 
                                                     >> 1U)) 
                                                 | (1U 
                                                    & (4U 
                                                       >> (IData)(vlSelf->__VdfgTmp_h323e8784__0))))));
    wasmetal_core__DOT___045709_ = (1U & (4U >> ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h323e8784__0)) 
                                                     << 1U)) 
                                                 | (1U 
                                                    & (vlSelf->insn_op 
                                                       >> 2U)))));
    vlSelf->wasmetal_core__DOT___003092_ = (1U & (0xf1ff0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047787_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xfffeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___002984_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___002985_)))))));
    vlSelf->wasmetal_core__DOT___054736_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d)))));
    vlSelf->wasmetal_core__DOT___054737_ = (1U & (0x75U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048307_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & vlSelf->insn_op)))));
    vlSelf->wasmetal_core__DOT___054729_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->__VdfgTmp_hbec427aa__0 = (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048307_));
    vlSelf->wasmetal_core__DOT___048453_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___048305_ = (1U & (0x40U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))));
    vlSelf->wasmetal_core__DOT___047953_ = (1U & ((4U 
                                                   & vlSelf->insn_op)
                                                   ? 
                                                  ((2U 
                                                    & vlSelf->insn_op)
                                                    ? (IData)(
                                                              (0xffffffffb0bbbbbbULL 
                                                               >> 
                                                               ((0x20U 
                                                                 & (vlSelf->insn_op 
                                                                    << 5U)) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                    << 4U) 
                                                                   | ((8U 
                                                                       & ((0x4000U 
                                                                           >> 
                                                                           (0xfU 
                                                                            & (vlSelf->insn_op 
                                                                               >> 4U))) 
                                                                          << 3U)) 
                                                                      | ((4U 
                                                                          & (vlSelf->insn_op 
                                                                             >> 1U)) 
                                                                         | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0)))))))
                                                    : 
                                                   (0xbfU 
                                                    >> 
                                                    ((4U 
                                                      & (vlSelf->insn_op 
                                                         << 2U)) 
                                                     | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))))
                                                   : 
                                                  ((vlSelf->insn_op 
                                                    >> 1U) 
                                                   | (0x7fU 
                                                      >> 
                                                      (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                        << 2U) 
                                                       | ((2U 
                                                           & ((0x4000U 
                                                               >> 
                                                               (0xfU 
                                                                & (vlSelf->insn_op 
                                                                   >> 4U))) 
                                                              << 1U)) 
                                                          | (1U 
                                                             & (vlSelf->insn_op 
                                                                >> 3U))))))));
    if (vlSelf->wasmetal_core__DOT___043133_) {
        wasmetal_core__DOT___043138_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___043141_)
                                               ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                               : (IData)(vlSelf->wasmetal_core__DOT___043139_)));
        vlSelf->wasmetal_core__DOT___043283_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___043286_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043284_)));
        vlSelf->wasmetal_core__DOT___043129_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___043135_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___135104___DOT__CO__BRA__0__KET__)
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043131_)));
        wasmetal_core__DOT___043582_ = ((IData)(vlSelf->wasmetal_core__DOT___043141_) 
                                        | (IData)(vlSelf->wasmetal_core__DOT___043583_));
        vlSelf->wasmetal_core__DOT___043673_ = ((IData)(vlSelf->wasmetal_core__DOT___043286_) 
                                                | (IData)(vlSelf->wasmetal_core__DOT___043674_));
    } else {
        wasmetal_core__DOT___043138_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        vlSelf->wasmetal_core__DOT___043283_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        vlSelf->wasmetal_core__DOT___043129_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___043133_)));
        wasmetal_core__DOT___043582_ = 0U;
        vlSelf->wasmetal_core__DOT___043673_ = 0U;
    }
    vlSelf->wasmetal_core__DOT___045642_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045646_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135390___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045643_))))));
    vlSelf->wasmetal_core__DOT___045652_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___044076_) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___045654_))))));
    vlSelf->wasmetal_core__DOT___045682_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045687_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__)
                                                         : 
                                                        (~ 
                                                         (vlSelf->insn_op 
                                                          >> 7U)))))));
    vlSelf->wasmetal_core__DOT___045672_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045676_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045673_))))));
    vlSelf->wasmetal_core__DOT___042536_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044061_))));
    vlSelf->wasmetal_core__DOT___045693_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT___045697_)
                                                         ? (IData)(vlSelf->wasmetal_core__DOT___135386___DOT__CO__BRA__0__KET__)
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045694_))))));
    vlSelf->wasmetal_core__DOT___063445_ = (1U & (IData)(
                                                         (0xa03fafc0a000a00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->mem_fault) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__state__05b2__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xff33330f0faaaaULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                                << 4U) 
                                                                                | ((8U 
                                                                                & ((1U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0ff1168c__0))))))))))))))));
    wasmetal_core__DOT___019356_ = (1U & (0xca00U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                               << 2U) 
                                              | ((2U 
                                                  & ((4U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h56fc5986__0)) 
                                                     << 1U)) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___052953_))))));
    vlSelf->wasmetal_core__DOT___053282_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052953_))));
    vlSelf->wasmetal_core__DOT___052955_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052952_))));
    vlSelf->wasmetal_core__DOT___061659_ = (1U & (IData)(
                                                         (0xf0f0f0f03355ffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056501_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056336_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d)))))))));
    vlSelf->wasmetal_core__DOT___061999_ = (1U & (IData)(
                                                         (0xff55550f0f3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057095_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057205_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057127_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057129_)))))))));
    vlSelf->wasmetal_core__DOT___061924_ = (1U & (IData)(
                                                         (0x5533fffff0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___056967_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___056983_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))))))));
    vlSelf->wasmetal_core__DOT___061861_ = (1U & (IData)(
                                                         (0x3333555500ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056730_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056745_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___056777_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056768_)))))))));
    vlSelf->wasmetal_core__DOT___061771_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___056597_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___056599_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___011458_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___056623_)))))))));
    vlSelf->wasmetal_core__DOT___062112_ = (1U & (IData)(
                                                         (0x333355550f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___057390_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___057384_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___057443_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___057449_)))))))));
    vlSelf->wasmetal_core__DOT___062169_ = (1U & (IData)(
                                                         (0x3355fffff0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x53U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___057571_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___057574_)))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))))))));
    vlSelf->__VdfgTmp_h470ae9e3__0 = (((IData)(vlSelf->wasmetal_core__DOT___011519_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011518_));
    vlSelf->__VdfgTmp_hadb47ff7__0 = (((IData)(vlSelf->wasmetal_core__DOT___011125_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___011124_));
    vlSelf->__VdfgTmp_h3c2b613a__0 = (((IData)(vlSelf->wasmetal_core__DOT___010537_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010540_));
    vlSelf->__VdfgTmp_hf37b3ae8__0 = (((IData)(vlSelf->wasmetal_core__DOT___010538_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010537_));
    vlSelf->__VdfgTmp_he2e0905c__0 = (((IData)(vlSelf->wasmetal_core__DOT___010533_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010538_));
    vlSelf->__VdfgTmp_h2f9ca2ed__0 = (((IData)(vlSelf->wasmetal_core__DOT___010529_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___010528_));
    vlSelf->wasmetal_core__DOT___062054_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0xf0f333300ff5555ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___056324_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___010552_) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___010741_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010860_)))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x5555333300ff0f0fULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                         << 4U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___010918_) 
                                                                            << 3U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___056425_) 
                                                                               << 2U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___011125_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056436_)))))))))))));
    vlSelf->wasmetal_core__DOT___003011_ = (1U & (0x1fffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h11a2e1d4__0)))));
    vlSelf->wasmetal_core__DOT___047982_ = (1U & (0x777ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_haec53eda__0))))));
    vlSelf->wasmetal_core__DOT___002969_ = (1U & (0x53fffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((0x8000U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((0x8000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_haec53eda__0))))));
    vlSelf->wasmetal_core__DOT___048379_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048315_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000354_)))));
    vlSelf->wasmetal_core__DOT___048317_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048315_))));
    vlSelf->wasmetal_core__DOT___044194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070609_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (vlSelf->insn_op 
                                                         >> 2U)))));
    vlSelf->wasmetal_core__DOT___045719_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & (vlSelf->insn_op 
                                                       >> 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070609_))));
    wasmetal_core__DOT___045726_ = (1U & (4U >> (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___070609_))));
    vlSelf->wasmetal_core__DOT___046017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
    vlSelf->wasmetal_core__DOT___046019_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070489_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___070486_))));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_z >> 5U) & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__ 
        = (1U & ((0x20U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 5U) : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__0__KET__)));
    vlSelf->wasmetal_core__DOT___050456_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050454_))));
    vlSelf->wasmetal_core__DOT___068622_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068619_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x11U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1aU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068719_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068716_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x13U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1cU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068819_ = (1U & (0xbbb0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068816_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & (vlSelf->mem_rdata[1U] 
                                                             >> 0x15U)) 
                                                         | ((2U 
                                                             & (vlSelf->mem_rdata[0U] 
                                                                >> 0x1eU)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___065567_)))))));
    vlSelf->wasmetal_core__DOT___068915_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067623_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068912_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067039_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x19U))))))))));
    vlSelf->wasmetal_core__DOT___068874_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067569_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___068869_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7eff58ec__0))))));
    vlSelf->wasmetal_core__DOT___068982_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067704_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___068979_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067108_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1aU))))))))));
    vlSelf->wasmetal_core__DOT___069013_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067772_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069010_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067215_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1bU))))))))));
    vlSelf->wasmetal_core__DOT___069175_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067935_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069172_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067426_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1eU))))))))));
    vlSelf->wasmetal_core__DOT___069215_ = (1U & (0x7000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067986_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___069211_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h7e1b7882__0))))));
    vlSelf->wasmetal_core__DOT___069108_ = (1U & (IData)(
                                                         (0x7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___068870_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067864_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___069105_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067359_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___067570_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (vlSelf->mem_rdata[1U] 
                                                                             >> 0x1dU))))))))));
    vlSelf->wasmetal_core__DOT___065031_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065028_))))))));
    vlSelf->wasmetal_core__DOT___065148_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065145_))))))));
    vlSelf->wasmetal_core__DOT___065226_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065225_))));
    vlSelf->wasmetal_core__DOT___065383_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064836_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065382_))));
    vlSelf->wasmetal_core__DOT___065488_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065487_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128482___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032891_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032888_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___032877_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___032866_)))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032859_ = ((IData)(vlSelf->wasmetal_core__DOT___032891_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128482___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT___065512_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065145_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065511_))));
    vlSelf->wasmetal_core__DOT___065652_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065225_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065651_))));
    vlSelf->wasmetal_core__DOT___065764_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065763_))));
    vlSelf->wasmetal_core__DOT___065847_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065487_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065846_))));
    vlSelf->wasmetal_core__DOT___065959_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065511_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065958_))));
    vlSelf->wasmetal_core__DOT___066030_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065651_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066029_))));
    vlSelf->wasmetal_core__DOT___066183_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065763_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066182_))));
    vlSelf->wasmetal_core__DOT___066228_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065846_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066227_))));
    vlSelf->wasmetal_core__DOT___064444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064429_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064428_))));
    vlSelf->wasmetal_core__DOT___066339_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065958_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066338_))));
    vlSelf->wasmetal_core__DOT___064694_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064687_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064686_))));
    vlSelf->wasmetal_core__DOT___066437_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066029_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066436_))));
    vlSelf->wasmetal_core__DOT___064864_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064861_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064860_))));
    vlSelf->wasmetal_core__DOT___066503_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066182_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066502_))));
    vlSelf->wasmetal_core__DOT___065019_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065018_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065017_))));
    vlSelf->wasmetal_core__DOT___066584_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066227_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066583_))));
    vlSelf->wasmetal_core__DOT___065132_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064428_))));
    vlSelf->wasmetal_core__DOT___066698_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066338_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066697_))));
    vlSelf->wasmetal_core__DOT___066751_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066436_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066750_))));
    vlSelf->wasmetal_core__DOT___065374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064860_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065373_))));
    vlSelf->wasmetal_core__DOT___066833_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066502_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066832_))));
    vlSelf->wasmetal_core__DOT___066917_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066916_))));
    vlSelf->wasmetal_core__DOT___064407_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064382_))));
    vlSelf->wasmetal_core__DOT___067001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066697_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067000_))));
    vlSelf->wasmetal_core__DOT___064681_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064673_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064672_))));
    vlSelf->wasmetal_core__DOT___067046_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066750_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067045_))));
    vlSelf->wasmetal_core__DOT___070431_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069958_))));
    vlSelf->wasmetal_core__DOT___067131_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066832_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067130_))));
    vlSelf->wasmetal_core__DOT___065016_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065012_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065011_))));
    vlSelf->wasmetal_core__DOT___067242_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066916_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067241_))));
    vlSelf->wasmetal_core__DOT___069937_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069287_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065131_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064382_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064405_))));
    vlSelf->wasmetal_core__DOT___067281_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067280_))));
    vlSelf->wasmetal_core__DOT___065219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064672_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064679_))));
    vlSelf->wasmetal_core__DOT___067386_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067045_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067385_))));
    vlSelf->wasmetal_core__DOT___069915_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (2U 
                                                         & ((1U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___069267_)) 
                                                            << 1U))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___065376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064858_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064856_))));
    vlSelf->wasmetal_core__DOT___067433_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067130_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067432_))));
    vlSelf->wasmetal_core__DOT___065481_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065011_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065014_))));
    vlSelf->wasmetal_core__DOT___067530_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067241_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067529_))));
    vlSelf->wasmetal_core__DOT___069344_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069218_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065007_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065006_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___069321_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069186_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___069266_))))));
    vlSelf->wasmetal_core__DOT___064851_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064850_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064354_))))));
    vlSelf->wasmetal_core__DOT___069288_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069119_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069287_))));
    vlSelf->wasmetal_core__DOT___064664_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064663_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064662_))));
    vlSelf->wasmetal_core__DOT___064406_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064405_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064404_))));
    vlSelf->wasmetal_core__DOT___067578_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067577_))));
    vlSelf->wasmetal_core__DOT___064680_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064679_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064678_))));
    vlSelf->wasmetal_core__DOT___067644_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067385_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067643_))));
    vlSelf->wasmetal_core__DOT___069268_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069071_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069267_))));
    vlSelf->wasmetal_core__DOT___064358_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064356_))));
    vlSelf->wasmetal_core__DOT___064859_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064856_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064855_))));
    vlSelf->wasmetal_core__DOT___067712_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067711_))));
    vlSelf->wasmetal_core__DOT___065015_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065014_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065013_))));
    vlSelf->wasmetal_core__DOT___067791_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067529_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067790_))));
    vlSelf->wasmetal_core__DOT___069219_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069024_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069218_))));
    vlSelf->wasmetal_core__DOT___065477_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065003_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065006_))));
    vlSelf->wasmetal_core__DOT___069187_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068993_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069186_))));
    vlSelf->wasmetal_core__DOT___065370_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064850_))));
    vlSelf->wasmetal_core__DOT___065130_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064404_))));
    vlSelf->wasmetal_core__DOT___067840_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067839_))));
    vlSelf->wasmetal_core__DOT___069120_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068926_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069119_))));
    vlSelf->wasmetal_core__DOT___065215_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064656_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064663_))));
    vlSelf->wasmetal_core__DOT___069025_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068830_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069024_))));
    vlSelf->wasmetal_core__DOT___069072_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068877_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069071_))));
    vlSelf->wasmetal_core__DOT___065008_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065004_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065003_))));
    vlSelf->wasmetal_core__DOT___065138_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064334_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064357_))));
    vlSelf->wasmetal_core__DOT___065218_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064678_))));
    vlSelf->wasmetal_core__DOT___067883_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067882_))));
    vlSelf->wasmetal_core__DOT___065375_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064855_))));
    vlSelf->wasmetal_core__DOT___067943_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067711_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067942_))));
    vlSelf->wasmetal_core__DOT___065480_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065013_))));
    vlSelf->wasmetal_core__DOT___068006_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067790_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068005_))));
    vlSelf->wasmetal_core__DOT___064313_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064289_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064288_))));
    vlSelf->wasmetal_core__DOT___068059_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067839_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068058_))));
    vlSelf->wasmetal_core__DOT___068994_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068993_))));
    vlSelf->wasmetal_core__DOT___064852_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064848_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064847_))));
    vlSelf->wasmetal_core__DOT___064651_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064642_))));
    vlSelf->wasmetal_core__DOT___068134_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067882_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068133_))));
    vlSelf->wasmetal_core__DOT___065002_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064998_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064997_))));
    vlSelf->wasmetal_core__DOT___064846_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064842_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064841_))));
    vlSelf->wasmetal_core__DOT___065136_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064288_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064311_))));
    vlSelf->wasmetal_core__DOT___068220_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068219_))));
    vlSelf->wasmetal_core__DOT___068186_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067942_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068185_))));
    vlSelf->wasmetal_core__DOT___068273_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068058_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068272_))));
    vlSelf->wasmetal_core__DOT___065213_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064642_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064649_))));
    vlSelf->wasmetal_core__DOT___068326_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068325_))));
    vlSelf->wasmetal_core__DOT___068927_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068730_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068926_))));
    vlSelf->wasmetal_core__DOT___064665_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064657_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064656_))));
    vlSelf->wasmetal_core__DOT___065368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064841_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064844_))));
    vlSelf->wasmetal_core__DOT___068382_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068185_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068381_))));
    vlSelf->wasmetal_core__DOT___064359_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064335_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064334_))));
    vlSelf->wasmetal_core__DOT___068878_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068683_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068877_))));
    vlSelf->wasmetal_core__DOT___065475_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064997_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065000_))));
    vlSelf->wasmetal_core__DOT___068457_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068219_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068456_))));
    vlSelf->wasmetal_core__DOT___065212_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064648_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064657_))));
    vlSelf->wasmetal_core__DOT___064650_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064649_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064648_))));
    vlSelf->wasmetal_core__DOT___065001_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065000_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064999_))));
    vlSelf->wasmetal_core__DOT___065474_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064999_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065004_))));
    vlSelf->wasmetal_core__DOT___065367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064843_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064848_))));
    vlSelf->wasmetal_core__DOT___064845_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064844_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064843_))));
    vlSelf->wasmetal_core__DOT___065135_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064310_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064335_))));
    vlSelf->wasmetal_core__DOT___064312_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064311_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064310_))));
    vlSelf->wasmetal_core__DOT___068831_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068830_))));
    vlSelf->wasmetal_core__DOT___068634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068633_))));
    vlSelf->wasmetal_core__DOT___068731_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068730_))));
    vlSelf->wasmetal_core__DOT___068520_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068325_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068519_))));
    vlSelf->wasmetal_core__DOT___068781_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068583_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068780_))));
    vlSelf->wasmetal_core__DOT___068584_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068381_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068583_))));
    vlSelf->wasmetal_core__DOT___068684_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068501_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068683_))));
    vlSelf->wasmetal_core__DOT___068502_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068272_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___068501_))));
    vlSelf->wasmetal_core__DOT___064948_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064940_))))))));
    vlSelf->wasmetal_core__DOT___065112_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128567___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065104_))))))));
    vlSelf->wasmetal_core__DOT___065245_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064589_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065244_))));
    vlSelf->wasmetal_core__DOT___065333_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064796_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065332_))));
    vlSelf->wasmetal_core__DOT___065444_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064940_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065443_))));
    vlSelf->wasmetal_core__DOT___067291_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b28__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067288_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066352_) 
                                                                  << 2U) 
                                                                 | ((2U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064132_)) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (4U 
                                                                          >> 
                                                                          ((IData)(vlSelf->wasmetal_core__DOT___064199_) 
                                                                           << 1U))))))))));
    vlSelf->wasmetal_core__DOT___065528_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065104_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065527_))));
    vlSelf->wasmetal_core__DOT___064964_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064963_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___067780_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067516_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___067547_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___064606_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064605_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___064812_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064811_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064130_))))));
    vlSelf->wasmetal_core__DOT___067634_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067372_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067633_))));
    vlSelf->wasmetal_core__DOT___067692_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067414_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___067548_))))));
    vlSelf->wasmetal_core__DOT___065668_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065244_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065667_))));
    vlSelf->wasmetal_core__DOT___064156_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067550_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067274_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067549_))));
    vlSelf->wasmetal_core__DOT___065863_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065443_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065862_))));
    vlSelf->wasmetal_core__DOT___065746_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065332_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065745_))));
    vlSelf->wasmetal_core__DOT___065979_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065527_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065978_))));
    vlSelf->__VdfgTmp_hf24dfeba__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064960_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064963_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((4U 
                                                    >> 
                                                    (2U 
                                                     & ((4U 
                                                         >> 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___064128_) 
                                                          << 1U)) 
                                                        << 1U))) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067517_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067228_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067516_))));
    vlSelf->wasmetal_core__DOT___066042_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065667_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066041_))));
    vlSelf->__VdfgTmp_hedd7926b__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064808_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064811_))) 
                                             << 1U)) 
                                      | (1U & (4U >> 
                                               (2U 
                                                & ((1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___064130_)) 
                                                   << 1U)))));
    vlSelf->wasmetal_core__DOT___067415_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067118_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067414_))));
    vlSelf->wasmetal_core__DOT___064197_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064178_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064177_))));
    vlSelf->wasmetal_core__DOT___066240_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065862_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066239_))));
    vlSelf->wasmetal_core__DOT___066171_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065745_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066170_))));
    if ((1U & (IData)((1ULL >> (vlSelf->insn_op >> 0x1aU))))) {
        if (vlSelf->wasmetal_core__DOT___044063_) {
            if (vlSelf->wasmetal_core__DOT___044062_) {
                if (vlSelf->wasmetal_core__DOT___044061_) {
                    vlSelf->wasmetal_core__DOT___044055_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044066_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045643_))));
                    vlSelf->wasmetal_core__DOT___044082_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044086_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (IData)(vlSelf->wasmetal_core__DOT___044083_)));
                    vlSelf->wasmetal_core__DOT__divider__02ewide 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044104_)
                                  ? (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                  : (vlSelf->insn_op 
                                     >> 7U)));
                    vlSelf->wasmetal_core__DOT___044092_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044096_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045673_))));
                    vlSelf->wasmetal_core__DOT___044230_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044234_) 
                                 | (IData)(vlSelf->wasmetal_core__DOT___044231_)));
                    wasmetal_core__DOT___044157_ = 
                        (1U & ((IData)(vlSelf->wasmetal_core__DOT___044162_)
                                ? ((4U >> (3U & vlSelf->insn_op)) 
                                   | (8U >> (IData)(vlSelf->__VdfgTmp_h2780d718__0)))
                                : (IData)(vlSelf->wasmetal_core__DOT___044158_)));
                    vlSelf->wasmetal_core__DOT___044072_ 
                        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044076_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (IData)(vlSelf->wasmetal_core__DOT___044073_)));
                    vlSelf->wasmetal_core__DOT___044220_ 
                        = (1U & ((IData)(wasmetal_core__DOT___044224_)
                                  ? (IData)(vlSelf->wasmetal_core__DOT___135236___DOT__CO__BRA__0__KET__)
                                  : (~ (IData)(vlSelf->wasmetal_core__DOT___045735_))));
                } else {
                    vlSelf->wasmetal_core__DOT___044055_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044082_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT__divider__02ewide 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044092_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044230_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    wasmetal_core__DOT___044157_ = 
                        (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044072_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                    vlSelf->wasmetal_core__DOT___044220_ 
                        = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)));
                }
            } else {
                vlSelf->wasmetal_core__DOT___044055_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044082_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT__divider__02ewide 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044092_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044230_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                wasmetal_core__DOT___044157_ = (1U 
                                                & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044072_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
                vlSelf->wasmetal_core__DOT___044220_ 
                    = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044062_)));
            }
        } else {
            vlSelf->wasmetal_core__DOT___044055_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044082_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT__divider__02ewide 
                = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044092_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044230_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            wasmetal_core__DOT___044157_ = (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044072_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
            vlSelf->wasmetal_core__DOT___044220_ = 
                (1U & (~ (IData)(vlSelf->wasmetal_core__DOT___044063_)));
        }
        if ((1U & (4U >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))) {
            vlSelf->wasmetal_core__DOT__decoded_table 
                = (1U & ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_he33f1ed5__0)))
                          ? ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                              ? ((IData)(wasmetal_core__DOT___044115_) 
                                 | (0xfffeU >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                              : (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                          : (IData)(vlSelf->wasmetal_core__DOT___044111_)));
            vlSelf->wasmetal_core__DOT___044180_ = 
                (1U & ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                        ? ((IData)(vlSelf->wasmetal_core__DOT___044061_)
                            ? ((~ (IData)(wasmetal_core__DOT___045726_)) 
                               | (IData)(vlSelf->wasmetal_core__DOT___044184_))
                            : (~ (IData)(vlSelf->wasmetal_core__DOT___044061_)))
                        : (IData)(vlSelf->wasmetal_core__DOT___044170_)));
        } else {
            vlSelf->wasmetal_core__DOT__decoded_table 
                = (1U & (0xeU >> (3U & (vlSelf->insn_op 
                                        >> 0x18U))));
            vlSelf->wasmetal_core__DOT___044180_ = 
                (1U & (0xeU >> (3U & (vlSelf->insn_op 
                                      >> 0x18U))));
        }
    } else {
        vlSelf->wasmetal_core__DOT___044055_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044082_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT__divider__02ewide 
            = (1U & (~ (IData)((1ULL >> (vlSelf->insn_op 
                                         >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044092_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044230_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        wasmetal_core__DOT___044157_ = (1U & (~ (IData)(
                                                        (1ULL 
                                                         >> 
                                                         (vlSelf->insn_op 
                                                          >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044072_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044220_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT__decoded_table = 
            (1U & (~ (IData)((1ULL >> (vlSelf->insn_op 
                                       >> 0x1aU)))));
        vlSelf->wasmetal_core__DOT___044180_ = (1U 
                                                & (~ (IData)(
                                                             (1ULL 
                                                              >> 
                                                              (vlSelf->insn_op 
                                                               >> 0x1aU)))));
    }
    vlSelf->wasmetal_core__DOT___066349_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065978_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066348_))));
    vlSelf->__VdfgTmp_ha0b0298a__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064598_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064605_))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064604_))));
    vlSelf->wasmetal_core__DOT___067373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067057_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067372_))));
    vlSelf->wasmetal_core__DOT___064621_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064613_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___066449_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066448_))));
    vlSelf->__VdfgTmp_h0f450401__0 = ((2U & ((0xf0f0aaccU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064133_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_he8a45048__0))) 
                                             << 1U)) 
                                      | (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___064132_))));
    vlSelf->wasmetal_core__DOT___067229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066927_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067228_))));
    vlSelf->wasmetal_core__DOT___067119_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066822_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067118_))));
    vlSelf->wasmetal_core__DOT___067275_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067010_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067274_))));
    vlSelf->wasmetal_core__DOT___064607_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064598_))));
    vlSelf->wasmetal_core__DOT___065239_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064599_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064612_))));
    vlSelf->wasmetal_core__DOT___065438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064966_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064961_))));
    vlSelf->wasmetal_core__DOT___064969_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064967_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064966_))));
    vlSelf->wasmetal_core__DOT___065327_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064814_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064809_))));
    vlSelf->wasmetal_core__DOT___064817_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064815_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064814_))));
    vlSelf->wasmetal_core__DOT___065114_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064177_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064154_))));
    vlSelf->wasmetal_core__DOT___067058_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067057_))));
    vlSelf->wasmetal_core__DOT___066738_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066448_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066737_))));
    vlSelf->wasmetal_core__DOT___066571_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066239_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066570_))));
    vlSelf->wasmetal_core__DOT___066928_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066570_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066927_))));
    vlSelf->wasmetal_core__DOT___066823_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066494_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066822_))));
    vlSelf->wasmetal_core__DOT___066495_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066170_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066494_))));
    vlSelf->wasmetal_core__DOT___066688_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066348_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066687_))));
    vlSelf->wasmetal_core__DOT___067011_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066687_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067010_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128010___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___027826_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___027823_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___027812_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___027801_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___027794_ = ((IData)(vlSelf->wasmetal_core__DOT___027826_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128010___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__callee_base__05b3__05d));
    vlSelf->wasmetal_core__DOT___064985_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___064981_))))))));
    vlSelf->__VdfgTmp_h2cdbdda9__0 = ((2U & ((0xacU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___064558_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___064557_))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___064561_));
    vlSelf->wasmetal_core__DOT___065097_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (8U 
                                                         >> 
                                                         (1U 
                                                          & (4U 
                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065091_))))))));
    vlSelf->wasmetal_core__DOT___065995_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065544_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064055_))));
    vlSelf->wasmetal_core__DOT___065270_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064544_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065269_))));
    vlSelf->wasmetal_core__DOT___066562_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066251_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___066359_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___066485_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066152_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___066360_))))));
    vlSelf->wasmetal_core__DOT___065357_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064779_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065356_))));
    vlSelf->wasmetal_core__DOT___065464_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064981_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065463_))));
    vlSelf->wasmetal_core__DOT___066428_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066055_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066427_))));
    vlSelf->wasmetal_core__DOT___064081_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064056_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064055_))));
    vlSelf->wasmetal_core__DOT___066362_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065989_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066361_))));
    vlSelf->wasmetal_core__DOT___065470_ = (1U & (IData)(
                                                         (0xaa330f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064989_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h9d56b9e6__0))))));
    vlSelf->wasmetal_core__DOT___064994_ = (1U & (IData)(
                                                         (0xf0f553300000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                            << 5U) 
                                                           | ((4U 
                                                               & ((0x5cU 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h9d56b9e6__0)) 
                                                                  << 2U)) 
                                                              | ((2U 
                                                                  & ((0xf0f05533U 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064564_) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___064069_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___064060_)))) 
                                                                     << 1U)) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___064989_)))))));
    vlSelf->wasmetal_core__DOT___064833_ = (1U & (IData)(
                                                         (0x5f3f0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064097_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064079_) 
                                                               << 4U) 
                                                              | ((4U 
                                                                  & ((0x20003fffU 
                                                                      >> 
                                                                      (((IData)(vlSelf->wasmetal_core__DOT___064788_) 
                                                                        << 4U) 
                                                                       | ((8U 
                                                                           & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                              << 2U)) 
                                                                          | ((4U 
                                                                              & ((8U 
                                                                                >> 
                                                                                (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128576___O) 
                                                                                >> 2U))) 
                                                                                << 2U)) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___064787_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064786_)))))) 
                                                                     << 2U)) 
                                                                 | ((2U 
                                                                     & ((0xf0f0aaccU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___064789_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064076_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064066_)))) 
                                                                        << 1U)) 
                                                                    | (1U 
                                                                       & (0x5cU 
                                                                          >> (IData)(vlSelf->__VdfgTmp_h23108600__0))))))))));
    vlSelf->wasmetal_core__DOT___065679_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065269_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065678_))));
    vlSelf->wasmetal_core__DOT___066056_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065678_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066055_))));
    vlSelf->wasmetal_core__DOT___065875_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065463_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065874_))));
    vlSelf->wasmetal_core__DOT___066252_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065874_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066251_))));
    vlSelf->wasmetal_core__DOT___065990_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065537_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065989_))));
    vlSelf->wasmetal_core__DOT___065538_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065091_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065537_))));
    vlSelf->wasmetal_core__DOT___066153_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065776_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066152_))));
    vlSelf->wasmetal_core__DOT___065777_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065356_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065776_))));
    vlSelf->wasmetal_core__DOT___064834_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(
                                                                  (0x200000003fffffffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___064829_) 
                                                                     << 5U) 
                                                                    | ((0x18U 
                                                                        & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                           << 3U)) 
                                                                       | ((4U 
                                                                           & ((8U 
                                                                               >> 
                                                                               (3U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128585___O) 
                                                                                >> 2U))) 
                                                                              << 2U)) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___064828_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___064827_))))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (IData)(
                                                                   (0x55330f00000000ULL 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                      << 5U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064228_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_ha92622e4__0))))))))));
    vlSelf->wasmetal_core__DOT___064251_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064244_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xa0aac0cc00ff00ffULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___064241_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                         << 2U) 
                                                                        | ((2U 
                                                                            & ((0xff003535U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064228_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                ((IData)(vlSelf->wasmetal_core__DOT___064224_) 
                                                                                << 1U)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & (vlSelf->mem_rdata[0U] 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___064226_))))) 
                                                                               << 1U)) 
                                                                           | (1U 
                                                                              & (0xacU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha92622e4__0)))))))))))));
    vlSelf->wasmetal_core__DOT___064954_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___064952_))))));
    vlSelf->wasmetal_core__DOT___066722_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065639_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___066667_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065548_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d))));
    vlSelf->wasmetal_core__DOT___065640_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065257_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065639_))));
    vlSelf->wasmetal_core__DOT___065258_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064571_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065257_))));
    vlSelf->wasmetal_core__DOT___065835_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065454_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___065546_) 
                                                               << 1U)) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065455_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064952_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065454_))));
    vlSelf->wasmetal_core__DOT___065124_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065122_))))));
    vlSelf->wasmetal_core__DOT___065973_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___065122_)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065548_)))))));
    vlSelf->__VdfgTmp_h20cdb85c__0 = (((IData)(vlSelf->wasmetal_core__DOT__load_lane__05b0__05d) 
                                       << 1U) | (1U 
                                                 & (0xacU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___065122_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___065548_)))));
    vlSelf->wasmetal_core__DOT___065346_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___064822_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065345_))));
    vlSelf->wasmetal_core__DOT___065735_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065345_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065547_))))));
    vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__1__KET__ 
        = ((vlSelf->insn_x >> 5U) & (IData)(vlSelf->wasmetal_core__DOT___128051___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___128042___DOT__CO__BRA__0__KET__ 
        = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___028091_)) 
                 & vlSelf->insn_x));
    vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__1__KET__ 
        = ((~ (vlSelf->function_params >> 5U)) & (IData)(vlSelf->wasmetal_core__DOT___128315___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___052871_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->function_valid) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___044693_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128466___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___032699_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___032696_) 
                        << 2U) | (IData)(vlSelf->__VdfgTmp_h74a82ee2__0))) 
           ^ (1U | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__) 
                     << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__1__KET__) 
                                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__0__KET__) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___032667_ = ((IData)(vlSelf->wasmetal_core__DOT___032699_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___128466___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__sp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___134208___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___037209_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___037206_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___037195_) 
                                   << 1U) | (1U & (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h2d9d1f69__0)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__) 
               << 3U) | ((IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__1__KET__) 
                         << 2U)));
    vlSelf->wasmetal_core__DOT___037178_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___037209_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134208___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (6U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h60140cd4__0))));
    vlSelf->wasmetal_core__DOT___026350_ = ((IData)(vlSelf->wasmetal_core__DOT___026382_)
                                             ? (IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__)
                                             : (IData)(vlSelf->wasmetal_core__DOT__fp__05b3__05d));
    vlSelf->wasmetal_core__DOT____Vcellout___127842___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___026382_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___026379_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___026368_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___026357_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__1__KET__) 
                          << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___127842___DOT__CO__BRA__0__KET__) 
                                    << 1U))));
    vlSelf->wasmetal_core__DOT___043576_ = ((IData)(vlSelf->wasmetal_core__DOT___043133_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___043135_) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___043578_)));
    vlSelf->wasmetal_core__DOT___053264_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003041_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003040_))));
    vlSelf->wasmetal_core__DOT___056255_ = (1U & (IData)(
                                                         (0x101010101ffffffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___052731_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048302_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___053779_ = (1U & (0x10101ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))));
    vlSelf->wasmetal_core__DOT___053754_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047783_))))));
    vlSelf->wasmetal_core__DOT___053757_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___019203_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hbcc95063__0)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048283_)))))));
    vlSelf->wasmetal_core__DOT___048456_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048321_)))));
    vlSelf->__VdfgTmp_h4ab35b3e__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048321_));
    vlSelf->wasmetal_core__DOT___048323_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048321_))));
    vlSelf->wasmetal_core__DOT___053332_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052953_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053331_))));
    vlSelf->wasmetal_core__DOT___070681_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071867_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054321_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___070784_ = (1U & (0xf770000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a)))))));
    vlSelf->wasmetal_core__DOT___071886_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054320_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b0__05d)))))));
    vlSelf->wasmetal_core__DOT___070682_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054329_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070687_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054335_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___070697_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054352_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___070702_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054358_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070712_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054370_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___070717_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054376_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___070727_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054388_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070732_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054394_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___070742_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054406_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070747_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054412_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___070757_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054424_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___070762_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054430_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___070772_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054442_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___070777_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054448_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___070692_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___070707_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054364_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___070722_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054382_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___070737_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054400_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___070752_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054418_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___070767_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054436_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___054477_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__memory_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___070785_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054328_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b4__05d)))))));
    vlSelf->wasmetal_core__DOT___070790_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054334_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 7U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b7__05d)))))));
    vlSelf->wasmetal_core__DOT___070800_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054351_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xcU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b13__05d)))))));
    vlSelf->wasmetal_core__DOT___070805_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0xfU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b16__05d)))))));
    vlSelf->wasmetal_core__DOT___070815_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054369_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x14U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b22__05d)))))));
    vlSelf->wasmetal_core__DOT___070820_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054375_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x17U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b25__05d)))))));
    vlSelf->wasmetal_core__DOT___070830_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054387_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b31__05d)))))));
    vlSelf->wasmetal_core__DOT___070835_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054393_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x1fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b34__05d)))))));
    vlSelf->wasmetal_core__DOT___070845_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054405_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x24U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b40__05d)))))));
    vlSelf->wasmetal_core__DOT___070850_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054411_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x27U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b43__05d)))))));
    vlSelf->wasmetal_core__DOT___070860_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054423_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2cU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b49__05d)))))));
    vlSelf->wasmetal_core__DOT___070865_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054429_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x2fU)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b52__05d)))))));
    vlSelf->wasmetal_core__DOT___070875_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054441_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x34U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b58__05d)))))));
    vlSelf->wasmetal_core__DOT___070880_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054447_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x37U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b61__05d)))))));
    vlSelf->wasmetal_core__DOT___070795_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054345_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 9U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b10__05d)))))));
    vlSelf->wasmetal_core__DOT___070810_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054363_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x11U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b19__05d)))))));
    vlSelf->wasmetal_core__DOT___070825_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054381_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x19U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b28__05d)))))));
    vlSelf->wasmetal_core__DOT___070840_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054399_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x21U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b37__05d)))))));
    vlSelf->wasmetal_core__DOT___070855_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054417_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x29U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b46__05d)))))));
    vlSelf->wasmetal_core__DOT___070870_ = (1U & (0xaac0553fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___054435_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067603_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT__table_bounds__02ewords__02e0__02e0.__PVT__data 
                                                                      >> 0x31U)) 
                                                             << 2U)) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__table_bounds__02evalid_a) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__memory_bounds__02ewrite_data__05b55__05d)))))));
    vlSelf->wasmetal_core__DOT___062990_ = (1U & (0xeU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((4U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h19b7a9a0__0)))))));
    vlSelf->wasmetal_core__DOT___052700_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052577_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->wasmetal_core__DOT___052687_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052578_))));
    vlSelf->__VdfgTmp_h568bee24__0 = ((2U & ((1U >> (IData)(vlSelf->__VdfgTmp_h301f8c5d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___052578_));
    vlSelf->wasmetal_core__DOT___071404_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_heb46fbcb__0))));
    vlSelf->wasmetal_core__DOT___071405_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h48de7988__0))));
    vlSelf->wasmetal_core__DOT___071383_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2535fff2__0))));
    vlSelf->wasmetal_core__DOT___071384_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hed7c6d19__0))));
    vlSelf->wasmetal_core__DOT___071385_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha300b05f__0))));
    vlSelf->wasmetal_core__DOT___071386_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h17228d9d__0))));
    vlSelf->wasmetal_core__DOT___071387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h7ee7d44c__0))));
    vlSelf->wasmetal_core__DOT___071388_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha431143d__0))));
    vlSelf->wasmetal_core__DOT___071389_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd266b697__0))));
    vlSelf->wasmetal_core__DOT___071390_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h123a295b__0))));
    vlSelf->wasmetal_core__DOT___071391_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h73075b94__0))));
    vlSelf->wasmetal_core__DOT___071392_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he372c179__0))));
    vlSelf->wasmetal_core__DOT___071393_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8fd79857__0))));
    vlSelf->wasmetal_core__DOT___071394_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb3e6303e__0))));
    vlSelf->wasmetal_core__DOT___071395_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1bbfb27a__0))));
    vlSelf->wasmetal_core__DOT___071396_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8d7f942c__0))));
    vlSelf->wasmetal_core__DOT___071397_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a6dc29d__0))));
    vlSelf->wasmetal_core__DOT___071398_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h86abd4f4__0))));
    vlSelf->wasmetal_core__DOT___071399_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966a07d3__0))));
    vlSelf->wasmetal_core__DOT___071400_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbceb8814__0))));
    vlSelf->wasmetal_core__DOT___071401_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h8a64daef__0))));
    vlSelf->wasmetal_core__DOT___071402_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h966312d4__0))));
    vlSelf->wasmetal_core__DOT___071403_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dc57786__0))));
    vlSelf->wasmetal_core__DOT___071347_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd8bdfcc6__0))));
    vlSelf->wasmetal_core__DOT___071348_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0bf68f44__0))));
    vlSelf->wasmetal_core__DOT___071349_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf7e0b807__0))));
    vlSelf->wasmetal_core__DOT___071350_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb8649aac__0))));
    vlSelf->wasmetal_core__DOT___071351_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hd389bfd2__0))));
    vlSelf->wasmetal_core__DOT___071352_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he127cdd2__0))));
    vlSelf->wasmetal_core__DOT___071359_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h65437cee__0))));
    vlSelf->wasmetal_core__DOT___071360_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4c7f02d9__0))));
    vlSelf->wasmetal_core__DOT___071361_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h83bd92c8__0))));
    vlSelf->wasmetal_core__DOT___071362_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1915a5ff__0))));
    vlSelf->wasmetal_core__DOT___071363_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h70b63d5e__0))));
    vlSelf->wasmetal_core__DOT___071364_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf6358f59__0))));
    vlSelf->wasmetal_core__DOT___071371_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hdf9c0a20__0))));
    vlSelf->wasmetal_core__DOT___071372_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_he08c96ba__0))));
    vlSelf->wasmetal_core__DOT___071373_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h370a9404__0))));
    vlSelf->wasmetal_core__DOT___071374_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1473a3fc__0))));
    vlSelf->wasmetal_core__DOT___071375_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbbedaddf__0))));
    vlSelf->wasmetal_core__DOT___071376_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h098d62f8__0))));
    vlSelf->wasmetal_core__DOT___071380_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc1d04e55__0))));
    vlSelf->wasmetal_core__DOT___071381_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_ha31457b4__0))));
    vlSelf->wasmetal_core__DOT___071382_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3006d0f0__0))));
    vlSelf->wasmetal_core__DOT___071343_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5dfde09f__0))));
    vlSelf->wasmetal_core__DOT___071344_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h31b47573__0))));
    vlSelf->wasmetal_core__DOT___071345_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hedf8c8b5__0))));
    vlSelf->wasmetal_core__DOT___071346_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbba81ae3__0))));
    vlSelf->wasmetal_core__DOT___071353_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0201c3e9__0))));
    vlSelf->wasmetal_core__DOT___071354_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hbc582c17__0))));
    vlSelf->wasmetal_core__DOT___071355_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h670f6b42__0))));
    vlSelf->wasmetal_core__DOT___071356_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4dc6a706__0))));
    vlSelf->wasmetal_core__DOT___071357_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h978cb234__0))));
    vlSelf->wasmetal_core__DOT___071358_ = (1U & (0xcaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfb8717f5__0))));
    vlSelf->wasmetal_core__DOT___071365_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h9685a33e__0))));
    vlSelf->wasmetal_core__DOT___071366_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hee7ba675__0))));
    vlSelf->wasmetal_core__DOT___071367_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h5b1f350b__0))));
    vlSelf->wasmetal_core__DOT___071368_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2c74d244__0))));
    vlSelf->wasmetal_core__DOT___071369_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hf5aac232__0))));
    vlSelf->wasmetal_core__DOT___071370_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h852d6a23__0))));
    vlSelf->wasmetal_core__DOT___071377_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0919c673__0))));
    vlSelf->wasmetal_core__DOT___071378_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc7238523__0))));
    vlSelf->wasmetal_core__DOT___071379_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___062976_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h0ba16cdb__0))));
    vlSelf->wasmetal_core__DOT___052892_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052891_))));
    vlSelf->wasmetal_core__DOT___053087_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052741_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___025060_)))));
    vlSelf->__VdfgTmp_h99cee8a1__0 = (((IData)(vlSelf->wasmetal_core__DOT___052693_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___052577_));
    vlSelf->wasmetal_core__DOT___053989_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052578_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052693_))));
    vlSelf->wasmetal_core__DOT___048352_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048339_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___000354_))))));
    vlSelf->wasmetal_core__DOT___007194_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048432_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048434_))));
    vlSelf->wasmetal_core__DOT___052851_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052850_))));
    vlSelf->wasmetal_core__DOT___055311_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052850_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052891_))));
    vlSelf->wasmetal_core__DOT___056254_ = (1U & ((0x10U 
                                                   & vlSelf->insn_op)
                                                   ? 
                                                  (0xaaa22aaaU 
                                                   >> 
                                                   ((0x1cU 
                                                     & (vlSelf->insn_op 
                                                        >> 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010005_))))
                                                   : 
                                                  (0xa2222aaaU 
                                                   >> 
                                                   ((0x1cU 
                                                     & (vlSelf->insn_op 
                                                        >> 3U)) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___010005_))))));
    vlSelf->wasmetal_core__DOT___053496_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053495_))));
    vlSelf->wasmetal_core__DOT___053767_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053495_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048283_))))));
    vlSelf->wasmetal_core__DOT___064012_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    vlSelf->wasmetal_core__DOT___048443_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048381_))));
    vlSelf->wasmetal_core__DOT___007033_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048383_))));
    vlSelf->wasmetal_core__DOT___019205_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019280_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048404_))));
    vlSelf->wasmetal_core__DOT___007034_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019280_))));
    vlSelf->wasmetal_core__DOT___007035_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047786_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048344_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047783_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048350_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x4000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___048370_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h82d8a9a1__0))));
    vlSelf->wasmetal_core__DOT___007031_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048384_))));
    vlSelf->wasmetal_core__DOT___048374_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048367_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048366_)))));
    vlSelf->wasmetal_core__DOT___065610_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048414_))));
    vlSelf->wasmetal_core__DOT___052846_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048440_))));
    vlSelf->wasmetal_core__DOT___048442_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048440_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048439_))));
    vlSelf->wasmetal_core__DOT___053776_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___010005_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048418_))));
    vlSelf->wasmetal_core__DOT___050366_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050357_))));
    vlSelf->wasmetal_core__DOT___053761_ = (1U & (0x777U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050357_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048314_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048320_)))))));
    vlSelf->wasmetal_core__DOT___054146_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048474_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1ff00000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048468_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___051531_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___010007_))))))))))));
    vlSelf->wasmetal_core__DOT___063783_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063775_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((6U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h77a25d8c__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h0d1a9c72__0)))))));
    vlSelf->wasmetal_core__DOT___053013_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc62a6006__0))));
    vlSelf->wasmetal_core__DOT___052896_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((0x1000U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc62a6006__0))));
    vlSelf->wasmetal_core__DOT___052905_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052904_))));
    vlSelf->wasmetal_core__DOT___053755_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053753_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x4000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb92dbfd9__0))))))));
    vlSelf->wasmetal_core__DOT___060659_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007190_))));
    vlSelf->wasmetal_core__DOT___052899_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                    << 3U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h4a5b8c23__0))));
    vlSelf->wasmetal_core__DOT___052902_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048461_))));
    vlSelf->wasmetal_core__DOT___053777_ = (1U & (IData)(
                                                         (0x1ff00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053775_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___048461_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                     << 3U)) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h7dabefa3__0)))))));
    vlSelf->wasmetal_core__DOT___052906_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048460_))));
    vlSelf->wasmetal_core__DOT___053768_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048460_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((0x1000U 
                                                              >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048336_))))));
    vlSelf->wasmetal_core__DOT___048464_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048461_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048460_))));
    vlSelf->wasmetal_core__DOT___067481_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___000657_)))));
    vlSelf->wasmetal_core__DOT___053012_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048490_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048439_)))));
    vlSelf->wasmetal_core__DOT___071777_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048324_))));
    vlSelf->wasmetal_core__DOT___052746_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc8342b84__0))));
    vlSelf->wasmetal_core__DOT___052901_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hc8342b84__0)))));
    vlSelf->wasmetal_core__DOT___065611_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d3657d5__0))));
    vlSelf->wasmetal_core__DOT___048312_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6d3657d5__0))));
    vlSelf->wasmetal_core__DOT___052584_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x1515153fULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___048404_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___048365_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___010007_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007028_) 
                                                                            << 2U) 
                                                                           | (IData)(vlSelf->__VdfgTmp_haa5fc240__0)))))))))));
    vlSelf->wasmetal_core__DOT___048411_ = (1U & (0x303035fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048329_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((8U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_haa5fc240__0))))));
    vlSelf->wasmetal_core__DOT___048373_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048368_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048304_)))));
    vlSelf->wasmetal_core__DOT___052645_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048514_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048513_))));
    vlSelf->wasmetal_core__DOT___048401_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048398_))));
    vlSelf->wasmetal_core__DOT___048465_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(
                                                               (0xc7f8ffffffffffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                                     << 4U) 
                                                                    | (0xfU 
                                                                       & vlSelf->insn_op))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048462_))));
    vlSelf->wasmetal_core__DOT___052845_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048400_))));
    vlSelf->wasmetal_core__DOT___007874_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048490_))));
    vlSelf->wasmetal_core__DOT___052886_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025061_))));
    vlSelf->wasmetal_core__DOT___063817_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053367_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052891_)))));
    vlSelf->wasmetal_core__DOT___052893_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___025061_))));
    vlSelf->wasmetal_core__DOT___054744_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048307_))));
    vlSelf->wasmetal_core__DOT___048451_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048444_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048368_))));
    vlSelf->wasmetal_core__DOT___063824_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048438_))));
    vlSelf->wasmetal_core__DOT___063860_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048366_)))));
    vlSelf->wasmetal_core__DOT___019246_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048322_))));
    vlSelf->wasmetal_core__DOT___048369_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048364_))));
    vlSelf->wasmetal_core__DOT___052897_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019304_))));
    vlSelf->wasmetal_core__DOT___054677_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___019304_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052741_))));
    vlSelf->wasmetal_core__DOT___052840_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_haf8eec33__0)))));
    vlSelf->wasmetal_core__DOT___007060_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf8eec33__0))));
    vlSelf->wasmetal_core__DOT___054145_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_haf8eec33__0))));
    vlSelf->wasmetal_core__DOT___050449_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019304_)))));
    vlSelf->wasmetal_core__DOT___052884_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050447_))));
    vlSelf->wasmetal_core__DOT___061644_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050447_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050392_))));
    vlSelf->wasmetal_core__DOT___052879_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052878_))));
    vlSelf->wasmetal_core__DOT___052882_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf2823744__0))));
    vlSelf->wasmetal_core__DOT___048372_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_hf2823744__0))));
    vlSelf->wasmetal_core__DOT___065609_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048403_))));
    vlSelf->wasmetal_core__DOT___048408_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048403_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048402_))));
    vlSelf->wasmetal_core__DOT___061648_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT____Vcellinp___128623___DI)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___007032_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___048415_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048412_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048385_))));
    vlSelf->wasmetal_core__DOT___053762_ = (1U & (IData)(
                                                         (0x153fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052878_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___053760_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___002985_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___000353_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___047781_)))))))));
    vlSelf->wasmetal_core__DOT___048416_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048413_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___019304_))));
    vlSelf->wasmetal_core__DOT___066332_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048405_))));
    vlSelf->wasmetal_core__DOT___048441_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048438_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048405_))));
    vlSelf->wasmetal_core__DOT___007036_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048371_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048358_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___048342_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_he81561f4__0))));
    vlSelf->wasmetal_core__DOT___056256_ = (1U & (IData)(
                                                         (0x1f00000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___056252_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048446_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048327_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((0x1000U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h682c3842__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002994_)))))))));
    vlSelf->wasmetal_core__DOT___053766_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053765_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053764_))));
    vlSelf->wasmetal_core__DOT___052894_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052891_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048437_)))));
    vlSelf->wasmetal_core__DOT___052895_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048437_))));
    vlSelf->wasmetal_core__DOT___025062_ = (1U & (0xf8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000375_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)))))));
    vlSelf->wasmetal_core__DOT___007054_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___025060_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048437_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___025061_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((8U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hc416787b__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___000375_)))))));
    vlSelf->wasmetal_core__DOT___048357_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002988_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h9205a979__0))));
    vlSelf->wasmetal_core__DOT___048348_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048346_) 
                                                    << 2U) 
                                                   | (IData)(__VdfgTmp_h9205a979__0))));
    vlSelf->wasmetal_core__DOT___054144_ = (1U & (0x1f000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048472_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048473_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___010006_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)))))))));
    vlSelf->wasmetal_core__DOT___019396_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048325_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048324_)))));
    vlSelf->wasmetal_core__DOT___019336_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048324_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048325_))));
    vlSelf->wasmetal_core__DOT___053758_ = (1U & (IData)(
                                                         (0x1515153fULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___053756_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___048326_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x1000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h6ef8db86__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb92dbfd9__0))))))));
    vlSelf->wasmetal_core__DOT___063854_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048351_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048347_))))));
    vlSelf->wasmetal_core__DOT___064017_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048360_))));
    vlSelf->wasmetal_core__DOT___048452_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048364_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048322_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048360_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048376_))))));
    vlSelf->wasmetal_core__DOT___048470_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000378_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048284_) 
                                                       << 3U) 
                                                      | (IData)(__VdfgTmp_hcc483c10__0)))));
    vlSelf->wasmetal_core__DOT___048454_ = (1U & (0x1ffffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048336_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h4e9e0a77__0)) 
                                                          << 3U)) 
                                                      | (IData)(__VdfgTmp_hcc483c10__0)))));
    vlSelf->wasmetal_core__DOT___045662_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(wasmetal_core__DOT___045666_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : 
                                                        (0x4fU 
                                                         >> 
                                                         ((4U 
                                                           & ((8U 
                                                               >> 
                                                               (3U 
                                                                & (vlSelf->insn_op 
                                                                   >> 6U))) 
                                                              << 2U)) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___070629_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (vlSelf->insn_op 
                                                                   >> 2U))))))))));
    vlSelf->wasmetal_core__DOT___053266_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047787_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0x80U 
                                                           >> 
                                                           ((4U 
                                                             & ((0x4000U 
                                                                 >> 
                                                                 (0xfU 
                                                                  & (vlSelf->insn_op 
                                                                     >> 4U))) 
                                                                << 2U)) 
                                                            | (IData)(vlSelf->__VdfgTmp_hbcc95063__0))) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048362_)))));
    vlSelf->wasmetal_core__DOT___048390_ = (1U & (0x1ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048363_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048362_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048361_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048360_)))))));
    vlSelf->wasmetal_core__DOT___048380_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048375_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048270_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___048269_))))));
    vlSelf->wasmetal_core__DOT___045734_ = ((IData)(
                                                    (1ULL 
                                                     >> 
                                                     (vlSelf->insn_op 
                                                      >> 0x1aU))) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___044063_) 
                                               & ((IData)(vlSelf->wasmetal_core__DOT___044062_) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                     & ((IData)(wasmetal_core__DOT___045738_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h2780d718__0))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___045735_))))));
    vlSelf->wasmetal_core__DOT___003034_ = (1U & (0xfff8f8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_op 
                                                          << 3U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x8000000000000000ULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___047969_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___047968_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___047967_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___047966_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((0x7f7f7fU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h28012a28__0))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___047964_)))))))) 
                                                                << 1U)) 
                                                            | (1U 
                                                               & (IData)(
                                                                         (0x8000000000000000ULL 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT___047963_) 
                                                                            << 5U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047962_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047961_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0x777ffffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___002994_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001234_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___002985_)))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((0xf1ffU 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((0xfffeU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000366_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h97facc1b__0))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfbfbfbfbfbfbfULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___001241_) 
                                                                                << 5U) 
                                                                                | ((0x10U 
                                                                                & ((0x8000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                                << 4U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha37d1f60__0))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___063370_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053017_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050435_))));
    vlSelf->wasmetal_core__DOT___047784_ = (1U & (0x700U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((0x80U 
                                                           >> 
                                                           ((4U 
                                                             & ((0x1000U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((0x8000U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___000368_)))) 
                                                          << 2U)) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___047781_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___047780_))))));
    vlSelf->wasmetal_core__DOT___003147_ = (1U & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___047791_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___047790_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___047789_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003040_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003039_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___002965_)))))))));
    vlSelf->wasmetal_core__DOT___047988_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___003045_)) 
                                                  & ((~ (IData)(vlSelf->wasmetal_core__DOT___003044_)) 
                                                     & (IData)(
                                                               (0x80ffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___003043_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003042_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___003041_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___003040_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___003039_)))))))))));
    vlSelf->wasmetal_core__DOT___003032_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___047979_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___000158_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (vlSelf->insn_op 
                                                            >> 7U))))));
    vlSelf->__VdfgTmp_h93f3e051__0 = (((IData)(vlSelf->wasmetal_core__DOT___000354_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___048419_));
    vlSelf->wasmetal_core__DOT___063786_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___053367_))));
    vlSelf->wasmetal_core__DOT___053011_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___050381_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->wasmetal_core__DOT___048422_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048419_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048418_))));
    vlSelf->wasmetal_core__DOT___002967_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___001234_)
                                                   ? (IData)(
                                                             (0x11111000fffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001230_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0x4000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fefcec1__0))))))))))
                                                   : (IData)(wasmetal_core__DOT___001235_)));
    vlSelf->wasmetal_core__DOT___047975_ = (1U & ((1U 
                                                   & (0x8000U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h695ce273__0)))
                                                   ? (IData)(
                                                             (0x11111000fffffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___000368_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___001233_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___001232_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___001231_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___001240_) 
                                                                            << 1U) 
                                                                           | (1U 
                                                                              & (0x1000U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h3fee6eff__0))))))))))
                                                   : (IData)(wasmetal_core__DOT___001235_)));
    vlSelf->wasmetal_core__DOT___051567_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048276_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0))))));
    vlSelf->wasmetal_core__DOT___051572_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051565_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051564_))));
    vlSelf->wasmetal_core__DOT___062502_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051253_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050430_))));
    vlSelf->wasmetal_core__DOT___036595_ = (1U & (0x96U 
                                                  >> 
                                                  ((4U 
                                                    & (vlSelf->insn_x 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___051253_)))));
    vlSelf->wasmetal_core__DOT___036767_ = (1U & (0x8e71U 
                                                  >> 
                                                  ((8U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8befad22__0)) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__sp__05b0__05d) 
                                                       << 2U) 
                                                      | ((2U 
                                                          & (vlSelf->insn_x 
                                                             << 1U)) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___051253_))))));
    vlSelf->wasmetal_core__DOT___053010_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052888_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052839_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___052838_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___052880_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051201_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->wasmetal_core__DOT___052887_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052837_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048435_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048433_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048424_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___001233_)))));
    vlSelf->wasmetal_core__DOT___052881_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___000357_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052898_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___000357_))));
    vlSelf->wasmetal_core__DOT___048429_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___000359_)) 
                                                  & (IData)(
                                                            (0x7f7f7fULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___000358_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___000357_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                     << 3U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4a5b8c23__0))))))));
    vlSelf->wasmetal_core__DOT___051200_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048516_))));
    vlSelf->__VdfgTmp_hced715c6__0 = (((IData)(vlSelf->wasmetal_core__DOT___052643_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___051191_));
    vlSelf->wasmetal_core__DOT___062971_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051191_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___048519_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___000357_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048425_)))));
    vlSelf->wasmetal_core__DOT___053427_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___051569_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048276_))));
    vlSelf->wasmetal_core__DOT___054460_ = (1U & (0xfef00000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048425_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048321_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (8U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h28012a28__0)))))))));
    vlSelf->wasmetal_core__DOT___052883_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000354_))));
    vlSelf->wasmetal_core__DOT___052796_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048445_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___000357_)))));
    vlSelf->wasmetal_core__DOT___052648_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048516_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048399_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___052647_)))));
    vlSelf->wasmetal_core__DOT___054465_ = (1U & (0x1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052647_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h9fdaf630__0)))))));
    vlSelf->wasmetal_core__DOT___045703_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(wasmetal_core__DOT___045709_) 
                                                          | (1U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h323e8784__0))))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT___053260_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_phase) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___003092_))));
    vlSelf->wasmetal_core__DOT___048661_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005581_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8696f73b__0))))))));
    vlSelf->wasmetal_core__DOT___048666_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001169_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb1867682__0))))))));
    vlSelf->wasmetal_core__DOT___048651_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001147_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb73e868c__0))))))));
    vlSelf->wasmetal_core__DOT___048656_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001125_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1bd58642__0))))))));
    vlSelf->wasmetal_core__DOT___048602_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001102_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001103_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2d637bc4__0))))))));
    vlSelf->wasmetal_core__DOT___048597_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001081_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4403b5cc__0))))))));
    vlSelf->wasmetal_core__DOT___048614_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001058_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001059_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h339d407e__0))))))));
    vlSelf->wasmetal_core__DOT___048609_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001036_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001037_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8aa65d09__0))))))));
    vlSelf->wasmetal_core__DOT___048626_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001014_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001015_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc2efa860__0))))))));
    vlSelf->wasmetal_core__DOT___048621_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003313_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8df5578a__0))))))));
    vlSelf->wasmetal_core__DOT___048638_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003381_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h87d91e6a__0))))))));
    vlSelf->wasmetal_core__DOT___048633_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003901_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94ceffb3__0))))))));
    vlSelf->wasmetal_core__DOT___048794_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2a4ee2b9__0))));
    vlSelf->wasmetal_core__DOT___048796_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hb2eda61f__0)))));
    vlSelf->wasmetal_core__DOT___048800_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001875_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001874_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004783_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))))))));
    vlSelf->wasmetal_core__DOT___048803_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001887_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001886_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004709_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))))))));
    vlSelf->wasmetal_core__DOT___048805_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003233_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))));
    vlSelf->wasmetal_core__DOT___048807_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h47317805__0)))));
    vlSelf->wasmetal_core__DOT___048875_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_had719570__0))));
    vlSelf->wasmetal_core__DOT___048877_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h8b5bebff__0)))));
    vlSelf->wasmetal_core__DOT___048840_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000498_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000499_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005147_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))))))));
    vlSelf->wasmetal_core__DOT___048865_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000520_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000521_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005079_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d)))))))));
    vlSelf->wasmetal_core__DOT___048845_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000542_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000543_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005351_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d)))))))));
    vlSelf->wasmetal_core__DOT___048858_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000564_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000565_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h4f39dfcd__0))))))));
    vlSelf->wasmetal_core__DOT___048883_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h3ce0f075__0))));
    vlSelf->wasmetal_core__DOT___048885_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1656da2e__0)))));
    vlSelf->wasmetal_core__DOT___048868_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000591_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000592_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h957273a9__0))))))));
    vlSelf->wasmetal_core__DOT___048855_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000613_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000614_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___004875_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d)))))))));
    vlSelf->wasmetal_core__DOT___048848_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000635_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000636_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d)))))))));
    vlSelf->wasmetal_core__DOT___048926_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h67e9fb36__0))))))));
    vlSelf->wasmetal_core__DOT___048873_ = (1U & (IData)(
                                                         (0x5555333300ff0f0fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000657_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000658_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h39dd035b__0))))))));
    vlSelf->wasmetal_core__DOT___048890_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004413_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))));
    vlSelf->wasmetal_core__DOT___048892_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1048f6d3__0)))));
    vlSelf->wasmetal_core__DOT___048915_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004801_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_he7d3ff65__0))))))));
    vlSelf->wasmetal_core__DOT___048686_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004727_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf8cdee79__0))))))));
    vlSelf->wasmetal_core__DOT___048750_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004561_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))));
    vlSelf->wasmetal_core__DOT___048752_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1ea91d16__0)))));
    vlSelf->wasmetal_core__DOT___048763_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___001647_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___001646_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_ha2b26e01__0))))))));
    vlSelf->wasmetal_core__DOT___048881_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000420_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000419_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003827_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))))))));
    vlSelf->wasmetal_core__DOT___047924_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___003845_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf33edb7b__0))))))));
    vlSelf->wasmetal_core__DOT___047917_ = (1U & (IData)(
                                                         (0xf0f555500ff3333ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___004061_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hb40a316f__0))))))));
    vlSelf->wasmetal_core__DOT___048737_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h2112a96a__0))));
    vlSelf->wasmetal_core__DOT___048739_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h6a7f974d__0)))));
    vlSelf->wasmetal_core__DOT___048748_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000433_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000432_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h63a6348e__0))))))));
    vlSelf->wasmetal_core__DOT___048745_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000465_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000464_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9eae91ba__0))))))));
    vlSelf->wasmetal_core__DOT___048534_ = (1U & (IData)(
                                                         (0x555533330f0f00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000477_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___000476_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h76527ded__0))))))));
    vlSelf->wasmetal_core__DOT___048765_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003597_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))));
    vlSelf->wasmetal_core__DOT___048767_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_hcc9d97e7__0)))));
    vlSelf->wasmetal_core__DOT___048780_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003449_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))));
    vlSelf->wasmetal_core__DOT___048782_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h4172973d__0)))));
    vlSelf->wasmetal_core__DOT___048773_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003523_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))));
    vlSelf->wasmetal_core__DOT___048775_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h0585c3f4__0)))));
    vlSelf->wasmetal_core__DOT___048834_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hb14b0648__0))));
    vlSelf->wasmetal_core__DOT___048836_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h840c74b0__0)))));
    vlSelf->wasmetal_core__DOT___048810_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h491e13b5__0))));
    vlSelf->wasmetal_core__DOT___048812_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5bc17448__0)))));
    vlSelf->wasmetal_core__DOT___048823_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004635_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))));
    vlSelf->wasmetal_core__DOT___048825_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h88a0d3a9__0)))));
    vlSelf->wasmetal_core__DOT___048731_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003671_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))));
    vlSelf->wasmetal_core__DOT___048732_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h5e46481a__0)))));
    vlSelf->wasmetal_core__DOT___048818_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003969_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))));
    vlSelf->wasmetal_core__DOT___048820_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h652edcf1__0)))));
    vlSelf->wasmetal_core__DOT___047861_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_hac359f24__0))));
    vlSelf->wasmetal_core__DOT___047862_ = (1U & (0xac00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___003689_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d))))));
    vlSelf->wasmetal_core__DOT___048757_ = (1U & (0x53U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___004265_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))));
    vlSelf->wasmetal_core__DOT___048759_ = (1U & (0xa0cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003092_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__simd_lane__05b0__05d) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_ha8cefda7__0)))));
    vlSelf->wasmetal_core__DOT___048308_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048306_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048305_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___048304_)))));
    vlSelf->wasmetal_core__DOT___053772_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___043582_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___043138_))));
    vlSelf->wasmetal_core__DOT___034341_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001169_))));
    vlSelf->wasmetal_core__DOT___034340_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001147_))));
    vlSelf->wasmetal_core__DOT___034339_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001125_))));
    vlSelf->wasmetal_core__DOT___034337_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001103_))));
    vlSelf->wasmetal_core__DOT___034336_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001081_))));
    vlSelf->wasmetal_core__DOT___034335_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001059_))));
    vlSelf->wasmetal_core__DOT___034334_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001037_))));
    vlSelf->wasmetal_core__DOT___034333_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001015_))));
    vlSelf->wasmetal_core__DOT___034332_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000993_))));
    vlSelf->wasmetal_core__DOT___034331_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000981_))));
    vlSelf->wasmetal_core__DOT___034330_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000926_))));
    vlSelf->wasmetal_core__DOT___034329_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000927_))));
    vlSelf->wasmetal_core__DOT___034328_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000897_))));
    vlSelf->wasmetal_core__DOT___034342_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001330_))));
    vlSelf->wasmetal_core__DOT___034326_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000896_))));
    vlSelf->wasmetal_core__DOT___034325_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000873_))));
    vlSelf->wasmetal_core__DOT___034324_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000872_))));
    vlSelf->wasmetal_core__DOT___034323_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000849_))));
    vlSelf->wasmetal_core__DOT___034322_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000848_))));
    vlSelf->wasmetal_core__DOT___034321_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000824_))));
    vlSelf->wasmetal_core__DOT___034320_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000825_))));
    vlSelf->wasmetal_core__DOT___034319_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000796_))));
    vlSelf->wasmetal_core__DOT___034318_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000795_))));
    vlSelf->wasmetal_core__DOT___034317_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000772_))));
    vlSelf->wasmetal_core__DOT___034315_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000771_))));
    vlSelf->wasmetal_core__DOT___034314_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000747_))));
    vlSelf->wasmetal_core__DOT___034313_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000748_))));
    vlSelf->wasmetal_core__DOT___034312_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000723_))));
    vlSelf->wasmetal_core__DOT___034311_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000724_))));
    vlSelf->wasmetal_core__DOT___034310_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000694_))));
    vlSelf->wasmetal_core__DOT___034309_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000693_))));
    vlSelf->wasmetal_core__DOT___034308_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000665_))));
    vlSelf->wasmetal_core__DOT___034507_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d))));
    vlSelf->wasmetal_core__DOT___034506_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001168_))));
    vlSelf->wasmetal_core__DOT___034505_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001146_))));
    vlSelf->wasmetal_core__DOT___034504_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001124_))));
    vlSelf->wasmetal_core__DOT___034503_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001102_))));
    vlSelf->wasmetal_core__DOT___034502_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001080_))));
    vlSelf->wasmetal_core__DOT___034501_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001058_))));
    vlSelf->wasmetal_core__DOT___034500_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001036_))));
    vlSelf->wasmetal_core__DOT___034499_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001014_))));
    vlSelf->wasmetal_core__DOT___034498_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000992_))));
    vlSelf->wasmetal_core__DOT___034497_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___000980_))));
    vlSelf->wasmetal_core__DOT___034496_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___001327_))));
    vlSelf->wasmetal_core__DOT___034495_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b51__05d))));
    vlSelf->wasmetal_core__DOT___034494_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b50__05d))));
    vlSelf->wasmetal_core__DOT___034493_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b49__05d))));
    vlSelf->wasmetal_core__DOT___034492_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d))));
    vlSelf->wasmetal_core__DOT___034491_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d))));
    vlSelf->wasmetal_core__DOT___034490_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d))));
    vlSelf->wasmetal_core__DOT___052583_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005617_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide))));
    vlSelf->wasmetal_core__DOT___034489_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d))));
    vlSelf->wasmetal_core__DOT___034488_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d))));
    vlSelf->wasmetal_core__DOT___034487_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d))));
    vlSelf->wasmetal_core__DOT___034486_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d))));
    vlSelf->wasmetal_core__DOT___034485_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d))));
    vlSelf->wasmetal_core__DOT___034484_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d))));
    vlSelf->wasmetal_core__DOT___034483_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d))));
    vlSelf->wasmetal_core__DOT___034482_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b38__05d))));
    vlSelf->wasmetal_core__DOT___034481_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b37__05d))));
    vlSelf->wasmetal_core__DOT___034480_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d))));
    vlSelf->wasmetal_core__DOT___034479_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d))));
    vlSelf->wasmetal_core__DOT___034478_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d))));
    vlSelf->wasmetal_core__DOT___034477_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d))));
    vlSelf->wasmetal_core__DOT___034476_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__divider__02ewide) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b32__05d))));
    vlSelf->wasmetal_core__DOT___048393_ = (1U & (0xf8880000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048114_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___045672_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___044092_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___045682_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02ewide)))))));
    vlSelf->wasmetal_core__DOT___053482_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___045693_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___044157_))));
    vlSelf->wasmetal_core__DOT___063425_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063422_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___019356_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___038870_)))))));
    vlSelf->wasmetal_core__DOT___063395_ = (1U & ((~ (IData)(
                                                             (0xf00000dd00000000ULL 
                                                              >> 
                                                              ((0x20U 
                                                                & ((1U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                   << 5U)) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___053308_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___053343_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT__bulk_fill))))))))) 
                                                  & (IData)(
                                                            (0x3300ff3033f0fbULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___019356_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__state__05b3__05d) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->mem_fault) 
                                                                        << 2U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___019355_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d))))))))));
    vlSelf->wasmetal_core__DOT___053349_ = (1U & (IData)(
                                                         (0x1000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053287_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053286_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053285_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053284_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053282_)))))))));
    vlSelf->wasmetal_core__DOT___052989_ = (1U & (0x7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___052956_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___052955_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052859_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052954_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT__divider__02edone)))))));
    vlSelf->wasmetal_core__DOT___053333_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053331_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___052955_))));
    vlSelf->wasmetal_core__DOT___061661_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061659_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056331_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056335_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056371_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056382_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056325_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056326_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056367_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056381_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011519_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056428_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010992_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011004_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062001_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061999_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xff55550f0f3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057094_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057092_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057128_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057130_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010533_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010546_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010735_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010854_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010911_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011508_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011124_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010961_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___061863_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061861_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3333555500ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056731_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056746_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056778_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056769_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010537_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010590_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010761_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010880_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010932_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011503_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010983_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011014_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___061774_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___061771_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056598_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056600_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011459_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___056622_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010540_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056327_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010773_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010892_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011537_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___056427_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010999_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___011011_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062114_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062112_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x333355550f0f00ffULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057391_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057385_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057442_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057450_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010528_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010559_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010755_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010868_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010925_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011522_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010958_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010969_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___062170_ = (1U & (IData)(
                                                         (0xff00ccccf0f0aaaaULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b2__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b3__05d) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___062169_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xf0f555500ff3333ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057536_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057539_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___057572_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___057573_)))))))) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0xf0f333300ff5555ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010529_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010568_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___010749_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010874_)))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x5555333300ff0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b1__05d) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__simd_integer__02ebyte_index__05b0__05d) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011527_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011518_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___011867_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___010976_)))))))))))))))));
    vlSelf->__VdfgTmp_h223d2b22__0 = (((IData)(vlSelf->wasmetal_core__DOT___003013_) 
                                       << 5U) | (((IData)(vlSelf->wasmetal_core__DOT___003012_) 
                                                  << 4U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___003011_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___003010_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h88a73cb4__0)))));
    vlSelf->wasmetal_core__DOT___054463_ = (1U & (IData)(
                                                         (0xff00ff00ff00e000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048317_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___051191_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___000356_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___047780_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048283_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048314_)))))))));
    vlSelf->wasmetal_core__DOT___045716_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___070610_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___045719_))));
    vlSelf->wasmetal_core__DOT___045725_ = (1U & ((IData)(
                                                          (1ULL 
                                                           >> 
                                                           (vlSelf->insn_op 
                                                            >> 0x1aU))) 
                                                  & ((1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044174_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044061_) 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT___044194_) 
                                                          | (IData)(wasmetal_core__DOT___045726_)))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___045705_))
                                                      : 
                                                     (1U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hc705d0d5__0)))));
    vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__2__KET__ 
        = ((vlSelf->insn_z >> 6U) & (IData)(vlSelf->wasmetal_core__DOT___128027___DOT__CO__BRA__1__KET__));
    vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__2__KET__ 
        = (1U & ((0x40U & vlSelf->mem_rdata[0U]) ? 
                 (vlSelf->mem_rdata[0U] >> 6U) : (IData)(vlSelf->wasmetal_core__DOT___128267___DOT__CO__BRA__1__KET__)));
    vlSelf->wasmetal_core__DOT___053438_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050456_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___050389_))));
    vlSelf->wasmetal_core__DOT___065228_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065226_))))));
    vlSelf->wasmetal_core__DOT___065385_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065383_))))));
    vlSelf->wasmetal_core__DOT___065490_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065488_))))));
    vlSelf->wasmetal_core__DOT___128483___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___032892_)
            ? (IData)(vlSelf->wasmetal_core__DOT___032859_)
            : (IData)(vlSelf->wasmetal_core__DOT__sp__05b4__05d));
    vlSelf->wasmetal_core__DOT___065517_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (4U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___065512_))))));
    vlSelf->wasmetal_core__DOT___065653_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (8U 
                                                            >> 
                                                            (1U 
                                                             & (8U 
                                                                >> (IData)(vlSelf->wasmetal_core__DOT___064698_)))))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065652_))));
    vlSelf->wasmetal_core__DOT___065765_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (1U 
                                                         & (4U 
                                                            >> (IData)(vlSelf->wasmetal_core__DOT___064836_)))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065764_))));
    vlSelf->wasmetal_core__DOT___065848_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065028_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065847_))));
    vlSelf->wasmetal_core__DOT___065960_ = (1U & (0xa3U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___065145_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065959_))));
    vlSelf->wasmetal_core__DOT___066031_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065226_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066030_))));
    vlSelf->wasmetal_core__DOT___066184_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065383_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066183_))));
    vlSelf->wasmetal_core__DOT___066229_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065488_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066228_))));
    vlSelf->wasmetal_core__DOT___066340_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065512_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066339_))));
    vlSelf->wasmetal_core__DOT___066438_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065652_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066437_))));
    vlSelf->wasmetal_core__DOT___066504_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065764_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066503_))));
    vlSelf->wasmetal_core__DOT___066585_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065847_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066584_))));
    vlSelf->wasmetal_core__DOT___066699_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065959_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066698_))));
    vlSelf->wasmetal_core__DOT___066752_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066030_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066751_))));
    vlSelf->wasmetal_core__DOT___066834_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066183_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066833_))));
    vlSelf->wasmetal_core__DOT___066918_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066228_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___066917_))));
    vlSelf->wasmetal_core__DOT___067002_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066339_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067001_))));
    vlSelf->wasmetal_core__DOT___067047_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066437_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067046_))));
    vlSelf->wasmetal_core__DOT___067132_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066503_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067131_))));
    vlSelf->wasmetal_core__DOT___067243_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066584_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067242_))));
    vlSelf->wasmetal_core__DOT___067282_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066698_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067281_))));
    vlSelf->wasmetal_core__DOT___067387_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066751_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067386_))));
    vlSelf->wasmetal_core__DOT___070406_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___069915_))));
    vlSelf->wasmetal_core__DOT___067434_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066833_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067433_))));
    vlSelf->wasmetal_core__DOT___067531_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___066917_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067530_))));
    vlSelf->wasmetal_core__DOT___069894_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069344_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069031_ = (1U & (IData)(
                                                         (0xff3f0020ff3fff3fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b59__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___069029_) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((1U 
                                                                            >> (IData)(vlSelf->wasmetal_core__DOT___065007_)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->wasmetal_core__DOT___065033_)))))))))));
    vlSelf->wasmetal_core__DOT___069873_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069321_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___069000_ = (1U & (0x33207f7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__load_vector__05b58__05d) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068998_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___067581_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->wasmetal_core__DOT___064851_)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___067134_)))))));
    vlSelf->wasmetal_core__DOT___069855_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069288_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064445_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064407_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064406_))));
    vlSelf->wasmetal_core__DOT___067579_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067001_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067578_))));
    vlSelf->wasmetal_core__DOT___064696_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064681_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___064680_))));
    vlSelf->wasmetal_core__DOT___067645_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067046_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067644_))));
    vlSelf->wasmetal_core__DOT___069834_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->wasmetal_core__DOT___069268_)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128533___O)))));
    vlSelf->wasmetal_core__DOT___064866_ = (1U & (0xf0f33aaU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___064859_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___064858_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0xaacc0f0fU 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___064370_) 
                                                              << 2U) 
                                                             | (IData)(vlSelf->__VdfgTmp_hdbf4091d__0))))))));
    vlSelf->wasmetal_core__DOT___067713_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067131_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067712_))));
    vlSelf->wasmetal_core__DOT___065023_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065016_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___065015_))));
    vlSelf->wasmetal_core__DOT___067792_ = (1U & (0xacU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___067791_))));
    vlSelf->wasmetal_core__DOT___069451_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069219_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___069265_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___065478_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___065477_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((4U 
                                                              >> 
                                                              (2U 
                                                               & ((4U 
                                                                   >> 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___064352_) 
                                                                    << 1U)) 
                                                                  << 1U))) 
                                                             << 1U)))))));
    vlSelf->wasmetal_core__DOT___069420_ = (1U & (0x5cU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069187_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (4U 
                                                         >> 
                                                         (2U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->wasmetal_core__DOT___069266_)) 
                                                             << 1U)))))));
}
