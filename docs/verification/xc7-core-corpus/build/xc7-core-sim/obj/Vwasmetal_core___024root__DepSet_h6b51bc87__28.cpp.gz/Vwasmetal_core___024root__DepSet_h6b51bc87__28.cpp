#pragma GCC diagnostic ignored "-Wint-in-bool-context"
#pragma GCC diagnostic ignored "-Wbool-operation"
#pragma GCC diagnostic ignored "-Wbitwise-instead-of-logical"
// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vwasmetal_core.h for the primary calling header

#include "Vwasmetal_core__pch.h"
#include "Vwasmetal_core__Syms.h"
#include "Vwasmetal_core___024root.h"

VL_INLINE_OPT void Vwasmetal_core___024root___nba_comb__TOP__26(Vwasmetal_core___024root* vlSelf) {
    if (false && vlSelf) {}  // Prevent unused
    Vwasmetal_core__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vwasmetal_core___024root___nba_comb__TOP__26\n"); );
    // Init
    CData/*0:0*/ wasmetal_core__DOT___009186_;
    wasmetal_core__DOT___009186_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009238_;
    wasmetal_core__DOT___009238_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009239_;
    wasmetal_core__DOT___009239_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009251_;
    wasmetal_core__DOT___009251_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009252_;
    wasmetal_core__DOT___009252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009291_;
    wasmetal_core__DOT___009291_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009301_;
    wasmetal_core__DOT___009301_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009302_;
    wasmetal_core__DOT___009302_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009768_;
    wasmetal_core__DOT___009768_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___009769_;
    wasmetal_core__DOT___009769_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015598_;
    wasmetal_core__DOT___015598_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015599_;
    wasmetal_core__DOT___015599_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015819_;
    wasmetal_core__DOT___015819_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015826_;
    wasmetal_core__DOT___015826_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015963_;
    wasmetal_core__DOT___015963_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015976_;
    wasmetal_core__DOT___015976_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015977_;
    wasmetal_core__DOT___015977_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___015993_;
    wasmetal_core__DOT___015993_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016004_;
    wasmetal_core__DOT___016004_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016033_;
    wasmetal_core__DOT___016033_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016051_;
    wasmetal_core__DOT___016051_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016071_;
    wasmetal_core__DOT___016071_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016097_;
    wasmetal_core__DOT___016097_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___016123_;
    wasmetal_core__DOT___016123_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___017373_;
    wasmetal_core__DOT___017373_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___043085_;
    wasmetal_core__DOT___043085_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___044837_;
    wasmetal_core__DOT___044837_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___048489_;
    wasmetal_core__DOT___048489_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051495_;
    wasmetal_core__DOT___051495_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___051533_;
    wasmetal_core__DOT___051533_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055224_;
    wasmetal_core__DOT___055224_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055225_;
    wasmetal_core__DOT___055225_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055406_;
    wasmetal_core__DOT___055406_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055564_;
    wasmetal_core__DOT___055564_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055565_;
    wasmetal_core__DOT___055565_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055571_;
    wasmetal_core__DOT___055571_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055574_;
    wasmetal_core__DOT___055574_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055621_;
    wasmetal_core__DOT___055621_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___055692_;
    wasmetal_core__DOT___055692_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058231_;
    wasmetal_core__DOT___058231_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058240_;
    wasmetal_core__DOT___058240_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058252_;
    wasmetal_core__DOT___058252_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058272_;
    wasmetal_core__DOT___058272_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058273_;
    wasmetal_core__DOT___058273_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058278_;
    wasmetal_core__DOT___058278_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058281_;
    wasmetal_core__DOT___058281_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058285_;
    wasmetal_core__DOT___058285_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058289_;
    wasmetal_core__DOT___058289_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058311_;
    wasmetal_core__DOT___058311_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058318_;
    wasmetal_core__DOT___058318_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058327_;
    wasmetal_core__DOT___058327_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058340_;
    wasmetal_core__DOT___058340_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058814_;
    wasmetal_core__DOT___058814_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058818_;
    wasmetal_core__DOT___058818_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058915_;
    wasmetal_core__DOT___058915_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___058922_;
    wasmetal_core__DOT___058922_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___063368_;
    wasmetal_core__DOT___063368_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067661_;
    wasmetal_core__DOT___067661_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___067727_;
    wasmetal_core__DOT___067727_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___068971_;
    wasmetal_core__DOT___068971_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069093_;
    wasmetal_core__DOT___069093_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069142_;
    wasmetal_core__DOT___069142_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069161_;
    wasmetal_core__DOT___069161_ = 0;
    CData/*0:0*/ wasmetal_core__DOT___069236_;
    wasmetal_core__DOT___069236_ = 0;
    CData/*2:0*/ wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0;
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = 0;
    CData/*0:0*/ wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__;
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ = 0;
    CData/*0:0*/ wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
    wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ = 0;
    CData/*1:0*/ __VdfgTmp_hd06a07d0__0;
    __VdfgTmp_hd06a07d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_hc9f60877__0;
    __VdfgTmp_hc9f60877__0 = 0;
    CData/*2:0*/ __VdfgTmp_hb26667c8__0;
    __VdfgTmp_hb26667c8__0 = 0;
    CData/*2:0*/ __VdfgTmp_h5be2ea26__0;
    __VdfgTmp_h5be2ea26__0 = 0;
    CData/*1:0*/ __VdfgTmp_h9c4bb670__0;
    __VdfgTmp_h9c4bb670__0 = 0;
    CData/*2:0*/ __VdfgTmp_h7e4803dd__0;
    __VdfgTmp_h7e4803dd__0 = 0;
    CData/*1:0*/ __VdfgTmp_hf54ed2ea__0;
    __VdfgTmp_hf54ed2ea__0 = 0;
    CData/*2:0*/ __VdfgTmp_h2fff67d0__0;
    __VdfgTmp_h2fff67d0__0 = 0;
    CData/*1:0*/ __VdfgTmp_he0d9cd96__0;
    __VdfgTmp_he0d9cd96__0 = 0;
    CData/*1:0*/ __VdfgTmp_he6226459__0;
    __VdfgTmp_he6226459__0 = 0;
    CData/*1:0*/ __VdfgTmp_h1a57c023__0;
    __VdfgTmp_h1a57c023__0 = 0;
    CData/*1:0*/ __VdfgTmp_hdf3675f5__0;
    __VdfgTmp_hdf3675f5__0 = 0;
    CData/*3:0*/ __VdfgTmp_h61bc6a8d__0;
    __VdfgTmp_h61bc6a8d__0 = 0;
    CData/*3:0*/ __VdfgTmp_hc7c22dbd__0;
    __VdfgTmp_hc7c22dbd__0 = 0;
    CData/*1:0*/ __VdfgTmp_h5abf1189__0;
    __VdfgTmp_h5abf1189__0 = 0;
    CData/*3:0*/ __VdfgTmp_h816ad3b7__0;
    __VdfgTmp_h816ad3b7__0 = 0;
    CData/*1:0*/ __VdfgTmp_ha292b77c__0;
    __VdfgTmp_ha292b77c__0 = 0;
    // Body
    __VdfgTmp_hb26667c8__0 = (((IData)(vlSelf->wasmetal_core__DOT___015688_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_he2a347e4__0));
    vlSelf->wasmetal_core__DOT___016007_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            & (IData)(
                                                      (0xf0f555500ff3333ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015737_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    wasmetal_core__DOT___016051_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))))));
    __VdfgTmp_hdf3675f5__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015605_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_he2a347e4__0))))
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))))));
    wasmetal_core__DOT___015976_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                               << 2U) 
                                              | (IData)(vlSelf->__VdfgTmp_h29141d8d__0)))));
    __VdfgTmp_h7e4803dd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h766529e2__0));
    if (vlSelf->wasmetal_core__DOT___015606_) {
        wasmetal_core__DOT___015977_ = (1U & (0xeU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 2U) 
                                                  | (IData)(vlSelf->__VdfgTmp_ha302ee77__0))));
        wasmetal_core__DOT___015993_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
        wasmetal_core__DOT___015819_ = (1U & (0x53U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h10a18780__0)))));
    } else {
        wasmetal_core__DOT___015977_ = (1U & (0xf1U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015684_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hf420cd01__0)))));
        wasmetal_core__DOT___015993_ = (1U & (0x35U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hd1c7c886__0)))));
        wasmetal_core__DOT___015819_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015831_));
    }
    if (vlSelf->wasmetal_core__DOT___015607_) {
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_hc3174423__0))));
        wasmetal_core__DOT___016071_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h7f4536ab__0)))));
        wasmetal_core__DOT___058240_ = (1U & (0x503U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))));
    } else {
        vlSelf->wasmetal_core__DOT___015820_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_ha302ee77__0)))));
        wasmetal_core__DOT___016071_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015840_));
        wasmetal_core__DOT___058240_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015806_));
    }
    __VdfgTmp_h5abf1189__0 = (((IData)(vlSelf->wasmetal_core__DOT___016030_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016029_));
    __VdfgTmp_he6226459__0 = (((IData)(vlSelf->wasmetal_core__DOT___016029_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016030_));
    wasmetal_core__DOT___015826_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015816_))));
    __VdfgTmp_h816ad3b7__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 3U) | ((4U & ((4U 
                                                 >> 
                                                 (((IData)(vlSelf->wasmetal_core__DOT___058267_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015594_))) 
                                                << 2U)) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                             << 1U) 
                                            | (IData)(vlSelf->wasmetal_core__DOT___016046_))));
    __VdfgTmp_ha292b77c__0 = (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016045_));
    wasmetal_core__DOT___058272_ = (1U & (0xfc00aaU 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___058267_)))))));
    wasmetal_core__DOT___015599_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->wasmetal_core__DOT___015954_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015949_))));
    vlSelf->__VdfgTmp_h45982c59__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0)));
    wasmetal_core__DOT___058231_ = (1U & (0xeU >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h6c8cc102__0))));
    __VdfgTmp_hc9f60877__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015969_));
    vlSelf->wasmetal_core__DOT___058317_ = (1U & (0xe000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015928_)))))));
    vlSelf->wasmetal_core__DOT___015932_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015927_))));
    vlSelf->wasmetal_core__DOT___058363_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058326_))));
    vlSelf->wasmetal_core__DOT___058254_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xfefefefe000000ffULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015983_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015982_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058222_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h1a6a5523__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h2acad42a__0)))));
    vlSelf->wasmetal_core__DOT___058364_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (0x4000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))));
    wasmetal_core__DOT___016097_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0xfff0fff055553333ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015910_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015909_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0)))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? (IData)(vlSelf->wasmetal_core__DOT___015806_)
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hc3174423__0)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d 
        = (1U & (0xfeU >> (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h75158e97__0))));
    vlSelf->wasmetal_core__DOT___036952_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((9U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT___018507_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058531_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 1U)))));
    wasmetal_core__DOT___017373_ = ((IData)(vlSelf->wasmetal_core__DOT___017412_) 
                                    & (IData)((0xefff1000000000ULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017410_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017409_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___014330_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017408_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___017407_)))))))));
    vlSelf->wasmetal_core__DOT___036292_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___005686_)) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__)));
    vlSelf->wasmetal_core__DOT____Vcellout___128846___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___005686_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b10__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02ein_sExp__05b9__05d) 
                                   << 1U) | (1U & (~ (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O)))))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128846___DOT__CO__BRA__1__KET__) 
                          << 2U) | (2U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127551___O) 
                                          << 1U)))));
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___036961_)
            ? (IData)(vlSelf->wasmetal_core__DOT___036948_)
            : (IData)(vlSelf->wasmetal_core__DOT___036647_));
    vlSelf->__VdfgTmp_h11374272__0 = (((IData)(vlSelf->wasmetal_core__DOT___006583_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___005679_));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b61__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__ 
            = vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__;
    }
    vlSelf->wasmetal_core__DOT___036951_ = (1U & (0x78U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___036962_ = (1U & (0xb4U 
                                                  >> 
                                                  ((4U 
                                                    & ((6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h97610f75__0))));
    wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0 = ((4U 
                                                   & ((~ 
                                                       (6U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))) 
                                                      << 2U)) 
                                                  | ((2U 
                                                      & ((~ 
                                                          (6U 
                                                           >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))) 
                                                         << 1U)) 
                                                     | (1U 
                                                        & (~ (IData)(vlSelf->wasmetal_core__DOT___036647_)))));
    vlSelf->wasmetal_core__DOT___065945_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065939_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065938_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065937_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b12__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066090_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066084_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066083_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066082_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b13__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___065617_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065605_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065604_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065603_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b8__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065807_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065803_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065802_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065801_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b10__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___065191_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___065190_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___065189_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___065188_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b5__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___065705_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065701_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065700_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065699_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b9__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___067461_ = (1U & (IData)(
                                                         (0x3f15000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___067457_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___067456_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___067455_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b30__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063451_)))))))));
    vlSelf->wasmetal_core__DOT___065903_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0x3f15000000000000ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___065899_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___065898_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___065897_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b11__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___063451_))))))))))));
    vlSelf->wasmetal_core__DOT___066129_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066126_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066125_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066124_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b14__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___066977_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___066973_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___066972_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___066971_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b24__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___067490_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x2a3f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067482_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067481_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b31__05d) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053011_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h3edf8090__0))))))));
    vlSelf->wasmetal_core__DOT___064744_ = (1U & (IData)(
                                                         (0xf080f0f0f0f0f0f0ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___064733_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___064732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___064731_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__value_aux__05b2__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___048278_)))))))));
    vlSelf->wasmetal_core__DOT___064479_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x3f15151500000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___064467_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___064466_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053011_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h365733f0__0))))))));
    vlSelf->wasmetal_core__DOT___053597_ = (1U & (0x10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___053593_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___052695_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___052700_)))))));
    wasmetal_core__DOT___063368_ = (1U & (0x10U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                            << 2U) 
                                           | (((IData)(vlSelf->wasmetal_core__DOT___053588_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___052849_)))));
    vlSelf->wasmetal_core__DOT___051229_ = (1U & (IData)(
                                                         (0x100000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051225_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((1U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051224_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((8U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                           << 1U) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___050365_))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0xffff100000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050360_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051205_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___051204_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___044240_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))))))))))))));
    vlSelf->wasmetal_core__DOT___052710_ = (1U & (IData)(
                                                         (0x1f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052697_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052696_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___051222_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___051220_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052695_)))))))));
    vlSelf->wasmetal_core__DOT___068609_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068607_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b50__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068658_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068656_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b51__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068706_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068704_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b52__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068755_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068753_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b53__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068799_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068797_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b54__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068854_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068852_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b55__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___068901_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068899_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___067760_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067751_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067750_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067749_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b35__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf98ad324__0))))))));
    vlSelf->wasmetal_core__DOT___019403_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068022_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068021_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068020_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b39__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h94bf9d34__0))))))));
    vlSelf->wasmetal_core__DOT___068085_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068081_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068080_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068079_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b40__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0ee6a0be__0))))))));
    vlSelf->wasmetal_core__DOT___068161_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068157_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068156_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068155_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b42__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h38fb75d8__0))))))));
    vlSelf->wasmetal_core__DOT___068246_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068242_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068241_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068240_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b43__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h8d1b60d2__0))))))));
    vlSelf->wasmetal_core__DOT___068299_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068295_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068294_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068293_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b44__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h598b279f__0))))))));
    vlSelf->wasmetal_core__DOT___068353_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068349_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068348_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068347_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b45__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h1fd76cb3__0))))))));
    vlSelf->wasmetal_core__DOT___068408_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068404_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068403_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068402_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b46__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h2cbbdbef__0))))))));
    wasmetal_core__DOT___067727_ = (1U & (IData)((0x3faf00000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___067726_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___067725_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b34__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))))));
    vlSelf->wasmetal_core__DOT___019398_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___067812_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067811_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067810_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b36__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h20a4ea67__0))))))));
    vlSelf->wasmetal_core__DOT___068432_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068428_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068427_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b47__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h97b1be8c__0))))))));
    vlSelf->wasmetal_core__DOT___068487_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068480_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068479_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068478_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b48__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfec86816__0))))))));
    wasmetal_core__DOT___067661_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___067658_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b33__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    vlSelf->wasmetal_core__DOT___068110_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___068106_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068105_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068104_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b41__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfe166c9c__0))))))));
    vlSelf->wasmetal_core__DOT___068945_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___068943_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___069043_ = (1U & (0xf7f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___069041_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b59__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069093_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069091_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b60__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069142_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069140_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b61__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___068971_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___068969_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b58__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    wasmetal_core__DOT___069236_ = (1U & (0x3faf0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069233_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___051203_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b63__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___054478_)))))));
    wasmetal_core__DOT___069161_ = (1U & (0xf7f0000U 
                                          >> (((IData)(vlSelf->wasmetal_core__DOT___069159_) 
                                               << 4U) 
                                              | (((IData)(vlSelf->wasmetal_core__DOT___068606_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050366_) 
                                                     << 2U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT__memory_sizes__02eread_data_a__05b62__05d) 
                                                        << 1U) 
                                                       | (IData)(vlSelf->wasmetal_core__DOT___051203_)))))));
    vlSelf->wasmetal_core__DOT___019804_ = (1U & (IData)(
                                                         (0xbf00bfbf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053370_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053369_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052733_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___050365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053368_)))))))));
    wasmetal_core__DOT___044837_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___044883_)
                                           ? ((IData)(vlSelf->wasmetal_core__DOT___044882_)
                                               ? ((IData)(vlSelf->wasmetal_core__DOT___044880_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___044879_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___044878_)
                                                     ? 
                                                    ((IData)(vlSelf->wasmetal_core__DOT___044877_)
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___044876_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___044875_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___044874_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___044873_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___044872_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___044871_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___044891_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___044890_)
                                                              ? 
                                                             ((IData)(vlSelf->wasmetal_core__DOT___044889_)
                                                               ? 
                                                              ((IData)(vlSelf->wasmetal_core__DOT___044888_)
                                                                ? 
                                                               ((IData)(vlSelf->wasmetal_core__DOT___044887_)
                                                                 ? 
                                                                ((IData)(vlSelf->wasmetal_core__DOT___044886_)
                                                                  ? 
                                                                 ((IData)(vlSelf->wasmetal_core__DOT___044885_)
                                                                   ? 
                                                                  ((IData)(vlSelf->wasmetal_core__DOT___044884_)
                                                                    ? 
                                                                   ((IData)(vlSelf->wasmetal_core__DOT___044881_)
                                                                     ? 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044870_))
                                                                     : 
                                                                    (~ (IData)(vlSelf->wasmetal_core__DOT___044881_)))
                                                                    : 
                                                                   (~ (IData)(vlSelf->wasmetal_core__DOT___044884_)))
                                                                   : 
                                                                  (~ (IData)(vlSelf->wasmetal_core__DOT___044885_)))
                                                                  : 
                                                                 (~ (IData)(vlSelf->wasmetal_core__DOT___044886_)))
                                                                 : (IData)(vlSelf->wasmetal_core__DOT___044863_))
                                                                : (IData)(vlSelf->wasmetal_core__DOT___044864_))
                                                               : (IData)(vlSelf->wasmetal_core__DOT___044865_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___044866_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___044867_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___044847_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___044848_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___044849_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___044850_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___044851_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___044852_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___044853_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___044854_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___044855_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___044856_))
                                               : (IData)(vlSelf->wasmetal_core__DOT___044858_))
                                           : (IData)(vlSelf->wasmetal_core__DOT___044859_)));
    wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023181_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__));
    wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023797_)
            ? (IData)(vlSelf->wasmetal_core__DOT___023732_)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d));
    wasmetal_core__DOT___058915_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058912_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058911_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058910_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h263b1cf5__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))));
    wasmetal_core__DOT___058814_ = (1U & (IData)((0x1000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058784_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058783_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058782_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((8U 
                                                                 >> 
                                                                 ((2U 
                                                                   & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127620___O) 
                                                                      >> 2U)) 
                                                                  | (1U 
                                                                     & (4U 
                                                                        >> (IData)(vlSelf->__VdfgTmp_had5b18f3__0))))) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((8U 
                                                                    >> 
                                                                    ((2U 
                                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127621___O) 
                                                                         >> 1U)) 
                                                                     | (1U 
                                                                        & (4U 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hcf1816fa__0))))) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (8U 
                                                                     >> 
                                                                     ((2U 
                                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127624___O) 
                                                                          >> 1U)) 
                                                                      | (1U 
                                                                         & (4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h5b8de47f__0))))))))))))));
    vlSelf->__VdfgTmp_h3056fe7c__0 = ((8U & ((0x10U 
                                              >> (IData)(vlSelf->__VdfgTmp_h963234d4__0)) 
                                             << 3U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                           << 1U) | 
                                          (1U & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O) 
                                                 >> 1U)))));
    vlSelf->__VdfgTmp_h5ac6c849__0 = (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___017945_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058478_) 
                                                     << 1U) 
                                                    | (1U 
                                                       & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___128868___O)))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___036420_));
    vlSelf->wasmetal_core__DOT___058365_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0x80U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))))));
    vlSelf->wasmetal_core__DOT___058294_ = (1U & ((~ 
                                                   (0x40U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hee741df9__0))) 
                                                  & (IData)(
                                                            (0x1111ffff000fffffULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016046_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016045_) 
                                                                        << 2U) 
                                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))))))));
    vlSelf->wasmetal_core__DOT___058336_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((0x80U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015597_))));
    vlSelf->wasmetal_core__DOT___058239_ = (1U & (0xf011U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((IData)(
                                                                  (0xaaaaccccf0f0ff00ULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015613_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015637_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015636_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_h9a784e39__0))))))) 
                                                          << 2U)) 
                                                      | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))));
    wasmetal_core__DOT___058285_ = (1U & (IData)((0xccccaaaaf0f0ff00ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((IData)(
                                                                        (0xaaaaccccff00f0f0ULL 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                << 2U)) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058226_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015730_)))))))));
    __VdfgTmp_h5be2ea26__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                               << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015731_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015730_)));
    vlSelf->__VdfgTmp_h9b99f784__0 = ((2U & ((0x1000U 
                                              >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___058262_));
    vlSelf->wasmetal_core__DOT___058322_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___015964_))));
    wasmetal_core__DOT___043085_ = ((IData)(vlSelf->wasmetal_core__DOT___043121_)
                                     ? ((IData)(vlSelf->wasmetal_core__DOT___043120_)
                                         ? ((IData)(vlSelf->wasmetal_core__DOT___043119_)
                                             ? ((IData)(vlSelf->wasmetal_core__DOT___017201_)
                                                 ? 
                                                ((IData)(vlSelf->wasmetal_core__DOT___043118_)
                                                  ? 
                                                 ((IData)(vlSelf->wasmetal_core__DOT___043117_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___043116_)
                                                    ? 
                                                   ((IData)(vlSelf->wasmetal_core__DOT___043115_)
                                                     ? 
                                                    ((1U 
                                                      & (8U 
                                                         >> (IData)(vlSelf->__VdfgTmp_hb820c59b__0)))
                                                      ? 
                                                     ((IData)(vlSelf->wasmetal_core__DOT___043125_)
                                                       ? 
                                                      ((IData)(vlSelf->wasmetal_core__DOT___043124_)
                                                        ? 
                                                       ((IData)(vlSelf->wasmetal_core__DOT___043123_)
                                                         ? 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___043122_)
                                                          ? 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___017375_)
                                                           ? 
                                                          ((IData)(vlSelf->wasmetal_core__DOT___017269_)
                                                            ? 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___017371_)
                                                             ? 
                                                            ((IData)(vlSelf->wasmetal_core__DOT___017372_)
                                                              ? 
                                                             ((~ (IData)(vlSelf->wasmetal_core__DOT___017412_)) 
                                                              & (IData)(vlSelf->wasmetal_core__DOT___043095_))
                                                              : (IData)(vlSelf->wasmetal_core__DOT___043104_))
                                                             : (IData)(vlSelf->wasmetal_core__DOT___043105_))
                                                            : (IData)(vlSelf->wasmetal_core__DOT___043106_))
                                                           : (IData)(vlSelf->wasmetal_core__DOT___043107_))
                                                          : (IData)(vlSelf->wasmetal_core__DOT___043108_))
                                                         : (IData)(vlSelf->wasmetal_core__DOT___043109_))
                                                        : (IData)(vlSelf->wasmetal_core__DOT___043110_))
                                                       : (IData)(vlSelf->wasmetal_core__DOT___043111_))
                                                      : (IData)(vlSelf->wasmetal_core__DOT___043112_))
                                                     : (IData)(vlSelf->wasmetal_core__DOT___043096_))
                                                    : (IData)(vlSelf->wasmetal_core__DOT___043097_))
                                                   : (IData)(vlSelf->wasmetal_core__DOT___043098_))
                                                  : (IData)(vlSelf->wasmetal_core__DOT___043099_))
                                                 : (IData)(vlSelf->wasmetal_core__DOT___043100_))
                                             : (IData)(vlSelf->wasmetal_core__DOT___043101_))
                                         : (IData)(vlSelf->wasmetal_core__DOT___043102_))
                                     : (IData)(vlSelf->wasmetal_core__DOT___043103_));
    __VdfgTmp_hc7c22dbd__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
    vlSelf->__VdfgTmp_h9d948fd9__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)));
    __VdfgTmp_h2fff67d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015851_) 
                               << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0));
    vlSelf->wasmetal_core__DOT___058297_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0xeeee0000fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    wasmetal_core__DOT___058340_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015928_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015927_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT___058264_ = (1U & (0xf1111U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058260_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xeU 
                                                              >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0))))));
    wasmetal_core__DOT___016123_ = (1U & (1U >> ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   & (IData)(
                                                             (0x555533330f0f00ffULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015738_) 
                                                                      << 3U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                                                  << 1U) 
                                                 | (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                        ? 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0))))
                                                        : 
                                                       (0x503U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_h766529e2__0)))))))));
    __VdfgTmp_h1a57c023__0 = ((((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                & (IData)((0xff00ff5533330f0fULL 
                                           >> (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                << 5U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015943_) 
                                                      << 3U) 
                                                     | (IData)(vlSelf->__VdfgTmp_h1811098d__0))))))) 
                               << 1U) | (1U & ((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                ? (IData)(vlSelf->wasmetal_core__DOT___015840_)
                                                : (0x503U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015868_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___015867_))))))));
    wasmetal_core__DOT___016033_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0xff555533330f0fULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015604_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    wasmetal_core__DOT___015598_ = ((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                    & (IData)((0x555533330f0f00ffULL 
                                               >> (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015689_) 
                                                          << 3U) 
                                                         | (IData)(__VdfgTmp_hb26667c8__0)))))));
    __VdfgTmp_h9c4bb670__0 = ((2U & ((0xacU >> (IData)(__VdfgTmp_h7e4803dd__0)) 
                                     << 1U)) | (1U 
                                                & (0xacU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h12dd4af8__0)))));
    wasmetal_core__DOT___016004_ = (1U & (0x5300U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                            << 3U) 
                                           | (IData)(__VdfgTmp_h7e4803dd__0))));
    __VdfgTmp_he0d9cd96__0 = (((IData)(wasmetal_core__DOT___015977_) 
                               << 1U) | (IData)(wasmetal_core__DOT___015976_));
    vlSelf->wasmetal_core__DOT___058305_ = (1U & (0x5500fcU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015817_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_)))))));
    wasmetal_core__DOT___058273_ = (1U & (IData)((0xeeee0000fff00000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___016043_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___016044_) 
                                                             << 2U) 
                                                            | (IData)(__VdfgTmp_he6226459__0))))))));
    vlSelf->wasmetal_core__DOT___058361_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058315_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(__VdfgTmp_h816ad3b7__0))))));
    vlSelf->wasmetal_core__DOT___058354_ = (1U & ((1U 
                                                   & (0x40U 
                                                      >> (IData)(vlSelf->__VdfgTmp_hee741df9__0)))
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_hcaafbee5__0))))
                                                    : 
                                                   (0xe000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_ha292b77c__0)))))));
    if (vlSelf->wasmetal_core__DOT___015594_) {
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h70395930__0)))));
        if (vlSelf->wasmetal_core__DOT___015596_) {
            wasmetal_core__DOT___058281_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058278_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
        } else {
            wasmetal_core__DOT___058281_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015954_));
            wasmetal_core__DOT___058278_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015932_));
        }
    } else {
        vlSelf->wasmetal_core__DOT___058335_ = (1U 
                                                & (0xf0e0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                        << 2U) 
                                                       | (IData)(__VdfgTmp_ha292b77c__0)))));
        wasmetal_core__DOT___058281_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015953_)));
        wasmetal_core__DOT___058278_ = (1U & ((~ (IData)(vlSelf->wasmetal_core__DOT___015596_)) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015931_)));
    }
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b57__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015954_)))))));
    vlSelf->wasmetal_core__DOT___058356_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015954_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h0d424198__0))))))));
    vlSelf->__VdfgTmp_h1ac41acf__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___015954_)));
    wasmetal_core__DOT___058327_ = (1U & (IData)((0xeeee0000fff0ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                                          << 3U) 
                                                         | (((IData)(wasmetal_core__DOT___015993_) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___015992_)))))))));
    __VdfgTmp_h61bc6a8d__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                          << 2U) | 
                                         (((IData)(vlSelf->wasmetal_core__DOT___015994_) 
                                           << 1U) | (IData)(wasmetal_core__DOT___015993_))));
    wasmetal_core__DOT___058252_ = (1U & (0xe0U >> 
                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                            << 2U) 
                                           | (((IData)(wasmetal_core__DOT___015993_) 
                                               << 1U) 
                                              | (IData)(vlSelf->wasmetal_core__DOT___015994_)))));
    wasmetal_core__DOT___015963_ = (1U & (1U >> (((IData)(vlSelf->wasmetal_core__DOT___015818_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___015819_))));
    __VdfgTmp_hf54ed2ea__0 = (((IData)(wasmetal_core__DOT___015819_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015818_));
    vlSelf->wasmetal_core__DOT___058362_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (0xe000U 
                                                         >> (IData)(vlSelf->__VdfgTmp_h45982c59__0))))));
    vlSelf->wasmetal_core__DOT___058349_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((0xe00U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)) 
                                                          << 1U)) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058283_)))));
    __VdfgTmp_hd06a07d0__0 = (((IData)(vlSelf->wasmetal_core__DOT___058230_) 
                               << 1U) | (IData)(wasmetal_core__DOT___058231_));
    vlSelf->__VdfgTmp_hac8f2958__0 = (((IData)(wasmetal_core__DOT___058231_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058230_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b60__05d 
        = (1U & (0x807fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                         << 2U) | (IData)(__VdfgTmp_hc9f60877__0)))));
    wasmetal_core__DOT___058289_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                           ? (0x1111000fU 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015849_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)))))
                                           : (1U >> (IData)(vlSelf->wasmetal_core__DOT___015969_))));
    vlSelf->wasmetal_core__DOT___016450_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058289_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0xccccaaaaf0f0ff00ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058286_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058243_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058246_)))))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___015850_))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b56__05d 
        = (1U & (0x4000bfffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___015932_)))))));
    vlSelf->wasmetal_core__DOT___058355_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015932_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h86126eef__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b61__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058363_))));
    vlSelf->wasmetal_core__DOT___058324_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___016132_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___016132_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015850_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0))
                                                    : 
                                                   (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015848_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___015849_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b28__05d 
        = (1U & (0x55c0aa3fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058324_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b62__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058364_))));
    vlSelf->wasmetal_core__DOT___058249_ = (1U & (0xfee0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((0xffaa0fccU 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___058245_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058244_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___058243_)))))) 
                                                             << 2U)) 
                                                         | (((IData)(wasmetal_core__DOT___016071_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___016072_)))))));
    vlSelf->wasmetal_core__DOT___058091_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___006589_)))));
    vlSelf->wasmetal_core__DOT___049343_ = (1U & (IData)(
                                                         (0xf0004400000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02edivide_unit__02esqrtOp) 
                                                               << 4U) 
                                                              | ((8U 
                                                                  & ((8U 
                                                                      >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)) 
                                                                     << 3U)) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___014612_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___049341_)))))))));
    vlSelf->__VdfgTmp_h7b6a46b3__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d));
    vlSelf->__VdfgTmp_he488fa83__0 = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d));
    vlSelf->wasmetal_core__DOT____Vcellinp___135065___A 
        = (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_a__02esig__05b52__05d) 
            << 0x12U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b51__05d) 
                          << 0x11U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b50__05d) 
                                        << 0x10U) | 
                                       (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b49__05d) 
                                         << 0xfU) | 
                                        (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b48__05d) 
                                          << 0xeU) 
                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b47__05d) 
                                             << 0xdU) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b46__05d) 
                                                << 0xcU) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b45__05d) 
                                                   << 0xbU) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b44__05d) 
                                                      << 0xaU) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b43__05d) 
                                                         << 9U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b42__05d) 
                                                            << 8U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b41__05d) 
                                                               << 7U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b40__05d) 
                                                                  << 6U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b39__05d) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b38__05d) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b37__05d) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b36__05d) 
                                                                              << 2U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b34__05d)))))))))))))))))));
    vlSelf->wasmetal_core__DOT___017195_ = (((IData)(vlSelf->wasmetal_core__DOT___017375_) 
                                             & ((IData)(vlSelf->wasmetal_core__DOT___017374_) 
                                                & (IData)(
                                                          (0x8000000000000000ULL 
                                                           >> 
                                                           (((IData)(wasmetal_core__DOT___017373_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017372_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017371_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017370_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hb820c59b__0))))))))) 
                                            & (((IData)(vlSelf->wasmetal_core__DOT___017342_) 
                                                & (IData)(
                                                          (0x1001000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017341_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017340_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017339_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017338_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_h6cc9accb__0)))))))) 
                                               & (IData)(
                                                         (0x8000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017206_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017205_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017204_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017203_) 
                                                                     << 2U) 
                                                                    | ((((IData)(vlSelf->wasmetal_core__DOT___017234_) 
                                                                         & ((IData)(vlSelf->wasmetal_core__DOT___017233_) 
                                                                            & (IData)(
                                                                                (0x9009000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___017232_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___017231_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5fa4cdd4__0))))))) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___017201_))))))))));
    wasmetal_core__DOT___051533_ = (1U & (IData)((0x100000000ULL 
                                                  >> 
                                                  ((0x20U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 2U)) 
                                                   | ((0x10U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                          << 4U)) 
                                                      | ((8U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 3U)) 
                                                         | ((4U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U)) 
                                                            | (3U 
                                                               & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                  >> 1U)))))))));
    vlSelf->wasmetal_core__DOT___017519_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128846___O) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                         >> 3U)))));
    if ((1U & (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0)))) {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b62__05d;
    } else {
        wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__;
        wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__ 
            = wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036962_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hcbf9eea7__0))));
    vlSelf->wasmetal_core__DOT___063400_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050397_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___063368_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052887_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053568_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___063371_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063367_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053569_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053355_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053093_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053592_)))))))));
    vlSelf->wasmetal_core__DOT___063426_ = (1U & (IData)(
                                                         (0x700000000ULL 
                                                          >> 
                                                          (((IData)(wasmetal_core__DOT___063368_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052883_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hde1d4dea__0)) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h93f3e051__0))))))));
    vlSelf->wasmetal_core__DOT___019797_ = (1U & (IData)(
                                                         (0xb000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___051230_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051229_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050388_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___051228_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_hc49c7557__0)) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051227_)))))))));
    vlSelf->wasmetal_core__DOT___067736_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xbbb00000U 
                                                                         >> 
                                                                         (((IData)(wasmetal_core__DOT___067727_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___053926_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___052644_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b34__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___063450_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h84433958__0))))))));
    vlSelf->wasmetal_core__DOT___067670_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___067661_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067660_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___067659_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b33__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hd2ae5a25__0))))))));
    vlSelf->wasmetal_core__DOT___069099_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069093_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069092_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001124_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b60__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hc23ff14f__0))))))));
    vlSelf->wasmetal_core__DOT___069147_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069142_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069141_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001146_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b61__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h26fdb0d9__0))))))));
    vlSelf->wasmetal_core__DOT___068975_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___068971_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___068970_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001080_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b58__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h99cf87be__0))))))));
    vlSelf->wasmetal_core__DOT___069239_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x8f00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069236_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069235_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069234_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__alu__02eb__05b63__05d) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hae6fbe86__0))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h965c3061__0))))))));
    vlSelf->wasmetal_core__DOT___069167_ = (1U & (IData)(
                                                         (0xcfaf0f0f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063451_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___050430_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((IData)(
                                                                                (0x45cf00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___069161_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___069160_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048278_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___001168_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063450_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__value_aux__05b62__05d)))))))) 
                                                                        << 2U)) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hf266c674__0))))))));
    wasmetal_core__DOT___048489_ = (1U & (1U >> (((IData)(wasmetal_core__DOT___044837_) 
                                                  << 2U) 
                                                 | ((2U 
                                                     & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127950___CO) 
                                                        >> 2U)) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___044240_)))));
    vlSelf->wasmetal_core__DOT____Vcellout___127527___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023182_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___023181_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023243_) 
                                   << 1U) | (1U & (0x5cU 
                                                   >> (IData)(vlSelf->__VdfgTmp_h3b955ce1__0)))))) 
           ^ (((IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___127527___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023305_)))));
    vlSelf->wasmetal_core__DOT___023246_ = ((IData)(vlSelf->wasmetal_core__DOT___023182_) 
                                            & (IData)(wasmetal_core__DOT___127527___DOT__CO__BRA__2__KET__));
    wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023798_)
            ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__)
            : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b60__05d));
    wasmetal_core__DOT___058922_ = (1U & (IData)((0x100000000000000ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058917_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058916_) 
                                                       << 4U) 
                                                      | (((IData)(wasmetal_core__DOT___058915_) 
                                                          << 3U) 
                                                         | ((4U 
                                                             & ((4U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h8fda36d2__0)) 
                                                                << 2U)) 
                                                            | ((2U 
                                                                & ((4U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_hf2c31503__0)) 
                                                                   << 1U)) 
                                                               | (1U 
                                                                  & (4U 
                                                                     >> (IData)(vlSelf->__VdfgTmp_hea953bdf__0)))))))))));
    wasmetal_core__DOT___058818_ = (1U & (IData)((0xb00000000000000ULL 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058814_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058813_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058812_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b51__05d) 
                                                             << 2U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d) 
                                                                << 1U) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___005882_)))))))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b63__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058365_))));
    vlSelf->wasmetal_core__DOT___058306_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(wasmetal_core__DOT___058240_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058239_))))));
    vlSelf->wasmetal_core__DOT___058241_ = (1U & (0xffaa0c0fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                       << 3U) 
                                                      | (((IData)(wasmetal_core__DOT___058240_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058238_)))))));
    vlSelf->wasmetal_core__DOT___058303_ = (1U & (IData)(
                                                         (0xafcf00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 3U) 
                                                                 | (IData)(__VdfgTmp_h5be2ea26__0)))))));
    vlSelf->wasmetal_core__DOT___058232_ = (1U & ((~ 
                                                   (0x5030000U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & ((IData)(
                                                                          (0xaaaaccccff00f0f0ULL 
                                                                           >> (IData)(vlSelf->__VdfgTmp_hffe7d15f__0))) 
                                                                  << 1U)) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___058226_))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ffafffcfULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015732_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 3U) 
                                                                    | (IData)(__VdfgTmp_h5be2ea26__0))))))));
    vlSelf->wasmetal_core__DOT___058360_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h9b99f784__0)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b59__05d 
        = (1U & (0x87U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058322_)))));
    vlSelf->wasmetal_core__DOT___017197_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___043068_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017411_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___043085_)))));
    vlSelf->wasmetal_core__DOT___058353_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))));
    vlSelf->__VdfgTmp_he58e0004__0 = (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                       << 3U) | (IData)(__VdfgTmp_h2fff67d0__0));
    vlSelf->wasmetal_core__DOT___058341_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058340_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016051_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)))))))))));
    vlSelf->wasmetal_core__DOT___058518_ = (1U & (0xfefU 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___058340_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | ((2U 
                                                             & ((1U 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___015594_)))))));
    vlSelf->wasmetal_core__DOT___058321_ = (1U & (0xc5U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & (((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                            ? (IData)(wasmetal_core__DOT___016123_)
                                                            : 
                                                           ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                             ? (IData)(vlSelf->wasmetal_core__DOT___016122_)
                                                             : 
                                                            (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___016116_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016115_))))) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xe000U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))));
    vlSelf->wasmetal_core__DOT___016448_ = (1U & (IData)(
                                                         (0xff00f0f011111111ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058285_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___016123_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058283_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xe00U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h45982c59__0)))))))))));
    vlSelf->wasmetal_core__DOT___058334_ = (1U & (0xf10000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___016033_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                          << 2U) 
                                                         | (IData)(__VdfgTmp_he6226459__0))))));
    vlSelf->wasmetal_core__DOT___058342_ = (1U & (IData)(
                                                         (0xfff1ff0000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___015599_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___015598_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (1U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)))))))))));
    vlSelf->wasmetal_core__DOT___016441_ = (1U & (1U 
                                                  >> 
                                                  ((((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                     & (IData)(
                                                               (0xeeee0000fff0ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015949_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015950_) 
                                                                           << 2U) 
                                                                          | (IData)(vlSelf->__VdfgTmp_h0d424198__0)))))))) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___016062_))))
                                                          : 
                                                         ((IData)(wasmetal_core__DOT___015598_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_h36951d10__0))))))))));
    vlSelf->wasmetal_core__DOT___058225_ = (1U & ((~ (IData)(
                                                             (0x1111fff000000000ULL 
                                                              >> 
                                                              (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                << 5U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 4U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___016062_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___016063_) 
                                                                         << 2U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___058224_))))))))) 
                                                  & (IData)(
                                                            (0xff00ff00ff0fffefULL 
                                                             >> 
                                                             (((IData)(wasmetal_core__DOT___015599_) 
                                                               << 5U) 
                                                              | (((IData)(wasmetal_core__DOT___015598_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                     << 3U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                        << 2U) 
                                                                       | ((2U 
                                                                           & ((1U 
                                                                               >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)) 
                                                                              << 1U)) 
                                                                          | (IData)(vlSelf->wasmetal_core__DOT___015594_))))))))));
    vlSelf->wasmetal_core__DOT___058296_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                   ? 
                                                  (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | (IData)(vlSelf->__VdfgTmp_h9a38454b__0)))
                                                   : 
                                                  ((IData)(wasmetal_core__DOT___016051_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)))))));
    vlSelf->__VdfgTmp_hf599dae9__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (1U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058297_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___058296_)))));
    vlSelf->wasmetal_core__DOT___058302_ = (1U & (0x5300U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                       << 2U) 
                                                      | (IData)(__VdfgTmp_h9c4bb670__0)))));
    vlSelf->wasmetal_core__DOT___058233_ = ((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                            & (IData)(
                                                      (0x55553333fff0fff0ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015772_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015771_) 
                                                                  << 2U) 
                                                                 | (IData)(__VdfgTmp_h9c4bb670__0))))))));
    vlSelf->__VdfgTmp_ha2f7036a__0 = (((IData)(wasmetal_core__DOT___016004_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016003_));
    if (vlSelf->wasmetal_core__DOT___015596_) {
        wasmetal_core__DOT___058318_ = (1U & (1U >> (IData)(__VdfgTmp_hdf3675f5__0)));
        wasmetal_core__DOT___058311_ = (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h2acad42a__0)));
        if (vlSelf->wasmetal_core__DOT___015594_) {
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_hf69e15ee__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015850_)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___016125_)));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015820_)));
        } else {
            vlSelf->wasmetal_core__DOT___058351_ = 
                (1U & (0xe0U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                  << 2U) | (IData)(vlSelf->__VdfgTmp_h5b5b6b1b__0))));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf69e15ee__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (2U >> (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                               << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015820_))));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
        }
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___016072_) 
                                                     << 1U) 
                                                    | (IData)(wasmetal_core__DOT___016071_))));
        vlSelf->wasmetal_core__DOT___058314_ = (1U 
                                                & (IData)(wasmetal_core__DOT___016097_));
        vlSelf->wasmetal_core__DOT___058316_ = (1U 
                                                & (1U 
                                                   >> (IData)(__VdfgTmp_h1a57c023__0)));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & (0xe0U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 2U) 
                                                    | ((2U 
                                                        & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                             ? 
                                                            (0xeU 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (IData)(vlSelf->__VdfgTmp_h14009f5a__0)))
                                                             : 
                                                            (0x53U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                  << 2U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc102c9b5__0))))) 
                                                           << 1U)) 
                                                       | (1U 
                                                          & (0xe0U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 2U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058268_) 
                                                                  << 1U) 
                                                                 | (IData)(vlSelf->wasmetal_core__DOT___058269_)))))))));
        vlSelf->wasmetal_core__DOT___058312_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h4f78e4d3__0)));
    } else {
        if (vlSelf->wasmetal_core__DOT___015594_) {
            wasmetal_core__DOT___058318_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h36951d10__0)));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___015976_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___015977_))));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h5abf1189__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(__VdfgTmp_h2fff67d0__0)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_h7369d2e1__0)));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015826_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (1U >> (IData)(__VdfgTmp_hf54ed2ea__0)));
            vlSelf->wasmetal_core__DOT___058312_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_ha2f7036a__0)));
        } else {
            wasmetal_core__DOT___058318_ = (1U & (IData)(vlSelf->wasmetal_core__DOT___015953_));
            wasmetal_core__DOT___058311_ = (1U & (1U 
                                                  >> (IData)(vlSelf->__VdfgTmp_h7f6f5bfd__0)));
            vlSelf->wasmetal_core__DOT___058314_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hcaafbee5__0)));
            vlSelf->wasmetal_core__DOT___058248_ = 
                (1U & (1U >> (IData)(vlSelf->wasmetal_core__DOT___015851_)));
            vlSelf->wasmetal_core__DOT___058316_ = 
                (1U & (IData)(vlSelf->wasmetal_core__DOT___015931_));
            vlSelf->wasmetal_core__DOT___058323_ = 
                (1U & (IData)(wasmetal_core__DOT___015963_));
            vlSelf->wasmetal_core__DOT___058242_ = 
                (1U & (2U >> (IData)(vlSelf->wasmetal_core__DOT___015821_)));
            vlSelf->wasmetal_core__DOT___058312_ = 
                (1U & (1U >> (IData)(vlSelf->__VdfgTmp_hf1a5f561__0)));
        }
        vlSelf->wasmetal_core__DOT___058351_ = (1U 
                                                & (8U 
                                                   >> (IData)(__VdfgTmp_hc9f60877__0)));
        vlSelf->wasmetal_core__DOT___058308_ = (1U 
                                                & (0xf011U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015850_) 
                                                        << 2U) 
                                                       | (IData)(vlSelf->__VdfgTmp_h0dbc0f0f__0)))));
        vlSelf->wasmetal_core__DOT___058295_ = (1U 
                                                & ((IData)(wasmetal_core__DOT___016033_)
                                                    ? 
                                                   (2U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                    : 
                                                   (0xe00U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                         << 2U) 
                                                        | (IData)(__VdfgTmp_h5abf1189__0))))));
    }
    vlSelf->__VdfgTmp_hfb1d3885__0 = (((IData)(vlSelf->wasmetal_core__DOT___016003_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___016004_));
    vlSelf->wasmetal_core__DOT___058255_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015992_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015991_) 
                                                                     << 2U) 
                                                                    | (IData)(__VdfgTmp_he0d9cd96__0))))))));
    vlSelf->wasmetal_core__DOT___058346_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___058272_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___058273_)))));
    vlSelf->wasmetal_core__DOT___058275_ = (1U & (IData)(
                                                         (0xaaaaff0003030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___016097_) 
                                                                  << 3U) 
                                                                 | (((IData)(wasmetal_core__DOT___058273_) 
                                                                     << 2U) 
                                                                    | (((IData)(wasmetal_core__DOT___058272_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xfff01111U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 4U) 
                                                                              | ((8U 
                                                                                & ((0xf0f0ccaaU 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha298e6e0__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058269_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___058268_)))))))))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b55__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058361_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b47__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058354_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b49__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058356_))));
    vlSelf->wasmetal_core__DOT___058319_ = (1U & (0xff00bfbfU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058318_) 
                                                       << 3U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h1ac41acf__0)))));
    vlSelf->wasmetal_core__DOT___058348_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058281_))));
    vlSelf->wasmetal_core__DOT___016447_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058281_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f000eeU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058221_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058224_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015981_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___015607_)))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_hdf3675f5__0))))))));
    vlSelf->wasmetal_core__DOT___058328_ = (1U & (IData)(
                                                         (0x1f1f00ff00ffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(wasmetal_core__DOT___058327_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058326_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(__VdfgTmp_he0d9cd96__0))))))))))));
    vlSelf->wasmetal_core__DOT___058352_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                   ? 
                                                  (2U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                    ? 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                    : 
                                                   (0xe000U 
                                                    >> (IData)(__VdfgTmp_h61bc6a8d__0)))));
    vlSelf->wasmetal_core__DOT___016451_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___015995_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_hc7c22dbd__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(__VdfgTmp_h61bc6a8d__0)))) 
                                                       << 1U)) 
                                                   | ((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      & (IData)(
                                                                (0xff00fff0f0fefeULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015979_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___015978_) 
                                                                            << 2U) 
                                                                           | (IData)(__VdfgTmp_he0d9cd96__0)))))))))));
    vlSelf->wasmetal_core__DOT___016442_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___058311_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(wasmetal_core__DOT___058252_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058253_)))))));
    vlSelf->__VdfgTmp_h240228f9__0 = (((IData)(vlSelf->wasmetal_core__DOT___058253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___058252_));
    vlSelf->__VdfgTmp_hf1c161b0__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                  << 3U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                     << 2U) 
                                                    | (((IData)(wasmetal_core__DOT___015963_) 
                                                        << 1U) 
                                                       | (1U 
                                                          & (1U 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___015816_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___015817_))))))));
    vlSelf->__VdfgTmp_hb564d990__0 = (((IData)(vlSelf->wasmetal_core__DOT___015821_) 
                                       << 2U) | (IData)(__VdfgTmp_hf54ed2ea__0));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b58__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058362_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b42__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058349_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b50__05d 
        = (1U & (0xe0001fffU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (IData)(__VdfgTmp_hd06a07d0__0))))));
    vlSelf->__VdfgTmp_hbec899f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                  << 2U) 
                                                 | (IData)(__VdfgTmp_hd06a07d0__0)));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b44__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058351_))));
    vlSelf->__VdfgTmp_h3c71f500__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016450_));
    vlSelf->wasmetal_core__DOT___016460_ = (1U & (IData)(
                                                         (0x7fULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058364_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058363_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058355_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___015596_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b48__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058355_))));
    vlSelf->wasmetal_core__DOT___058347_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 1U) 
                                                   | (IData)(wasmetal_core__DOT___058278_))));
    vlSelf->wasmetal_core__DOT___058279_ = (1U & (IData)(
                                                         (0xf0f01111ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058278_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xf0f0ccaaU 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___015607_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___058276_) 
                                                                                << 2U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha6796979__0))))) 
                                                                        << 2U)) 
                                                                    | (IData)(__VdfgTmp_h1a57c023__0))))))));
    vlSelf->__VdfgTmp_h86dfc376__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058314_))));
    vlSelf->wasmetal_core__DOT___058090_ = (1U & (7U 
                                                  >> 
                                                  ((4U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h7b6a46b3__0)) 
                                                       << 2U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_h11374272__0))));
    vlSelf->__VdfgTmp_hc204a2d8__0 = ((4U & ((9U >> 
                                              (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                << 1U) 
                                               | (IData)(vlSelf->wasmetal_core__DOT___017194_))) 
                                             << 2U)) 
                                      | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                          << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017196_)));
    vlSelf->wasmetal_core__DOT___057697_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___051533_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057695_))));
    vlSelf->wasmetal_core__DOT___036315_ = (1U & (0xbU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015777_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT___013209_ = (1U & (7U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___051533_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057693_ = (1U & (0xe0ffU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 3U) 
                                                   | ((4U 
                                                       & ((8U 
                                                           >> 
                                                           (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                               >> 1U))) 
                                                          << 2U)) 
                                                      | ((2U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                             << 1U)) 
                                                         | (1U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                               >> 3U)))))));
    vlSelf->wasmetal_core__DOT___013621_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___057689_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((8U 
                                                        >> 
                                                        (3U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                            >> 1U))) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___017519_))));
    vlSelf->wasmetal_core__DOT____Vcellout___128791___O 
        = (((8U & ((~ (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128791___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128791___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035873_)))));
    if ((1U & (9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)))) {
        vlSelf->wasmetal_core__DOT___035864_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
        vlSelf->wasmetal_core__DOT___035721_ = wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__;
    } else {
        vlSelf->wasmetal_core__DOT___035864_ = wasmetal_core__DOT___128791___DOT__CO__BRA__2__KET__;
        vlSelf->wasmetal_core__DOT___035721_ = vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02ea__05b63__05d;
    }
    vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__ 
        = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036951_)
                  ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__)
                  : (6U >> (IData)(vlSelf->__VdfgTmp_hfa042eae__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___128777___O 
        = (((8U & ((9U >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0)) 
                   << 3U)) | (IData)(wasmetal_core__DOT____VdfgTmp_hc1bf57ea__0)) 
           ^ (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(wasmetal_core__DOT___128777___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128777___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___035729_)))));
    vlSelf->wasmetal_core__DOT___053574_ = (1U & (IData)(
                                                         (0x8b8bff00bbbbff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053572_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___048489_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052840_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052841_)))))))));
    vlSelf->wasmetal_core__DOT___053489_ = (1U & (0x40000000U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___048489_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___053484_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->__VdfgTmp_h1205819c__0 = (((IData)(wasmetal_core__DOT___048489_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009544_));
    vlSelf->wasmetal_core__DOT___007872_ = (1U & (0x10000000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009541_) 
                                                    << 4U) 
                                                   | (((IData)(wasmetal_core__DOT___048489_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___048488_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___048487_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___048486_)))))));
    vlSelf->wasmetal_core__DOT___005849_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 2U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_hb31c73a1__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h397c5a04__0)))));
    vlSelf->wasmetal_core__DOT___005783_ = (1U & (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                   >> 1U) 
                                                  & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                      ? (IData)(
                                                                (0xf3f0f2e0f3faaaaULL 
                                                                 >> (IData)(vlSelf->__VdfgTmp_h444b75da__0)))
                                                      : 
                                                     (0x302U 
                                                      >> (IData)(vlSelf->__VdfgTmp_h399a9b9d__0)))));
    vlSelf->wasmetal_core__DOT___005782_ = (IData)(
                                                   (((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127527___O) 
                                                     >> 3U) 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT___005715_)
                                                        ? (IData)(
                                                                  (0xf3f0f2e0f3faaaaULL 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                     << 5U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                                        << 4U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                                           << 3U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                                              << 2U) 
                                                                             | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))))
                                                        : 
                                                       (0x302U 
                                                        >> 
                                                        (((IData)(vlSelf->wasmetal_core__DOT___005714_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005712_) 
                                                             << 2U) 
                                                            | (IData)(vlSelf->__VdfgTmp_hf53bec91__0)))))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023183_) 
           & (IData)(vlSelf->wasmetal_core__DOT___023246_));
    vlSelf->wasmetal_core__DOT____Vcellout___127591___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___023799_) 
             << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___023798_) 
                        << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023797_))) 
           ^ ((((IData)(vlSelf->wasmetal_core__DOT___023799_)
                 ? (IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__)
                 : (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d)) 
               << 3U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(wasmetal_core__DOT___127591___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___023732_)))));
    vlSelf->wasmetal_core__DOT___058928_ = (1U & (IData)(
                                                         (0x100000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___058924_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058923_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___058922_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)) 
                                                                        << 2U)) 
                                                                    | ((2U 
                                                                        & ((4U 
                                                                            >> (IData)(vlSelf->__VdfgTmp_h8ddb6508__0)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0)))))))))));
    vlSelf->wasmetal_core__DOT___058929_ = (1U & ((IData)(
                                                          (0x1000000000000ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___058862_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___058861_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___058860_) 
                                                                   << 3U) 
                                                                  | ((4U 
                                                                      & ((4U 
                                                                          >> 
                                                                          (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b13__05d) 
                                                                            << 1U) 
                                                                           | (IData)(vlSelf->wasmetal_core__DOT___006204_))) 
                                                                         << 2U)) 
                                                                     | ((2U 
                                                                         & ((4U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b19__05d) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT___003806_))) 
                                                                            << 1U)) 
                                                                        | (1U 
                                                                           & (4U 
                                                                              >> 
                                                                              (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b28__05d) 
                                                                                << 1U) 
                                                                               | (IData)(vlSelf->wasmetal_core__DOT___006144_))))))))))) 
                                                  & (IData)(
                                                            (0x8000000000000000ULL 
                                                             >> 
                                                             (((IData)(vlSelf->wasmetal_core__DOT___017453_) 
                                                               << 5U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017452_) 
                                                                  << 4U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017451_) 
                                                                     << 3U) 
                                                                    | ((4U 
                                                                        & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058840_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058839_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058838_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005928_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b16__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___003811_))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b43__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006178_))))))))))) 
                                                                           << 2U)) 
                                                                       | ((2U 
                                                                           & ((8U 
                                                                               >> 
                                                                               ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058824_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058823_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058822_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b32__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005889_))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b55__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b57__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006065_))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xb00000000ULL 
                                                                                >> 
                                                                                (((IData)(wasmetal_core__DOT___058818_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058817_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058816_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___005802_))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b61__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___006238_))))))))))) 
                                                                              << 1U)) 
                                                                          | (1U 
                                                                             & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058752_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058751_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058750_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127627___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hff1f1b74__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127628___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hd093a298__0))))))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058724_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058723_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058722_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127630___O)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h9c2e8d35__0))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127629___O) 
                                                                                >> 2U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h276f18a3__0))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127625___O) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0))))))))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
           & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__));
    vlSelf->__VdfgTmp_hf5238d18__0 = (((IData)(vlSelf->wasmetal_core__DOT___058305_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058306_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b54__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058360_))));
    vlSelf->wasmetal_core__DOT___058696_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                    << 2U) 
                                                   | ((2U 
                                                       & ((8U 
                                                           >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                          << 1U)) 
                                                      | (1U 
                                                         & (0xf3f2f333U 
                                                            >> 
                                                            (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                              << 4U) 
                                                             | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                 << 3U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                                    << 2U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT___017195_)))))))))));
    if ((1U & (8U >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)))) {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (1U 
                                                   >> (IData)(vlSelf->wasmetal_core__DOT___017193_)));
    } else {
        vlSelf->wasmetal_core__DOT___058688_ = (1U 
                                                & (IData)(
                                                          (0x5d5d5ddd5d5d5d5fULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
        vlSelf->wasmetal_core__DOT___018273_ = (1U 
                                                & (IData)(
                                                          (0x7777777f55575555ULL 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                             << 5U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                                << 4U) 
                                                               | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                   << 3U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                      << 2U) 
                                                                     | (IData)(vlSelf->__VdfgTmp_hf6eff41b__0))))))));
    }
    vlSelf->wasmetal_core__DOT___058687_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x55570100ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT___018272_ = ((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                            & (IData)(
                                                      (0x222a2223ULL 
                                                       >> 
                                                       ((0x20U 
                                                         & ((8U 
                                                             >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                            << 5U)) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___017197_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017195_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017196_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___005713_)))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b46__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058353_))));
    vlSelf->wasmetal_core__DOT___058358_ = (1U & (IData)(
                                                         (0xfef0000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->wasmetal_core__DOT___058309_ = (1U & (IData)(
                                                         (0xfef000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                               << 4U) 
                                                              | (IData)(vlSelf->__VdfgTmp_he58e0004__0))))));
    vlSelf->__VdfgTmp_h0d8c930c__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058248_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b32__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058341_))));
    vlSelf->wasmetal_core__DOT___016429_ = (1U & (IData)(
                                                         (0xeeeef0f0ff00ff00ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058518_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h9a38454b__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___058276_)))))))));
    vlSelf->__VdfgTmp_h20c89172__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058321_));
    vlSelf->__VdfgTmp_h8d5d3612__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016448_));
    vlSelf->wasmetal_core__DOT___016444_ = (1U & (0x8fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058315_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058314_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___058316_)))))));
    vlSelf->__VdfgTmp_h6df53282__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058317_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058316_))));
    vlSelf->__VdfgTmp_h37243dd3__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058295_) 
                                                  << 2U) 
                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                     << 1U) 
                                                    | (IData)(vlSelf->wasmetal_core__DOT___058294_))));
    vlSelf->wasmetal_core__DOT___058337_ = (1U & (0xf400U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058335_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058334_))))));
    vlSelf->wasmetal_core__DOT___058338_ = (1U & (0xdU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058336_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058334_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058335_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b33__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058342_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b17__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016441_))));
    vlSelf->__VdfgTmp_hba6f19f8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058225_));
    vlSelf->__VdfgTmp_heb95d931__0 = ((2U & ((0xe00U 
                                              >> (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                   << 3U) 
                                                  | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                      << 2U) 
                                                     | (IData)(vlSelf->__VdfgTmp_hac8f2958__0)))) 
                                             << 1U)) 
                                      | (1U & (IData)(
                                                      (0xfff100000000ULL 
                                                       >> 
                                                       (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                         << 5U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___058303_) 
                                                            << 4U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058302_) 
                                                               << 3U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 2U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                     << 1U) 
                                                                    | (IData)(vlSelf->wasmetal_core__DOT___016122_))))))))));
    vlSelf->wasmetal_core__DOT___058343_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))));
    vlSelf->wasmetal_core__DOT___058234_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058233_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058232_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hac8f2958__0))))))));
    vlSelf->wasmetal_core__DOT___016452_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & (((IData)(vlSelf->wasmetal_core__DOT___016021_)
                                                         ? 
                                                        (1U 
                                                         >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                         : 
                                                        ((IData)(vlSelf->wasmetal_core__DOT___015594_)
                                                          ? 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_h9d948fd9__0))
                                                          : 
                                                         (0xe0U 
                                                          >> (IData)(vlSelf->__VdfgTmp_hbb3c60ea__0)))) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT___015596_)
                                                          ? 
                                                         (0xe0U 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 2U) 
                                                           | ((2U 
                                                               & (((IData)(vlSelf->wasmetal_core__DOT___015607_)
                                                                    ? 
                                                                   (0xeU 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 2U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015897_) 
                                                                         << 1U) 
                                                                        | (IData)(vlSelf->wasmetal_core__DOT___015896_))))
                                                                    : 
                                                                   (0x53U 
                                                                    >> 
                                                                    (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                      << 3U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___015606_) 
                                                                         << 2U) 
                                                                        | (IData)(vlSelf->__VdfgTmp_hd3573026__0))))) 
                                                                  << 1U)) 
                                                              | (1U 
                                                                 & (0xe0U 
                                                                    >> (IData)(vlSelf->__VdfgTmp_h2eec3533__0))))))
                                                          : 
                                                         ((IData)(vlSelf->wasmetal_core__DOT___016007_)
                                                           ? 
                                                          (2U 
                                                           >> (IData)(vlSelf->wasmetal_core__DOT___015597_))
                                                           : 
                                                          (0xe00U 
                                                           >> 
                                                           (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                             << 3U) 
                                                            | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                << 2U) 
                                                               | (IData)(vlSelf->__VdfgTmp_ha2f7036a__0))))))))));
    vlSelf->wasmetal_core__DOT___058332_ = (1U & (IData)(
                                                         (0x11ff0fff0fffULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058331_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0x4000U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___016007_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0xeU 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                               << 2U) 
                                                                              | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))))))));
    vlSelf->wasmetal_core__DOT___058265_ = (1U & (IData)(
                                                         (0xeeee0000fff00000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___016018_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___016017_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_hfb1d3885__0))))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b39__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058346_))));
    vlSelf->__VdfgTmp_he7bb7b74__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058275_));
    vlSelf->__VdfgTmp_h6712d737__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058319_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b41__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058348_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b9__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016447_))));
    vlSelf->__VdfgTmp_h7041ac57__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058328_));
    vlSelf->wasmetal_core__DOT___058521_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058354_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058353_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058352_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058351_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b45__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058352_))));
    vlSelf->__VdfgTmp_hbca2c4ae__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016451_));
    vlSelf->__VdfgTmp_he60f6eaf__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016442_));
    vlSelf->wasmetal_core__DOT___058359_ = (1U & (0xe000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                       << 2U) 
                                                      | (IData)(vlSelf->__VdfgTmp_h240228f9__0)))));
    vlSelf->wasmetal_core__DOT___058344_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h240228f9__0))))));
    vlSelf->__VdfgTmp_hc888fbf4__0 = (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                       << 2U) | (IData)(vlSelf->__VdfgTmp_h240228f9__0));
    vlSelf->wasmetal_core__DOT___016431_ = (1U & (0x80U 
                                                  >> 
                                                  ((4U 
                                                    & ((IData)(
                                                               (0x88888888000fffffULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___015969_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->wasmetal_core__DOT___015964_) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___058324_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___058323_)))))))) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058321_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058319_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b27__05d 
        = (1U & (0x3ca5U >> (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058323_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058322_))))));
    vlSelf->wasmetal_core__DOT___058350_ = (1U & (IData)(
                                                         (0x5533f0f000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (IData)(vlSelf->__VdfgTmp_hf1c161b0__0)))));
    vlSelf->wasmetal_core__DOT___016449_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___015597_)
                                                   ? 
                                                  (2U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(
                                                              (0xccccf0f000ff00aaULL 
                                                               >> 
                                                               (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                 << 5U) 
                                                                | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                    << 4U) 
                                                                   | (((IData)(vlSelf->wasmetal_core__DOT___016125_) 
                                                                       << 3U) 
                                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058239_) 
                                                                          << 2U) 
                                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058238_) 
                                                                             << 1U) 
                                                                            | (IData)(vlSelf->wasmetal_core__DOT___015820_))))))))))
                                                   : 
                                                  (0xaacc0f0fU 
                                                   >> (IData)(vlSelf->__VdfgTmp_hf1c161b0__0))));
    vlSelf->wasmetal_core__DOT___058357_ = (1U & (IData)(
                                                         (0xee0f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->wasmetal_core__DOT___058307_ = (1U & (IData)(
                                                         (0xee000f00000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___015594_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hb564d990__0)))))));
    vlSelf->__VdfgTmp_h787befb5__0 = (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058242_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b3__05d 
        = (1U & (0x53acU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                              << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                         << 2U) | (
                                                   ((IData)(vlSelf->wasmetal_core__DOT___058242_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058241_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b40__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058347_))));
    vlSelf->wasmetal_core__DOT___016433_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058279_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058275_))));
    vlSelf->__VdfgTmp_h2a4257a8__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058279_));
    vlSelf->wasmetal_core__DOT___058092_ = (1U & (0xe0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058090_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02earithmetic__02eadd_unit__02erecFNToRawFN_b__02esig__05b52__05d) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h75158e97__0)))))));
    vlSelf->wasmetal_core__DOT___058689_ = (1U & (0x1fU 
                                                  >> 
                                                  ((8U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h5ba5065d__0)) 
                                                       << 3U)) 
                                                   | (IData)(vlSelf->__VdfgTmp_hc204a2d8__0))));
    vlSelf->wasmetal_core__DOT___013204_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017519_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057697_))));
    vlSelf->__VdfgTmp_h8fcc0329__0 = (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___013206_));
    vlSelf->__VdfgTmp_h917221d1__0 = (((IData)(vlSelf->wasmetal_core__DOT___013621_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___015658_));
    vlSelf->wasmetal_core__DOT___057692_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057689_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O)))));
    vlSelf->wasmetal_core__DOT___057698_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127550___O) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057689_))));
    vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__ 
        = ((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
           & (IData)(vlSelf->wasmetal_core__DOT___035864_));
    vlSelf->wasmetal_core__DOT___036940_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___036952_)
                                                   ? (IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__)
                                                   : 
                                                  (9U 
                                                   >> (IData)(vlSelf->__VdfgTmp_h8e7aae2a__0))));
    vlSelf->wasmetal_core__DOT____Vcellout___134181___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT___036952_) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___036951_) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___036962_) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036961_)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___134181___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036948_)))));
    vlSelf->wasmetal_core__DOT___048951_ = (1U & (1U 
                                                  >> 
                                                  ((0x10U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128776___O) 
                                                       << 1U)) 
                                                   | ((8U 
                                                       & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                          << 3U)) 
                                                      | ((4U 
                                                          & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                             << 1U)) 
                                                         | (3U 
                                                            & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128777___O) 
                                                               >> 2U)))))));
    vlSelf->wasmetal_core__DOT___019776_ = (1U & (IData)(
                                                         (0xf7000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053574_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053573_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052835_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052834_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))));
    vlSelf->wasmetal_core__DOT___019415_ = (1U & (IData)(
                                                         (0xffff0000bf000000ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                               << 5U)) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h66357502__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((0xd0000U 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063366_) 
                                                                           << 4U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                              << 3U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050402_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___054469_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->mem_valid)))))) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063365_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___063363_)))))))));
    vlSelf->wasmetal_core__DOT___063403_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048392_))));
    vlSelf->wasmetal_core__DOT___063397_ = (1U & (IData)(
                                                         (0xff00ff004f4f0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT__state__05b4__05d) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063396_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063395_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((1U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (0x4f000000U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___048111_) 
                                                                               << 4U) 
                                                                              | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050361_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (0xf0fd0000U 
                                                                                >> 
                                                                                ((0x10U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 4U)) 
                                                                                | ((8U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                                                << 3U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___048392_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063371_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063370_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063369_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___053096_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053087_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_)))))))))))))))))))));
    vlSelf->wasmetal_core__DOT___052916_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((4U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h1205819c__0)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___051239_))));
    vlSelf->wasmetal_core__DOT___053501_ = (1U & (0x10U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___051239_) 
                                                    << 2U) 
                                                   | (IData)(vlSelf->__VdfgTmp_h1205819c__0))));
    vlSelf->wasmetal_core__DOT___009290_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h83a675b5__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b126__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055000_)))))))));
    wasmetal_core__DOT___009291_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hef8f7e11__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b118__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054998_)))))))));
    wasmetal_core__DOT___055621_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h84d68e3f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b78__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054988_)))))))));
    vlSelf->wasmetal_core__DOT___008935_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9ebbc558__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b70__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054987_)))))))));
    vlSelf->wasmetal_core__DOT___055617_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc08ecb6b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b94__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054990_)))))))));
    vlSelf->wasmetal_core__DOT___055618_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_haf65e04e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b86__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054989_)))))))));
    vlSelf->wasmetal_core__DOT___009292_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h437f0271__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b110__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054996_)))))))));
    vlSelf->wasmetal_core__DOT___009293_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hab3c597f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b102__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054995_)))))))));
    wasmetal_core__DOT___055574_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdc49a285__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b77__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054949_)))))))));
    vlSelf->wasmetal_core__DOT___008904_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5f14afc9__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b69__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054948_)))))))));
    vlSelf->wasmetal_core__DOT___055570_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde99fb2e__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b93__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054951_)))))))));
    wasmetal_core__DOT___055571_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha4d9f57f__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b85__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054950_)))))))));
    wasmetal_core__DOT___055564_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h1ad74d3e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b125__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054959_)))))))));
    wasmetal_core__DOT___055565_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h707c99af__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b117__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054958_)))))))));
    vlSelf->wasmetal_core__DOT___055566_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc03ee7e3__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b109__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054957_)))))))));
    vlSelf->wasmetal_core__DOT___055567_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb18976f4__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b101__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054956_)))))))));
    vlSelf->wasmetal_core__DOT___055544_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd6444f5a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b84__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054900_)))))))));
    vlSelf->wasmetal_core__DOT___055543_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5d9bd5b8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b76__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054898_)))))))));
    vlSelf->wasmetal_core__DOT___008860_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3d3eaa9d__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b68__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054899_)))))))));
    vlSelf->wasmetal_core__DOT___009771_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6eb17b7a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b92__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054901_)))))))));
    wasmetal_core__DOT___009769_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h692f01d1__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b108__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054907_)))))))));
    vlSelf->wasmetal_core__DOT___009770_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h68d11ed0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b100__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054906_)))))))));
    vlSelf->wasmetal_core__DOT___055534_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0e7ef094__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b124__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054909_)))))))));
    wasmetal_core__DOT___009768_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2e164c3d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b116__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054908_)))))))));
    vlSelf->wasmetal_core__DOT___009189_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h815644ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b91__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051496_)))))))));
    vlSelf->wasmetal_core__DOT___051500_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f418a9b__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b83__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051498_)))))))));
    vlSelf->wasmetal_core__DOT___008835_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hce0059e1__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b67__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___051493_)))))))));
    vlSelf->wasmetal_core__DOT___009187_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h79bfec12__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b107__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054861_)))))))));
    vlSelf->wasmetal_core__DOT___009188_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbf3b567a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b99__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054860_)))))))));
    vlSelf->wasmetal_core__DOT___009185_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc530df9f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b123__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054865_)))))))));
    wasmetal_core__DOT___009186_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb918ea35__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b115__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054863_)))))))));
    wasmetal_core__DOT___051495_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h86c1a93d__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b75__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___051491_)))))))));
    vlSelf->wasmetal_core__DOT___055448_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb98e230__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b74__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054808_)))))))));
    vlSelf->wasmetal_core__DOT___009174_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8916279c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b66__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054807_)))))))));
    vlSelf->wasmetal_core__DOT___055444_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hff1fe4fa__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b90__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054810_)))))))));
    vlSelf->wasmetal_core__DOT___055445_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hbb6385ec__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b82__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054809_)))))))));
    vlSelf->wasmetal_core__DOT___009254_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hf2656e40__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b98__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054815_)))))))));
    vlSelf->wasmetal_core__DOT___009253_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h4f29d017__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b106__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054816_)))))))));
    wasmetal_core__DOT___009251_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd9f044bb__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b122__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054820_)))))))));
    wasmetal_core__DOT___009252_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h13d4f79e__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b114__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054818_)))))))));
    wasmetal_core__DOT___055406_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7751d301__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b73__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054768_)))))))));
    vlSelf->wasmetal_core__DOT___009163_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h890db370__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b65__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054767_)))))))));
    vlSelf->wasmetal_core__DOT___055408_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h9fcdfa16__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b81__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054769_)))))))));
    vlSelf->wasmetal_core__DOT___055407_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h5a84499c__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b89__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054770_)))))))));
    wasmetal_core__DOT___009238_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h782800f0__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b121__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054781_)))))))));
    wasmetal_core__DOT___009239_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h43b9ff93__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b113__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054779_)))))))));
    vlSelf->wasmetal_core__DOT___009240_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hc86399cc__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b105__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054777_)))))))));
    vlSelf->wasmetal_core__DOT___009241_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3f534570__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b97__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054775_)))))))));
    vlSelf->wasmetal_core__DOT___055234_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h42498a1f__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b88__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054698_)))))))));
    vlSelf->wasmetal_core__DOT___055235_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h3caf5d97__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b80__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054701_)))))))));
    vlSelf->wasmetal_core__DOT___055236_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h2814f082__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b72__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054705_)))))))));
    vlSelf->wasmetal_core__DOT___009146_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h8893fd49__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b64__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054708_)))))))));
    vlSelf->wasmetal_core__DOT___055228_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h52f4f13a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b104__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054688_)))))))));
    vlSelf->wasmetal_core__DOT___055229_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7780ec55__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b96__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___054691_)))))))));
    wasmetal_core__DOT___055224_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_ha292c154__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b120__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054674_)))))))));
    wasmetal_core__DOT___055225_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd1bccf33__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b112__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___054682_)))))))));
    wasmetal_core__DOT___055692_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb4659c85__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b79__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055034_)))))))));
    vlSelf->wasmetal_core__DOT___008962_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h7a210d44__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b71__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055033_)))))))));
    vlSelf->wasmetal_core__DOT___009303_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hb69256f0__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b111__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055042_)))))))));
    vlSelf->wasmetal_core__DOT___009304_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hde24342a__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b103__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055041_)))))))));
    vlSelf->wasmetal_core__DOT___055696_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h6ce01618__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b87__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055035_)))))))));
    wasmetal_core__DOT___009301_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_h0919a607__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b127__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055046_)))))))));
    wasmetal_core__DOT___009302_ = (1U & (IData)((0x3aaaaaa03030303ULL 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 5U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                       << 4U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                          << 3U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                             << 2U) 
                                                            | ((2U 
                                                                & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                     ? (IData)(
                                                                               (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hdfae4d94__0)))))
                                                                     : 
                                                                    (7U 
                                                                     >> 
                                                                     (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                       << 1U) 
                                                                      | (IData)(vlSelf->wasmetal_core__DOT__top__05b119__05d)))) 
                                                                   << 1U)) 
                                                               | (IData)(vlSelf->wasmetal_core__DOT___055044_)))))))));
    vlSelf->wasmetal_core__DOT___055695_ = (1U & (IData)(
                                                         (0x3aaaaaa03030303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & (((IData)(vlSelf->wasmetal_core__DOT___000356_)
                                                                             ? (IData)(
                                                                                (0xf0f33550f0f0f0fULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___007205_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                                << 4U) 
                                                                                | (IData)(vlSelf->__VdfgTmp_hd79df6c8__0)))))
                                                                             : 
                                                                            (7U 
                                                                             >> 
                                                                             (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                               << 1U) 
                                                                              | (IData)(vlSelf->wasmetal_core__DOT__top__05b95__05d)))) 
                                                                           << 1U)) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055036_)))))))));
    vlSelf->__VdfgTmp_hb0e57990__0 = (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___007872_));
    if (vlSelf->wasmetal_core__DOT___008018_) {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 2U))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O) 
                                                       >> 1U))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & (IData)(vlSelf->wasmetal_core__DOT____Vcellout___134217___O))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (1U 
                                                   >> 
                                                   (1U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___128656___O) 
                                                       >> 3U))));
    } else {
        vlSelf->wasmetal_core__DOT___007844_ = (1U 
                                                & (0x80bfaaaaU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___008495_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (0x35U 
                                                                   >> 
                                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                                >> 3U)) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & vlSelf->insn_x)))))))))));
        vlSelf->wasmetal_core__DOT___007847_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008500_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 2U)))))))));
        vlSelf->wasmetal_core__DOT___007846_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___008017_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(
                                                                          (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                           >> 1U)))))))));
        vlSelf->wasmetal_core__DOT___007858_ = (1U 
                                                & (0x5333ffffU 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                     << 4U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                        << 3U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                           << 2U) 
                                                          | (((IData)(vlSelf->wasmetal_core__DOT___007208_) 
                                                              << 1U) 
                                                             | (1U 
                                                                & (IData)(vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum))))))));
    }
    vlSelf->wasmetal_core__DOT___007880_ = (1U & (0x7fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007869_)))));
    vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__1__KET__ 
        = ((IData)(vlSelf->wasmetal_core__DOT___023184_) 
           & (IData)(vlSelf->wasmetal_core__DOT___127528___DOT__CO__BRA__0__KET__));
    vlSelf->wasmetal_core__DOT___018280_ = (1U & (IData)(
                                                         (0xfff08880fff0fff0ULL 
                                                          >> 
                                                          ((0x20U 
                                                            & ((4U 
                                                                >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                               << 5U)) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058929_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058928_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___058927_) 
                                                                     << 2U) 
                                                                    | ((2U 
                                                                        & ((IData)(
                                                                                (0x8000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058884_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058883_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058882_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x153f000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058876_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058875_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058758_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha2ad37d5__0)) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b59__05d) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b56__05d)))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0x700000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058872_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058871_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058870_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hdd48e33a__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b36__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b35__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_he93f6ca8__0)))))))))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0x700000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058868_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058867_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058866_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h7a46858f__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b33__05d))) 
                                                                                << 2U)) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b20__05d) 
                                                                                << 1U) 
                                                                                | (1U 
                                                                                & (4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h87705c6a__0)))))))))))))))))) 
                                                                           << 1U)) 
                                                                       | (1U 
                                                                          & (IData)(
                                                                                (0x1000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058907_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058906_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058905_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((IData)(
                                                                                (0x1000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___058894_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058893_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___058892_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2b50f7e1__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b46__05d))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h61354930__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b44__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h324d1ed5__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b49__05d))))))))))) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_ha0adc294__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b4__05d))) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (8U 
                                                                                >> 
                                                                                ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_hc2de3b41__0)) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp64__02eintegral_round__02ehalf_bit__05b0__05d))))))))))))))))))));
    vlSelf->wasmetal_core__DOT____Vcellout___128869___O 
        = ((((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
             << 3U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b30__05d) 
                        << 2U) | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b29__05d) 
                                   << 1U) | (IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b28__05d)))) 
           ^ (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__) 
               << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__1__KET__) 
                          << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__0__KET__) 
                                     << 1U) | (IData)(vlSelf->wasmetal_core__DOT___036420_)))));
    vlSelf->wasmetal_core__DOT___036490_ = ((IData)(vlSelf->wasmetal_core__DOT__fpu__02efp32__02econvert_i32__02ecomplUnroundedInt__05b31__05d) 
                                            & (IData)(vlSelf->wasmetal_core__DOT___128869___DOT__CO__BRA__2__KET__));
    vlSelf->__VdfgTmp_hb63e733c__0 = (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058688_));
    vlSelf->wasmetal_core__DOT___059568_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005875_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059596_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006092_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059719_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003810_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059771_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006400_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059799_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003807_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059823_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003811_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059884_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059312_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005928_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059375_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005716_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059418_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005935_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059673_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005982_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059694_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003809_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059746_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006204_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059851_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___003808_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059967_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___059994_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005868_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060026_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006106_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->wasmetal_core__DOT___060182_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006215_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018273_))));
    vlSelf->__VdfgTmp_hef0df0fb__0 = (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->__VdfgTmp_h385650d9__0 = ((2U & ((4U >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___018273_));
    vlSelf->wasmetal_core__DOT___060301_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___060335_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___059667_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006085_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013654_))))));
    vlSelf->wasmetal_core__DOT___019166_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006178_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013739_)))))));
    vlSelf->wasmetal_core__DOT___060646_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058687_))));
    vlSelf->wasmetal_core__DOT___019032_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005795_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013770_)))))));
    vlSelf->wasmetal_core__DOT___019046_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005889_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013771_)))))));
    vlSelf->wasmetal_core__DOT___059644_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___006015_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013648_))))));
    vlSelf->wasmetal_core__DOT___019092_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005802_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013797_)))))));
    vlSelf->wasmetal_core__DOT___019106_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005882_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013796_)))))));
    vlSelf->wasmetal_core__DOT___019116_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005948_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013785_)))))));
    vlSelf->wasmetal_core__DOT___019138_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006051_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013787_)))))));
    vlSelf->wasmetal_core__DOT___019157_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___006029_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013786_)))))));
    vlSelf->wasmetal_core__DOT___019004_ = (1U & (0x111f0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017184_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___005711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___013805_)))))));
    vlSelf->wasmetal_core__DOT___017183_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___005731_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013672_))))));
    vlSelf->__VdfgTmp_he45ddc74__0 = (((IData)(vlSelf->wasmetal_core__DOT___058687_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017186_));
    vlSelf->wasmetal_core__DOT___059911_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002193_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060096_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002634_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019167_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013739_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060462_ = (1U & (IData)(
                                                         (0xeee00000ffff0000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___019006_) 
                                                            << 5U) 
                                                           | ((0x10U 
                                                               & ((8U 
                                                                   >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                  << 4U)) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02eb__05b51__05d) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b51__05d) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___060578_ = (1U & (IData)(
                                                         (0x45cf4545ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017171_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058688_) 
                                                                        << 1U) 
                                                                       | (1U 
                                                                          & (4U 
                                                                             >> (IData)(vlSelf->__VdfgTmp_h8bd952af__0)))))))))));
    vlSelf->wasmetal_core__DOT___060300_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013788_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060334_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013740_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019033_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013770_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019047_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013771_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019093_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013797_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019107_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013796_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019117_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013785_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019139_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013787_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019158_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013786_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___019005_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013805_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060272_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013795_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060374_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013738_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060389_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013918_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060404_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014037_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060412_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013780_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060428_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013778_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060442_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___014245_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___059936_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002472_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060050_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002630_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060075_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002633_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060122_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002631_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060146_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___002632_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060645_ = (1U & (IData)(
                                                         (0x77ff7777030f0303ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___017194_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___018273_) 
                                                                  << 3U) 
                                                                 | ((4U 
                                                                     & ((4U 
                                                                         >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                                        << 2U)) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___019034_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018272_)))))))));
    vlSelf->wasmetal_core__DOT___060483_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048718_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005830_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060500_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048725_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005896_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060514_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048726_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___127601___DOT__CO__BRA__0__KET__) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060542_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048713_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b56__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060556_ = (1U & (0x1f110000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048711_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT__fpu__02ea__05b57__05d) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060528_ = (1U & (0x4f440000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___060482_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___048727_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___005962_) 
                                                             << 1U) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))));
    vlSelf->wasmetal_core__DOT___060618_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048714_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060349_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013737_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060258_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013798_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___018272_))));
    vlSelf->wasmetal_core__DOT___060629_ = (1U & (0xd0U 
                                                  >> 
                                                  ((4U 
                                                    & ((8U 
                                                        >> (IData)(vlSelf->__VdfgTmp_h10c9b581__0)) 
                                                       << 2U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___019197_)))));
    vlSelf->__VdfgTmp_h74741c3a__0 = (((IData)(vlSelf->wasmetal_core__DOT___018272_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___017924_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b52__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058358_))));
    vlSelf->__VdfgTmp_hdd49dc43__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (1U 
                                                 & (0xdU 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___058309_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___058308_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___015597_))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b36__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0))));
    vlSelf->__VdfgTmp_ha1b196f5__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 3U) | (((IData)(vlSelf->wasmetal_core__DOT___058249_) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->__VdfgTmp_h0d8c930c__0)));
    vlSelf->__VdfgTmp_had1ad578__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016429_));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b31__05d 
        = (1U & (0xeU >> (((IData)(vlSelf->wasmetal_core__DOT___058338_) 
                           << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058337_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b18__05d 
        = (1U & (6U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (1U & (1U >> (IData)(vlSelf->__VdfgTmp_heb95d931__0))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b34__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058343_))));
    vlSelf->__VdfgTmp_h8f31d0f1__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058234_));
    vlSelf->wasmetal_core__DOT___016443_ = (1U & (0xff001f1fU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058312_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                          << 2U) 
                                                         | (((IData)(vlSelf->wasmetal_core__DOT___058262_) 
                                                             << 1U) 
                                                            | (1U 
                                                               & (0x1000U 
                                                                  >> (IData)(vlSelf->__VdfgTmp_h2900ee3d__0)))))))));
    vlSelf->__VdfgTmp_ha253f9f2__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016452_));
    vlSelf->__VdfgTmp_he2e2fa14__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058332_));
    vlSelf->wasmetal_core__DOT___058345_ = (1U & (0xf0fe0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                       << 3U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                          << 2U) 
                                                         | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))));
    vlSelf->wasmetal_core__DOT___058266_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058265_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058264_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___015596_) 
                                                                     << 2U) 
                                                                    | (IData)(vlSelf->__VdfgTmp_h9b99f784__0))))))));
    vlSelf->wasmetal_core__DOT___016458_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058361_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___058360_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___058359_)))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b53__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058359_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b37__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058344_))));
    vlSelf->wasmetal_core__DOT___058256_ = (1U & (IData)(
                                                         (0xff00ff000000f1f1ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___058255_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___058254_) 
                                                                  << 3U) 
                                                                 | (IData)(vlSelf->__VdfgTmp_hc888fbf4__0)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b43__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058350_))));
    vlSelf->__VdfgTmp_hff2cd213__0 = (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___016449_));
    vlSelf->wasmetal_core__DOT___058524_ = (1U & (1U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___058358_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b51__05d 
        = (1U & (9U >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                         << 1U) | (IData)(vlSelf->wasmetal_core__DOT___058357_))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i32__02ecomplUnroundedInt__05b19__05d 
        = (1U & (0xffe0001fU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                                  << 4U) | (((IData)(vlSelf->wasmetal_core__DOT___058307_) 
                                             << 3U) 
                                            | (((IData)(vlSelf->wasmetal_core__DOT___015597_) 
                                                << 2U) 
                                               | (((IData)(vlSelf->wasmetal_core__DOT___058306_) 
                                                   << 1U) 
                                                  | (IData)(vlSelf->wasmetal_core__DOT___058305_)))))));
    vlSelf->wasmetal_core__DOT__fpu__02efp64__02econvert_i64__02ecomplUnroundedInt__05b35__05d 
        = (1U & (0x4bU >> (((IData)(vlSelf->wasmetal_core__DOT___005713_) 
                            << 2U) | (IData)(vlSelf->__VdfgTmp_h787befb5__0))));
    vlSelf->wasmetal_core__DOT___017182_ = (1U & (0x40bU 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___017924_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___017185_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___058689_))))));
    vlSelf->wasmetal_core__DOT___060587_ = (1U & (IData)(
                                                         (0xfcffffff00540055ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___048717_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___017193_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___017186_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___005996_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___058689_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___018273_)))))))));
    vlSelf->wasmetal_core__DOT___013523_ = (1U & (0xeee0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                                    << 3U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___013206_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___013209_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___013205_))))));
    vlSelf->__VdfgTmp_h60102cdd__0 = (((IData)(vlSelf->wasmetal_core__DOT___013204_) 
                                       << 1U) | (1U 
                                                 & (0xefU 
                                                    >> (IData)(vlSelf->__VdfgTmp_h83a6d262__0))));
    vlSelf->wasmetal_core__DOT__fpu__02edemote__02egenblk1__02eroundRawInToOut__02egenblk2__02egenblk1__02elowMask_roundMask__02eout__05b24__05d 
        = (1U & (0x8fU >> (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                            << 2U) | ((2U & ((1U >> 
                                              (3U & 
                                               ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                >> 1U))) 
                                             << 1U)) 
                                      | (IData)(vlSelf->wasmetal_core__DOT___057692_)))));
    vlSelf->wasmetal_core__DOT___057725_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                            >> 2U))))));
    vlSelf->wasmetal_core__DOT___017782_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___057717_)))));
    vlSelf->wasmetal_core__DOT___017794_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> 
                                                            (3U 
                                                             & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                                >> 1U))))))));
    vlSelf->wasmetal_core__DOT___017756_ = (1U & (0xb0U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (8U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057694_ = (1U & (0x70U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057693_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___057692_) 
                                                       << 1U) 
                                                      | (1U 
                                                         & (1U 
                                                            >> (IData)(vlSelf->__VdfgTmp_h46c2cf96__0)))))));
    vlSelf->wasmetal_core__DOT___057701_ = (1U & (8U 
                                                  >> 
                                                  ((2U 
                                                    & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                       >> 2U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___057698_))));
    vlSelf->wasmetal_core__DOT___057699_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___057698_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & ((IData)(vlSelf->wasmetal_core__DOT____Vcellout___127549___O) 
                                                         >> 3U)))));
    vlSelf->wasmetal_core__DOT____Vcellout___128792___O 
        = ((3U & (- (IData)((1U & (1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)))))) 
           ^ (((((1U >> (IData)(vlSelf->__VdfgTmp_h647f0add__0)) 
                 & (IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__)) 
                << 2U) | ((IData)(vlSelf->wasmetal_core__DOT___128792___DOT__CO__BRA__0__KET__) 
                          << 1U)) | (IData)(vlSelf->wasmetal_core__DOT___035864_)));
    vlSelf->wasmetal_core__DOT___042756_ = (1U & (1U 
                                                  >> 
                                                  ((2U 
                                                    & ((~ (IData)(vlSelf->wasmetal_core__DOT___035721_)) 
                                                       << 1U)) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___048951_))));
    vlSelf->wasmetal_core__DOT___042760_ = (1U & (4U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___048951_) 
                                                    << 1U) 
                                                   | (1U 
                                                      & (~ (IData)(vlSelf->wasmetal_core__DOT___035721_))))));
    vlSelf->wasmetal_core__DOT___063412_ = (1U & (4U 
                                                  >> 
                                                  ((2U 
                                                    & ((1U 
                                                        >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                       << 1U)) 
                                                   | (1U 
                                                      & (IData)(
                                                                (0xff00bb00ff000f00ULL 
                                                                 >> 
                                                                 (((IData)(vlSelf->wasmetal_core__DOT__state__05b0__05d) 
                                                                   << 5U) 
                                                                  | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                                      << 4U) 
                                                                     | (((IData)(vlSelf->wasmetal_core__DOT___063394_) 
                                                                         << 3U) 
                                                                        | (((IData)(vlSelf->wasmetal_core__DOT___050467_) 
                                                                            << 2U) 
                                                                           | (((IData)(vlSelf->wasmetal_core__DOT___063007_) 
                                                                               << 1U) 
                                                                              | (1U 
                                                                                & (0xdf0f0000U 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 3U) 
                                                                                | ((4U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 2U)) 
                                                                                | ((2U 
                                                                                & ((IData)(
                                                                                (0xe000000000000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063400_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___050435_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___050449_)))))))) 
                                                                                << 1U)) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___009544_))))))))))))))))));
    vlSelf->wasmetal_core__DOT___063433_ = (1U & (0x5fcf0000U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___063431_) 
                                                    << 4U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT__state__05b1__05d) 
                                                       << 3U) 
                                                      | ((4U 
                                                          & ((1U 
                                                              >> (IData)(vlSelf->__VdfgTmp_hb5e2654e__0)) 
                                                             << 2U)) 
                                                         | ((2U 
                                                             & ((IData)(
                                                                        (0x4000ffffULL 
                                                                         >> 
                                                                         (((IData)(vlSelf->wasmetal_core__DOT___063418_) 
                                                                           << 5U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___063428_) 
                                                                              << 4U) 
                                                                             | (((IData)(vlSelf->wasmetal_core__DOT___050362_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063403_) 
                                                                                << 2U) 
                                                                                | ((2U 
                                                                                & ((4U 
                                                                                >> (IData)(vlSelf->__VdfgTmp_h2a482fa4__0)) 
                                                                                << 1U)) 
                                                                                | (1U 
                                                                                & (IData)(
                                                                                (0xbfffffff00000000ULL 
                                                                                >> 
                                                                                (((IData)(vlSelf->wasmetal_core__DOT___009544_) 
                                                                                << 5U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063401_) 
                                                                                << 4U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063426_) 
                                                                                << 3U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063372_) 
                                                                                << 2U) 
                                                                                | (((IData)(vlSelf->wasmetal_core__DOT___063399_) 
                                                                                << 1U) 
                                                                                | (IData)(vlSelf->wasmetal_core__DOT___053568_)))))))))))))))) 
                                                                << 1U)) 
                                                            | (IData)(vlSelf->wasmetal_core__DOT___063392_)))))));
    vlSelf->wasmetal_core__DOT___053008_ = (1U & (IData)(
                                                         (0x8f000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___052918_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___052917_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___052916_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___050380_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___052915_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___052914_)))))))));
    vlSelf->wasmetal_core__DOT___019800_ = (1U & (IData)(
                                                         (0x1000000000000000ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___053752_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___053514_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___053506_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___052658_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___053621_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___053501_)))))))));
    vlSelf->wasmetal_core__DOT___053622_ = (1U & (0x4000U 
                                                  >> 
                                                  ((8U 
                                                    & ((IData)(
                                                               (0xf35100000000ULL 
                                                                >> 
                                                                (((IData)(vlSelf->wasmetal_core__DOT___053618_) 
                                                                  << 5U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___053617_) 
                                                                     << 4U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___048483_) 
                                                                        << 3U) 
                                                                       | (((IData)(vlSelf->mem_ready) 
                                                                           << 2U) 
                                                                          | (((IData)(vlSelf->wasmetal_core__DOT___048481_) 
                                                                              << 1U) 
                                                                             | (IData)(vlSelf->wasmetal_core__DOT___053616_)))))))) 
                                                       << 3U)) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___053619_) 
                                                       << 2U) 
                                                      | (((IData)(vlSelf->wasmetal_core__DOT___052656_) 
                                                          << 1U) 
                                                         | (IData)(vlSelf->wasmetal_core__DOT___053501_))))));
    vlSelf->__VdfgTmp_hbd36bb7c__0 = (((IData)(wasmetal_core__DOT___009291_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009290_));
    vlSelf->__VdfgTmp_ha16fbbbf__0 = (((IData)(vlSelf->wasmetal_core__DOT___055618_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055617_));
    vlSelf->__VdfgTmp_hd2b13b0f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009292_));
    vlSelf->__VdfgTmp_h6e24fc79__0 = (((IData)(wasmetal_core__DOT___055565_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055564_));
    vlSelf->__VdfgTmp_hb785bdc8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055566_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055565_));
    vlSelf->__VdfgTmp_h8b31618a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055543_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055544_));
    vlSelf->__VdfgTmp_h1ccd197a__0 = (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009770_));
    vlSelf->__VdfgTmp_hf7b90195__0 = (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009769_));
    vlSelf->__VdfgTmp_hd1825153__0 = (((IData)(wasmetal_core__DOT___009769_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009768_));
    vlSelf->__VdfgTmp_h23e0654e__0 = (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009188_));
    vlSelf->__VdfgTmp_hbf11cfc1__0 = (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009187_));
    vlSelf->__VdfgTmp_hd63c68ee__0 = (((IData)(wasmetal_core__DOT___009186_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009185_));
    vlSelf->__VdfgTmp_he1badc2d__0 = (((IData)(vlSelf->wasmetal_core__DOT___055445_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055444_));
    vlSelf->__VdfgTmp_he6145195__0 = (((IData)(vlSelf->wasmetal_core__DOT___055448_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055445_));
    vlSelf->__VdfgTmp_h52b8127f__0 = (((IData)(vlSelf->wasmetal_core__DOT___009254_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009253_));
    vlSelf->__VdfgTmp_h416357e2__0 = (((IData)(vlSelf->wasmetal_core__DOT___009253_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009252_));
    vlSelf->__VdfgTmp_h53c22b41__0 = (((IData)(wasmetal_core__DOT___009252_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009251_));
    vlSelf->__VdfgTmp_ha9c0231a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055408_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055407_));
    vlSelf->__VdfgTmp_h10a22e24__0 = (((IData)(wasmetal_core__DOT___009239_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009238_));
    vlSelf->__VdfgTmp_ha4fdb8c7__0 = (((IData)(vlSelf->wasmetal_core__DOT___009240_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009239_));
    vlSelf->__VdfgTmp_h381f02c3__0 = (((IData)(vlSelf->wasmetal_core__DOT___009241_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009240_));
    vlSelf->__VdfgTmp_h0eab1d01__0 = (((IData)(vlSelf->wasmetal_core__DOT___055235_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055234_));
    vlSelf->__VdfgTmp_h0b92bce8__0 = (((IData)(vlSelf->wasmetal_core__DOT___055236_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055235_));
    vlSelf->__VdfgTmp_hef4c4e2a__0 = (((IData)(vlSelf->wasmetal_core__DOT___055229_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055228_));
    vlSelf->__VdfgTmp_haccd68b9__0 = (((IData)(vlSelf->wasmetal_core__DOT___055228_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055225_));
    vlSelf->__VdfgTmp_h0dc57e5a__0 = (((IData)(wasmetal_core__DOT___055225_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___055224_));
    vlSelf->__VdfgTmp_hd3eaf9cd__0 = (((IData)(vlSelf->wasmetal_core__DOT___009304_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009303_));
    vlSelf->__VdfgTmp_h567718cf__0 = (((IData)(wasmetal_core__DOT___055692_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055696_));
    vlSelf->__VdfgTmp_h74bdf3b8__0 = (((IData)(vlSelf->wasmetal_core__DOT___009303_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009302_));
    vlSelf->__VdfgTmp_h4ba92f5a__0 = (((IData)(wasmetal_core__DOT___009302_) 
                                       << 1U) | (IData)(wasmetal_core__DOT___009301_));
    vlSelf->__VdfgTmp_h2fcb0063__0 = (((IData)(vlSelf->wasmetal_core__DOT___055695_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___009304_));
    vlSelf->__VdfgTmp_h3832b0f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___055696_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___055695_));
    vlSelf->wasmetal_core__DOT___008809_ = (1U & (0x8080ff00U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007874_) 
                                                    << 4U) 
                                                   | ((8U 
                                                       & (vlSelf->insn_x 
                                                          << 2U)) 
                                                      | ((4U 
                                                          & ((IData)(
                                                                     (vlSymsp->TOP__wasmetal_core__DOT___135426_.__PVT__alu_sum 
                                                                      >> 4U)) 
                                                             << 2U)) 
                                                         | (IData)(vlSelf->__VdfgTmp_hb0e57990__0))))));
    vlSelf->__VdfgTmp_h315e9115__0 = (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                       << 1U) | (IData)(vlSelf->wasmetal_core__DOT___008962_));
    vlSelf->wasmetal_core__DOT___009762_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009771_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009769_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009770_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009768_)))))));
    vlSelf->wasmetal_core__DOT___009449_ = ((IData)(vlSelf->wasmetal_core__DOT___007844_) 
                                            & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                ? (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                           << 1U) 
                                                          | (IData)(vlSelf->wasmetal_core__DOT___009187_)))))
                                                : (0xf3f5U 
                                                   >> 
                                                   (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                     << 3U) 
                                                    | (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                        << 2U) 
                                                       | (((IData)(vlSelf->wasmetal_core__DOT___009188_) 
                                                           << 1U) 
                                                          | (IData)(wasmetal_core__DOT___009186_)))))));
    vlSelf->__VdfgTmp_h4ad8a46a__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___007847_)));
    vlSelf->wasmetal_core__DOT___055983_ = (1U & (0x80U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___009290_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___007846_)))));
    vlSelf->wasmetal_core__DOT___055962_ = (1U & ((IData)(vlSelf->wasmetal_core__DOT___007858_)
                                                   ? 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (0x35U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 2U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___009189_) 
                                                         << 1U) 
                                                        | (IData)(vlSelf->wasmetal_core__DOT___009185_))))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009187_))))
                                                   : 
                                                  ((IData)(vlSelf->wasmetal_core__DOT___007846_)
                                                    ? 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___009188_)))
                                                    : 
                                                   (7U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007847_) 
                                                      << 1U) 
                                                     | (IData)(wasmetal_core__DOT___009186_))))));
    vlSelf->wasmetal_core__DOT___009472_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(vlSelf->wasmetal_core__DOT___055617_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___009293_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___009292_) 
                                                                        << 1U) 
                                                                       | (IData)(wasmetal_core__DOT___009291_)))))))));
    vlSelf->wasmetal_core__DOT___055953_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009251_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->wasmetal_core__DOT___009412_ = (1U & (IData)(
                                                         (0xff33330f0f5555ULL 
                                                          >> 
                                                          (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                            << 5U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007846_) 
                                                               << 4U) 
                                                              | (((IData)(wasmetal_core__DOT___055571_) 
                                                                  << 3U) 
                                                                 | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                                     << 2U) 
                                                                    | (((IData)(vlSelf->wasmetal_core__DOT___055567_) 
                                                                        << 1U) 
                                                                       | (IData)(vlSelf->wasmetal_core__DOT___055566_)))))))));
    vlSelf->wasmetal_core__DOT___055822_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055570_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055567_)))));
    vlSelf->wasmetal_core__DOT___055768_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055444_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009254_)))));
    vlSelf->wasmetal_core__DOT___055738_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055407_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___009241_)))));
    vlSelf->wasmetal_core__DOT___055718_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___055234_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055229_)))));
    vlSelf->wasmetal_core__DOT___009745_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055571_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055570_)))));
    vlSelf->wasmetal_core__DOT___009471_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(wasmetal_core__DOT___055621_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055618_)))));
    vlSelf->wasmetal_core__DOT___009463_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055564_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_hb307080d__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055574_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055571_)));
    vlSelf->wasmetal_core__DOT___008877_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___055534_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_ha296f98c__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___051495_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___051500_)));
    vlSelf->__VdfgTmp_h62e050c1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___055406_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055408_)));
    vlSelf->wasmetal_core__DOT___055736_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009238_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->wasmetal_core__DOT___055719_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___055224_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_h7d874977__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008935_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055621_)));
    vlSelf->__VdfgTmp_ha295f108__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008904_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055574_)));
    vlSelf->wasmetal_core__DOT___009091_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008860_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055543_)))));
    vlSelf->__VdfgTmp_h6ca56fa1__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(wasmetal_core__DOT___009768_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055534_)));
    vlSelf->wasmetal_core__DOT___009069_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___008835_) 
                                                       << 1U) 
                                                      | (IData)(wasmetal_core__DOT___051495_)))));
    vlSelf->wasmetal_core__DOT___009035_ = (1U & (0x35U 
                                                  >> 
                                                  (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                                    << 2U) 
                                                   | (((IData)(vlSelf->wasmetal_core__DOT___009174_) 
                                                       << 1U) 
                                                      | (IData)(vlSelf->wasmetal_core__DOT___055448_)))));
    vlSelf->__VdfgTmp_hecc250a9__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009163_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055406_)));
    vlSelf->__VdfgTmp_h6b0a05f6__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___009146_) 
                                                  << 1U) 
                                                 | (IData)(vlSelf->wasmetal_core__DOT___055236_)));
    vlSelf->wasmetal_core__DOT___009477_ = (1U & (8U 
                                                  >> 
                                                  (((IData)(wasmetal_core__DOT___009301_) 
                                                    << 1U) 
                                                   | (IData)(vlSelf->wasmetal_core__DOT___007858_))));
    vlSelf->__VdfgTmp_he25b62bf__0 = (((IData)(vlSelf->wasmetal_core__DOT___007858_) 
                                       << 2U) | (((IData)(vlSelf->wasmetal_core__DOT___008962_) 
                                                  << 1U) 
                                                 | (IData)(wasmetal_core__DOT___055692_)));
    if (vlSelf->wasmetal_core__DOT___007874_) {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007870_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT__alu__02eb32__05b1__05d))))))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007886_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001874_))))))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007894_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001886_))))))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007907_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001437_))))))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007915_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001443_))))))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007923_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001475_))))))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007931_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001487_))))))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007946_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001369_))))))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007954_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001381_))))))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007962_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001413_))))))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007970_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001425_))))))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007983_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001524_))))))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007991_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001536_))))))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___007999_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001568_))))))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008007_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001580_))))))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008032_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001612_))))))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008040_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001624_))))))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008048_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___001646_))))))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? (IData)(vlSelf->wasmetal_core__DOT___007880_)
                                                    : 
                                                   (0x22f0f0f0U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007872_) 
                                                      << 4U) 
                                                     | (((IData)(vlSelf->wasmetal_core__DOT___007871_) 
                                                         << 3U) 
                                                        | (((IData)(vlSelf->wasmetal_core__DOT___008056_) 
                                                            << 2U) 
                                                           | (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                               << 1U) 
                                                              | (IData)(vlSelf->wasmetal_core__DOT___000419_))))))));
    } else {
        vlSelf->wasmetal_core__DOT___007864_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007873_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007247_)))));
        vlSelf->wasmetal_core__DOT___007863_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007887_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007274_)))));
        vlSelf->wasmetal_core__DOT___007862_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007895_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007301_)))));
        vlSelf->wasmetal_core__DOT___007905_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007908_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007334_)))));
        vlSelf->wasmetal_core__DOT___007904_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007916_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007360_)))));
        vlSelf->wasmetal_core__DOT___007903_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007924_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007386_)))));
        vlSelf->wasmetal_core__DOT___007902_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007932_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007413_)))));
        vlSelf->wasmetal_core__DOT___007942_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007947_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007431_)))));
        vlSelf->wasmetal_core__DOT___007941_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007955_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007246_)))));
        vlSelf->wasmetal_core__DOT___007940_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007963_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007273_)))));
        vlSelf->wasmetal_core__DOT___007939_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007971_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007300_)))));
        vlSelf->wasmetal_core__DOT___007981_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007984_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007333_)))));
        vlSelf->wasmetal_core__DOT___007980_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___007992_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007359_)))));
        vlSelf->wasmetal_core__DOT___007979_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008000_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007385_)))));
        vlSelf->wasmetal_core__DOT___007978_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008008_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007412_)))));
        vlSelf->wasmetal_core__DOT___008028_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008033_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007430_)))));
        vlSelf->wasmetal_core__DOT___008027_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008041_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007249_)))));
        vlSelf->wasmetal_core__DOT___008026_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008049_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007276_)))));
        vlSelf->wasmetal_core__DOT___008025_ = (1U 
                                                & ((IData)(vlSelf->wasmetal_core__DOT___008057_)
                                                    ? 
                                                   (1U 
                                                    >> (IData)(vlSelf->wasmetal_core__DOT___007869_))
                                                    : 
                                                   (2U 
                                                    >> 
                                                    (((IData)(vlSelf->wasmetal_core__DOT___007869_) 
                                                      << 1U) 
                                                     | (IData)(vlSelf->wasmetal_core__DOT___007303_)))));
    }
}
